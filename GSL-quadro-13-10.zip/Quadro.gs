/**
 * QUADRO DO CD — o BI de funcoes dentro do GSL.
 *
 * 13/10 — UMA ABA SO. O quadro vem da aba GERAL da planilha de apoio:
 *
 *   EQUIPE | COD | PROD | DESCRIÇÃO | RH | STATUS
 *   (turno) (produtivo) (nome) (funcao) (matricula) (na empresa?)
 *
 * e o GSL separa os turnos (1° TURNO, 2° TURNO, 3° TURNO e ADM). As abas
 * APOIO TA / TB / TC ficam de lado: so sao lidas se a planilha ainda nao
 * tiver a GERAL (outra filial no layout antigo). Admitidos (CADMITIDOS) e
 * desligados (CDESLIGADOS) continuam vindo das mesmas abas.
 *
 * INCONSISTENCIAS: desligado (CDESLIGADOS) que continua ATIVO na GERAL — o
 * pedido da gerencia, a unica "grave" (a faixa vermelha da tela) — e, como
 * "atencao", o que deixa o quadro errado: linha sem nome, EQUIPE fora do
 * padrao, produtivo ou matricula repetidos e admitido que nao entrou na
 * GERAL. Cada uma diz a linha da planilha.
 */
const BUILD_QUADRO = '2026.10.13b';   // carimbo da entrega — ver APP.build no Codigo.gs

const QUADRO_ABA_GERAL = 'GERAL';
const QUADRO_ABAS_APOIO = ['APOIO TA', 'APOIO TB', 'APOIO TC'];
const QUADRO_ABA_ADMITIDOS = 'CADMITIDOS';
const QUADRO_ABA_DESLIGADOS = 'CDESLIGADOS';
const QUADRO_EQUIPES = ['1° TURNO', '2° TURNO', '3° TURNO', 'ADM'];
// O formato do que vai para o cache: copia de outro formato (versao anterior do Quadro.gs) e relida.
const QUADRO_FORMATO = 3;

/*
 * A aba e achada pelo nome sem diferenciar maiuscula, acento, espaco ou
 * pontuacao, e por apelidos: a planilha de apoio de algumas filiais chama
 * "CDADMITIDOS" (e nao "CADMITIDOS") — e a aba inteira era ignorada, sem
 * admitido nenhum no Quadro. A GERAL so pelo nome (sem pedacos: "RESUMO
 * GERAL" nao e ela).
 */
const QUADRO_APELIDOS = {
  GERAL: { nomes: ['GERAL', 'QUADROGERAL', 'BASEGERAL', 'GERALCD'], pedacos: [] },
  CADMITIDOS: { nomes: ['CADMITIDOS', 'CDADMITIDOS', 'ADMITIDOS', 'ADMISSOES', 'CADMISSOES', 'CDADMISSOES'], pedacos: ['ADMITID', 'ADMISS'] },
  CDESLIGADOS: { nomes: ['CDESLIGADOS', 'CDDESLIGADOS', 'DESLIGADOS', 'DESLIGAMENTOS', 'CDESLIGAMENTOS', 'CDDESLIGAMENTOS'], pedacos: ['DESLIG', 'DEMITID', 'DEMISS'] }
};
function chaveAbaQ_(nome) { return normalizaQ_(nome).replace(/[^A-Z0-9]/g, ''); }
function abaQuadro_(ss, nomeAba) {
  const exata = ss.getSheetByName(nomeAba);
  if (exata) return exata;
  const abas = ss.getSheets();
  const alvo = chaveAbaQ_(nomeAba);
  const ap = QUADRO_APELIDOS[nomeAba] || { nomes: [], pedacos: [] };
  const nomes = [alvo].concat(ap.nomes);
  const porNome = abas.filter(function (a) { return nomes.indexOf(chaveAbaQ_(a.getName())) !== -1; })[0];
  if (porNome) return porNome;
  return abas.filter(function (a) {
    const k = chaveAbaQ_(a.getName());
    return ap.pedacos.some(function (x) { return k.indexOf(x) !== -1; });
  })[0] || null;
}
const QUADRO_CACHE_SEGUNDOS = 300;

function idPlanilhaQuadro_() {
  const bruto = String(parametro('QUADRO_PLANILHA', '') || '').trim();
  if (!bruto) return '';
  const m = bruto.match(/\/d\/([\w-]{20,})/);
  if (m) return m[1];
  return /^[\w-]{20,}$/.test(bruto) ? bruto : '';
}

function dadosQuadro(usuario) {
  const id = idPlanilhaQuadro_();
  const base = {
    configurado: !!id,
    podeConfigurar: podeFazer(usuario, 'PROGRAMAR'),
    filial: filialAtual().nome
  };
  if (!id) return base;

  const chave = chaveNoEspaco('quadro|' + id);
  const guardado = lerTextoCache(chave);
  if (guardado) {
    try {
      const g = JSON.parse(guardado);
      if (g && g.formato === QUADRO_FORMATO) return Object.assign(base, g);
    } catch (e) { /* le de novo */ }
  }
  try {
    const dados = lerPlanilhaQuadro_(id);
    gravarTextoCache(chave, JSON.stringify(dados), QUADRO_CACHE_SEGUNDOS);
    return Object.assign(base, dados);
  } catch (e) {
    base.erro = e && e.semAba ? e.message : 'Não consegui ler a planilha do Quadro: ' + (e.message || e) +
      '. Confira se o link está certo e se a conta dona do GSL tem acesso a ela.';
    return base;
  }
}

/* ------------------------------------------------------------------ */
/* COLUNAS                                                             */
/* ------------------------------------------------------------------ */

/*
 * O "NOME QUE SOME" (13/10). A coluna do nome era achada por pedaco do
 * cabecalho — COLABORADOR ou NOME — e o cabecalho era a primeira linha com
 * uma dessas palavras. Duas coisas davam errado, de vez em quando:
 *   - a coluna do nome chamada PROD (como na GERAL) nao era achada: o nome
 *     ficava vazio e a lista mostrava so o produtivo;
 *   - um titulo em cima do cabecalho ("QUADRO DE COLABORADORES") era tomado
 *     como o cabecalho: as colunas de verdade viravam uma linha de dados e o
 *     "nome" passava a ser o valor de outra coluna (ou nada).
 * Agora o cabecalho e a primeira das 15 primeiras linhas com pelo menos DUAS
 * colunas conhecidas, comparadas pelo nome INTEIRO; o pedaco so entra para
 * o que o nome inteiro nao achou, e nunca para uma coluna ja usada.
 */
const QUADRO_COLUNAS = {
  nome:   { exatos: ['PROD', 'COLABORADOR', 'NOME', 'NOME DO COLABORADOR', 'NOME COMPLETO', 'FUNCIONARIO'], pedacos: ['COLABORADOR', 'NOME', 'FUNCIONARIO'], evitar: ['COD', 'MATRIC', 'PRODUTIV'] },
  cod:    { exatos: ['COD', 'CODIGO', 'PRODUTIVA', 'PRODUTIVO', 'COD PRODUTIVO', 'CODIGO PRODUTIVO', 'N PRODUTIVO'], pedacos: ['PRODUTIV', 'COD'], evitar: ['DESCRI', 'RH', 'MATRIC'] },
  rh:     { exatos: ['RH', 'MATRICULA', 'MATRICULA RH', 'MAT RH', 'MAT', 'COD RH', 'CODIGO RH', 'N RH'], pedacos: ['MATRIC', 'RH'] },
  equipe: { exatos: ['EQUIPE', 'TURNO', 'EQUIPE TURNO'], pedacos: ['EQUIPE', 'TURNO'] },
  funcao: { exatos: ['DESCRICAO', 'FUNCAO', 'CARGO', 'DESCRICAO DA FUNCAO'], pedacos: ['FUNCAO', 'CARGO', 'DESCRICAO'] },
  status: { exatos: ['STATUS', 'SITUACAO'], pedacos: ['STATUS', 'SITUAC'] }
};
const QUADRO_COLUNAS_ADM = {
  data: { exatos: ['DATA ADMISSAO', 'DATA DE ADMISSAO', 'ADMISSAO', 'DATA'], pedacos: ['ADMISS', 'ADMIT', 'DATA', 'ENTRADA', 'INICIO', 'MES'], evitar: ['MOTIVO', 'TIPO', 'STATUS', 'SITUAC', 'NASC'] }
};
const QUADRO_COLUNAS_DES = {
  data:   { exatos: ['DATA DESLIGAMENTO', 'DATA DO DESLIGAMENTO', 'DATA DEMISSAO', 'DATA DE DEMISSAO', 'DESLIGAMENTO', 'DATA'], pedacos: ['DESLIG', 'DEMISS', 'SAIDA', 'DATA'], evitar: ['MOTIVO', 'TIPO', 'ADMISS', 'NASC'] },
  tipo:   { exatos: ['TIPO', 'TIPO DE DESLIGAMENTO', 'TIPO DESLIGAMENTO'], pedacos: ['TIPO'], evitar: ['MOTIVO'] },
  motivo: { exatos: ['MOTIVO', 'MOTIVO DO DESLIGAMENTO', 'MOTIVO DESLIGAMENTO'], pedacos: ['MOTIVO'] }
};

/* Cabecalho comparavel: sem acento, maiusculo, pontuacao vira espaco ("PROD." = "PROD"). */
function cabQ_(v) { return normalizaQ_(v).replace(/[^A-Z0-9]+/g, ' ').trim(); }

/*
 * Le a aba: o cabecalho (ver acima), as linhas de dados e o numero, na
 * planilha, da primeira delas (para a inconsistencia dizer "linha 37").
 */
function lerTabelaQ_(aba, campos) {
  const valores = aba.getDataRange().getValues();
  const conhecidos = {};
  Object.keys(campos).forEach(function (k) { campos[k].exatos.forEach(function (x) { conhecidos[x] = true; }); });
  let iCab = -1;
  for (let i = 0; i < Math.min(15, valores.length); i++) {
    const n = valores[i].filter(function (c) { return conhecidos[cabQ_(c)]; }).length;
    if (n >= 2) { iCab = i; break; }
  }
  if (iCab === -1) {
    // Layout desconhecido: o jeito antigo (a linha com COLABORADOR/NOME), senao a primeira.
    iCab = 0;
    for (let i = 0; i < Math.min(15, valores.length); i++) {
      if (valores[i].some(function (c) { const t = cabQ_(c); return t === 'COLABORADOR' || t === 'NOME' || t === 'PROD'; })) { iCab = i; break; }
    }
  }
  const cab = (valores[iCab] || []).map(cabQ_);
  return { cab: cab, linhas: valores.slice(iCab + 1), primeiraLinha: iCab + 2, col: colunasQ_(cab, campos) };
}

/* Coluna de cada campo: nome inteiro primeiro (na ordem da lista), pedaco depois; cada coluna serve a um campo so. */
function colunasQ_(cab, campos) {
  const usada = {}, col = {};
  Object.keys(campos).forEach(function (k) {
    const lista = campos[k].exatos;
    for (let e = 0; e < lista.length; e++) {
      const i = cab.indexOf(lista[e]);
      if (i !== -1 && !usada[i]) { col[k] = i; usada[i] = true; return; }
    }
  });
  // Depois, por pedaco — na ordem de prioridade dos pedacos (nao a da posicao da coluna).
  Object.keys(campos).forEach(function (k) {
    if (col[k] !== undefined || !campos[k].pedacos.length) return;
    const evitar = campos[k].evitar || [];
    const pedacos = campos[k].pedacos;
    for (let p = 0; p < pedacos.length; p++) {
      for (let i = 0; i < cab.length; i++) {
        const c = cab[i];
        if (!c || usada[i]) continue;
        if (c.indexOf(pedacos[p]) !== -1 && !evitar.some(function (x) { return c.indexOf(x) !== -1; })) { col[k] = i; usada[i] = true; return; }
      }
    }
  });
  return col;
}

function valorQ_(linha, col, campo) { return col[campo] === undefined ? '' : linha[col[campo]]; }

/*
 * Celulas mescladas (ex.: "1° TURNO" mesclado no bloco do turno): o Sheets
 * so devolve o valor na primeira linha da mesclagem. Aqui as linhas de baixo
 * recebem o valor de cima — so dentro das mesclagens de verdade, nunca por
 * palpite. Devolve quantas linhas foram completadas.
 */
function preencherMescladasQ_(aba, t) {
  let n = 0;
  try {
    const mescladas = aba.getDataRange().getMergedRanges();
    mescladas.forEach(function (m) {
      const topo = m.getRow() - t.primeiraLinha, c = m.getColumn() - 1;
      if (topo < 0 || !t.linhas[topo]) return;              // mesclagem no titulo ou no cabecalho
      const v = t.linhas[topo][c];
      if (v === '' || v === null || v === undefined) return;
      for (let i = topo + 1; i < topo + m.getNumRows(); i++) {
        if (t.linhas[i] && (t.linhas[i][c] === '' || t.linhas[i][c] === null)) { t.linhas[i][c] = v; n++; }
      }
    });
  } catch (e) { /* sem acesso as mesclagens: segue com os valores como vieram */ }
  return n;
}

/* ------------------------------------------------------------------ */
/* EQUIPE E STATUS                                                     */
/* ------------------------------------------------------------------ */

/*
 * "1° TURNO", "1º TURNO" (o ordinal), "1 TURNO", "TURNO 1", "TA" (as abas
 * antigas e as abas de admitidos/desligados), "A" -> 1° TURNO; o mesmo para
 * o 2° e o 3°; ADM / ADMINISTRATIVO -> ADM. Fora disso: '' (vira
 * inconsistencia "equipe fora do padrao", com o valor como esta escrito).
 */
function equipeQ_(v) {
  const t = normalizaQ_(v).replace(/[^A-Z0-9]+/g, ' ').trim();
  if (!t) return '';
  if (/^ADM/.test(t)) return 'ADM';
  let m = t.match(/^(\d)\s*O?\s*TURNO$/) || t.match(/^TURNO\s*(\d)$/) || t.match(/^T\s*(\d)$/) || t.match(/^(\d)$/);
  if (m) return ['', '1° TURNO', '2° TURNO', '3° TURNO'][Number(m[1])] || '';
  m = t.match(/^(?:TURNO\s*|T\s*)?([ABC])$/);
  if (m) return { A: '1° TURNO', B: '2° TURNO', C: '3° TURNO' }[m[1]];
  if (/^PRIMEIRO/.test(t)) return '1° TURNO';
  if (/^SEGUNDO/.test(t)) return '2° TURNO';
  if (/^TERCEIRO/.test(t)) return '3° TURNO';
  return '';
}

/*
 * STATUS -> se a pessoa ainda esta na empresa. FORA: inativo, desligado,
 * demitido, rescisao, "nao"... Na empresa: ATIVO, FERIAS e AFASTADO
 * (afastamento, licenca, atestado, INSS) — os dois ultimos contam no
 * efetivo, mas a tela mostra quantos estao fora do posto. Vazio: na empresa.
 */
function situacaoQ_(v) {
  const t = normalizaQ_(v).replace(/[^A-Z ]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!t) return 'ATIVO';
  if (/^(INATIV|DESATIV|DESLIG|DEMIT|DEMISS|RESCI|EX |SAIU|SAIDA|FORA|BAIXA|NAO|N$|FALSE|ENCERR|TERMIN|DISPENS|TRANSFERID)/.test(t)) return 'FORA';
  if (/FERIAS/.test(t)) return 'FERIAS';
  if (/(AFAST|LICEN|ATESTAD|INSS|AUXILIO|MATERNID|PATERNID|ACIDENT)/.test(t)) return 'AFASTADO';
  return 'ATIVO';
}

/* ------------------------------------------------------------------ */
/* LEITURA                                                             */
/* ------------------------------------------------------------------ */

function lerPlanilhaQuadro_(id) {
  exigirPorta_();
  const ss = SpreadsheetApp.openById(id);
  const leitura = { aba: '', linhas: 0, colunas: {}, faltam: [], status: {}, equipes: {}, gid: null, linhaCabecalho: 0 };
  const geral = [];

  const abaGeral = abaQuadro_(ss, QUADRO_ABA_GERAL);
  if (abaGeral) {
    const t = lerTabelaQ_(abaGeral, QUADRO_COLUNAS);
    leitura.mescladas = preencherMescladasQ_(abaGeral, t);
    leitura.aba = abaGeral.getName();
    leitura.linhaCabecalho = t.primeiraLinha - 1;
    try { leitura.gid = abaGeral.getSheetId(); } catch (e) { leitura.gid = null; }   // "abrir na planilha" vai direto a linha
    Object.keys(t.col).forEach(function (k) { leitura.colunas[k] = t.cab[t.col[k]]; });
    leitura.faltam = ['equipe', 'cod', 'nome', 'funcao', 'rh', 'status'].filter(function (k) { return t.col[k] === undefined; });
    t.linhas.forEach(function (linha, i) {
      const r = linhaGeralQ_(linha, t.col, t.primeiraLinha + i, '');
      if (r) geral.push(r);
    });
    leitura.layout = 'GERAL';
  } else {
    // Planilha ainda no layout antigo: as tres abas APOIO, com o turno vindo do nome da aba.
    QUADRO_ABAS_APOIO.forEach(function (nomeAba) {
      const aba = abaQuadro_(ss, nomeAba);
      if (!aba) return;
      const t = lerTabelaQ_(aba, QUADRO_COLUNAS);
      preencherMescladasQ_(aba, t);
      const turnoDaAba = nomeAba.replace(/APOIO\s*/i, '').trim();
      t.linhas.forEach(function (linha, i) {
        const r = linhaGeralQ_(linha, t.col, t.primeiraLinha + i, turnoDaAba);
        if (r) { r.aba = aba.getName(); geral.push(r); }
      });
      if (!leitura.aba) Object.keys(t.col).forEach(function (k) { leitura.colunas[k] = t.cab[t.col[k]]; });
      leitura.aba = leitura.aba ? leitura.aba + ', ' + aba.getName() : aba.getName();
    });
    leitura.layout = leitura.aba ? 'APOIO' : '';
    if (!leitura.layout) {
      const e = new Error('Não achei a aba GERAL na planilha «' + ss.getName() + '». Confira o nome da aba (GERAL) — as abas APOIO TA, TB e TC não são mais usadas.');
      e.semAba = true;
      throw e;
    }
  }
  leitura.linhas = geral.length;
  // Chave de cada pessoa na tela: no layout APOIO o numero da linha se repete entre as abas.
  geral.forEach(function (r, i) { r.ref = i + 1; });
  // Como cada valor escrito foi entendido (a aba Conferencia mostra): STATUS -> situacao; EQUIPE -> turno.
  geral.forEach(function (r) {
    const k = r.status || '(vazio)';
    leitura.status[k] = leitura.status[k] || { n: 0, situacao: r.situacao };
    leitura.status[k].n++;
    const e = r.equipeBruta || '(vazio)';
    leitura.equipes[e] = leitura.equipes[e] || { n: 0, equipe: r.equipe };
    leitura.equipes[e].n++;
  });

  const adm = [];
  const abaAdm = abaQuadro_(ss, QUADRO_ABA_ADMITIDOS);
  if (abaAdm) {
    const t = lerTabelaQ_(abaAdm, Object.assign({}, QUADRO_COLUNAS, QUADRO_COLUNAS_ADM));
    t.linhas.forEach(function (linha) {
      const r = {
        cod: txtQ_(valorQ_(linha, t.col, 'cod')),
        rh: txtQ_(valorQ_(linha, t.col, 'rh')),
        nome: txtQ_(valorQ_(linha, t.col, 'nome')),
        equipeBruta: txtQ_(valorQ_(linha, t.col, 'equipe')).toUpperCase(),
        funcao: txtQ_(valorQ_(linha, t.col, 'funcao')).toUpperCase(),
        status: txtQ_(valorQ_(linha, t.col, 'status')).toUpperCase(),
        data: dataQ_(valorQ_(linha, t.col, 'data'))
      };
      if (!r.nome && !r.cod) return;
      r.equipe = equipeQ_(r.equipeBruta);
      r.mes = r.data ? r.data.slice(0, 7) : '';
      adm.push(r);
    });
    leitura.adm = { aba: abaAdm.getName(), linhas: adm.length, semData: adm.filter(function (a) { return !a.data; }).length };
  } else {
    leitura.adm = null;
  }

  const des = [], desSemData = [];
  let temColunaMotivo = false;
  const abaDes = abaQuadro_(ss, QUADRO_ABA_DESLIGADOS);
  if (abaDes) {
    const t = lerTabelaQ_(abaDes, Object.assign({}, QUADRO_COLUNAS, QUADRO_COLUNAS_DES));
    temColunaMotivo = t.col.motivo !== undefined;
    t.linhas.forEach(function (linha) {
      const r = {
        cod: txtQ_(valorQ_(linha, t.col, 'cod')),
        rh: txtQ_(valorQ_(linha, t.col, 'rh')),
        nome: txtQ_(valorQ_(linha, t.col, 'nome')),
        equipeBruta: txtQ_(valorQ_(linha, t.col, 'equipe')).toUpperCase(),
        funcao: txtQ_(valorQ_(linha, t.col, 'funcao')).toUpperCase(),
        data: dataQ_(valorQ_(linha, t.col, 'data')),
        dataSoMes: soMesQ_(valorQ_(linha, t.col, 'data')),
        tipo: txtQ_(valorQ_(linha, t.col, 'tipo')) || 'Não informado',
        motivo: txtQ_(valorQ_(linha, t.col, 'motivo'))
      };
      if (!r.nome && !r.cod && !r.rh) return;
      r.equipe = equipeQ_(r.equipeBruta);
      // Sem data: fica fora dos graficos e do periodo, mas entra na conferencia (desligado que continua ATIVO).
      if (!r.data) { r.mes = ''; desSemData.push(r); return; }
      r.mes = r.data.slice(0, 7);
      des.push(r);
    });
    leitura.des = { aba: abaDes.getName(), linhas: des.length + desSemData.length, semData: desSemData.length, semMotivo: !temColunaMotivo };
  } else {
    leitura.des = null;
  }

  return {
    formato: QUADRO_FORMATO,
    geral: geral, adm: adm, des: des, desSemData: desSemData,
    // Transicao (13/10): so a tela anterior do Quadro le "apoio" (aberta durante a implantacao). Sai na proxima entrega.
    apoio: geral.filter(function (g) { return g.ativo; }).map(function (g) {
      return { cod: g.cod, nome: g.nome, equipe: { '1° TURNO': 'TA', '2° TURNO': 'TB', '3° TURNO': 'TC' }[g.equipe] || g.equipe || g.equipeBruta, funcao: g.funcao };
    }),
    inconsistencias: inconsistenciasQ_(geral, adm, des.concat(desSemData)),
    leitura: leitura,
    atualizado: new Date().toISOString(),
    fonte: { nome: ss.getName(), url: ss.getUrl() },
    temColunaMotivo: temColunaMotivo
  };
}

/* Uma linha da GERAL (ou de uma aba APOIO). Linha sem nome, produtivo nem matricula nao e gente. */
function linhaGeralQ_(linha, col, numeroLinha, turnoDaAba) {
  const r = {
    cod: txtQ_(valorQ_(linha, col, 'cod')),
    nome: txtQ_(valorQ_(linha, col, 'nome')),
    rh: txtQ_(valorQ_(linha, col, 'rh')),
    equipeBruta: txtQ_(valorQ_(linha, col, 'equipe')).toUpperCase() || turnoDaAba,
    funcao: txtQ_(valorQ_(linha, col, 'funcao')).toUpperCase(),
    status: txtQ_(valorQ_(linha, col, 'status')).toUpperCase(),
    linha: numeroLinha
  };
  if (!r.nome && !r.cod && !r.rh) return null;
  r.equipe = equipeQ_(r.equipeBruta);
  r.situacao = situacaoQ_(r.status);
  r.ativo = r.situacao !== 'FORA';
  return r;
}

/* ------------------------------------------------------------------ */
/* INCONSISTENCIAS                                                     */
/* ------------------------------------------------------------------ */

/* Produtivo e matricula comparados sem zeros a esquerda ("030001" = 30001); nome sem acento e espaco duplo. */
function codigoQ_(v) {
  const c = txtQ_(v).replace(/\s+/g, '').replace(/\.0+$/, '').replace(/^0+(?=\d)/, '').toUpperCase();
  return /[1-9]/.test(c) ? c : '';          // "-", "0", "#N/A", "SEM" nao identificam ninguem
}
/* A linha r tem um COD ou um RH diferente do da linha g (os dois preenchidos): pode ser outra pessoa. */
function numeroConflitaQ_(r, g) {
  return !!((codigoQ_(r.cod) && codigoQ_(g.cod) && codigoQ_(r.cod) !== codigoQ_(g.cod)) ||
    (codigoQ_(r.rh) && codigoQ_(g.rh) && codigoQ_(r.rh) !== codigoQ_(g.rh)));
}
function nomeChaveQ_(v) { return normalizaQ_(v).replace(/[^A-Z ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
function dataCurtaQ_(iso) { const p = String(iso || '').split('-'); return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : String(iso || ''); }

function indiceQ_(lista) {
  const ix = { cod: {}, rh: {}, nome: {} };
  lista.forEach(function (r) {
    const c = codigoQ_(r.cod), m = codigoQ_(r.rh), n = nomeChaveQ_(r.nome);
    if (c) (ix.cod[c] = ix.cod[c] || []).push(r);
    if (m) (ix.rh[m] = ix.rh[m] || []).push(r);
    if (n) (ix.nome[n] = ix.nome[n] || []).push(r);
  });
  return ix;
}
/* Acha a pessoa: pelo produtivo, senao pela matricula, senao pelo nome. Devolve { lista, chave }. */
function acharQ_(ix, r) {
  const c = codigoQ_(r.cod), m = codigoQ_(r.rh), n = nomeChaveQ_(r.nome);
  if (c && ix.cod[c]) return { lista: ix.cod[c], chave: 'produtivo' };
  if (m && ix.rh[m]) return { lista: ix.rh[m], chave: 'matrícula' };
  if (n && ix.nome[n]) {
    const lista = ix.nome[n].filter(function (g) { return !(c && codigoQ_(g.cod)) && !(m && codigoQ_(g.rh)); });
    if (lista.length) return { lista: lista, chave: 'nome' };
  }
  return null;
}

function inconsistenciasQ_(geral, adm, des) {
  const saida = [];
  const ix = indiceQ_(geral), ixAdm = indiceQ_(adm), ixDes = indiceQ_(des);
  const quem = function (g) { return { cod: g.cod, rh: g.rh, nome: g.nome, equipe: g.equipe || g.equipeBruta, linha: g.linha, ref: g.ref, aba: g.aba || '' }; };
  const ondeQ = function (g) { return (g.aba ? g.aba + ' ' : '') + g.linha; };

  /*
   * 1. Desligado que continua ATIVO na GERAL (o pedido): um aviso por linha da
   * GERAL, decidido pelo desligamento mais recente. Desligamento com data
   * futura (aviso previo) ainda nao conta. Quem foi admitido de novo DEPOIS da
   * saida (CADMITIDOS com data) foi recontratado: o quadro esta certo e nao ha
   * aviso — a saida antiga fica na CDESLIGADOS, porque conta no turnover.
   */
  const jaVisto = {}, recontratado = {}, hoje = hojeISO();
  const desAte = des.filter(function (d) { return !(d.data && d.data > hoje); })
    .sort(function (a, b) { return String(b.data).localeCompare(String(a.data)); });     // a mais recente primeiro; sem data no fim
  // Admissoes achadas por NUMERO (COD ou RH): so elas podem provar uma recontratacao (pelo nome pode ser homonimo).
  const admPorNumero = function (r) {
    return [acharQ_(ixAdm, r)].filter(function (x) { return x && x.chave !== 'nome'; })
      .reduce(function (l, x) { return l.concat(x.lista); }, []);
  };
  // ...e com o mesmo nome (ou sem nome): o numero pode ter sido reaproveitado ou digitado errado na CADMITIDOS.
  const nomeOk = function (a, nomes) { const n = nomeChaveQ_(a.nome); return !n || nomes.indexOf(n) !== -1; };
  // Admitido depois da saida, e nao no futuro; saida anotada so com o mes ("out/2026" = dia 1): admissao em mes posterior.
  const depoisDe = function (a, d) {
    return !!a.data && a.data <= hoje && (d.dataSoMes ? a.data.slice(0, 7) > d.data.slice(0, 7) : a.data > d.data);
  };
  // Saida so com o mes e readmissao (ja feita) no mesmo mes: so o dia da saida decide.
  const noMesmoMes = function (a, d) { return !!(d.dataSoMes && a.data && a.data <= hoje && a.data.slice(0, 7) === d.data.slice(0, 7)); };
  // O numero pelo qual a admissao foi achada (COD ou RH), para a dica apontar o certo.
  const numeroDe = function (a, rs) {
    const c = codigoQ_(a.cod);
    return c && rs.some(function (r) { return codigoQ_(r.cod) === c; }) ? 'COD ' + a.cod : 'RH ' + a.rh;
  };
  /*
   * O que falta para a CADMITIDOS provar (ou descartar) uma recontratacao.
   * porNumero: admissoes achadas pelo COD/RH de rs; nomes: os nomes aceitos;
   * soNome: ha uma admissao achada so pelo nome (linha sem COD e sem RH).
   */
  const dica = function (d, porNumero, nomes, rs, soNome) {
    // so interessa admissao que poderia ser a volta: sem data, ou depois da saida (ou no mesmo mes, se a saida so tem o mes)
    const volta = function (a) { return !a.data || !d.data || a.data > d.data || noMesmoMes(a, d); };
    const outro = porNumero.filter(function (a) { return !nomeOk(a, nomes) && volta(a); })[0];
    if (outro) {
      return ' A CADMITIDOS tem o ' + numeroDe(outro, rs) + ' com outro nome (' + (outro.nome || 'sem nome') + (outro.data ? ', ' + dataCurtaQ_(outro.data) : '') +
        '): se for a mesma pessoa, escreva o nome como na ' + (rs[rs.length - 1].aba || 'GERAL') + '; se não for, confira o número.';
    }
    const certos = porNumero.filter(function (a) { return nomeOk(a, nomes); });
    const futura = certos.filter(function (a) { return a.data && a.data > hoje; })[0];
    if (futura) return ' A CADMITIDOS tem uma admissão com data no futuro (' + dataCurtaQ_(futura.data) + '): confira a data.';
    const mesmoMes = certos.filter(function (a) { return noMesmoMes(a, d); })[0];
    if (mesmoMes) return ' A saída está só com o mês e a readmissão (' + dataCurtaQ_(mesmoMes.data) + ') é do mesmo mês: ponha o dia da saída para conferir.';
    const datada = certos.filter(function (a) { return a.data; }).sort(function (a, b) { return b.data.localeCompare(a.data); })[0];
    if (!d.data && datada) return ' Há uma admissão na CADMITIDOS (' + dataCurtaQ_(datada.data) + '): ponha a data desta saída para conferir se ela veio antes (recontratação).';
    if (certos.some(function (a) { return !a.data; })) return ' Está na CADMITIDOS pelo COD/RH, sem data: se foi recontratação, ponha a data da nova admissão.';
    if (soNome) return ' Há na CADMITIDOS uma admissão com o mesmo nome, mas sem o COD/RH desta pessoa: se for recontratação, ponha o COD ou o RH (e a data) nessa linha da CADMITIDOS.';
    return '';
  };
  const soNomeAdm = function (r) { return (acharQ_(ixAdm, r) || {}).chave === 'nome'; };
  desAte.forEach(function (d) {
    const achou = acharQ_(ix, d);
    if (!achou) return;
    achou.lista.filter(function (g) { return g.ativo; }).forEach(function (g) {
      if (jaVisto[g.ref]) return;
      // Ja calado por recontratacao: as saidas datadas de antes da readmissao nao contam. Ainda contam a saida SEM data
      // e a saida so com o mes do mes da readmissao em diante (na ordem, "set/2026" vem como dia 1).
      const rec = recontratado[g.ref];
      if (rec && d.data && !(d.dataSoMes && d.data.slice(0, 7) >= rec.slice(0, 7))) return;
      const nomes = [nomeChaveQ_(d.nome), nomeChaveQ_(g.nome)], nomeG = [nomeChaveQ_(g.nome)];
      const porNumero = admPorNumero(d).concat(admPorNumero(g));
      const volta = function (aceitos) {
        return d.data ? porNumero.filter(function (a) { return nomeOk(a, aceitos) && depoisDe(a, d); }).map(function (a) { return a.data; }).sort()[0] : '';
      };
      if (volta(nomes)) {
        // Esta saida foi seguida de uma readmissao: sem aviso por ela. So a saida DESTA pessoa (pelo numero, sem outro
        // nome nem outro numero) com a readmissao DELA cala as saidas mais antigas; a de um homonimo ou de outra linha
        // com o mesmo numero, nao.
        const dela = achou.chave !== 'nome' && nomeOk(d, nomeG) && !numeroConflitaQ_(d, g) ? volta(nomeG) : '';
        if (dela && !rec) recontratado[g.ref] = dela;
        return;
      }
      jaVisto[g.ref] = true;
      const extra = !rec ? dica(d, porNumero, nomes, [d, g], soNomeAdm(d) || soNomeAdm(g))
        : (d.data ? ' Há também uma readmissão em ' + dataCurtaQ_(rec) + ' e esta saída está só com o mês: ponha o dia da saída para conferir.'
          : ' Há também uma saída antiga e uma readmissão (' + dataCurtaQ_(rec) + '): ponha a data desta saída para conferir.');
      saida.push(Object.assign(quem(g), {
        tipo: 'DESLIGADO_ATIVO', gravidade: 'grave', data: d.data || '', chave: achou.chave,
        detalhe: (d.data ? 'Desligado em ' + dataCurtaQ_(d.data) : 'Está na CDESLIGADOS (sem data)') + (d.motivo ? ' (' + d.motivo + ')' : '') +
          ', mas está ' + (g.status || 'sem status') + ' na ' + (g.aba || 'GERAL') + '.' +
          (achou.chave !== 'produtivo' ? ' Achado pelo ' + achou.chave + ' — confira se é a mesma pessoa.' : '') + extra
      }));
    });
  });
  /*
   * 1b. MESMO_NOME: alguem ativo tem o mesmo nome de um desligado, mas outro
   * COD ou RH — homonimo, numero digitado errado ou recontratacao com numero
   * novo. Atencao, para conferir; nunca manda inativar ninguem. Quem foi
   * admitido (pelo numero da GERAL, com o mesmo nome) depois DESTA saida e
   * recontratacao com numero novo: sem aviso.
   */
  const jaVistoNome = {};
  desAte.forEach(function (d) {
    if (acharQ_(ix, d)) return;
    const n = nomeChaveQ_(d.nome);
    ((n && ix.nome[n]) || []).filter(function (g) { return g.ativo && !jaVisto[g.ref] && !jaVistoNome[g.ref]; }).forEach(function (g) {
      const porNumero = admPorNumero(g), nomes = [nomeChaveQ_(g.nome)];
      if (d.data && porNumero.some(function (a) { return nomeOk(a, nomes) && depoisDe(a, d); })) return;
      jaVistoNome[g.ref] = true;
      const dif = [];
      if (codigoQ_(d.cod) && codigoQ_(g.cod) && codigoQ_(d.cod) !== codigoQ_(g.cod)) dif.push('o COD é ' + d.cod + ' na CDESLIGADOS e ' + g.cod + ' na ' + (g.aba || 'GERAL'));
      if (codigoQ_(d.rh) && codigoQ_(g.rh) && codigoQ_(d.rh) !== codigoQ_(g.rh)) dif.push('a matrícula é ' + d.rh + ' na CDESLIGADOS e ' + g.rh + ' na ' + (g.aba || 'GERAL'));
      saida.push(Object.assign(quem(g), {
        tipo: 'MESMO_NOME', gravidade: 'atencao', data: d.data || '', chave: 'nome',
        detalhe: 'Tem o mesmo nome de quem está na CDESLIGADOS' + (d.data ? ' (desligado em ' + dataCurtaQ_(d.data) + ')' : '') + ', mas ' +
          (dif.join(' e ') || 'os números não batem') + '. Confira se é a mesma pessoa (número digitado errado) ou um homônimo.' +
          dica(d, porNumero, nomes, [g], soNomeAdm(g))
      }));
    });
  });

  // 2. Linha sem nome (a coluna PROD vazia).
  geral.filter(function (g) { return !g.nome; }).forEach(function (g) {
    saida.push(Object.assign(quem(g), { tipo: 'SEM_NOME', gravidade: 'atencao', nome: '',
      detalhe: 'Sem o nome (coluna PROD)' + (g.cod ? ' — produtivo ' + g.cod : '') + (g.rh ? ', matrícula ' + g.rh : '') + '.' }));
  });

  // 3. Equipe fora do padrao (so de quem esta na empresa: e quem precisa de um turno).
  geral.filter(function (g) { return g.ativo && !g.equipe; }).forEach(function (g) {
    saida.push(Object.assign(quem(g), { tipo: 'EQUIPE', gravidade: 'atencao',
      detalhe: g.equipeBruta ? 'EQUIPE "' + g.equipeBruta + '" não é 1° TURNO, 2° TURNO, 3° TURNO nem ADM.' : 'Sem EQUIPE.' }));
  });

  // 4 e 5. Produtivo e matricula repetidos entre os que estao na empresa.
  [['cod', 'COD_REPETIDO', 'O produtivo'], ['rh', 'RH_REPETIDO', 'A matrícula']].forEach(function (x) {
    const grupos = {};
    geral.filter(function (g) { return g.ativo; }).forEach(function (g) {
      const k = codigoQ_(g[x[0]]);
      if (k) (grupos[k] = grupos[k] || []).push(g);
    });
    Object.keys(grupos).filter(function (k) { return grupos[k].length > 1; }).forEach(function (k) {
      const gs = grupos[k];
      saida.push(Object.assign(quem(gs[0]), { tipo: x[1], gravidade: 'atencao',
        nome: gs.map(function (g) { return g.nome || '(sem nome)'; }).join(' · '),
        linhas: gs.map(ondeQ), refs: gs.map(function (g) { return g.ref; }),
        detalhe: x[2] + ' ' + gs[0][x[0]] + ' está em ' + gs.length + ' linhas ativas (' + gs.map(ondeQ).join(', ') + ').' }));
    });
  });

  // 6. Admitido que nao entrou na GERAL (nem saiu depois).
  adm.forEach(function (a) {
    if (situacaoQ_(a.status) === 'FORA' || acharQ_(ix, a) || acharQ_(ixDes, a)) return;
    saida.push({ tipo: 'ADMITIDO_FORA', gravidade: 'atencao', cod: a.cod, rh: a.rh, nome: a.nome,
      equipe: a.equipe || a.equipeBruta, linha: 0, data: a.data,
      detalhe: 'Está na aba de admitidos' + (a.data ? ' (' + dataCurtaQ_(a.data) + ')' : '') + ', mas não na GERAL.' });
  });
  return saida;
}

/* ------------------------------------------------------------------ */
/* UTEIS                                                               */
/* ------------------------------------------------------------------ */

function normalizaQ_(v) {
  return String(v == null ? '' : v).trim().toUpperCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '');
}

function txtQ_(v) {
  // Numero da planilha (produtivo, matricula) sem o ".0" que o Sheets as vezes devolve.
  if (typeof v === 'number' && isFinite(v) && Math.floor(v) === v) return String(v);
  return String(v == null ? '' : v).trim();
}

/* Mes escrito por extenso ou abreviado, sem o dia ("ago/2025", "Agosto de 2025", "AGO-25"). */
const MES_TEXTO_Q = /^([A-Z]{3})[A-Z]*\s*(?:DE\s*)?[\/\-\s]?\s*(\d{2,4})$/;
/* "aaaa-mm-dd", "aaaa/mm/dd" ou so "aaaa-mm" (sem o dia: vira o dia 1). */
const DATA_ISO_Q = /^(\d{4})[\/\-](\d{1,2})(?:[\/\-](\d{1,2}))?/;
/* A data veio so com o mes (vira o dia 1 em dataQ_): "ago/2025" ou "2025-08". */
function soMesQ_(v) {
  if (v && typeof v.getTime === 'function') return false;
  const s = txtQ_(v);
  const iso = s.match(DATA_ISO_Q);
  if (iso) return !iso[3];
  const mx = normalizaQ_(s).match(MES_TEXTO_Q);
  return !!(mx && MESES_Q.indexOf(mx[1]) !== -1);
}

/** Data (ou texto dd/mm/aaaa) -> "aaaa-mm". */
function aoMesQ_(v) {
  const d = dataQ_(v);
  return d ? d.slice(0, 7) : '';
}

const MESES_Q = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];
function dataQ_(v) {
  if (v && typeof v.getTime === 'function' && !isNaN(v.getTime())) return Utilities.formatDate(v, fuso(), 'yyyy-MM-dd');
  // Numero de serie do Sheets/Excel (dias desde 30/12/1899).
  if (typeof v === 'number' && v > 20000 && v < 80000) {
    return Utilities.formatDate(new Date(Math.round((v - 25569) * 86400000)), 'UTC', 'yyyy-MM-dd');
  }
  const s = txtQ_(v);
  // "ago/2025", "Agosto de 2025", "AGO-25"
  const mx = normalizaQ_(s).match(MES_TEXTO_Q);
  if (mx && MESES_Q.indexOf(mx[1]) !== -1) {
    const ano = mx[2].length === 2 ? '20' + mx[2] : mx[2];
    return ano + '-' + ('0' + (MESES_Q.indexOf(mx[1]) + 1)).slice(-2) + '-01';
  }
  // Mes fora de 1-12 ou dia fora de 1-31 (ex.: 09/15/2026, colado no formato americano) = sem data.
  const ok = function (ano, mes, dia) {
    return (mes >= 1 && mes <= 12 && dia >= 1 && dia <= 31) ? ano + '-' + ('0' + mes).slice(-2) + '-' + ('0' + dia).slice(-2) : '';
  };
  const iso = s.match(DATA_ISO_Q);
  if (iso) return ok(iso[1], Number(iso[2]), Number(iso[3] || 1));
  const br = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (br) return ok(br[3].length === 2 ? '20' + br[3] : br[3], Number(br[2]), Number(br[1]));
  return '';
}

/* --- Acoes da tela --- */

function acaoSalvarFonteQuadro(usuario, params) {
  const link = String(params.link || '').trim();
  if (!link) throw new Error('Cole o link da planilha do Quadro.');
  const m = link.match(/\/d\/([\w-]{20,})/);
  const id = m ? m[1] : (/^[\w-]{20,}$/.test(link) ? link : '');
  if (!id) throw new Error('Esse link não parece de uma planilha do Google.');
  let nome = '';
  try {
    exigirPorta_();
    const ss = SpreadsheetApp.openById(id);
    nome = ss.getName();
    const temQuadro = abaQuadro_(ss, QUADRO_ABA_GERAL) || QUADRO_ABAS_APOIO.some(function (a) { return abaQuadro_(ss, a); });
    if (!temQuadro && !abaQuadro_(ss, QUADRO_ABA_ADMITIDOS) && !abaQuadro_(ss, QUADRO_ABA_DESLIGADOS)) {
      throw new Error('A planilha não tem nenhuma das abas esperadas (GERAL, CADMITIDOS, CDESLIGADOS).');
    }
  } catch (e) {
    throw new Error(String(e.message || e).indexOf('abas') !== -1 ? e.message
      : 'Não consegui abrir a planilha. A conta dona do GSL precisa ter acesso a ela.');
  }
  acaoSalvarParametro(usuario, { chave: 'QUADRO_PLANILHA', valor: 'https://docs.google.com/spreadsheets/d/' + id + '/edit',
    descricao: 'Link da planilha do Quadro do CD' });
  return { ok: true, invalidarTudo: true, recado: 'Quadro ligado à planilha "' + nome + '".' };
}

function acaoAtualizarQuadro(usuario) {
  const id = idPlanilhaQuadro_();
  if (id) { try { CacheService.getScriptCache().remove(chaveNoEspaco('quadro|' + id)); } catch (e) {} }
  // A chave e fatiada (gravarTextoCache): sem o numero de fatias, a leitura
  // volta vazia e a planilha e relida.
  limparCache('PARAMETROS');
  return { ok: true, recado: 'Quadro relido da planilha.' };
}
