/**
 * BI de Funções — CD Bartofil Feira de Santana
 * Lê as abas APOIO TA / APOIO TB / APOIO TC (+ CADMITIDOS e CDESLIGADOS)
 * e serve um dashboard web.
 *
 * COMO USAR
 * 1. Abra a planilha > Extensões > Apps Script.
 * 2. Cole este arquivo em Codigo.gs e o Index.html em um arquivo HTML chamado Index.
 * 3. Ajuste as constantes abaixo se os nomes das abas forem diferentes.
 * 4. Implantar > Nova implantação > Aplicativo da Web > Executar como: eu >
 *    Quem tem acesso: Qualquer pessoa da Bartofil.
 */

var ABAS_APOIO      = ['APOIO TA', 'APOIO TB', 'APOIO TC'];
var ABA_ADMITIDOS   = 'CADMITIDOS';
var ABA_DESLIGADOS  = 'CDESLIGADOS';
var LINHA_CABECALHO = 1;          // linha onde estão os títulos das colunas
var CACHE_SEGUNDOS  = 300;        // 5 min de cache; 0 desliga

/* ------------------------------------------------------------------ */

function doGet() {
  var t = HtmlService.createTemplateFromFile('Index');
  t.dadosJson = JSON.stringify(montarDados());          // já vai embutido: 1 ida só ao servidor
  return t.evaluate()
    .setTitle('Quadro de Funções — Bartofil')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** Usado pelo botão "Atualizar" do dashboard. */
function recarregar() {
  CacheService.getScriptCache().remove('bi_funcoes');
  return montarDados();
}

function montarDados() {
  var cache = CACHE_SEGUNDOS > 0 ? CacheService.getScriptCache() : null;
  if (cache) {
    var guardado = cache.get('bi_funcoes');
    if (guardado) return JSON.parse(guardado);
  }

  var ss = SpreadsheetApp.getActive();
  var apoio = [];
  ABAS_APOIO.forEach(function (nomeAba) {
    var turnoPadrao = nomeAba.replace(/APOIO\s*/i, '').trim().toUpperCase();
    lerAba(ss, nomeAba).forEach(function (linha) {
      var reg = {
        cod:    txt(pega(linha, ['COD', 'CÓD', 'PRODUTIVO'])),
        nome:   txt(pega(linha, ['COLABORADOR', 'NOME'])),
        equipe: txt(pega(linha, ['EQUIPE', 'TURNO'])).toUpperCase() || turnoPadrao,
        funcao: txt(pega(linha, ['FUNCAO', 'FUNÇÃO', 'CARGO'])).toUpperCase()
      };
      if (reg.nome || reg.cod) apoio.push(reg);
    });
  });

  var adm = lerAba(ss, ABA_ADMITIDOS).map(function (linha) {
    return {
      cod:    txt(pega(linha, ['COD', 'CÓD', 'PRODUTIVO'])),
      nome:   txt(pega(linha, ['COLABORADOR', 'NOME'])),
      equipe: txt(pega(linha, ['EQUIPE', 'TURNO'])).toUpperCase(),
      funcao: txt(pega(linha, ['FUNCAO', 'FUNÇÃO', 'CARGO'])).toUpperCase(),
      mes:    aoMes(pega(linha, ['ADMISS', 'DATA'], ['MOTIVO', 'TIPO']))
    };
  }).filter(function (r) { return r.mes; });

  var des = lerAba(ss, ABA_DESLIGADOS).map(function (linha) {
    return {
      cod:    txt(pega(linha, ['COD', 'CÓD', 'PRODUTIVO'])),
      nome:   txt(pega(linha, ['COLABORADOR', 'NOME'])),
      equipe: txt(pega(linha, ['EQUIPE', 'TURNO'])).toUpperCase(),
      funcao: txt(pega(linha, ['FUNCAO', 'FUNÇÃO', 'CARGO'])).toUpperCase(),
      mes:    aoMes(pega(linha, ['DESLIG', 'DEMISS', 'DATA'], ['MOTIVO', 'TIPO'])),
      data:   aoDia(pega(linha, ['DESLIG', 'DEMISS', 'DATA'], ['MOTIVO', 'TIPO'])),
      tipo:   txt(pega(linha, ['TIPO'], ['MOTIVO'])) || 'Não informado',
      // Pedido da gerencia: o motivo de cada demissao, da coluna MOTIVO.
      motivo: txt(pega(linha, ['MOTIVO']))
    };
  }).filter(function (r) { return r.mes; });

  var dados = { apoio: apoio, adm: adm, des: des, atualizado: new Date().toISOString(),
                temColunaMotivo: temColuna(ss, ABA_DESLIGADOS, 'MOTIVO') };
  if (cache) {
    var texto = JSON.stringify(dados);
    // o cache do Apps Script aceita no máximo 100 KB por chave
    if (texto.length < 95000) cache.put('bi_funcoes', texto, CACHE_SEGUNDOS);
  }
  return dados;
}

/** Lê uma aba inteira e devolve linhas como {CABECALHO: valor}. Aba inexistente devolve []. */
function lerAba(ss, nomeAba) {
  var aba = ss.getSheetByName(nomeAba);
  if (!aba) return [];
  var valores = aba.getDataRange().getValues();
  if (valores.length <= LINHA_CABECALHO) return [];
  var cab = valores[LINHA_CABECALHO - 1].map(function (c) { return normaliza(c); });
  return valores.slice(LINHA_CABECALHO).map(function (linha) {
    var obj = {};
    cab.forEach(function (nome, i) { if (nome) obj[nome] = linha[i]; });
    return obj;
  }).filter(function (obj) {
    return Object.keys(obj).some(function (k) { return String(obj[k]).trim() !== ''; });
  });
}

/** true se a aba tem uma coluna cujo cabeçalho contém o pedaço. */
function temColuna(ss, nomeAba, pedaco) {
  var aba = ss.getSheetByName(nomeAba);
  if (!aba || aba.getLastColumn() < 1) return false;
  return aba.getRange(LINHA_CABECALHO, 1, 1, aba.getLastColumn()).getValues()[0]
    .some(function (c) { return normaliza(c).indexOf(pedaco) !== -1; });
}

/**
 * Devolve o primeiro campo cujo cabeçalho contém um dos pedaços informados.
 * `evitar` tira da busca cabeçalhos que também contêm o pedaço mas são outra
 * coisa: sem isso, "MOTIVO DO DESLIGAMENTO" seria lido como a data, porque
 * contém "DESLIG".
 */
function pega(linha, pedacos, evitar) {
  var chaves = Object.keys(linha).filter(function (k) {
    return !(evitar || []).some(function (x) { return k.indexOf(x) !== -1; });
  });
  for (var p = 0; p < pedacos.length; p++) {
    var alvo = normaliza(pedacos[p]);
    for (var c = 0; c < chaves.length; c++) {
      if (chaves[c].indexOf(alvo) >= 0) return linha[chaves[c]];
    }
  }
  return '';
}

function normaliza(v) {
  return String(v == null ? '' : v).trim().toUpperCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function txt(v) { return String(v == null ? '' : v).trim(); }

/** Data (ou texto dd/mm/aaaa) -> "aaaa-mm-dd". */
function aoDia(v) {
  if (v instanceof Date && !isNaN(v)) {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  var s = txt(v);
  var br = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/);
  if (br) {
    var ano = br[3].length === 2 ? '20' + br[3] : br[3];
    return ano + '-' + ('0' + br[2]).slice(-2) + '-' + ('0' + br[1]).slice(-2);
  }
  var iso = s.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
  if (iso) return iso[1] + '-' + ('0' + iso[2]).slice(-2) + '-' + ('0' + iso[3]).slice(-2);
  return '';
}

/** Data (ou texto dd/mm/aaaa) -> "aaaa-mm". */
function aoMes(v) {
  if (v instanceof Date && !isNaN(v)) {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM');
  }
  var s = txt(v);
  var iso = s.match(/^(\d{4})[\/\-](\d{1,2})/);           // 2026-07-15
  if (iso) return iso[1] + '-' + ('0' + iso[2]).slice(-2);
  var br = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/); // 15/07/2026
  if (br) {
    var ano = br[3].length === 2 ? '20' + br[3] : br[3];
    return ano + '-' + ('0' + br[2]).slice(-2);
  }
  return '';
}
