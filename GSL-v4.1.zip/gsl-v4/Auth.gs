/**
 * IDENTIDADE — so reconhecer quem abriu.
 *
 * A PORTA E DO GOOGLE, NAO DO GSL.
 *
 * O GSL e implantado como "Executar como: eu" e "Quem pode acessar:
 * Qualquer pessoa da Bartofil". Com isso o proprio Google Workspace faz
 * o login: quem nao esta logado com uma conta @bartofil.com.br nem chega
 * a ver a pagina. E a mesma implantacao do BI de funcoes, que funciona
 * no servidor em nuvem.
 *
 * O que sobra para o GSL e uma pergunta so: QUEM e esta pessoa, para
 * saber quais telas ela ve. A resposta vem de Session.getActiveUser(),
 * que o Google preenche quando quem abre e do mesmo dominio do dono do
 * script. O navegador nao manda e-mail, token nem senha — nao ha o que
 * forjar e nao ha tela de entrada para travar.
 *
 * O que saiu (e por que):
 *   - o botao "Entrar com Google" (OAuth) e o token de sessao: eram a
 *     tela que ficava em loop no servidor em nuvem;
 *   - a tela de pedido de acesso e a triagem: quem nao esta cadastrado
 *     ve um aviso para falar com o administrador, e o administrador
 *     cadastra em Pessoas e acessos.
 */

var _usuarioDaVez = null;

function usuarioAtual() {
  if (_usuarioDaVez) return _usuarioDaVez;
  _usuarioDaVez = calcularUsuarioAtual();
  return _usuarioDaVez;
}

/** Zera a memoria quando o proprio usuario muda (simulacao, novo perfil). */
function esquecerUsuario() { _usuarioDaVez = null; }

/* Erro com motivo que a tela sabe explicar. */
function erroDeEntrada_(tipo, mensagem, email) {
  const e = new Error(mensagem);
  e.tipoEntrada = tipo;          // SEM_CONTA · SEM_CADASTRO · DESATIVADO · SEM_NIVEL
  e.email = email || '';
  return e;
}

function calcularUsuarioAtual() {
  const email = emailDeQuemAbriu();

  if (!email) {
    throw erroDeEntrada_('SEM_CONTA',
      'O Google não informou qual conta abriu o sistema. Confira se você está com a conta ' +
      '@bartofil.com.br aberta neste navegador e recarregue a página.');
  }

  const simulado = simulacaoAtiva(email);
  if (simulado) return montarUsuario(simulado);

  const registro = buscarAcesso(email);
  const admin = String(prop('EMAIL_ADMIN', '')).toLowerCase().trim();

  // O dono do sistema nunca fica trancado do lado de fora, mesmo se
  // alguem apagar a linha dele em ACESSOS. "Dono" e o EMAIL_ADMIN da
  // instalacao OU a conta que fez a implantacao (a que executa o script).
  if (!registro && (email === admin || email === donoDoScript())) {
    return montarUsuario({ email: email, nome: nomeDaPessoa(email, ''), papel: 'Administrador do sistema',
      perfil: 'ADMIN', turno: '', filiais: '*', situacao: 'ATIVO', cadastrado: true, verificado: true });
  }

  if (!registro) {
    throw erroDeEntrada_('SEM_CADASTRO',
      'Sua conta ainda não foi cadastrada no GSL. Peça ao administrador para liberar o seu acesso.', email);
  }

  const situacao = String(registro.SITUACAO || '').toUpperCase().trim();
  const perfil = String(registro.PERFIL || '').toUpperCase().trim();

  if (!marcado(registro.ATIVO) || situacao === 'RECUSADO' || situacao === 'INATIVO') {
    throw erroDeEntrada_('DESATIVADO',
      'Seu acesso ao GSL está desativado. Fale com o administrador.', email);
  }
  if (!perfil || perfil === PERFIL_PADRAO_NOVO_USUARIO) {
    throw erroDeEntrada_('SEM_NIVEL',
      'Seu cadastro existe, mas ainda não tem nível de acesso definido. Fale com o administrador.', email);
  }

  return montarUsuario({
    verificado: true,
    id: registro.ID,
    email: email,
    nome: nomeDaPessoa(email, registro.NOME),
    papel: String(registro.PAPEL || '').trim(),
    perfil: perfil,
    turno: String(registro.TURNO || '').toUpperCase().trim(),
    filiais: String(registro.FILIAIS || '').trim(),
    modulos: String(registro.MODULOS || '').trim(),
    situacao: situacao || 'ATIVO',
    cadastrado: true
  });
}

/*
 * Nome de quem esta usando. Sem nome no cadastro, o ultimo recurso e o
 * comeco do e-mail arrumado (ponto e underline viram espaco, cada
 * palavra com inicial maiuscula).
 */
function nomeDaPessoa(email, nomeAcesso) {
  const direto = String(nomeAcesso || '').trim();
  if (direto) return direto;
  const raiz = String(email || '').split('@')[0].replace(/[._\-]+/g, ' ').replace(/\d+$/, '').trim();
  if (!raiz) return 'Usuário';
  return raiz.split(/\s+/).map(function (p) {
    return p ? p.charAt(0).toUpperCase() + p.slice(1).toLowerCase() : '';
  }).join(' ').trim();
}

function montarUsuario(base) {
  const nivel = permissoesDe(base.perfil);
  // O ADMIN ve tudo sempre; nos demais vale o ajuste por modulo da pessoa.
  const ajustes = String(base.perfil || '').toUpperCase() === 'ADMIN' ? {} : lerModulosPessoa(base.modulos);
  base.permissoes = aplicarModulosDaPessoa(nivel, ajustes);
  // Entra na chave do cache de tela: duas pessoas do mesmo nivel com
  // ajustes diferentes nao podem dividir o mesmo payload.
  base.chaveModulos = Object.keys(ajustes).sort().map(function (k) { return k + ':' + ajustes[k]; }).join(',');
  return base;
}

/*
 * getActiveUser()    = a pessoa que esta com o navegador aberto.
 * getEffectiveUser() = a conta que o script RODA (o dono da implantacao).
 *
 * So a primeira serve para dizer quem esta usando. A segunda seria o
 * dono para todo mundo — e todo mundo entraria como administrador.
 */
function emailDeQuemAbriu() {
  let email = '';
  try { email = Session.getActiveUser().getEmail(); } catch (e) { email = ''; }
  return String(email || '').toLowerCase().trim();
}

/* A conta que EXECUTA o script. Serve para instalacao e avisos de sistema. */
function donoDoScript() {
  let email = '';
  try { email = Session.getEffectiveUser().getEmail(); } catch (e) { email = ''; }
  return String(email || '').toLowerCase().trim();
}

/*
 * DIAGNOSTICO — /exec?diagnostico=1
 * Responde, de dentro da implantacao, se o Google esta informando quem abriu.
 */
function diagnosticoIdentidade() {
  const ativo = emailDeQuemAbriu();
  const dono = donoDoScript();
  let cadastro = null;
  try { cadastro = ativo ? buscarAcesso(ativo) : null; } catch (e) { cadastro = null; }

  const r = {
    usuarioAtivo: ativo || '(vazio)',
    donoDoScript: dono || '(vazio)',
    identidadeConfiavel: !!ativo,
    cadastrado: !!cadastro,
    perfil: cadastro ? String(cadastro.PERFIL || '') : '',
    veredito: ''
  };

  if (!ativo) {
    r.veredito = 'O Google NÃO informou quem abriu. Confira a implantação: "Executar como: eu" e ' +
      '"Quem pode acessar: Qualquer pessoa da Bartofil". E confira se a pessoa está com a conta ' +
      '@bartofil.com.br aberta no navegador.';
  } else if (!cadastro) {
    r.veredito = 'O Google informou a conta ' + ativo + ', mas ela não está cadastrada em Pessoas e acessos.';
  } else {
    r.veredito = 'Tudo certo: o Google informou a conta e ela está cadastrada com o nível ' + r.perfil + '.';
  }

  Logger.log(JSON.stringify(r, null, 2));
  return r;
}

function buscarAcesso(email) {
  const cadastrados = comCache('acessos', function () {
    return listar('ACESSOS').map(function (l) {
      return {
        ID: l.ID,
        EMAIL: String(l.EMAIL || '').toLowerCase().trim(),
        NOME: l.NOME, PAPEL: l.PAPEL, PERFIL: l.PERFIL, TURNO: l.TURNO,
        ATIVO: l.ATIVO, SITUACAO: l.SITUACAO, FILIAIS: l.FILIAIS, MODULOS: l.MODULOS
      };
    });
  });
  const alvo = String(email || '').toLowerCase().trim();
  const achados = cadastrados.filter(function (a) { return a.EMAIL === alvo; });
  return achados.length ? achados[0] : null;
}

/* A LISTA DE PESSOAS — alimenta a tela "Pessoas e acessos". */
function listarPessoas() {
  return listar('ACESSOS').map(function (l) {
    const perfil = String(l.PERFIL || '').toUpperCase().trim();
    let situacao = String(l.SITUACAO || '').toUpperCase().trim() ||
                   (marcado(l.ATIVO) ? 'ATIVO' : 'INATIVO');
    if (!marcado(l.ATIVO)) situacao = 'INATIVO';
    return {
      id: l.ID,
      email: String(l.EMAIL || '').trim(),
      nome: String(l.NOME || '').trim(),
      papel: String(l.PAPEL || '').trim(),
      perfil: perfil,
      semNivel: !perfil || perfil === PERFIL_PADRAO_NOVO_USUARIO,
      turno: String(l.TURNO || '').toUpperCase().trim(),
      filiais: String(l.FILIAIS || '').toUpperCase().trim(),
      modulos: lerModulosPessoa(l.MODULOS),
      ativo: marcado(l.ATIVO),
      situacao: situacao,
      observacao: String(l.OBSERVACAO || ''),
      desde: l.CRIADO_EM
    };
  }).filter(function (a) { return a.email; })
    .sort(function (a, b) { return a.nome.localeCompare(b.nome); });
}

/* Nome antigo, mantido para nao quebrar chamada existente. */
function listarAcessos() { return listarPessoas(); }

/* --- Administracao de pessoas, chamada pela tela --- */

/*
 * Cadastrar = liberar. Nao existe mais pedido nem fila: o administrador
 * cadastra a pessoa, escolhe o nivel e as filiais, e ela ja entra.
 */
function acaoSalvarUsuario(usuario, params) {
  exigirCapacidade(usuario, 'GERIR_ACESSOS');
  const campos = {
    EMAIL: String(params.email || '').toLowerCase().trim(),
    NOME: String(params.nome || '').trim(),
    PAPEL: String(params.papel || '').trim(),
    PERFIL: String(params.perfil || '').toUpperCase().trim(),
    TURNO: String(params.turno || '').toUpperCase().trim(),
    FILIAIS: String(params.filiais || '').toUpperCase().replace(/\s+/g, ''),
    ATIVO: params.ativo === false ? 'NAO' : 'SIM'
  };
  if (params.modulos && typeof params.modulos === 'object') {
    campos.MODULOS = JSON.stringify(lerModulosPessoa(JSON.stringify(params.modulos)));
    if (campos.MODULOS === '{}') campos.MODULOS = '';
  }
  if (!campos.EMAIL || campos.EMAIL.indexOf('@') === -1) throw new Error('Informe um e-mail válido.');
  if (!campos.NOME) throw new Error('Informe o nome da pessoa — é ele que aparece no sistema.');
  if (!campos.PERFIL || campos.PERFIL === PERFIL_PADRAO_NOVO_USUARIO) throw new Error('Escolha o nível de acesso.');
  campos.SITUACAO = campos.ATIVO === 'SIM' ? 'ATIVO' : 'INATIVO';
  campos.DECIDIDO_EM = agoraTexto();
  campos.DECIDIDO_POR = usuario.email;

  if (params.id) {
    const alvo = obter('ACESSOS', params.id);
    if (alvo && String(alvo.EMAIL || '').toLowerCase() === usuario.email && campos.ATIVO === 'NAO') {
      throw new Error('Você não pode desativar o próprio acesso.');
    }
    const r = atualizar('ACESSOS', params.id, campos, usuario.email);
    limparCache('ACESSOS');
    return r;
  }

  const jaExiste = buscarAcesso(campos.EMAIL);
  if (jaExiste) throw new Error('Esse e-mail já está cadastrado.');
  const id = inserir('ACESSOS', campos, usuario.email);
  limparCache('ACESSOS');
  const resposta = { ok: true, id: id };
  try { avisarAcessoLiberado({ nome: campos.NOME, email: campos.EMAIL, perfil: campos.PERFIL }); }
  catch (e) { resposta.avisoEmail = 'Pessoa cadastrada, mas o e-mail de aviso não saiu: ' + (e.message || e); }
  return resposta;
}

/*
 * Muda UM modulo de UMA pessoa — o clique na tabela "Modulos por pessoa".
 * modo: PADRAO (volta a seguir o nivel) · NAO · VER · EDITAR
 */
function acaoDefinirModuloPessoa(usuario, params) {
  exigirCapacidade(usuario, 'GERIR_ACESSOS');
  const alvo = obter('ACESSOS', params.id);
  if (!alvo) throw new Error('Pessoa não encontrada.');
  const modulo = String(params.modulo || '');
  if (!MODULOS_AJUSTAVEIS[modulo]) throw new Error('Este módulo segue sempre o nível de acesso.');
  const modo = String(params.modo || '').toUpperCase().trim();
  const atuais = lerModulosPessoa(alvo.MODULOS);
  if (modo === 'PADRAO' || !modo) delete atuais[modulo];
  else if (MODOS_MODULO.indexOf(modo) !== -1) atuais[modulo] = modo;
  else throw new Error('Opção inválida.');
  atualizar('ACESSOS', params.id, { MODULOS: Object.keys(atuais).length ? JSON.stringify(atuais) : '' }, usuario.email);
  limparCache('ACESSOS');
  return { ok: true };
}

/** Liga/desliga o acesso sem apagar a pessoa. */
function acaoAlternarAtivo(usuario, params) {
  exigirCapacidade(usuario, 'GERIR_ACESSOS');
  const alvo = obter('ACESSOS', params.id);
  if (!alvo) throw new Error('Pessoa não encontrada.');
  if (String(alvo.EMAIL || '').toLowerCase() === usuario.email) {
    throw new Error('Você não pode desativar o próprio acesso.');
  }
  const ligar = !marcado(alvo.ATIVO);
  atualizar('ACESSOS', params.id, {
    ATIVO: ligar ? 'SIM' : 'NAO',
    SITUACAO: ligar ? 'ATIVO' : 'INATIVO',
    DECIDIDO_EM: agoraTexto(), DECIDIDO_POR: usuario.email
  }, usuario.email);
  limparCache('ACESSOS');
  return { ok: true, ativo: ligar };
}

function acaoExcluirUsuario(usuario, params) {
  exigirCapacidade(usuario, 'GERIR_ACESSOS');
  if (String(params.email || '').toLowerCase() === usuario.email) {
    throw new Error('Você não pode remover o próprio acesso.');
  }
  const r = excluir('ACESSOS', params.id, usuario.email);
  limparCache('ACESSOS');
  return r;
}

/** Liga ou desliga uma celula da matriz de permissoes, pela tela. */
function acaoAlterarPermissao(usuario, params) {
  const coluna = String(params.coluna || '').toUpperCase();
  if (coluna.indexOf('TELA_') !== 0 && coluna.indexOf('PODE_') !== 0 && coluna !== 'ESCOPO') {
    throw new Error('Coluna de permissão invalida.');
  }
  const campos = {};
  campos[coluna] = (coluna === 'ESCOPO') ? params.valor : (params.valor ? 'SIM' : 'NAO');
  const r = atualizar('PERFIS', params.id, campos, usuario.email);
  r.invalidarTudo = true;
  return r;
}

/* --- Ver o sistema como outro nivel (so o administrador) ---
 * Guardado nas propriedades do SCRIPT com o e-mail na chave: com
 * "Executar como: eu", as propriedades de usuario sao as do dono, iguais
 * para todo mundo. */

function chaveSimulacao_(email) { return 'SIMULACAO_' + String(email).toLowerCase(); }

function simularPerfil(perfil, turno) {
  const email = emailDeQuemAbriu();
  if (email !== String(prop('EMAIL_ADMIN', '')).toLowerCase()) {
    throw new Error('Somente o administrador pode simular perfis.');
  }
  PropertiesService.getScriptProperties().setProperty(chaveSimulacao_(email), JSON.stringify({
    perfil: String(perfil).toUpperCase().trim(),
    turno: String(turno || '').toUpperCase().trim()
  }));
  esquecerProps();
  esquecerUsuario();
  return { ok: true };
}

function encerrarSimulacao() {
  const email = emailDeQuemAbriu();
  PropertiesService.getScriptProperties().deleteProperty(chaveSimulacao_(email));
  esquecerProps();
  esquecerUsuario();
  return { ok: true };
}

function simulacaoAtiva(email) {
  if (email !== String(prop('EMAIL_ADMIN', '')).toLowerCase()) return null;
  const bruto = prop(chaveSimulacao_(email), '');
  if (!bruto) return null;
  let s;
  try { s = JSON.parse(bruto); } catch (e) { return null; }
  return {
    email: email, nome: 'Simulando ' + s.perfil + (s.turno ? ' / turno ' + s.turno : ''),
    perfil: s.perfil, turno: s.turno, filiais: '*', cadastrado: true, simulado: true, verificado: true
  };
}
