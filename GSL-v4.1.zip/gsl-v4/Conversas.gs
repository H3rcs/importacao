/**
 * CONVERSA E FEEDBACK
 *
 * Duas coisas que nasceram da mesma reclamacao: hoje, quando o gerente
 * escreve alguma coisa numa atividade, o coordenador nao tem onde
 * responder. A resposta virava WhatsApp — e sumia.
 *
 * CONVERSA DE ATIVIDADE
 *   A caixa que aparece dentro da propria atividade. Gerente escreve,
 *   coordenador responde ali, com foto ou link. Fica no historico da
 *   atividade, nao no celular de ninguem.
 *
 * CONVERSA DIRETA
 *   Duas pessoas, uma linha do tempo. A chave e o par de e-mails em ordem
 *   alfabetica — os dois lados sempre caem na MESMA conversa, seja quem
 *   for que abriu.
 *
 * FEEDBACK
 *   O botao de reportar erro, de dentro do sistema. Grava a tela, o
 *   usuario, o horario e o navegador — o que faltava toda vez que alguem
 *   dizia "deu erro" sem dizer onde.
 */

const CONVERSA_ATIVIDADE = 'ATIVIDADE';
const CONVERSA_DIRETA = 'DIRETO';
const CONVERSA_LIMITE = 200;        // mensagens carregadas por conversa
const FEEDBACK_TIPOS = ['ERRO', 'SUGESTAO', 'DUVIDA'];

/* ------------------------------------------------------------------ */
/* CHAVE DA CONVERSA DIRETA                                            */
/* ------------------------------------------------------------------ */

/**
 * A chave do par. Ordem alfabetica de proposito: sem isso,
 * ana->bruno e bruno->ana virariam duas conversas separadas e cada um
 * falaria sozinho achando que o outro nao respondeu.
 */
function chaveDireta(a, b) {
  const x = String(a || '').toLowerCase().trim();
  const y = String(b || '').toLowerCase().trim();
  if (!x || !y) throw new Error('Conversa precisa de duas pessoas.');
  return [x, y].sort().join('|');
}

/** O outro lado de uma conversa direta, visto por quem esta olhando. */
function outroLado(chave, eu) {
  const partes = String(chave || '').split('|');
  const meu = String(eu || '').toLowerCase().trim();
  return partes.filter(function (p) { return p !== meu; })[0] || partes[0] || '';
}

/* ------------------------------------------------------------------ */
/* LEITURA                                                             */
/* ------------------------------------------------------------------ */

function hidratarMensagem(m, eu) {
  const autor = String(m.AUTOR || '').toLowerCase().trim();
  const lidaPor = String(m.LIDA_POR || '').toLowerCase();
  return {
    id: String(m.ID || ''),
    contexto: String(m.CONTEXTO || '').toUpperCase().trim(),
    alvo: String(m.ALVO || ''),
    autor: autor,
    autorNome: String(m.AUTOR_NOME || '').trim() || autor.split('@')[0],
    texto: String(m.TEXTO || ''),
    link: String(m.LINK || '').trim(),
    anexos: listarAnexos(m.ANEXOS),
    quando: String(m.CRIADO_EM || '').trim(),
    minha: autor === String(eu || '').toLowerCase().trim(),
    lida: lidaPor.indexOf(String(eu || '').toLowerCase().trim()) !== -1
  };
}

function mensagensDe(contexto, alvo, eu) {
  const alvoTexto = String(alvo || '');
  const ctx = String(contexto || '').toUpperCase().trim();

  const achadas = listar('MENSAGENS').filter(function (m) {
    return String(m.CONTEXTO || '').toUpperCase().trim() === ctx &&
           String(m.ALVO || '') === alvoTexto;
  });

  // Mais antiga em cima — e uma conversa, nao um feed de noticias.
  achadas.sort(function (a, b) {
    return String(a.CRIADO_EM || '') < String(b.CRIADO_EM || '') ? -1 : 1;
  });

  const recortadas = achadas.length > CONVERSA_LIMITE
    ? achadas.slice(achadas.length - CONVERSA_LIMITE) : achadas;

  return recortadas.map(function (m) { return hidratarMensagem(m, eu); });
}

/** Mensagens de UMA atividade — chamado ao abrir a janela da atividade. */
function mensagensDaAtividade(idAtividade, eu) {
  return mensagensDe(CONVERSA_ATIVIDADE, idAtividade, eu);
}

/**
 * Tela Conversas: a lista de pessoas na esquerda e o fio aberto na
 * direita. A lista mostra so quem ja trocou mensagem com voce mais todo
 * mundo que tem acesso — comecar uma conversa nao pode exigir cadastro.
 */
function dadosConversa(usuario, params) {
  const eu = String(usuario.email || '').toLowerCase().trim();
  const com = String((params && params.com) || '').toLowerCase().trim();

  const todas = listar('MENSAGENS').filter(function (m) {
    return String(m.CONTEXTO || '').toUpperCase().trim() === CONVERSA_DIRETA &&
           String(m.ALVO || '').indexOf(eu) !== -1;
  });

  // Resumo por pessoa: ultima mensagem e quantas nao lidas.
  const porPessoa = {};
  todas.forEach(function (m) {
    const chave = String(m.ALVO || '');
    const outro = outroLado(chave, eu);
    if (!outro) return;
    if (!porPessoa[outro]) {
      porPessoa[outro] = { email: outro, ultima: '', quando: '', naoLidas: 0 };
    }
    const quando = String(m.CRIADO_EM || '');
    if (quando > porPessoa[outro].quando) {
      porPessoa[outro].quando = quando;
      porPessoa[outro].ultima = String(m.TEXTO || '').slice(0, 90);
    }
    const autor = String(m.AUTOR || '').toLowerCase().trim();
    const lida = String(m.LIDA_POR || '').toLowerCase().indexOf(eu) !== -1;
    if (autor !== eu && !lida) porPessoa[outro].naoLidas++;
  });

  const pessoas = pessoasParaAcao().filter(function (p) { return p.email !== eu; });
  const nomes = {};
  pessoas.forEach(function (p) { nomes[p.email] = p.nome; });

  const conversas = Object.keys(porPessoa).map(function (e) {
    const c = porPessoa[e];
    c.nome = nomes[e] || e.split('@')[0];
    return c;
  }).sort(function (a, b) { return a.quando < b.quando ? 1 : -1; });

  const aberta = com
    ? { com: com, nome: nomes[com] || com.split('@')[0],
        mensagens: mensagensDe(CONVERSA_DIRETA, chaveDireta(eu, com), eu) }
    : null;

  // Abrir a conversa marca como lida — senao o contador nunca zera.
  if (aberta) marcarConversaLida(usuario, chaveDireta(eu, com));

  const dados = {
    conversas: conversas,
    pessoas: pessoas,
    aberta: aberta,
    eu: eu,
    podeConversar: podeFazer(usuario, 'CONVERSAR'),
    podeVerFeedback: podeFazer(usuario, 'GERIR_ACESSOS')
  };

  if (dados.podeVerFeedback) dados.feedbacks = listarFeedback();
  return dados;
}

/* ------------------------------------------------------------------ */
/* ESCRITA                                                             */
/* ------------------------------------------------------------------ */

/**
 * Envia mensagem. Serve para os dois contextos:
 *   { contexto:'ATIVIDADE', alvo:'<id da atividade>', texto, link }
 *   { contexto:'DIRETO',    para:'fulano@...',        texto, link }
 *
 * A foto vai separada, em `arquivo` ({nome, tipo, dados em base64}),
 * porque ela precisa do ID da mensagem ja gravado para ir na pasta certa.
 */
function acaoEnviarMensagem(usuario, params) {
  exigirCapacidade(usuario, 'CONVERSAR');

  const texto = String(params.texto || '').trim();
  const link = String(params.link || '').trim();
  const temArquivo = !!(params.arquivo && params.arquivo.dados);
  if (!texto && !link && !temArquivo) throw new Error('Escreva alguma coisa antes de enviar.');

  if (link && !/^https?:\/\//i.test(link)) {
    throw new Error('O link precisa começar com http:// ou https://');
  }

  const contexto = String(params.contexto || CONVERSA_ATIVIDADE).toUpperCase().trim();
  let alvo = '', para = '';

  if (contexto === CONVERSA_ATIVIDADE) {
    alvo = String(params.alvo || '').trim();
    if (!alvo) throw new Error('Mensagem sem atividade.');
    // A mesma regra de alcance da atividade vale para a conversa dela:
    // ninguem comenta numa atividade que nao pode nem abrir.
    garantirAlcance(usuario, alvo);
  } else if (contexto === CONVERSA_DIRETA) {
    para = String(params.para || '').toLowerCase().trim();
    if (!para || para.indexOf('@') === -1) throw new Error('Informe para quem é a mensagem.');
    alvo = chaveDireta(usuario.email, para);
  } else {
    throw new Error('Contexto de conversa desconhecido: ' + contexto);
  }

  const id = inserir('MENSAGENS', {
    CONTEXTO: contexto,
    ALVO: alvo,
    AUTOR: String(usuario.email || '').toLowerCase().trim(),
    AUTOR_NOME: usuario.nome || usuario.papel || usuario.email,
    TEXTO: texto,
    LINK: link,
    ANEXOS: '',
    PARA: para,
    // Quem escreveu ja leu. Sem isto a propria mensagem contava como nao lida.
    LIDA_POR: String(usuario.email || '').toLowerCase().trim()
  }, usuario.email);

  let anexo = null;
  if (temArquivo) {
    anexo = anexarArquivo(usuario, 'MENSAGENS', id, params.arquivo);
  }

  let avisoEmail = '';
  try { avisarMensagem(usuario, contexto, alvo, para, texto); }
  catch (e) { avisoEmail = 'Mensagem enviada, mas o aviso por e-mail não saiu: ' + (e.message || e); }

  const r = { id: id, anexo: anexo, recado: 'Enviado.' };
  if (avisoEmail) r.avisoEmail = avisoEmail;
  return r;
}

/** Lista as mensagens de uma atividade — usada pela janela da atividade. */
function acaoMensagensAtividade(usuario, params) {
  const id = String(params.id || '').trim();
  garantirAlcance(usuario, id);
  const msgs = mensagensDaAtividade(id, usuario.email);
  marcarLidas(usuario, CONVERSA_ATIVIDADE, id);
  return { id: id, mensagens: msgs };
}

function acaoConversaDireta(usuario, params) {
  exigirCapacidade(usuario, 'CONVERSAR');
  const com = String(params.com || '').toLowerCase().trim();
  if (!com) throw new Error('Informe com quem é a conversa.');
  const chave = chaveDireta(usuario.email, com);
  const msgs = mensagensDe(CONVERSA_DIRETA, chave, usuario.email);
  marcarConversaLida(usuario, chave);
  return { com: com, mensagens: msgs };
}

/* Marca como lidas as mensagens que nao sao minhas. Uma escrita em lote. */
function marcarLidas(usuario, contexto, alvo) {
  const eu = String(usuario.email || '').toLowerCase().trim();
  const ctx = String(contexto || '').toUpperCase().trim();

  const mudancas = listar('MENSAGENS').filter(function (m) {
    if (String(m.CONTEXTO || '').toUpperCase().trim() !== ctx) return false;
    if (String(m.ALVO || '') !== String(alvo)) return false;
    if (String(m.AUTOR || '').toLowerCase().trim() === eu) return false;
    return String(m.LIDA_POR || '').toLowerCase().indexOf(eu) === -1;
  }).map(function (m) {
    const atual = String(m.LIDA_POR || '').trim();
    return { id: m.ID, campos: { LIDA_POR: atual ? atual + ',' + eu : eu } };
  });

  if (mudancas.length) atualizarVarios('MENSAGENS', mudancas, usuario.email);
  return mudancas.length;
}

function marcarConversaLida(usuario, chave) {
  return marcarLidas(usuario, CONVERSA_DIRETA, chave);
}

/* ------------------------------------------------------------------ */
/* AVISO POR E-MAIL                                                    */
/* ------------------------------------------------------------------ */

function avisarMensagem(usuario, contexto, alvo, para, texto) {
  const de = usuario.nome || usuario.email;
  const trecho = String(texto || '').slice(0, 300);

  if (contexto === CONVERSA_DIRETA) {
    if (!para) return;
    enviar([para], 'Mensagem de ' + de + ' no GSL',
      '<p><strong>' + htmlSeguro(de) + '</strong> escreveu para você:</p>' +
      '<p style="border-left:3px solid #111785;padding-left:12px;color:#333">' +
      htmlSeguro(trecho) + '</p>' + rodapeLink());
    return;
  }

  // Conversa de atividade: avisa o outro lado — coordenador da atividade
  // e a gestao —, nunca quem acabou de escrever.
  const registro = obter('ATIVIDADES', alvo);
  if (!registro) return;

  const eu = String(usuario.email || '').toLowerCase().trim();
  const destinos = []
    .concat(emailsDoTurno(hidratar(registro)) || [])
    .concat(emailsDaGestao() || [])
    .map(function (e) { return String(e || '').toLowerCase().trim(); })
    .filter(function (e) { return e && e !== eu; });

  const unicos = [];
  destinos.forEach(function (e) { if (unicos.indexOf(e) === -1) unicos.push(e); });
  if (!unicos.length) return;

  enviar(unicos, 'Nova mensagem na atividade: ' + String(registro.ATIVIDADE || alvo),
    '<p><strong>' + htmlSeguro(de) + '</strong> escreveu na atividade ' +
    '<strong>' + htmlSeguro(registro.ATIVIDADE || alvo) + '</strong>:</p>' +
    '<p style="border-left:3px solid #111785;padding-left:12px;color:#333">' +
    htmlSeguro(trecho) + '</p>' +
    '<p>Responda pelo sistema, na própria atividade.</p>' + rodapeLink());
}

/* ------------------------------------------------------------------ */
/* FEEDBACK DE ERROS DA PLATAFORMA                                     */
/* ------------------------------------------------------------------ */

/**
 * Qualquer pessoa pode reportar. Nao exige capacidade nenhuma de
 * proposito: quem esta travado num erro e justamente quem tem menos
 * permissao para contornar.
 */
function acaoEnviarFeedback(usuario, params) {
  const texto = String(params.texto || '').trim();
  if (!texto) throw new Error('Descreva o que aconteceu.');

  const tipo = String(params.tipo || 'ERRO').toUpperCase().trim();
  const id = inserir('FEEDBACK', {
    TIPO: FEEDBACK_TIPOS.indexOf(tipo) !== -1 ? tipo : 'ERRO',
    TELA: String(params.tela || '').trim(),
    TEXTO: texto,
    AUTOR: String(usuario.email || '').toLowerCase().trim(),
    AUTOR_NOME: usuario.nome || usuario.email,
    NAVEGADOR: String(params.navegador || '').slice(0, 300),
    SITUACAO: 'ABERTO',
    RESPOSTA: '', RESPONDIDO_EM: '', RESPONDIDO_POR: ''
  }, usuario.email);

  let avisoEmail = '';
  try {
    const admin = prop('EMAIL_ADMIN', '');
    if (admin) {
      enviar([admin], '[GSL] ' + tipo + ' reportado por ' + (usuario.nome || usuario.email),
        '<p><strong>' + htmlSeguro(usuario.nome || usuario.email) + '</strong> reportou:</p>' +
        '<p style="border-left:3px solid #C62828;padding-left:12px">' + htmlSeguro(texto) + '</p>' +
        '<p style="color:#666;font-size:12px">Tela: ' + htmlSeguro(params.tela || '—') +
        '<br>Navegador: ' + htmlSeguro(String(params.navegador || '—').slice(0, 200)) + '</p>' +
        rodapeLink());
    }
  } catch (e) {
    avisoEmail = 'Registrei o seu relato, mas o aviso por e-mail não saiu: ' + (e.message || e);
  }

  const r = { id: id, recado: 'Recebi. Obrigado por avisar.' };
  if (avisoEmail) r.avisoEmail = avisoEmail;
  return r;
}

function listarFeedback() {
  return listar('FEEDBACK').map(function (f) {
    return {
      id: String(f.ID || ''),
      tipo: String(f.TIPO || '').toUpperCase().trim(),
      tela: String(f.TELA || '').trim(),
      texto: String(f.TEXTO || ''),
      autorNome: String(f.AUTOR_NOME || '').trim() || String(f.AUTOR || '').split('@')[0],
      autor: String(f.AUTOR || ''),
      quando: String(f.CRIADO_EM || '').trim(),
      situacao: String(f.SITUACAO || 'ABERTO').toUpperCase().trim(),
      resposta: String(f.RESPOSTA || '').trim()
    };
  }).sort(function (a, b) {
    // Abertos primeiro; dentro de cada grupo, o mais recente em cima.
    if (a.situacao !== b.situacao) return a.situacao === 'ABERTO' ? -1 : 1;
    return a.quando < b.quando ? 1 : -1;
  });
}

function acaoResolverFeedback(usuario, params) {
  exigirCapacidade(usuario, 'GERIR_ACESSOS');
  const id = String(params.id || '').trim();
  const registro = obter('FEEDBACK', id);
  if (!registro) throw new Error('Relato não encontrado.');

  atualizar('FEEDBACK', id, {
    SITUACAO: 'RESOLVIDO',
    RESPOSTA: String(params.resposta || '').trim(),
    RESPONDIDO_EM: agoraTexto(),
    RESPONDIDO_POR: usuario.email
  }, usuario.email);

  // Quem reportou merece saber que foi resolvido — e o que faz a proxima
  // pessoa reportar de novo em vez de desistir.
  try {
    const autor = String(registro.AUTOR || '').toLowerCase().trim();
    if (autor && params.resposta) {
      enviar([autor], '[GSL] Resolvido: o que você reportou',
        '<p>Você reportou:</p><p style="color:#666">' + htmlSeguro(registro.TEXTO) + '</p>' +
        '<p><strong>Resposta:</strong></p><p>' + htmlSeguro(params.resposta) + '</p>' + rodapeLink());
    }
  } catch (e) { /* o relato ja esta resolvido; o aviso e extra */ }

  return { recado: 'Relato resolvido.' };
}
