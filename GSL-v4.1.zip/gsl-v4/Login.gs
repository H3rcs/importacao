/**
 * LOGIN.gs — DESATIVADO na versao 4.0.
 *
 * O GSL nao tem mais tela de entrada propria. A implantacao e
 * "Executar como: eu" + "Qualquer pessoa da Bartofil": o Google Workspace
 * faz o login e o GSL so reconhece quem abriu (Auth.gs).
 *
 * Pode APAGAR este arquivo do projeto. Ele ficou vazio de proposito, para
 * o caso de alguem colar a versao nova por cima da antiga sem apagar.
 */
