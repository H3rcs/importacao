/**
 * CONVERSA E FEEDBACK
 *
 * Duas coisas que nasceram da mesma reclamacao: hoje, quando o gerente
 * escreve alguma coisa numa atividade, o coordenador nao tem onde
 * responder. A resposta virava WhatsApp — e sumia.
 *
 * CONVERSA DE ATIVIDADE
 *   A caixa que aparece dentro da propria atividade. Gerente escreve,
 *   coordenador responde ali, com foto ou link. Fica no historico da
 *   atividade, nao no celular de ninguem.
 *
 * CONVERSA DIRETA
 *   Duas pessoas, uma linha do tempo. A chave e o par de e-mails em ordem
 *   alfabetica — os dois lados sempre caem na MESMA conversa, seja quem
 *   for que abriu.
 *
 * FEEDBACK
 *   O botao de reportar erro, de dentro do sistema. Grava a tela, o
 *   usuario, o horario e o navegador — o que faltava toda vez que alguem
 *   dizia "deu erro" sem dizer onde.
 */

const CONVERSA_ATIVIDADE = 'ATIVIDADE';
const CONVERSA_DIRETA = 'DIRETO';
const CONVERSA_LIMITE = 200;        // mensagens carregadas por conversa
const FEEDBACK_TIPOS = ['ERRO', 'SUGESTAO', 'DUVIDA'];

/* ------------------------------------------------------------------ */
/* CHAVE DA CONVERSA DIRETA                                            */
/* ------------------------------------------------------------------ */

/**
 * A chave do par. Ordem alfabetica de proposito: sem isso,
 * ana->bruno e bruno->ana virariam duas conversas separadas e cada um
 * falaria sozinho achando que o outro nao respondeu.
 */
function chaveDireta(a, b) {
  const x = String(a || '').toLowerCase().trim();
  const y = String(b || '').toLowerCase().trim();
  if (!x || !y) throw new Error('Conversa precisa de duas pessoas.');
  return [x, y].sort().join('|');
}

/*
 * Quem esta numa conversa direta: as duas partes EXATAS da chave.
 *
 * Antes a lista de conversas de uma pessoa era "toda chave que CONTEM o
 * meu e-mail" — e ana@ esta contido em joana@, mariana@, luciana@... A
 * Ana via na lista dela a previa da conversa entre Pedro e Joana, com um
 * contador de nao lidas que nunca zerava (abrir levava a outra conversa).
 */
function participantes_(chave) {
  return String(chave || '').toLowerCase().split('|')
    .map(function (p) { return p.trim(); }).filter(Boolean);
}

/*
 * Ordem REAL de uma mensagem. O CRIADO_EM e texto 'dd/MM/yyyy HH:mm:ss':
 * ordenado como texto, '01/10' vinha antes de '29/09' — na virada do mes a
 * conversa embaralhava, a "ultima mensagem" era a errada e o corte das 200
 * mais recentes podia jogar fora justamente as novas. O ID (gerarId poe o
 * relogio em base 36 logo depois do prefixo) tem o milissegundo; o
 * carimbo lido de verdade e o recuo para ID fora do padrao.
 */
function instanteDeMensagem_(m) {
  const partes = String(m.ID || '').split('-');
  if (partes.length >= 3) {
    const ms = parseInt(partes[1], 36);
    if (ms > 1e12 && ms < 1e14) return ms;
  }
  return instanteDoCarimbo(m.CRIADO_EM);
}

function porInstante_(a, b) {
  const d = instanteDeMensagem_(a) - instanteDeMensagem_(b);
  return d !== 0 ? d : (String(a.ID) < String(b.ID) ? -1 : (String(a.ID) > String(b.ID) ? 1 : 0));
}

/** O outro lado de uma conversa direta, visto por quem esta olhando. */
function outroLado(chave, eu) {
  const partes = String(chave || '').split('|');
  const meu = String(eu || '').toLowerCase().trim();
  return partes.filter(function (p) { return p !== meu; })[0] || partes[0] || '';
}

/* ------------------------------------------------------------------ */
/* LEITURA                                                             */
/* ------------------------------------------------------------------ */

/*
 * LIDA_POR e uma lista de e-mails por virgula. Conferir com indexOf no
 * texto inteiro fazia a leitura da joana@ valer para a ana@ (substring).
 */
function lidaPor_(m, eu) {
  const alvo = String(eu || '').toLowerCase().trim();
  return !!alvo && String(m.LIDA_POR || '').toLowerCase().split(',')
    .map(function (x) { return x.trim(); }).indexOf(alvo) !== -1;
}

function hidratarMensagem(m, eu) {
  const autor = String(m.AUTOR || '').toLowerCase().trim();
  return {
    id: String(m.ID || ''),
    contexto: String(m.CONTEXTO || '').toUpperCase().trim(),
    alvo: String(m.ALVO || ''),
    autor: autor,
    autorNome: String(m.AUTOR_NOME || '').trim() || autor.split('@')[0],
    texto: String(m.TEXTO || ''),
    link: String(m.LINK || '').trim(),
    anexos: listarAnexos(m.ANEXOS),
    quando: String(m.CRIADO_EM || '').trim(),
    minha: autor === String(eu || '').toLowerCase().trim(),
    lida: lidaPor_(m, eu)
  };
}

function mensagensDe(contexto, alvo, eu) {
  const alvoTexto = String(alvo || '');
  const ctx = String(contexto || '').toUpperCase().trim();

  const achadas = listar('MENSAGENS').filter(function (m) {
    return String(m.CONTEXTO || '').toUpperCase().trim() === ctx &&
           String(m.ALVO || '') === alvoTexto;
  });

  // Mais antiga em cima — e uma conversa, nao um feed de noticias. Pela
  // ordem real (ver instanteDeMensagem_), e so depois o corte das 200.
  achadas.sort(porInstante_);

  const recortadas = achadas.length > CONVERSA_LIMITE
    ? achadas.slice(achadas.length - CONVERSA_LIMITE) : achadas;

  return recortadas.map(function (m) { return hidratarMensagem(m, eu); });
}

/** Mensagens de UMA atividade — chamado ao abrir a janela da atividade. */
function mensagensDaAtividade(idAtividade, eu) {
  return mensagensDe(CONVERSA_ATIVIDADE, idAtividade, eu);
}

/**
 * Tela Conversas: a lista de pessoas na esquerda e o fio aberto na
 * direita. A lista mostra so quem ja trocou mensagem com voce mais todo
 * mundo que tem acesso — comecar uma conversa nao pode exigir cadastro.
 */
function dadosConversa(usuario, params) {
  const eu = String(usuario.email || '').toLowerCase().trim();
  const com = String((params && params.com) || '').toLowerCase().trim();

  const todas = listar('MENSAGENS').filter(function (m) {
    return String(m.CONTEXTO || '').toUpperCase().trim() === CONVERSA_DIRETA &&
           participantes_(m.ALVO).indexOf(eu) !== -1;
  });

  // Resumo por pessoa: ultima mensagem e quantas nao lidas.
  const porPessoa = {};
  todas.forEach(function (m) {
    const chave = String(m.ALVO || '');
    const outro = outroLado(chave, eu);
    if (!outro) return;
    if (!porPessoa[outro]) {
      porPessoa[outro] = { email: outro, ultima: '', quando: '', ordem: -1, naoLidas: 0 };
    }
    const ordem = instanteDeMensagem_(m);
    if (ordem > porPessoa[outro].ordem) {
      porPessoa[outro].ordem = ordem;
      porPessoa[outro].quando = String(m.CRIADO_EM || '');
      porPessoa[outro].ultima = String(m.TEXTO || '').slice(0, 90);
    }
    const autor = String(m.AUTOR || '').toLowerCase().trim();
    const lida = lidaPor_(m, eu);
    if (autor !== eu && !lida) porPessoa[outro].naoLidas++;
  });

  const pessoas = pessoasParaAcao().filter(function (p) { return p.email !== eu; });
  const nomes = {};
  pessoas.forEach(function (p) { nomes[p.email] = p.nome; });

  const conversas = Object.keys(porPessoa).map(function (e) {
    const c = porPessoa[e];
    c.nome = nomes[e] || e.split('@')[0];
    return c;
  }).sort(function (a, b) { return b.ordem - a.ordem; });

  const aberta = com
    ? { com: com, nome: nomes[com] || com.split('@')[0],
        mensagens: mensagensDe(CONVERSA_DIRETA, chaveDireta(eu, com), eu) }
    : null;

  /*
   * Abrir a conversa NAO grava mais nada aqui. Marcar como lida dentro da
   * leitura da tela era uma gravacao por abertura — e toda gravacao
   * aposenta o cache de tela de todo mundo. A tela pinta primeiro e, se
   * houver nao lidas, pede 'marcarLida' em segundo plano.
   */
  if (aberta) {
    aberta.naoLidas = aberta.mensagens.filter(function (m) { return !m.minha && !m.lida; }).length;
  }

  const dados = {
    conversas: conversas,
    pessoas: pessoas,
    aberta: aberta,
    eu: eu,
    podeConversar: podeFazer(usuario, 'CONVERSAR'),
    podeVerFeedback: podeFazer(usuario, 'GERIR_ACESSOS')
  };

  if (dados.podeVerFeedback) dados.feedbacks = listarFeedback();
  return dados;
}

/* ------------------------------------------------------------------ */
/* ESCRITA                                                             */
/* ------------------------------------------------------------------ */

/**
 * Envia mensagem. Serve para os dois contextos:
 *   { contexto:'ATIVIDADE', alvo:'<id da atividade>', texto, link }
 *   { contexto:'DIRETO',    para:'fulano@...',        texto, link }
 *
 * A foto vai separada, em `arquivo` ({nome, tipo, dados em base64}),
 * porque ela precisa do ID da mensagem ja gravado para ir na pasta certa.
 */
function acaoEnviarMensagem(usuario, params) {
  exigirCapacidade(usuario, 'CONVERSAR');

  const texto = String(params.texto || '').trim();
  const link = String(params.link || '').trim();
  const temArquivo = !!(params.arquivo && params.arquivo.dados);
  if (!texto && !link && !temArquivo) throw new Error('Escreva alguma coisa antes de enviar.');

  if (link && !/^https?:\/\//i.test(link)) {
    throw new Error('O link precisa começar com http:// ou https://');
  }

  const contexto = String(params.contexto || CONVERSA_ATIVIDADE).toUpperCase().trim();
  let alvo = '', para = '';

  if (contexto === CONVERSA_ATIVIDADE) {
    alvo = String(params.alvo || '').trim();
    if (!alvo) throw new Error('Mensagem sem atividade.');
    // A mesma regra de alcance da atividade vale para a conversa dela:
    // ninguem comenta numa atividade que nao pode nem abrir.
    garantirAlcance(usuario, alvo);
  } else if (contexto === CONVERSA_DIRETA) {
    para = String(params.para || '').toLowerCase().trim();
    if (!para) throw new Error('Informe para quem é a mensagem.');
    if (para === String(usuario.email || '').toLowerCase().trim()) {
      throw new Error('A conversa direta é entre duas pessoas: escolha outra pessoa na lista.');
    }
    /*
     * SEGURANCA: `para` so precisava ter "@". O valor volta na lista de
     * conversas do destinatario — e ia parar dentro de um onclick: dava
     * para mandar mensagem para "0'});<codigo>;//gerente@..." e o codigo
     * rodava na sessao de quem clicasse na conversa. Agora so vale o
     * e-mail EXATO de uma pessoa ativa desta filial.
     */
    if (!pessoaAtivaDaFilial_(para)) {
      throw new Error('"' + para + '" não está entre as pessoas ativas desta filial. Escolha a pessoa na lista.');
    }
    alvo = chaveDireta(usuario.email, para);
  } else {
    throw new Error('Contexto de conversa desconhecido: ' + contexto);
  }

  /*
   * A foto sobe ANTES e a linha nasce uma vez so, ja com nome, tamanho e
   * link do anexo (lista JSON em ANEXOS). Antes eram duas gravacoes
   * (inserir e depois atualizar ANEXOS) e, na leitura, uma ida ao Drive
   * POR FOTO toda vez que a conversa abria. O ID e reservado aqui porque
   * nomeia a pasta do anexo.
   */
  const id = gerarId('MENSAGENS');
  let anexo = null;
  if (temArquivo) anexo = gravarArquivoNoDrive_(usuario, 'MENSAGENS', id, params.arquivo);

  inserir('MENSAGENS', {
    ID: id,
    CONTEXTO: contexto,
    ALVO: alvo,
    AUTOR: String(usuario.email || '').toLowerCase().trim(),
    AUTOR_NOME: usuario.nome || usuario.papel || usuario.email,
    TEXTO: texto,
    LINK: link,
    ANEXOS: anexo ? JSON.stringify([metadadosDoAnexo_(anexo)]) : '',
    PARA: para,
    // Quem escreveu ja leu. Sem isto a propria mensagem contava como nao lida.
    LIDA_POR: String(usuario.email || '').toLowerCase().trim()
  }, usuario.email);
  if (anexo) registrarLog(usuario.email, 'ANEXAR', 'MENSAGENS', id, anexo.nome);

  let avisoEmail = '';
  try { avisarMensagem(usuario, contexto, alvo, para, texto); }
  catch (e) { avisoEmail = 'Mensagem enviada, mas o aviso por e-mail não saiu: ' + (e.message || e); }

  const r = { id: id, anexo: anexo, recado: 'Enviado.' };
  if (avisoEmail) r.avisoEmail = avisoEmail;
  return r;
}

/** Lista as mensagens de uma atividade — usada pela janela da atividade. */
function acaoMensagensAtividade(usuario, params) {
  const id = String(params.id || '').trim();
  garantirAlcance(usuario, id);
  const msgs = mensagensDaAtividade(id, usuario.email);
  marcarLidas(usuario, CONVERSA_ATIVIDADE, id);
  return { id: id, mensagens: msgs };
}

function acaoConversaDireta(usuario, params) {
  exigirCapacidade(usuario, 'CONVERSAR');
  const com = String(params.com || '').toLowerCase().trim();
  if (!com) throw new Error('Informe com quem é a conversa.');
  const chave = chaveDireta(usuario.email, com);
  const msgs = mensagensDe(CONVERSA_DIRETA, chave, usuario.email);
  marcarConversaLida(usuario, chave);
  return { com: com, mensagens: msgs };
}

/*
 * Marca como lidas as mensagens que nao sao minhas. Uma escrita em lote,
 * lida e gravada na mesma trava: duas pessoas marcando juntas a mesma
 * mensagem nao apagam a marca uma da outra (LIDA_POR e uma lista).
 */
function marcarLidas(usuario, contexto, alvo) {
  const eu = String(usuario.email || '').toLowerCase().trim();
  const ctx = String(contexto || '').toUpperCase().trim();

  // Sem nada para marcar (o caso comum), nem trava nem gravacao.
  const pendente = function (m) {
    if (String(m.CONTEXTO || '').toUpperCase().trim() !== ctx) return false;
    if (String(m.ALVO || '') !== String(alvo)) return false;
    if (String(m.AUTOR || '').toLowerCase().trim() === eu) return false;
    return !lidaPor_(m, eu);
  };
  if (!listar('MENSAGENS').some(pendente)) return 0;

  return comTrava(function () {
    const mudancas = listar('MENSAGENS').filter(pendente).map(function (m) {
      const atual = String(m.LIDA_POR || '').trim();
      return { id: m.ID, campos: { LIDA_POR: atual ? atual + ',' + eu : eu } };
    });
    if (mudancas.length) atualizarVarios('MENSAGENS', mudancas, usuario.email);
    return mudancas.length;
  });
}

/*
 * 'marcarLida' — a tela chama em segundo plano, depois de pintar, so
 * quando ha nao lidas na conversa aberta. Sem agir() e sem recarregar.
 *   { contexto: 'DIRETO', com: 'fulano@...' }  ou
 *   { contexto: 'ATIVIDADE', id: '<id da atividade>' }
 */
function acaoMarcarLida(usuario, params) {
  const contexto = String((params && params.contexto) || CONVERSA_DIRETA).toUpperCase().trim();
  if (contexto === CONVERSA_DIRETA) {
    const com = String(params.com || '').toLowerCase().trim();
    if (!com) return { ok: true, marcadas: 0 };
    return { ok: true, marcadas: marcarConversaLida(usuario, chaveDireta(usuario.email, com)) };
  }
  if (contexto === CONVERSA_ATIVIDADE) {
    const id = String(params.id || params.alvo || '').trim();
    if (!id) return { ok: true, marcadas: 0 };
    garantirAlcance(usuario, id);
    return { ok: true, marcadas: marcarLidas(usuario, CONVERSA_ATIVIDADE, id) };
  }
  throw new Error('Contexto de conversa desconhecido: ' + contexto);
}

/* Pessoa ativa desta filial com exatamente este e-mail (mesma lista do "Responsavel"). */
function pessoaAtivaDaFilial_(email) {
  const alvo = String(email || '').toLowerCase().trim();
  return !!alvo && pessoasParaAcao().some(function (p) { return p.email === alvo; });
}

function marcarConversaLida(usuario, chave) {
  return marcarLidas(usuario, CONVERSA_DIRETA, chave);
}

/* ------------------------------------------------------------------ */
/* AVISO POR E-MAIL                                                    */
/* ------------------------------------------------------------------ */

function avisarMensagem(usuario, contexto, alvo, para, texto) {
  const de = usuario.nome || usuario.email;
  const trecho = String(texto || '').slice(0, 300);

  if (contexto === CONVERSA_DIRETA) {
    if (!para) return;
    enviar([para], 'Mensagem de ' + de + ' no GSL',
      '<p><strong>' + htmlSeguro(de) + '</strong> escreveu para você:</p>' +
      '<p style="border-left:3px solid #111785;padding-left:12px;color:#333">' +
      htmlSeguro(trecho) + '</p>' + rodapeLink());
    return;
  }

  // Conversa de atividade: avisa o outro lado — coordenador da atividade
  // e a gestao —, nunca quem acabou de escrever.
  const registro = obter('ATIVIDADES', alvo);
  if (!registro) return;

  const eu = String(usuario.email || '').toLowerCase().trim();
  const destinos = []
    .concat(emailsDoTurno(hidratar(registro)) || [])
    .concat(emailsDaGestao() || [])
    .map(function (e) { return String(e || '').toLowerCase().trim(); })
    .filter(function (e) { return e && e !== eu; });

  const unicos = [];
  destinos.forEach(function (e) { if (unicos.indexOf(e) === -1) unicos.push(e); });
  if (!unicos.length) return;

  enviar(unicos, 'Nova mensagem na atividade: ' + String(registro.ATIVIDADE || alvo),
    '<p><strong>' + htmlSeguro(de) + '</strong> escreveu na atividade ' +
    '<strong>' + htmlSeguro(registro.ATIVIDADE || alvo) + '</strong>:</p>' +
    '<p style="border-left:3px solid #111785;padding-left:12px;color:#333">' +
    htmlSeguro(trecho) + '</p>' +
    '<p>Responda pelo sistema, na própria atividade.</p>' + rodapeLink());
}

/* ------------------------------------------------------------------ */
/* FEEDBACK DE ERROS DA PLATAFORMA                                     */
/* ------------------------------------------------------------------ */

/**
 * Qualquer pessoa pode reportar. Nao exige capacidade nenhuma de
 * proposito: quem esta travado num erro e justamente quem tem menos
 * permissao para contornar.
 */
function acaoEnviarFeedback(usuario, params) {
  const texto = String(params.texto || '').trim();
  if (!texto) throw new Error('Descreva o que aconteceu.');

  const tipo = String(params.tipo || 'ERRO').toUpperCase().trim();
  const id = inserir('FEEDBACK', {
    TIPO: FEEDBACK_TIPOS.indexOf(tipo) !== -1 ? tipo : 'ERRO',
    TELA: String(params.tela || '').trim(),
    TEXTO: texto,
    AUTOR: String(usuario.email || '').toLowerCase().trim(),
    AUTOR_NOME: usuario.nome || usuario.email,
    NAVEGADOR: String(params.navegador || '').slice(0, 300),
    SITUACAO: 'ABERTO',
    RESPOSTA: '', RESPONDIDO_EM: '', RESPONDIDO_POR: ''
  }, usuario.email);

  let avisoEmail = '';
  try {
    const admin = prop('EMAIL_ADMIN', '');
    if (admin) {
      enviar([admin], '[GSL] ' + tipo + ' reportado por ' + (usuario.nome || usuario.email),
        '<p><strong>' + htmlSeguro(usuario.nome || usuario.email) + '</strong> reportou:</p>' +
        '<p style="border-left:3px solid #C62828;padding-left:12px">' + htmlSeguro(texto) + '</p>' +
        '<p style="color:#666;font-size:12px">Tela: ' + htmlSeguro(params.tela || '—') +
        '<br>Navegador: ' + htmlSeguro(String(params.navegador || '—').slice(0, 200)) + '</p>' +
        rodapeLink());
    }
  } catch (e) {
    avisoEmail = 'Registrei o seu relato, mas o aviso por e-mail não saiu: ' + (e.message || e);
  }

  const r = { id: id, recado: 'Recebi. Obrigado por avisar.' };
  if (avisoEmail) r.avisoEmail = avisoEmail;
  return r;
}

function listarFeedback() {
  return listar('FEEDBACK').map(function (f) {
    return {
      id: String(f.ID || ''),
      tipo: String(f.TIPO || '').toUpperCase().trim(),
      tela: String(f.TELA || '').trim(),
      texto: String(f.TEXTO || ''),
      autorNome: String(f.AUTOR_NOME || '').trim() || String(f.AUTOR || '').split('@')[0],
      autor: String(f.AUTOR || ''),
      quando: String(f.CRIADO_EM || '').trim(),
      ordem: instanteDeMensagem_(f),
      situacao: String(f.SITUACAO || 'ABERTO').toUpperCase().trim(),
      resposta: String(f.RESPOSTA || '').trim()
    };
  }).sort(function (a, b) {
    // Abertos primeiro; dentro de cada grupo, o mais recente em cima —
    // pela ordem real, nao pelo texto 'dd/MM/yyyy' (ver instanteDeMensagem_).
    if (a.situacao !== b.situacao) return a.situacao === 'ABERTO' ? -1 : 1;
    return b.ordem - a.ordem;
  });
}

function acaoResolverFeedback(usuario, params) {
  exigirCapacidade(usuario, 'GERIR_ACESSOS');
  const id = String(params.id || '').trim();
  const registro = obter('FEEDBACK', id);
  if (!registro) throw new Error('Relato não encontrado.');

  atualizar('FEEDBACK', id, {
    SITUACAO: 'RESOLVIDO',
    RESPOSTA: String(params.resposta || '').trim(),
    RESPONDIDO_EM: agoraTexto(),
    RESPONDIDO_POR: usuario.email
  }, usuario.email);

  // Quem reportou merece saber que foi resolvido — e o que faz a proxima
  // pessoa reportar de novo em vez de desistir.
  try {
    const autor = String(registro.AUTOR || '').toLowerCase().trim();
    if (autor && params.resposta) {
      enviar([autor], '[GSL] Resolvido: o que você reportou',
        '<p>Você reportou:</p><p style="color:#666">' + htmlSeguro(registro.TEXTO) + '</p>' +
        '<p><strong>Resposta:</strong></p><p>' + htmlSeguro(params.resposta) + '</p>' + rodapeLink());
    }
  } catch (e) { /* o relato ja esta resolvido; o aviso e extra */ }

  return { recado: 'Relato resolvido.' };
}
