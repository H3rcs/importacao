/* GSL Bartofil — App.html (montado por ferramentas/montar-local.js; nao edite aqui) */

/* Cliente do GSL Bartofil.
   Leitura: carregarTela(filial, id, params) · Escrita: executarAcao(filial, nome, params) */

/*
 * REGRA DO HTMLSERVICE (4.2.2) — NUNCA escreva barra-barra nem barra-asterisco
 * dentro de texto, template (crase) ou regex neste arquivo e no Paineis.
 * Ao servir a pagina, o Google apaga o que PARECE comentario sem entender
 * crase: um accept="image/(asterisco)" num template engolia o codigo ate
 * o proximo fim de comentario e a tela travava na entrada com
 * "SyntaxError: Unexpected token 'class'". Escreva https:\/\/... e image/\*
 * (a barra invertida some no navegador). O teste testes/checar-htmlservice.js
 * confere isso antes de publicar.
 */

/*
 * GSL LOCAL — a pasta compartilhada da Bartofil, sem programa instalado.
 *
 * O ferramentas/montar-local.js monta a pasta GSL-Local (GSL.html e os
 * modulos .js e .css) com ESTES mesmos arquivos. Aberta da pasta (file://),
 * a pagina nao tem o google.script.run nem a carga dentro do HTML: aqui ela
 * ganha um google.script.run do mesmo jeito (withSuccessHandler,
 * withFailureHandler, a funcao pelo nome) que manda cada chamada por fetch()
 * ao /exec da implantacao, a API em JSON do doPost (ver API DA VERSAO LOCAL,
 * no Codigo.gs). O resto da tela nao muda. A carga inicial vem da API
 * ("inicio"). Sem cookie do Google no caminho, o "canal barrado" nao existe
 * aqui: CANAL_BARRADO nunca liga e nada navega para o /exec.
 * O endereco fica no gsl-config.js da pasta (GSL_CONFIG.url).
 */
const MODO_LOCAL = !!(typeof GSL_LOCAL !== 'undefined' && GSL_LOCAL) ||
  (location.protocol === 'file:' && typeof google === 'undefined');
let URL_ONLINE = '';         // o /exec da versao online (botao "Abrir a versão online")
function urlDaApi() {
  const c = (typeof GSL_CONFIG !== 'undefined' && GSL_CONFIG) || {};
  const u = String(c.url || '').trim();
  if (!/^https?:/i.test(u) || /COLE_AQUI/i.test(u)) return '';
  // O endereco com /a/macros/<dominio>/ pede o login da empresa; sem login, vale o /macros/s/ (mesma implantacao).
  return u.replace(new RegExp('/a/macros/[^/]+/s/'), '/macros/s/');
}
/*
 * Erro de transporte (servidor fora do alcance, endereco errado): a mensagem ja e legivel
 * (vai assim para qualquer aviso) e o explicarErro completa com o que conferir (RE_SEM_API).
 */
const RE_SEM_API = /^(Sem conexão com o servidor do GSL|Falta o endereço do servidor|O endereço do gsl-config\.js respondeu)/;
function erroDeApi(texto) { const e = new Error(texto); e.semApi = true; return e; }
function chamarApi(fn, args) {
  const url = urlDaApi();
  if (!url) return Promise.reject(erroDeApi('Falta o endereço do servidor no arquivo gsl-config.js da pasta GSL-Local.'));
  // text/plain: pedido "simples", sem preflight (o Apps Script nao responde OPTIONS). Sem cookie: a sessao e a do GSL.
  return fetch(url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, credentials: 'omit',
    cache: 'no-store', redirect: 'follow', body: JSON.stringify({ api: 1, fn: fn, args: args || [] }) })
    .catch(() => { throw erroDeApi('Sem conexão com o servidor do GSL.'); })
    .then((r) => r.text().then((t) => ({ codigo: r.status, texto: t })))
    .then((x) => {
      let j = null;
      try { j = JSON.parse(x.texto); } catch (e) { j = null; }
      if (!j || typeof j !== 'object' || typeof j.ok !== 'boolean') {
        throw erroDeApi('O endereço do gsl-config.js respondeu (código ' + x.codigo + '), mas não é a API do GSL ' +
          '(Codigo.gs de antes da versão local, ou o endereço de outra coisa).');
      }
      if (!j.ok) throw new Error(String(j.erro || 'Erro desconhecido.'));
      return j.valor;
    });
}
/* O google.script.run da pagina local: a mesma cara, outro caminho. */
function runLocal(o) {
  return new Proxy({}, { get: function (alvo, nome) {
    if (nome === 'withSuccessHandler') return (f) => runLocal(Object.assign({}, o, { ok: f }));
    if (nome === 'withFailureHandler') return (f) => runLocal(Object.assign({}, o, { falha: f }));
    if (nome === 'withUserObject') return (u) => runLocal(Object.assign({}, o, { u: u }));
    if (typeof nome !== 'string') return undefined;
    return function () {
      chamarApi(nome, Array.prototype.slice.call(arguments)).then(
        (v) => { if (o.ok) o.ok(v, o.u); },
        (e) => { if (o.falha) o.falha(e, o.u); else setTimeout(() => { throw e; }); });
    };
  } });
}
if (MODO_LOCAL) {
  window.google = { script: {
    run: runLocal({}),
    // Como o do Google: so troca os parametros do endereco (o F5 nao reabre o link de e-mail).
    history: { push: function () {}, setChangeHandler: function () {},
      replace: function (estado, params) {
        try {
          const q = Object.keys(params || {}).map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(params[k])).join('&');
          history.replaceState(estado || null, '', location.pathname + (q ? '?' + q : ''));
        } catch (e) { /* endereco que o navegador nao deixa trocar: fica como esta */ }
      } },
    url: { getLocation: function (cb) { cb({ parameter: {}, parameters: {}, hash: '' }); } },
    host: { close: function () {}, setHeight: function () {}, setWidth: function () {}, editor: { focus: function () {} } }
  } };
}
/*
 * A carga inicial da pagina local: o que o doGet poria dentro do HTML (entrada,
 * link de e-mail com ?tela=, endereco online). Falhou a conexao: tenta mais uma
 * vez e, se nao der, a tela diz o que conferir (internet, implantacao em
 * "Qualquer pessoa", gsl-config.js) e oferece a versao online.
 */
async function cargaLocal() {
  if (!urlDaApi()) { mostrarSemApi(erroDeApi('Falta o endereço do servidor no arquivo gsl-config.js da pasta GSL-Local.')); return null; }
  const q = new URLSearchParams(location.search), pedido = {};
  ['tela', 'filial', 'acao', 'p', 'aba'].forEach((k) => { if (q.get(k)) pedido[k] = q.get(k); });
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    try {
      const carga = await chamarJSON('inicio', pedido);
      URL_ONLINE = (carga && carga.urlApp) || '';
      if (carga) carga.urlApp = '';     // a pagina local nunca vai sozinha para a online (Tentar de novo = recarregar a pasta)
      CARGA_INICIAL = carga;
      return carga || { ok: false, erro: 'O servidor não respondeu.' };
    } catch (e) {
      if (tentativa === 0 && falhaPassageira(e)) { await esperar(1500); continue; }
      mostrarSemApi(e);
      return null;
    }
  }
  return null;
}
function mostrarSemApi(e) {
  mostrarFalha(e);
  botaoVersaoOnline();
}
function botaoVersaoOnline() {
  const caixa = el('falha'), url = URL_ONLINE || urlDaApi();
  if (!caixa || !url || el('falha-online')) return;
  const b = document.createElement('button');
  b.id = 'falha-online'; b.type = 'button'; b.className = 'botao secundario';
  b.textContent = 'Abrir a versão online';
  b.onclick = function () { window.open(url, '_blank'); };
  caixa.appendChild(b);
}
function explicarSemApi(m) {
  return m + ' Confira: 1) a internet deste computador; 2) no Apps Script, em Implantar › Gerenciar implantações, ' +
    'a implantação com "Quem pode acessar: Qualquer pessoa" (com "Qualquer pessoa em Bartofil" o Google pede login e a pasta ' +
    'não conecta); 3) o endereço /exec no arquivo gsl-config.js da pasta GSL-Local. Enquanto isso, use a versão online.';
}

let SESSAO = null, paginaAtual = 'inicio', paramsAtual = {}, DADOS = null, TEMA = 'claro';
let paginaAnterior = null;   // qual tela ja estava desenhada — ver pintar()

/*
 * SEM LOGIN.
 *
 * O Google Workspace ja fez a entrada antes da pagina abrir (implantacao
 * "Qualquer pessoa da Bartofil"). O servidor sabe quem e a pessoa pela
 * sessao Google; o navegador nao guarda e nao manda e-mail, token nem
 * senha. O que o cliente informa em cada chamada e so a FILIAL em que a
 * pessoa esta — e o servidor confere se ela pode estar ali.
 */
let FILIAL = '';           // codigo da filial em uso (FSA, SSA...)
let URL_APP = '';          // endereco do /exec — para a navegacao de reserva

const CHAVE_FILIAL = 'gsl_ultima_filial';
function lerLocal(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function gravarLocal(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

/*
 * SESSAO (4.2). Quem entra digita e-mail e PIN; o servidor devolve um
 * codigo de sessao. Ele fica so nesta ABA (sessionStorage): fechou a aba,
 * acabou — o proximo que usar o computador digita o proprio e-mail.
 */
let TOKEN = '';
const CHAVE_SESSAO = 'gsl_sessao';
/*
 * 4.2.2 — o navegador DEVOLVE o sessionStorage quando a aba fechada e
 * reaberta (Ctrl+Shift+T, "continuar de onde parou"): o proximo a usar o
 * computador entrava como a pessoa anterior, sem PIN. Agora a aba anota a
 * hora em que a pagina saiu, e o codigo so vale se ela voltou em ate 15 s
 * — um F5. Aba restaurada depois disso pede e-mail e PIN.
 */
const CHAVE_SAIDA = 'gsl_saida';
/*
 * 10/10: o relogio do F5 conta do PRIMEIRO script da pagina nova (GSL_T0, no
 * alto do Index), nao do fim da carga — numa maquina lenta, montar a pagina
 * passava dos 15 s e a pessoa "saia sozinha". Janela de 20 s. Aba fechada e
 * reaberta depois disso continua pedindo o PIN; aba sem pagehide (descartada,
 * travou) tambem.
 */
const JANELA_F5_MS = 20000;
const CHAVE_NOME = 'gsl_nome', CHAVE_ONDE = 'gsl_onde';
function lerSs(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
function gravarSs(k, v) { try { if (v) sessionStorage.setItem(k, v); else sessionStorage.removeItem(k); } catch (e) {} }
function lerSessao() {
  try {
    const t = sessionStorage.getItem(CHAVE_SESSAO) || '';
    const saiu = Number(sessionStorage.getItem(CHAVE_SAIDA) || 0);
    sessionStorage.removeItem(CHAVE_SAIDA);
    const ref = (typeof GSL_T0 === 'number' && GSL_T0) || Date.now();
    if (!t || !saiu || ref - saiu > JANELA_F5_MS) { gravarSessao(''); return ''; }
    return t;
  } catch (e) { return ''; }
}
/* Codigo da sessao (e o primeiro nome, para o "Continuar como ...") so nesta aba. */
function gravarSessao(t, nome) {
  gravarSs(CHAVE_SESSAO, t || '');
  if (!t) { gravarSs(CHAVE_NOME, ''); gravarSs(CHAVE_ONDE, ''); }
  else if (nome) gravarSs(CHAVE_NOME, String(nome).split(' ')[0]);
}
window.addEventListener('pagehide', function () {
  try { if (TOKEN) sessionStorage.setItem(CHAVE_SAIDA, String(Date.now())); } catch (e) {}
});
/* A tela em que a aba esta (para o F5 e o "Continuar" voltarem nela). So ids e filtros. */
function lembrarTelaDaAba(tela, params) {
  if (!TOKEN) return;
  gravarSs(CHAVE_ONDE, JSON.stringify({ f: FILIAL, tela: tela || '', p: params && Object.keys(params).length ? JSON.stringify(params) : '' }));
}
function telaDaAba() {
  // Link de e-mail vale mais. O ?tela= que a propria pagina da reserva poe na barra (daAba) e o da
  // tela que ELA abriu: a aba pode ter andado depois (outra tela, filtros) — vale a posicao da aba.
  const d = destinoDoLink(), onde = lerSs(CHAVE_ONDE);
  if (d && d.tela && !(d.daAba && onde)) return { tela: d.tela, p: paramsDoLinkJson(d), f: d.filial || '' };
  if (d && d.daAba) esquecerDestinoDoLink();      // senao o menu (montarSessao) abriria a tela velha do endereco
  try { return JSON.parse(onde || '{}') || {}; } catch (e) { return {}; }
}

/*
 * CANAL BARRADO. Em computador com varias contas Google (ou cookie de
 * terceiros bloqueado) o google.script.run falha — HTTP 403 ou o
 * PERMISSION_DENIED "reading from storage". Detectado uma vez, a entrada e
 * a saida passam a ir direto por POST (ver navegarPelaPagina).
 */
let CANAL_BARRADO = false;
const ctx = () => ({ t: TOKEN, f: FILIAL });
/*
 * 10/10 — O NAVEGADOR LEMBRA QUE E BARRADO. Antes cada pagina nova (F5,
 * POST da reserva) esquecia, e cada clique pagava uma chamada condenada de
 * 1 a 6 s antes de ir pela pagina — e, se o clique "vencesse" nesse meio
 * tempo, vinha o "Continuar". Agora fica guardada a HORA em que o canal
 * falhou de vez (localStorage, 12 h; nada que identifique a pessoa), e
 * qualquer chamada que passa (ou a sonda) apaga a marca.
 */
const CHAVE_CANAL = 'gsl_canal_barrado', CHAVE_SONDA = 'gsl_sonda';
const CANAL_LEMBRA_MS = 12 * 3600 * 1000;
function lembrarCanalBarrado() {
  if (MODO_LOCAL) return;          // pagina local: sem google.script.run, nao ha canal para barrar
  CANAL_BARRADO = true; gravarLocal(CHAVE_CANAL, String(Date.now()));
}
function esquecerCanalBarrado() { CANAL_BARRADO = false; try { localStorage.removeItem(CHAVE_CANAL); } catch (e) {} }
function canalBarradoLembrado() {
  const t = Number(lerLocal(CHAVE_CANAL) || 0);
  return !!t && Date.now() - t < CANAL_LEMBRA_MS;
}
let ULTIMO_CONTATO = Date.now();     // ultima ida ao servidor que conferiu a sessao (ver vigiarSessao)
const NAO_CONFERE_SESSAO = { renovarBilhete: true, sondarCanal: true, instalar: true };

const chamar = (f, ...a) => new Promise((ok, erro) => {
  const tk = TOKEN;                  // a sessao de quando o pedido saiu
  google.script.run.withSuccessHandler((v) => {
    if (CANAL_BARRADO || lerLocal(CHAVE_CANAL)) esquecerCanalBarrado();   // passou: nao e mais barrado
    if (TOKEN && TOKEN === tk && !NAO_CONFERE_SESSAO[f]) ULTIMO_CONTATO = Date.now();
    ok(v);
  }).withFailureHandler((e) => {
    // Sessao vencida (sem uso) ou apagada: volta para a entrada — so se a resposta e da sessao
    // de agora (a de quem saiu, chegando atrasada, derrubava quem entrou depois).
    if (/\[SESSAO\]/.test(String((e && e.message) || e || '')) && tk && tk === TOKEN) sessaoTerminou();
    if (canalBarradoDeVez(e)) lembrarCanalBarrado();
    erro(e);
  })[f](...a);
});

/*
 * SONDA: uma chamada que nao le nada (sondarCanal) descobre se o canal passa
 * ENQUANTO a pessoa digita o e-mail e o PIN — o clique de Entrar ja sabe o
 * caminho. Nas paginas da reserva, no maximo a cada 10 min, ve se o canal
 * voltou (ai os cliques seguintes voltam ao caminho rapido).
 */
let SONDA = '', SONDA_INDO = null, SONDA_BARROU_EM = 0;
function sondarCanal() {
  if (MODO_LOCAL) { SONDA = 'ok'; return Promise.resolve(true); }
  if (SONDA_INDO) return SONDA_INDO;
  if (typeof google === 'undefined' || !google.script || !google.script.run) return Promise.resolve(false);
  SONDA = 'indo';
  gravarSs(CHAVE_SONDA, String(Date.now()));
  let prazo = 0;
  const esta = new Promise((ok) => {
    const fim = (passou) => { clearTimeout(prazo); if (SONDA_INDO === esta) SONDA_INDO = null; ok(passou); };
    prazo = setTimeout(() => { if (SONDA === 'indo') SONDA = 'erro'; fim(false); }, 10000);
    try {
      google.script.run
        .withSuccessHandler(function () { SONDA = 'ok'; if (CANAL_BARRADO || lerLocal(CHAVE_CANAL)) esquecerCanalBarrado(); fim(true); })
        .withFailureHandler(function (e) {
          SONDA = canalBarradoDeVez(e) ? 'barrado' : 'erro';
          if (SONDA === 'barrado') { lembrarCanalBarrado(); SONDA_BARROU_EM = Date.now(); }
          fim(false);
        })
        .sondarCanal();
    } catch (e) { SONDA = 'erro'; fim(false); }
  });
  SONDA_INDO = esta;
  return esta;
}
/*
 * 20/10 — CONFERIR ANTES DE RECUSAR. A pagina que veio pela reserva (e o
 * navegador que lembra de uma falha de horas atras) comeca achando que o
 * canal e barrado. Recusar foto e arquivo na hora, sem tentar, dava o erro
 * na primeira foto do visor e passava na segunda (a sonda ja tinha voltado
 * e apagado a marca). Agora a sonda confere antes: so a recusa de verdade
 * (ou uma de menos de 2 min atras) segura o pedido.
 */
function canalLivre() {
  if (!CANAL_BARRADO) return Promise.resolve(true);
  if (SONDA === 'barrado' && Date.now() - SONDA_BARROU_EM < 2 * 60000) return Promise.resolve(false);
  return sondarCanal();
}
function sondarDeVezEmQuando() {
  if (Date.now() - Number(lerSs(CHAVE_SONDA) || 0) > 10 * 60 * 1000) setTimeout(sondarCanal, 4000);
}
/*
 * GERACAO DA SESSAO: sobe quando a pessoa sai (ou a sessao termina, ou
 * entra outra no lugar). A resposta de um pedido feito ANTES disso e
 * abandonada (a promessa nao se resolve): senao a tela de quem saiu
 * voltava para a pagina, para o cache da proxima pessoa, ou abria uma
 * janela por cima da entrada.
 */
let GERACAO_SESSAO = 0;
const chamarJSON = async (f, ...a) => {
  const geracao = GERACAO_SESSAO;
  let bruto;
  try { bruto = await chamar(f, ...a); } catch (e) {
    if (geracao !== GERACAO_SESSAO) return new Promise(() => {});
    throw e;
  }
  if (geracao !== GERACAO_SESSAO) return new Promise(() => {});
  if (!bruto) throw new Error('O servidor não respondeu. Recarregue a página.');
  return typeof bruto === 'string' ? JSON.parse(bruto) : bruto;
};

const carregarTelaSrv = (id, params) => {
  const filial = FILIAL;
  return chamarJSON('carregarTela', ctx(), id, params || {}).then((r) => {
    if (filial === FILIAL) notarBolinhaDaTela(id, r);    // o "Em aberto" que acabou de chegar vira o numero da bolinha
    return r;
  });
};
/*
 * Com o canal barrado de verdade (a sonda conferiu), as acoes chamadas direto,
 * fora do agir (abrir uma foto, anexar arquivo na entrega), nao tem caminho:
 * a explicacao em vez de uma chamada condenada. As gravacoes do agir, com
 * foto ou sem, vao pela pagina.
 */
const SEM_CANAL_PARA_ARQUIVO = 'Este computador bloqueia a conversa direta com o Google, e esta função precisa dela. ' +
  'Use um navegador só com a conta @bartofil.com.br (ou outro computador).';
const executarAcaoSrv = async (nome, params) => {
  if (CANAL_BARRADO && !LEITURAS_PELA_PAGINA[nome] && !(await canalLivre())) throw new Error(SEM_CANAL_PARA_ARQUIVO);
  return chamarJSON('executarAcao', ctx(), nome, params || {});
};
/* Leituras que tem caminho proprio pela pagina com o canal barrado (ver fichaPelaPagina). */
const LEITURAS_PELA_PAGINA = { fichaColaborador: true };
const esc = (t) => String(t == null ? '' : t)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
/*
 * ARGUMENTO DE onclick. Dentro de onclick="fn('...')" o navegador DECODIFICA
 * o HTML antes de rodar o JS — entao esc() sozinho nao protege: uma aspa
 * simples num codigo, e-mail ou link fechava a string e virava codigo
 * rodando no navegador de quem abrisse a tela. jsArg(v) devolve o literal
 * JS pronto (aspas e barras escapadas pelo JSON) e so depois escapa o HTML.
 * Uso: onclick="abrirItem(${jsArg(i.codigo)})" — sem aspas em volta.
 */
const jsArg = (v) => esc(JSON.stringify(v == null ? '' : String(v)));
const el = (id) => document.getElementById(id);
const val = (id) => (el(id) ? el(id).value : '');
const marcado = (id) => (el(id) ? el(id).checked : false);

/* ------------------------------------------------------------------ */
/* FLUIDEZ                                                             */
/*                                                                     */
/* Reclamacao real de quem usa no CD: "as telas abrem rapido, mas as    */
/* animacoes dao uma sensacao de lentidao". Nao da para saber daqui que */
/* maquina a pessoa tem — entao o app mede e, se preciso, liga o MODO   */
/* LEVE (ceu parado, sem desfoque). A decisao fica neste navegador.     */
/* ------------------------------------------------------------------ */

const CHAVE_LEVE = 'gsl_modo_leve';

function lerModoLeve() { return lerLocal(CHAVE_LEVE); }
function aplicarModoLeve(ligado) {
  document.documentElement.classList.toggle('modo-leve', !!ligado);
  const b = el('modo-leve-alternar');
  if (b) b.title = ligado
    ? 'Modo leve LIGADO — animações desligadas. Clique para voltar as animações.'
    : 'Modo leve desligado. Clique para desligar as animações e ganhar fluidez.';
  gravarLocal(CHAVE_LEVE, ligado ? '1' : '0');
}
function alternarModoLeve() {
  const agora = !document.documentElement.classList.contains('modo-leve');
  aplicarModoLeve(agora);
  avisar(agora ? 'Modo leve ligado — animacoes desligadas.'
               : 'Modo leve desligado — animacoes de volta.');
  if (paginaAtual === 'config') abrir('config', paramsAtual);
}

/*
 * BARRA LATERAL RECOLHIVEL (14/10). O botao ao lado do titulo esconde a
 * barra lateral e os paineis ganham a largura toda. A escolha fica neste
 * navegador (como o modo leve). Escondida, ela sai tambem da ordem do Tab.
 */
const CHAVE_LATERAL = 'gsl_lateral_oculta';
function aplicarLateral(oculta) {
  const app = el('aplicacao');
  if (!app) return;
  app.classList.toggle('lateral-oculta', !!oculta);
  const b = el('lateral-alternar');
  if (b) {
    const t = oculta ? 'Mostrar a barra lateral' : 'Ocultar a barra lateral';
    b.setAttribute('aria-expanded', oculta ? 'false' : 'true');
    b.setAttribute('aria-label', t);
    b.title = t;
  }
}
function alternarLateral() {
  const oculta = !(el('aplicacao') && el('aplicacao').classList.contains('lateral-oculta'));
  aplicarLateral(oculta);
  gravarLocal(CHAVE_LATERAL, oculta ? '1' : '0');
  // a largura do conteudo muda sem a janela mudar: quem desenha pela largura da caixa (graficos do Aprendiz) redesenha
  setTimeout(() => { try { window.dispatchEvent(new Event('resize')); } catch (e) {} }, 320);
}
aplicarLateral(lerLocal(CHAVE_LATERAL) === '1');

function medirFluidez() {
  const salvo = lerModoLeve();
  if (salvo !== null) { aplicarModoLeve(salvo === '1'); return; }
  try {
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      return aplicarModoLeve(true);
    }
    const nucleos = navigator.hardwareConcurrency || 8;
    const memoria = navigator.deviceMemory || 8;
    if (nucleos <= 2 || memoria <= 2) return aplicarModoLeve(true);
  } catch (e) { /* navegador sem essas informacoes: mede na marra */ }

  setTimeout(function () {
    let quadros = 0;
    const inicio = performance.now();
    const contar = function () {
      quadros++;
      const decorrido = performance.now() - inicio;
      if (decorrido < 1000) return requestAnimationFrame(contar);
      aplicarModoLeve(quadros / (decorrido / 1000) < 45);
    };
    requestAnimationFrame(contar);
  }, 400);
}

/* Aba em segundo plano: congela o ceu. */
function vigiarVisibilidade() {
  const ajustar = function () {
    document.documentElement.classList.toggle('aba-oculta', document.hidden);
  };
  document.addEventListener('visibilitychange', ajustar);
  ajustar();
}

/*
 * TEMA — guardado NESTE navegador.
 * Antes ia para as propriedades de usuario do servidor. Com "Executar
 * como: eu", essas propriedades sao as do dono do script — iguais para
 * todo mundo: um trocava o tema e mudava o de todos.
 */
const CHAVE_TEMA = 'gsl_tema';
function aplicarTema(tema) {
  TEMA = (tema === 'escuro') ? 'escuro' : 'claro';
  document.documentElement.setAttribute('data-tema', TEMA);
  const b = el('tema-alternar');
  if (b) b.textContent = TEMA === 'escuro' ? '\u2600' : '\u263E';
}
function alternarTema() {
  aplicarTema(TEMA === 'escuro' ? 'claro' : 'escuro');
  gravarLocal(CHAVE_TEMA, TEMA);
}

/*
 * Comeca no DOMContentLoaded, nao no load (4.2.2): o load espera TODOS os
 * recursos da pagina — inclusive a folha das fontes do Google. Com
 * fonts.googleapis.com lento ou bloqueado, a entrada so aparecia quando a
 * fonte desistia.
 */
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
else setTimeout(iniciar, 0);

/*
 * ABERTURA — tudo o que a primeira tela precisa ja veio dentro do HTML
 * (CARGA_INICIAL). Nenhuma chamada ao servidor para abrir.
 */
async function iniciar() {
  try {
    aplicarTema(lerLocal(CHAVE_TEMA) || 'claro');
    medirFluidez();
    vigiarVisibilidade();
    // Pagina local (pasta GSL-Local): a carga vem da API, nao de dentro do HTML.
    const inicio = MODO_LOCAL ? await cargaLocal()
      : ((typeof CARGA_INICIAL !== 'undefined' && CARGA_INICIAL) ? CARGA_INICIAL : { ok: true });
    if (!inicio) return;                 // a tela de "sem conexao com o servidor" ja esta na frente
    URL_APP = MODO_LOCAL ? '' : (inicio.urlApp || '');
    if (!MODO_LOCAL && (inicio.viaPost || canalBarradoLembrado())) CANAL_BARRADO = true;   // esta pagina ja veio pela reserva, ou o navegador ja sabe
    // A gravacao que esta aba mandou pela pagina (ver navegarPelaPagina): esta pagina e a resposta.
    ACAO_ENVIADA = Date.now() - Number(lerSs(CHAVE_ACAO) || 0) < 5 * 60000;
    gravarSs(CHAVE_ACAO, '');
    if (inicio.viaPost) {
      // A sessao desta pagina veio no proprio HTML: a marca do pagehide anterior nao vale mais.
      // Pagina RECUSADA (bilhete): a sessao nao veio — a marca decide o "Continuar" (lerSessao).
      if (!inicio.retomavel) gravarSs(CHAVE_SAIDA, '');
      // F5 ou Voltar numa pagina que veio por POST reenviava o POST (bilhete ja usado: "Por
      // seguranca..." e e-mail e PIN de novo). Trocando a entrada do historico, viram um GET, e a
      // aba continua com um clique. A tela vai no endereco para o "Continuar" voltar nela.
      try {
        // aba=1: o F5 sabe que esta tela foi a que a pagina abriu, nao um link (ver telaDaAba).
        const em = inicio.telaEmbutida && inicio.telaEmbutida.id ? { tela: inicio.telaEmbutida.id, aba: '1' } : {};
        if (inicio.filial && inicio.filial.codigo) em.filial = inicio.filial.codigo;
        google.script.history.replace(null, em, '');
      } catch (e) {}
      sondarDeVezEmQuando();
    } else if (inicio.entrada === 'ENTRAR' && !lerSs(CHAVE_SESSAO)) {
      sondarCanal();          // enquanto a pessoa digita e-mail e PIN, descobre se o canal passa
    }
    if (!inicio.ok) return mostrarFalha(inicio.erro);

    if (inicio.entrada === 'INSTALAR' || inicio.instalado === false) {
      if (MODO_LOCAL) {
        mostrarFalha('O GSL ainda não foi instalado. A instalação é feita uma vez, pela versão online (o endereço do Apps Script); ' +
          'depois disso a pasta GSL-Local funciona.');
        return botaoVersaoOnline();
      }
      soMostrar('instalacao');
      el('instalacao-conta').textContent = inicio.conta
        ? 'Você (' + inicio.conta + ') será cadastrado como administrador.'
        : 'Você será cadastrado como administrador.';
      if (inicio.conta) el('instalacao-email').value = inicio.conta;
      return;
    }
    if (inicio.entrada === 'ENTRAR') return retomarOuPedirEntrada(inicio);
    return tratarEntrada(inicio);
  } catch (e) { mostrarFalha(e.message || e); }
}

/* ------------------------------------------------------------------ */
/* ENTRADA — e-mail e PIN (4.2)                                        */
/* ------------------------------------------------------------------ */

/* Resposta do servidor (doGet, doPost, entrar, retomarSessao) -> tela certa. */
function tratarEntrada(r) {
  if (!r) return mostrarEntrada({ erroEntrada: 'O servidor não respondeu. Tente de novo.' });
  if (r.ok === false && !r.entrada) return mostrarEntrada({ erroEntrada: r.erro });
  if (r.entrada === 'SEM_SESSAO') return sessaoTerminou();
  if (r.entrada === 'APP' || r.entrada === 'ESCOLHER_FILIAL') {
    if (r.token) { TOKEN = r.token; gravarSessao(TOKEN, (r.usuario && r.usuario.nome) || ''); }
    ULTIMO_CONTATO = Date.now();
    if (r.entrada === 'APP') return montarSessao(r);
    return mostrarEscolhaFilial(r.filiais, r.usuario);
  }
  // Entrou, mas nao tem para onde ir (sem filial, desativado, sem nivel):
  // a sessao nao fica guardada — senao F5 e "tentar de novo" voltavam para
  // esta mesma tela, sem caminho para digitar outro e-mail.
  if (r.token) { try { google.script.run.withFailureHandler(function () {}).sairDoSistema({ t: r.token }); } catch (e) {} }
  TOKEN = ''; gravarSessao('');
  if (r.entrada === 'ENTRAR') return mostrarEntrada(r);
  return mostrarSemAcesso(r);
}

/*
 * A aba recarregou: se ainda tem sessao, entra sem pedir o PIN de novo.
 * 10/10 — a sessao valida NAO e mais jogada fora:
 *   - canal barrado (sabido, ou a pagina de reserva foi recusada): sem um
 *     clique o navegador nao deixa a moldura navegar, entao a tela pede um
 *     clique em "Continuar como Fulano" (e nao o e-mail e o PIN);
 *   - falha passageira: tenta de novo em 1,5 s; falhou de novo, o mesmo
 *     "Continuar" (o clique tenta outra vez).
 * Volta na tela em que a aba estava. A sessao so existe se passou pela regra
 * do F5 (lerSessao) e o servidor confere de novo (1 h sem uso).
 */
async function retomarOuPedirEntrada(inicio) {
  if (inicio.sessaoInvalida) gravarSessao('');
  const salvo = lerSessao();
  // A gravacao mandada pela pagina voltou na ENTRADA (pagina recusada, sessao vencida): nao foi feita.
  const naoFeita = ACAO_ENVIADA ? 'A última gravação não foi feita: faça de novo. ' : '';
  ACAO_ENVIADA = false;
  if (!salvo || (inicio.erroEntrada && !inicio.retomavel)) {
    return mostrarEntrada(naoFeita ? Object.assign({}, inicio, { erroEntrada: naoFeita + (inicio.erroEntrada || '') }) : inicio);
  }
  TOKEN = salvo;
  if (inicio.retomavel || (CANAL_BARRADO && URL_APP)) return mostrarContinuar(naoFeita ? { erroEntrada: naoFeita + 'Clique em Continuar.' } : undefined);
  soMostrar('carregando');
  const onde = telaDaAba();
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    try {
      const r = await chamarJSON('retomarSessao', { t: TOKEN, f: onde.f || lerLocal(CHAVE_FILIAL) || '', tela: onde.tela || '', p: onde.p || '' });
      // Erro do servidor (banco se atualizando, trava): a sessao continua; o clique tenta de novo.
      if (r && r.ok === false && !r.entrada) return mostrarContinuar({ erroEntrada: r.erro || 'O servidor não respondeu.' });
      if (r && r.telaEmbutida) { const d = destinoDoLink(); if (d && d.tela === r.telaEmbutida.id) esquecerDestinoDoLink(true); }
      return tratarEntrada(r);
    } catch (e) {
      if (canalBarradoDeVez(e) && URL_APP) { lembrarCanalBarrado(); return mostrarContinuar(); }
      if (tentativa === 0 && falhaPassageira(e)) { await esperar(1500); continue; }
      return mostrarContinuar({ erroEntrada: explicarErro(e) });
    }
  }
}

/* Um clique continua a sessao desta aba — sem e-mail nem PIN. */
function mostrarContinuar(info) {
  info = info || {};
  mostrarEntrada({ erroEntrada: info.erroEntrada || '' });
  const caixa = el('entrar-continuar');
  if (!caixa || !TOKEN) return;
  const b = el('entrar-continuar-botao');
  if (b) { b.disabled = false; b.innerHTML = 'Continuar como <b id="entrar-continuar-nome"></b>'; }
  el('entrar-continuar-nome').textContent = lerSs(CHAVE_NOME) || 'a sessão desta aba';
  const msg = el('entrar-continuar-msg');
  if (msg) { msg.textContent = info.erroEntrada || ''; msg.className = 'entrar-msg' + (info.erroEntrada ? ' erro' : ''); }
  caixa.classList.remove('oculto');
  el('form-entrar').classList.add('oculto');
  setTimeout(() => { const b = el('entrar-continuar-botao'); if (b) b.focus(); }, 60);
}
function esconderContinuar() {
  const caixa = el('entrar-continuar'); if (caixa) caixa.classList.add('oculto');
  const f = el('form-entrar'); if (f) f.classList.remove('oculto');
}
async function continuarSessao() {
  const b = el('entrar-continuar-botao');
  const onde = telaDaAba();
  const campos = { t: TOKEN, filial: onde.f || lerLocal(CHAVE_FILIAL) || '', tela: onde.tela || '', p: onde.p || '' };
  if (b) { b.disabled = true; b.innerHTML = 'Abrindo…'; }
  // Canal barrado: ja vai por POST, dentro do clique.
  if (CANAL_BARRADO && URL_APP) { navegarPelaPagina(campos); return; }
  const clique = Date.now();
  try {
    const r = await chamarJSON('retomarSessao', { t: TOKEN, f: campos.filial, tela: campos.tela, p: campos.p });
    if (r && r.ok === false && !r.entrada) throw new Error(r.erro || 'O servidor não respondeu.');
    if (r && r.telaEmbutida) { const d = destinoDoLink(); if (d && d.tela === r.telaEmbutida.id) esquecerDestinoDoLink(true); }
    esconderContinuar();
    tratarEntrada(r);
  } catch (e) {
    if (canalBloqueado(e) && URL_APP) {
      if (canalBarradoDeVez(e)) lembrarCanalBarrado();
      if (Date.now() - clique < 4500) { navegarPelaPagina(campos); return; }
    }
    mostrarContinuar({ erroEntrada: explicarErro(e) });
  }
}
/* "Nao e voce?": a sessao desta aba acaba (no servidor tambem) e volta o e-mail e o PIN. */
function naoSouEu() { esconderContinuar(); sair(); }

function mostrarEntrada(info) {
  info = info || {};
  esconderContinuar();
  soMostrar('entrar');
  const form = el('form-entrar');
  if (form && URL_APP) form.action = URL_APP;
  el('entrar-bilhete').value = bilheteDaPagina();
  if (info.emailDigitado) el('entrar-email').value = emailParaCampo(info.emailDigitado);
  sufixoDoEmail();
  el('entrar-pin').value = '';
  el('entrar-pin2').value = '';
  el('entrar-codigo').value = '';
  el('entrar-confirma').classList.toggle('oculto', !info.criarPin);
  el('entrar-codigo-caixa').classList.toggle('oculto', !info.pedirCodigo);
  const msg = el('entrar-msg');
  msg.textContent = info.erroEntrada || info.recado || '';
  msg.className = 'entrar-msg' + (info.erroEntrada ? ' erro' : (info.recado ? ' ok' : ''));
  setTimeout(() => { const alvo = el('entrar-email').value ? el(info.criarPin ? 'entrar-pin' : 'entrar-pin') : el('entrar-email'); if (alvo) alvo.focus(); }, 60);
}

/*
 * O formulario de entrada ja foi como POST: nenhum segundo envio. O servidor
 * queima o bilhete quando a entrada da certo, e um segundo POST com ele
 * (clique repetido enquanto a pagina nova nao chega) caia em "Por seguranca".
 */
let ENTRADA_ENVIADA = false;
function enviarFormEntrada() {
  if (ENTRADA_ENVIADA) return;
  ENTRADA_ENVIADA = true;
  const b = el('entrar-botao');
  b.disabled = true; b.textContent = 'Entrando…';
  el('form-entrar').submit();
  // Navegacao barrada (clique vencido): libera o botao para o proximo clique.
  setTimeout(() => {
    if (SAINDO_DA_PAGINA) return;
    liberarBotaoEntrar();
  }, 6000);
}
function liberarBotaoEntrar() {
  ENTRADA_ENVIADA = false;
  const b = el('entrar-botao');
  if (b) { b.disabled = false; b.textContent = 'Entrar'; }
}
// Voltar do navegador com a pagina guardada (bfcache): o botao nao fica preso em "Entrando…".
window.addEventListener('pageshow', function (ev) {
  if (ev.persisted) { SAINDO_DA_PAGINA = false; GRAVANDO_PELA_PAGINA = 0; liberarBotaoEntrar(); }
});

/* Trocou o e-mail: o codigo e a repeticao do PIN eram do primeiro acesso de OUTRO e-mail. */
function esquecerPrimeiroAcesso() {
  if (el('entrar-confirma').classList.contains('oculto') &&
      el('entrar-codigo-caixa').classList.contains('oculto')) return;
  el('entrar-confirma').classList.add('oculto');
  el('entrar-codigo-caixa').classList.add('oculto');
  el('entrar-codigo').value = ''; el('entrar-pin2').value = '';
  const msg = el('entrar-msg'); msg.textContent = ''; msg.className = 'entrar-msg';
}

/* 25/11: o campo mostra so o nome; o dominio da Bartofil completa (o servidor completa de novo). */
const DOMINIO_EMAIL = 'bartofil.com.br';
function completarEmail(v) {
  v = String(v || '').toLowerCase().replace(/\s+/g, '');
  if (!v) return '';
  if (v.indexOf('@') === -1) return v + '@' + DOMINIO_EMAIL;
  if (v.charAt(v.length - 1) === '@') return v + DOMINIO_EMAIL;
  return v;
}
function emailParaCampo(v) {
  v = String(v || '').trim();
  const fim = '@' + DOMINIO_EMAIL;
  return v.toLowerCase().slice(-fim.length) === fim ? v.slice(0, -fim.length) : v;
}
function sufixoDoEmail() {
  const campo = el('entrar-email-campo');
  if (campo) campo.classList.toggle('com-arroba', val('entrar-email').indexOf('@') !== -1);
}

async function entrarNoSistema(ev) {
  if (ev) ev.preventDefault();
  if (ENTRADA_ENVIADA) return false;
  const email = completarEmail(val('entrar-email'));
  const pin = val('entrar-pin').trim();
  const criando = !el('entrar-confirma').classList.contains('oculto');
  const conf = criando ? val('entrar-pin2').trim() : '';
  const pedindoCodigo = criando && !el('entrar-codigo-caixa').classList.contains('oculto');
  const codigo = pedindoCodigo ? val('entrar-codigo').replace(/\D/g, '') : '';
  const msg = el('entrar-msg');
  const falar = (t, tipo) => { msg.textContent = t; msg.className = 'entrar-msg ' + (tipo || 'erro'); };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { falar('Digite o seu usuário (o nome antes do @bartofil.com.br).'); return false; }
  if (!/^\d{4,6}$/.test(pin)) { falar('O PIN tem de 4 a 6 números.'); return false; }
  if (pedindoCodigo && !/^\d{6}$/.test(codigo)) { falar('Digite o código de 6 números que chegou no seu e-mail.'); return false; }
  if (criando && !conf) { falar('Repita o PIN no segundo campo.'); return false; }
  el('entrar-pin2').name = criando ? 'confirmacao' : '';
  el('entrar-codigo').name = pedindoCodigo ? 'codigo' : '';
  // A filial da ultima pessoa neste computador NAO vai junto: quem tem mais
  // de uma escolhe (antes caia direto na filial de quem usou antes).
  el('entrar-filial').value = (destinoDoLink() || {}).filial || '';
  // Link de e-mail (?tela=...): a tela ja volta montada junto com a entrada (uma ida so), com os filtros do link.
  if (el('entrar-tela')) el('entrar-tela').value = (destinoDoLink() || {}).tela || '';
  if (el('entrar-p')) el('entrar-p').value = paramsDoLinkJson(destinoDoLink());
  el('entrar-bilhete').value = bilheteDaPagina();
  // Canal ja sabidamente barrado: vai por POST ja, dentro do clique.
  if (CANAL_BARRADO && URL_APP) { enviarFormEntrada(); return false; }
  const clique = Date.now();
  const b = el('entrar-botao');
  b.disabled = true; b.textContent = 'Entrando…'; falar('', '');
  try {
    // A sonda (disparada quando a pagina abriu) corre junto com o entrar: se ela acusar o canal
    // barrado enquanto o clique ainda vale, a entrada vai por POST na hora (catch abaixo).
    const r = await Promise.race([
      chamarJSON('entrar', email, pin, conf, (destinoDoLink() || {}).filial || '', codigo, (destinoDoLink() || {}).tela || '',
        paramsDoLinkJson(destinoDoLink())),
      canalBarradoPelaSonda(clique)
    ]);
    if (r && r.telaEmbutida) { const d = destinoDoLink(); if (d && d.tela === r.telaEmbutida.id) esquecerDestinoDoLink(true); }
    if (r && r.criarPin) {
      el('entrar-confirma').classList.remove('oculto');
      el('entrar-codigo-caixa').classList.toggle('oculto', !r.pedirCodigo);
      falar(r.erro || r.recado || 'Primeiro acesso: repita o PIN para confirmar.', r.erro ? 'erro' : 'ok');
      el('entrar-pin2').value = '';
      (r.pedirCodigo && !val('entrar-codigo') ? el('entrar-codigo') : el('entrar-pin2')).focus();
      return false;
    }
    if (r && r.ok === false) {
      falar(r.erro || 'Não consegui entrar.');
      el('entrar-pin').value = '';
      el('entrar-pin').focus();
      return false;
    }
    tratarEntrada(r);
  } catch (e) {
    /*
     * O entrar() do servidor nunca falha (devolve JSON ate no erro): cair
     * aqui e o CANAL que falhou — 403, PERMISSION_DENIED de varias contas
     * Google, rede. O formulario vai como pagina (POST no /exec), que passa
     * onde a chamada nao passa. Mas a janela de cima so navega ate ~5 s
     * depois do clique: se a falha demorou mais, o proximo clique envia.
     */
    if (URL_APP) {
      if (canalBarradoDeVez(e)) lembrarCanalBarrado(); else CANAL_BARRADO = true;
      if (cliqueAindaVale(clique)) { enviarFormEntrada(); return false; }
      falar('A conexão com o Google falhou. Clique em Entrar de novo para continuar.', 'ok');
      return false;
    }
    falar(explicarErro(e));
  } finally {
    if (!ENTRADA_ENVIADA) { b.disabled = false; b.textContent = 'Entrar'; }
  }
  return false;
}

/* Rejeita (como erro de canal) se a sonda acusar o canal barrado enquanto o clique vale. */
function canalBarradoPelaSonda(clique) {
  return new Promise((ok, erro) => {
    const olhar = () => {
      if (SONDA === 'barrado' || (CANAL_BARRADO && lerLocal(CHAVE_CANAL))) return erro(new Error('PERMISSION_DENIED (sonda do canal)'));
      if (SONDA !== 'indo' || !cliqueAindaVale(clique)) return;   // sonda ok, ou clique vencido: o entrar decide
      setTimeout(olhar, 100);
    };
    olhar();
  });
}
/*
 * O navegador so deixa a moldura navegar a pagina ate ~5 s depois de um
 * clique (ativacao do usuario). Onde existe, a API diz na hora; senao, conta 4,5 s.
 */
function cliqueAindaVale(clique) {
  const ua = navigator.userActivation;
  return ua ? ua.isActive : Date.now() - clique < 4500;
}

/*
 * O que a pessoa estava vendo sai da pagina junto com ela (computador
 * compartilhado do CD): os dados da tela, a tela desenhada por baixo da
 * entrada e as escolhas guardadas nos modulos (Jovem Aprendiz).
 */
function apagarTelaDaPessoa() {
  GERACAO_SESSAO++;                 // o que ainda vem do servidor para quem saiu e abandonado
  pedidosDoUsuario = 0;             // ...e esses pedidos nunca vao descontar da fila
  DADOS = null;
  PENDENCIAS = null; PENDENCIAS_PEDIDO = '';      // as bolinhas eram de quem saiu (o pedido abandonado nunca termina)
  const pg = el('pagina'); if (pg) pg.innerHTML = '';
  // A janela fechada guardava a ficha inteira no HTML escondido; o visor, a ultima foto.
  try { fecharJanela(); } catch (e) {}
  ['janela-titulo', 'janela-corpo', 'janela-rodape', 'visor-imagem'].forEach((id) => { const x = el(id); if (x) x.innerHTML = ''; });
  if (typeof visorFechar === 'function') visorFechar();
  // O que as telas guardam fora do DADOS (assiduidade: a lista com as ausencias de todos).
  COLAB_CACHE = null; periodoParams = null; FICHA = { matricula: '', de: '', ate: '' };
  FOTO_CACHE.clear();
  if (typeof apzZerar === 'function') apzZerar();
  if (typeof qdZerar === 'function') qdZerar();       // o Quadro do CD de quem saiu (QD_MEMO guarda a GERAL inteira)
}

/* Sessao vencida no meio do uso. */
function sessaoTerminou() {
  if (!TOKEN && el('entrar') && !el('entrar').classList.contains('oculto')) return;
  TOKEN = ''; gravarSessao(''); SESSAO = null; apagarTelaDaPessoa(); avisoSessao(false);
  try { fecharJanela(); } catch (e) {}
  mostrarEntrada({ erroEntrada: 'Sua sessão terminou (ela acaba depois de 1 hora sem usar o sistema). Entre de novo com o seu e-mail e PIN.' });
}

/*
 * 1 HORA SEM USO, SEM SUSTO (10/10). A regra nao muda: 1 h sem usar o
 * sistema e a sessao acaba. O que muda e o que conta como uso:
 *   - a pessoa mexendo na tela (tecla, clique, rolagem) sem ir ao servidor
 *     ha 10 min: um manterSessao() discreto renova (so com o canal normal);
 *     aba esquecida, ninguem mexendo, nao renova nada;
 *   - 50 min sem ir ao servidor: faixa "sua sessao termina em N min" com o
 *     botao "Continuar conectado".
 */
let ULTIMA_ATIVIDADE = Date.now();
['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach((ev) =>
  document.addEventListener(ev, () => { ULTIMA_ATIVIDADE = Date.now(); }, { capture: true, passive: true }));
/*
 * O servidor anota o uso de 5 em 5 min (cache) e de 10 em 10 min (loja): o
 * prazo dele pode vencer ate 10 min antes da hora cheia. O relogio daqui conta
 * 50 min, o prazo mais curto: a faixa aparece aos 40 e, aos 50 sem ir ao
 * servidor E sem ninguem mexer na tela, a sessao acaba aqui tambem — a tela de
 * quem foi embora nao fica aberta para o proximo do computador.
 */
const SESSAO_LOCAL_MS = 50 * 60000, AVISO_SESSAO_MS = 40 * 60000;
function vigiarSessao() {
  if (!TOKEN || !SESSAO) return;
  const agora = Date.now(), parado = agora - ULTIMO_CONTATO, quieto = agora - ULTIMA_ATIVIDADE;
  if (!CANAL_BARRADO && quieto < 5 * 60000 && parado > 10 * 60000) {
    const tk = TOKEN;
    chamar('manterSessao', ctx()).then((r) => {
      if (tk !== TOKEN) return;                 // outra pessoa entrou nesse meio tempo
      let ok = true; try { ok = JSON.parse(r).ok !== false; } catch (e) {}
      if (ok) avisoSessao(false); else sessaoTerminou();
    }).catch(() => {});
    return;
  }
  if (parado >= SESSAO_LOCAL_MS && quieto >= SESSAO_LOCAL_MS) return encerrarPorFaltaDeUso();
  avisoSessao(parado > AVISO_SESSAO_MS ? Math.max(0, Math.round((SESSAO_LOCAL_MS - parado) / 60000)) : false);
}
setInterval(vigiarSessao, 60000);
function encerrarPorFaltaDeUso() {
  const t = TOKEN;
  if (t && !CANAL_BARRADO) { try { google.script.run.withFailureHandler(function () {}).sairDoSistema({ t: t }); } catch (e) {} }
  sessaoTerminou();
}
function avisoSessao(minutos) {
  let faixa = el('aviso-sessao');
  if (minutos === false) { if (faixa) faixa.remove(); return; }
  if (!faixa) {
    faixa = document.createElement('div'); faixa.id = 'aviso-sessao'; faixa.className = 'faixa-aviso';
    const pagina = el('pagina'); if (pagina && pagina.parentNode) pagina.parentNode.insertBefore(faixa, pagina); else document.body.prepend(faixa);
  }
  faixa.innerHTML = `${minutos > 0 ? `Sua sessão termina em ${minutos} min por falta de uso.` : 'Sua sessão está terminando por falta de uso.'}
    <button class="botao-texto" onclick="continuarConectado()">Continuar conectado</button>`;
}
let CONFIRMOU_RECARGA = false;
function continuarConectado() {
  if (CANAL_BARRADO) {
    // Sem o canal, continuar conectado e recarregar a pagina: o que estiver sendo escrito numa janela se perderia.
    if (temTextoDigitado() && !CONFIRMOU_RECARGA) {
      CONFIRMOU_RECARGA = true;
      return avisar('Para continuar conectado, a página vai recarregar. Salve (ou copie) o que está escrevendo e clique de novo em "Continuar conectado".', true);
    }
    CONFIRMOU_RECARGA = false;
    const tela = paginaAtual === 'modulos' ? '' : paginaAtual;
    const temP = tela && paramsAtual && Object.keys(paramsAtual).length;
    navegarPelaPagina({ t: TOKEN, filial: FILIAL, tela: tela, p: temP ? JSON.stringify(paramsAtual) : '' });
    return;
  }
  const tk = TOKEN;
  chamar('manterSessao', ctx()).then((r) => {
    if (tk !== TOKEN) return;
    let ok = true; try { ok = JSON.parse(r).ok !== false; } catch (e) {}
    if (ok) avisoSessao(false); else sessaoTerminou();
  }).catch((e) => avisar(explicarErro(e), true));
}
/* Alguma janela aberta com texto digitado (comentario, acao nova)? */
function temTextoDigitado() {
  const j = el('janela');
  if (!j || j.classList.contains('oculto')) return false;
  return Array.from(j.querySelectorAll('textarea, input')).some((c) =>
    !/^(hidden|checkbox|radio|file|button|submit)$/i.test(c.type || '') && String(c.value || '').trim());
}

/* A propria pessoa troca o PIN (o "senha" do GSL). */
function formTrocarPin() {
  abrirJanela('Trocar meu PIN', `
    <div class="campo"><label>PIN atual</label><input id="tp-atual" type="text" class="pin-mascara" inputmode="numeric" maxlength="6" autocomplete="off"></div>
    <div class="campo-duplo">
      <div class="campo"><label>PIN novo (4 a 6 números)</label><input id="tp-novo" type="text" class="pin-mascara" inputmode="numeric" maxlength="6" autocomplete="off"></div>
      <div class="campo"><label>Repita o PIN novo</label><input id="tp-conf" type="text" class="pin-mascara" inputmode="numeric" maxlength="6" autocomplete="off"></div>
    </div>
    <p class="dica">Esqueceu o PIN atual? Peça ao administrador: Pessoas e acessos › Zerar PIN.</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('trocarMeuPin',{atual:val('tp-atual'),novo:val('tp-novo'),confirmacao:val('tp-conf')}).catch(()=>{})">Trocar PIN</button>`);
  setTimeout(() => { const c = el('tp-atual'); if (c) c.focus(); }, 60);
}

function confirmarZerarPin(nome) {
  return window.confirm('Zerar o PIN de ' + nome + '? Na próxima entrada a pessoa cria um PIN novo.');
}

/*
 * Codigo de primeiro acesso gerado pelo administrador (Zerar PIN ou, para
 * quem ainda nao tem PIN, Codigo de acesso). Aparece numa janela — num
 * aviso que some em 7 s ninguem conseguiria anotar.
 */
async function gerarCodigoAcesso(id, nome, temPin) {
  if (temPin && !confirmarZerarPin(nome)) return;
  try {
    const r = await executarAcaoSrv('zerarPin', { id: id });
    esquecerTela(paginaAtual);
    abrirJanela('Código de primeiro acesso', `
      <p style="margin-top:0;line-height:1.7">Entregue este código para <b>${esc(r.nome)}</b> (${esc(r.email)}):</p>
      <p style="font-size:30px;font-weight:800;letter-spacing:8px;margin:6px 0 14px">${esc(r.codigo)}</p>
      <p class="dica">Vale 6 horas. Na entrada, a pessoa digita o e-mail e um PIN novo; o sistema pede este
        código e a repetição do PIN. Ela também pode receber um código no próprio e-mail, direto pela tela.</p>`,
      `<button class="botao" onclick="fecharJanela(); abrir(paginaAtual, paramsAtual)">Fechar</button>`);
  } catch (e) { avisar(e.message || e, true); }
}

/* Esconde todas as telas de entrada de uma vez. */
const TELAS_ENTRADA = ['carregando', 'falha', 'instalacao', 'entrar', 'sem-acesso', 'escolher-filial', 'aplicacao'];
function soMostrar(id) {
  TELAS_ENTRADA.forEach((t) => { const e = el(t); if (e) e.classList.add('oculto'); });
  const alvo = el(id); if (alvo) alvo.classList.remove('oculto');
}

/* ------------------------------------------------------------------ */
/* QUEM NAO ENTRA — e por que                                          */
/* ------------------------------------------------------------------ */

const TITULOS_SEM_ACESSO = {
  SEM_CONTA: 'Não reconheci a sua conta',
  SEM_CADASTRO: 'Acesso ainda não liberado',
  DESATIVADO: 'Acesso desativado',
  SEM_NIVEL: 'Falta definir o seu nível',
  SEM_FILIAL: 'Nenhuma filial liberada'
};

function mostrarSemAcesso(r) {
  soMostrar('sem-acesso');
  el('sem-acesso-titulo').textContent = TITULOS_SEM_ACESSO[r.entrada] || 'Acesso não liberado';
  el('sem-acesso-texto').textContent = r.motivo || 'Fale com o administrador do GSL.';
  const cartao = el('sem-acesso-cartao');
  cartao.classList.toggle('oculto', !r.conta);
  el('sem-acesso-conta').textContent = r.conta || '';
}

/*
 * Trocar de conta Google. Quem manda na conta conectada e o navegador,
 * nao o GSL — a tela explica o caminho.
 */
function trocarContaGoogle() {
  abrirJanela('Entrar com outra conta', `
    <ol style="line-height:1.9;padding-left:20px;color:var(--tinta-media);margin:0">
      <li>Clique em <b>Abrir contas do Google</b>.</li>
      <li>Saia da conta atual ou escolha a sua conta <b>@bartofil.com.br</b>.</li>
      <li>Volte para esta aba e clique em <b>Já troquei</b>.</li>
    </ol>`, `
    <button class="botao secundario" onclick="window.open('https:\/\/accounts.google.com/Logout','_blank')">Abrir contas do Google</button>
    <button class="botao" onclick="recarregarApp()">Já troquei</button>`);
}

/* ------------------------------------------------------------------ */
/* ESCOLHA DA FILIAL                                                   */
/* ------------------------------------------------------------------ */

let FILIAIS_DISPONIVEIS = [];

function mostrarEscolhaFilial(filiais, usuario) {
  FILIAIS_DISPONIVEIS = filiais || FILIAIS_DISPONIVEIS;
  soMostrar('escolher-filial');
  const ultima = lerLocal(CHAVE_FILIAL);
  const quem = usuario || (SESSAO && SESSAO.usuario) || {};
  el('escolher-filial-ola').textContent = quem.nome ? 'Olá, ' + quem.nome.split(' ')[0] + '.' : '';
  el('grade-filiais').innerHTML = FILIAIS_DISPONIVEIS.map((f) => `
    <a class="holocard azul cartao-filial ${f.codigo === ultima ? 'ultima' : ''}"
       href="#" onclick="return escolherFilial(${jsArg(f.codigo)})">
      <div class="holo-icone">${ICONES.filial}</div>
      <div class="holo-titulo">${esc(f.nome)}</div>
      <div class="holo-frase">${esc(f.cidade || '')}${f.cidade ? ' · ' : ''}${(f.paineis || []).length} painel(is)</div>
      <div class="holo-frase pequena">${esc((f.paineis || []).join(' · '))}</div>
      <div class="holo-rodape">
        <span class="holo-acao">${f.codigo === ultima ? 'Continuar aqui' : 'Entrar'}</span>
        <span class="holo-seta">\u2192</span>
      </div>
      <span class="holo-marca">${esc(f.codigo)}</span>
    </a>`).join('');
}

/*
 * Entrar numa filial: primeiro pelo canal normal (rapido, sem recarregar).
 * Se ele falhar — o HTTP 403 de maquina com cookie bloqueado —, vai por
 * navegacao de pagina (POST, ver navegarPelaPagina), que passa onde a
 * chamada nao passa, e o servidor ja devolve a filial montada no HTML.
 */
function escolherFilial(codigo) {
  gravarLocal(CHAVE_FILIAL, codigo);
  if (typeof google === 'undefined' || !google.script) { irParaFilial(codigo); return false; }
  if (CANAL_BARRADO && URL_APP) { irParaFilial(codigo); return false; }      // canal barrado: dentro do clique
  soMostrar('carregando');
  let respondeu = false;
  // Sem resposta em 12 s: volta aos cartoes. A navegacao de reserva precisa
  // de um clique recente, e o clique desta escolha ja "venceu".
  const reserva = setTimeout(() => {
    if (respondeu) return;
    respondeu = true;
    mostrarEscolhaFilial(FILIAIS_DISPONIVEIS);
    avisar('O servidor demorou para responder. Clique na filial de novo.', true);
  }, 12000);
  // Resposta (ou falha) que chega depois dos 12 s e de outra escolha: ignora
  // — senao abriria a filial que a pessoa ja abandonou.
  chamarJSON('abrirFilial', { t: TOKEN, f: codigo }).then((r) => {
    if (respondeu) return;
    respondeu = true; clearTimeout(reserva);
    if (r && (r.entrada === 'SEM_SESSAO' || /\[SESSAO\]/.test(r.erro || ''))) return sessaoTerminou();
    if (r && r.ok && r.entrada === 'APP') return montarSessao(r);
    if (r && r.entrada && r.entrada !== 'APP') return mostrarSemAcesso(r);
    mostrarFalha((r && r.erro) || 'Não consegui abrir a filial.');
  }).catch((e) => {
    if (respondeu) return;
    respondeu = true; clearTimeout(reserva);
    // Pagina local: nao ha reserva por pagina — volta aos cartoes e diz o que houve.
    if (MODO_LOCAL) { mostrarEscolhaFilial(FILIAIS_DISPONIVEIS); avisar(explicarErro(e), true); return; }
    irParaFilial(codigo);
  });
  return false;
}

function irParaFilial(codigo) {
  const destino = destinoDoLink();
  if (!navegarPelaPagina({ t: TOKEN, filial: codigo, tela: (destino && destino.tela) || '', p: paramsDoLinkJson(destino) })) {
    mostrarFalha('Não consegui abrir a filial e não sei o endereço do sistema para recarregar.');
  }
}

function trocarFilial() {
  if (!SESSAO || !(SESSAO.filiais || []).length) return;
  esquecerTelas();
  mostrarEscolhaFilial(SESSAO.filiais, SESSAO.usuario);
}

/* ------------------------------------------------------------------ */
/* SESSAO                                                              */
/* ------------------------------------------------------------------ */

function montarSessao(r) {
  if (!r || !r.usuario || !r.telas) {
    return mostrarFalha('O servidor não devolveu a sua sessão (usuário, telas e permissões). ' +
      'Recarregue a página; se continuar, use o botão Reportar erro.');
  }
  const quemEra = SESSAO && SESSAO.usuario ? SESSAO.usuario.email : '';
  if (quemEra && quemEra !== r.usuario.email) apagarTelaDaPessoa();   // outra pessoa: nada da anterior fica
  const filialEra = FILIAL;
  SESSAO = r;
  if (r.token) { TOKEN = r.token; gravarSessao(TOKEN, (r.usuario && r.usuario.nome) || ''); }
  ULTIMO_CONTATO = Date.now();
  FILIAL = (r.filial && r.filial.codigo) || '';
  // Outra filial: o portal do Jovem Aprendiz volta ao comeco (a busca e o aprendiz eram da outra).
  if (filialEra && filialEra !== FILIAL && typeof apzZerar === 'function') apzZerar();
  if (FILIAL) gravarLocal(CHAVE_FILIAL, FILIAL);
  // Bolinhas: a pagina da reserva ja traz; pelo canal normal vem depois do menu (atualizarPendencias).
  PENDENCIAS = r.pendencias ? { filial: FILIAL, quando: Date.now(), modulos: r.pendencias } : null;
  esquecerTelas();
  MENU_EM_USO = ++MENU_PEDIDOS;             // sessao nova: o menu dela vale mais que qualquer resposta ainda no caminho
  moduloAtual = null;
  filtroAtivo = null; filtroTurno = null;   // filtro do calendario era da filial/pessoa anterior
  montarMenu(r.telas);

  const u = r.usuario;
  el('usuario-nome').textContent = u.nome || u.papel || u.email;
  el('usuario-papel').textContent = [u.papel, u.perfil, u.turno ? 'turno ' + u.turno : '']
    .filter(Boolean).join(' · ');
  el('usuario-papel').title = u.email;
  el('usuario-conta').innerHTML = `<span class="selo-verificado">&#128274; ${esc(u.email)}</span>`;
  pintarCaixaFilial();

  const av = el('aviso-simulacao'); if (av) av.classList.toggle('oculto', !r.simulacao);
  conferirVersao(r);
  soMostrar('aplicacao');
  // A pagina veio de uma gravacao pela reserva: o recado (ou o erro) aparece aqui. Sem o resultado
  // (Codigo.gs antigo, resposta perdida), a pessoa precisa saber que nao houve confirmacao.
  if (r.resultadoAcao) setTimeout(() => mostrarResultadoAcao(r.resultadoAcao), 0);
  else if (ACAO_ENVIADA) setTimeout(() => avisar('Não recebi a confirmação da última gravação. Confira na tela se ela foi feita.', true), 0);
  ACAO_ENVIADA = false;
  // Tela que ja veio pronta no HTML (navegacao de reserva, link de e-mail, F5): abre direto.
  if (r.telaEmbutida && r.telaEmbutida.resposta) {
    const destino = destinoDoLink();
    if (destino && destino.tela === r.telaEmbutida.id) esquecerDestinoDoLink(true);
    const p = r.telaEmbutida.params || {};
    CACHE_TELAS[chaveTela(r.telaEmbutida.id, p)] = { resposta: r.telaEmbutida.resposta, quando: Date.now() };
    return abrir(r.telaEmbutida.id, p);
  }
  // Veio de um link de e-mail (?tela=calendario): abre direto nessa tela.
  const destino = destinoDoLink();
  if (destino) {
    // daAba: o endereco que a propria reserva escreveu — a aba ja decidiu onde estava (telaDaAba).
    const abre = !destino.daAba && (r.telas || []).some((t) => t.id === destino.tela);
    esquecerDestinoDoLink(abre);
    if (abre) return abrir(destino.tela, paramsDoLink(destino));
  }
  abrirModulos();
  if (r.avisoTela) avisar(avisoDaRecusa(r.avisoTela), true);    // F5 ou link numa tela que nao abre mais
}

/* A filial em uso na barra lateral, com o "Trocar filial" para quem tem mais de uma. */
function pintarCaixaFilial() {
  const caixa = el('filial-atual');
  if (!caixa) return;
  const f = SESSAO && SESSAO.filial;
  caixa.innerHTML = f ? `
    <span class="filial-rotulo">Filial</span>
    <strong>${esc(f.nome)}</strong>
    ${(SESSAO.filiais || []).length > 1 ? '<button class="botao-texto" onclick="trocarFilial()">Trocar filial</button>' : ''}` : '';
}

/*
 * VERSAO MISTURADA (4.2.2). Cada arquivo alterado numa entrega traz o
 * mesmo carimbo (APP.build no Codigo.gs, BUILD_APP aqui, BUILD_PAINEIS no
 * Paineis.html, BUILD_<ARQUIVO> nos .gs). Carimbo diferente = alguem colou
 * parte dos arquivos no Apps Script e parte nao — e ai aparecem erros como
 * "Ação desconhecida". A faixa diz QUAIS arquivos faltam.
 */
const BUILD_APP = '2026.11.26';
function mostrarResultadoAcao(x) {
  if (!x) return;
  if (x.ok === false) {
    const msg = String(x.erro || 'Não consegui gravar.');
    if (/MailApp|send_mail|autoriz/i.test(msg)) return janelaAutorizarEmail(msg);
    return avisar(avisoDaRecusa(msg), true);
  }
  if (x.avisoEmail) avisar(x.avisoEmail, true);
  else if (x.aviso) avisar(x.aviso, /NÃO atualizad/i.test(x.aviso));     // atualizarRH: meses que falharam
  else if (x.recado) avisar(x.recado);
  else if (x.recadoBotao) avisar(x.recadoBotao);
}

/* O Estilo.html e o PaineisEstilo.html trazem o carimbo numa variavel do CSS (--gsl-estilo, --gsl-paineis-estilo). */
function carimboCss(nome) {
  try { return getComputedStyle(document.documentElement).getPropertyValue(nome).replace(/["'\s]/g, ''); }
  catch (e) { return ''; }
}
function carimboDoEstilo() { return carimboCss('--gsl-estilo'); }

function conferirVersao(r) {
  const app = (r && r.app) || {};
  const faltam = [].concat(app.foraDaVersao || []);
  // Pagina local de outra versao: o servidor foi atualizado e a pasta GSL-Local nao (ou o contrario).
  const pastaVelha = MODO_LOCAL && app.build !== BUILD_APP;
  if (app.build !== BUILD_APP && !pastaVelha) faltam.unshift('Codigo.gs (ou App.html)');
  // Cada tela com o carimbo da entrega em que mudou por ultimo (como em arquivosForaDaVersao_, no Codigo.gs).
  if (typeof BUILD_PAINEIS === 'undefined' || BUILD_PAINEIS !== '2026.11.26') faltam.push('Paineis.html');
  if (carimboCss('--gsl-paineis-estilo') !== '2026.11.26') faltam.push('PaineisEstilo.html');
  if (typeof BUILD_APRENDIZ_TELA === 'undefined' || BUILD_APRENDIZ_TELA !== '2026.11.26') faltam.push('Aprendiz.html (e a linha dele no Index.html)');
  if (typeof GSL_T0 === 'undefined' || !el('entrar-continuar') || !el('lateral-alternar') || !el('entrar-p')) faltam.push('Index.html');
  if (carimboDoEstilo() !== '2026.11.26') faltam.push('Estilo.html');
  if (carimboCss('--gsl-plano-estilo') !== '2026.11.26') faltam.push('PlanoEstilo.html (e a linha dele no Index.html)');
  // Situacao de Carga: include opcional — so confere quando a tela esta na pagina.
  if (typeof BUILD_CARGA_TELA !== 'undefined' && BUILD_CARGA_TELA !== '2026.11.26') faltam.push('Carga.html');
  if (typeof BUILD_CARGA_TELA !== 'undefined' && carimboCss('--gsl-carga-estilo') !== '2026.11.26') faltam.push('CargaEstilo.html');
  let faixa = el('aviso-versao');
  if (!faltam.length && !pastaVelha) { if (faixa) faixa.remove(); return; }
  if (!faixa) {
    faixa = document.createElement('div');
    faixa.id = 'aviso-versao';
    faixa.className = 'faixa-aviso';
    const pagina = el('pagina');
    if (pagina && pagina.parentNode) pagina.parentNode.insertBefore(faixa, pagina);
    else document.body.prepend(faixa);
  }
  const local = pastaVelha ? `A pasta GSL-Local deste computador é da versão ${esc(BUILD_APP)} e o servidor está na
    ${esc(app.build || '(desconhecida)')}. ${r.admin
      ? 'Monte a pasta GSL-Local desta versão e copie por cima da pasta compartilhada (guarde o gsl-config.js).'
      : 'Avise o administrador: a pasta GSL-Local precisa ser trocada pela nova.'} ` : '';
  if (!faltam.length) { faixa.innerHTML = `<b>Atualização incompleta do GSL.</b> ${local}`; return; }
  faixa.innerHTML = `<b>Atualização incompleta do GSL.</b> ${local}Estes arquivos não estão na mesma versão das telas:
    ${faltam.map(esc).join(', ')}. ${r.admin
      ? 'Cole esses arquivos no Apps Script e crie uma <b>Nova versão</b> da implantação (Implantar › Gerenciar implantações).'
      : 'Algumas funções podem dar erro — avise o administrador do sistema.'}`;
}

/*
 * DESTINO DO LINK DE E-MAIL. Guardado na aba (sessionStorage) para valer
 * tambem depois da entrada pelo formulario de reserva (que recarrega a
 * pagina). Usado uma vez so. acao (19/10): o e-mail de quem foi marcado
 * num comentario leva tambem o ID da acao, e o plano abre o historico dela.
 */
function destinoDoLink() {
  try {
    const c = (typeof CARGA_INICIAL !== 'undefined' && CARGA_INICIAL) || {};
    if (c.telaDepois) {
      sessionStorage.setItem('gsl_destino', JSON.stringify({ tela: c.telaDepois, filial: c.filialDepois || '',
        daAba: !!c.destinoDaAba, acao: c.acaoDepois || '' }));
      c.telaDepois = '';
    }
    return JSON.parse(sessionStorage.getItem('gsl_destino') || 'null');
  } catch (e) { return null; }
}
/*
 * usar: a tela do link esta sendo aberta agora. A acao do link fica para
 * abrirAcaoDoLink (o plano abre o historico dela) e sai do endereco — o F5
 * volta na posicao da aba, sem abrir o historico de novo. Ela leva a tela
 * do link ({ id, tela }): so o plano dessa tela a abre, e pintar outra tela
 * a descarta (o outro plano nao a procura nem avisa que ela sumiu).
 */
let ACAO_DO_LINK = null;
function esquecerDestinoDoLink(usar) {
  const d = usar ? destinoDoLink() : null;
  try { sessionStorage.removeItem('gsl_destino'); } catch (e) {}
  if (!d || d.daAba || !d.acao) return;
  ACAO_DO_LINK = { id: String(d.acao), tela: String(d.tela || '') };
  try { google.script.history.replace(null, Object.assign({ tela: d.tela, aba: '1' }, d.filial ? { filial: d.filial } : {}), ''); } catch (e) {}
}
/*
 * A acao do link pode ja estar concluida: no Calendario (o filtro e do
 * servidor) o plano do link abre com todas — numa ida so, tambem pela
 * reserva, onde uma segunda ida pediria outro clique.
 */
const paramsDoLink = (d) => (d && d.acao && !d.daAba && d.tela === 'acoes' ? { situacao: 'TODAS' } : {});
function paramsDoLinkJson(d) { const p = paramsDoLink(d); return Object.keys(p).length ? JSON.stringify(p) : ''; }

/*
 * RESERVA DE LEITURA. Se o canal google.script.run for barrado nesta
 * maquina (HTTP 403), a tela pedida e aberta por navegacao de pagina:
 * o servidor devolve o HTML ja com ela montada. Gravar continua exigindo
 * o canal — a tela avisa quando for o caso.
 */
function canalBloqueado(e) {
  // "reading from storage ... PERMISSION_DENIED" e o erro do google.script.run
  // quando ha mais de uma conta Google aberta no navegador — o caso do
  // computador compartilhado. Antes so o 403 ativava a reserva.
  return canalBarradoDeVez(e) || falhaPassageira(e);
}
/* O Google recusa a conversa nesta maquina (varias contas, cookie barrado): vale lembrar. */
function canalBarradoDeVez(e) {
  // So os textos do proprio Google: a mensagem de uma acao pode ter "403" ou "armazenamento" dentro
  // (codigo do DE-PARA, saldo do estoque) e nao pode marcar o computador como barrado.
  return /HTTP 40[13]\b|PERMISSION_DENIED|reading from storage/i.test(String((e && e.message) || e || ''));
}
/* Rede que caiu um instante, servidor que nao respondeu: tenta de novo, nao marca a maquina. */
function falhaPassageira(e) {
  const m = String((e && e.message) || e || '');
  return !canalBarradoDeVez(e) && /NetworkError|Falha na conex|HTTP (0|5\d\d)\b|Failed to fetch|timeout|tempo esgotado|Sem conexão com o servidor do GSL/i.test(m);
}

/* Bilhete de uso unico que o servidor pos nesta pagina (ver doPost). */
let BILHETE_RENOVADO = '', BILHETE_DESDE = Date.now();
function bilheteDaPagina() {
  return BILHETE_RENOVADO ||
    (typeof CARGA_INICIAL !== 'undefined' && CARGA_INICIAL && CARGA_INICIAL.bilhete) || '';
}
/*
 * O bilhete vive 6 h no servidor. Pagina aberta o dia inteiro: enquanto o
 * canal funciona, pede um novo a cada 4 h — para a reserva por POST (se o
 * canal cair no meio do turno) nao sair com um bilhete vencido.
 */
function renovarBilheteSeVelho() {
  if (MODO_LOCAL || CANAL_BARRADO || Date.now() - BILHETE_DESDE < 4 * 3600 * 1000) return;   // a pagina local nao usa a reserva por POST
  if (typeof google === 'undefined' || !google.script) return;
  BILHETE_DESDE = Date.now();
  chamar('renovarBilhete', ctx()).then((b) => {
    if (typeof b !== 'string' || !/^[0-9a-f-]{36}$/i.test(b)) return;
    BILHETE_RENOVADO = b;
    const campo = el('entrar-bilhete'); if (campo) campo.value = b;
  }).catch(() => {});
}
setInterval(renovarBilheteSeVelho, 15 * 60 * 1000);
document.addEventListener('visibilitychange', function () {
  if (document.visibilityState === 'visible') renovarBilheteSeVelho();
});
function abrirPorNavegacao(idTela, params) {
  if (!URL_APP || !FILIAL) return false;
  if (gravacaoEmAndamento()) { avisar('Aguarde: a gravação anterior ainda está sendo feita.'); return true; }
  el('pagina').innerHTML = '<div class="vazio">Abrindo pela navegação…</div>';
  const temParams = params && Object.keys(params).length;
  return navegarPelaPagina({ t: TOKEN, filial: FILIAL, tela: idTela,
    p: temParams ? JSON.stringify(params) : '' });
}

/*
 * NAVEGACAO DE RESERVA (4.2.2) — sempre por POST no /exec.
 *
 * Antes ia como link /exec?t=<sessao>: o codigo ficava na barra de endereco
 * e no historico, e no computador compartilhado o proximo a usar voltava
 * pelo historico e entrava como a pessoa anterior, sem PIN. No POST o
 * codigo vai no corpo do pedido e nao fica em lugar nenhum. A janela de
 * cima so navega em resposta a um clique — por isso isto so e chamado
 * logo depois de um clique (abrir tela, escolher filial).
 */
let NAVEGACAO_PENDENTE = null;
let SAINDO_DA_PAGINA = false;        // a janela de cima ja comecou a navegar
window.addEventListener('beforeunload', function () { SAINDO_DA_PAGINA = true; });
/*
 * GRAVACAO PELA PAGINA EM ANDAMENTO. O POST da gravacao saiu e a pagina nova
 * ainda nao chegou: outro clique que navegasse trocaria a pagina dela, e o
 * resultado (ou o erro: "saldo insuficiente") se perderia. Sair sempre passa.
 * A marca na aba (CHAVE_ACAO) diz a pagina seguinte que ela e a resposta de
 * uma gravacao (ver montarSessao e retomarOuPedirEntrada).
 */
const CHAVE_ACAO = 'gsl_acao';
let GRAVANDO_PELA_PAGINA = 0, ACAO_ENVIADA = false;
function gravacaoEmAndamento() { return !!GRAVANDO_PELA_PAGINA && Date.now() - GRAVANDO_PELA_PAGINA < 30000; }
function navegarPelaPagina(campos) {
  if (!URL_APP) return false;
  if (gravacaoEmAndamento() && campos !== NAVEGACAO_PENDENTE && !campos.sair) {
    avisar('Aguarde: a gravação anterior ainda está sendo feita.');
    return true;
  }
  campos = Object.assign({ bilhete: bilheteDaPagina() }, campos);
  NAVEGACAO_PENDENTE = campos;
  // 10/10: o navegador so deixa a moldura navegar ate ~5 s depois de um clique. Sem clique
  // valido, a navegacao era barrada em silencio (so um erro no console) e o "Continuar" vinha
  // 6 s depois. Agora ele vem na hora.
  const ua = navigator.userActivation;
  if (ua && !ua.isActive) { pedirCliqueParaNavegar(); return true; }
  const f = document.createElement('form');
  f.method = 'post'; f.action = URL_APP; f.target = '_top'; f.style.display = 'none';
  Object.keys(campos).forEach((k) => {
    if (campos[k] === undefined || campos[k] === null || campos[k] === '') return;
    const i = document.createElement('input');
    i.type = 'hidden'; i.name = k; i.value = String(campos[k]);
    f.appendChild(i);
  });
  document.body.appendChild(f);
  if (campos.acao) { GRAVANDO_PELA_PAGINA = Date.now(); gravarSs(CHAVE_ACAO, String(Date.now())); }
  f.submit();
  // Ainda aqui depois de 4 s: o navegador barrou a navegacao (o clique ja
  // tinha "vencido"). Um botao da ao navegador o clique que ele exige.
  setTimeout(() => {
    // Navegacao em andamento (servidor lento) nao e bloqueio: nada a fazer.
    if (NAVEGACAO_PENDENTE !== campos || SAINDO_DA_PAGINA) return;
    pedirCliqueParaNavegar();
  }, 6000);
  return true;
}
/* O clique que o navegador exige: na janela e, se ela for fechada, tambem na pagina. */
function pedirCliqueParaNavegar() {
  abrirJanela('Continuar', `
    <p style="margin-top:0;line-height:1.7">Este computador bloqueia a conversa direta com o Google,
      então o sistema continua recarregando a página. Clique em <b>Continuar</b>.</p>`, `
    <button class="botao" onclick="fecharJanela(); navegarPelaPagina(NAVEGACAO_PENDENTE)">Continuar</button>`);
  setTimeout(() => { const b = document.querySelector('#janela-rodape .botao'); if (b) b.focus(); }, 50);
  const pg = el('pagina');
  if (pg && /Abrindo pela navega/.test(pg.textContent || '')) {
    pg.innerHTML = '<div class="vazio">Este computador precisa de um clique para abrir. ' +
      '<button class="botao" onclick="navegarPelaPagina(NAVEGACAO_PENDENTE)">Continuar</button></div>';
  }
}
/* Codigo unico de uma gravacao pela reserva: o mesmo POST reenviado nao grava duas vezes. */
function novoIdem() {
  try { if (window.crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
  return 'xxxxxxxx-xxxx-4xxx-8xxx-xxxxxxxxxxxx'.replace(/x/g, () => Math.floor(Math.random() * 16).toString(16));
}

async function pararSimulacao() {
  // Sem recarregar a pagina (na moldura do Google ela voltaria em branco):
  // pede a sessao de novo, ja com o perfil verdadeiro.
  try { await chamar('encerrarSimulacao', ctx()); tratarEntrada(await chamarJSON('retomarSessao', ctx())); }
  catch (e) { avisar(e.message || e, true); }
}

/*
 * SAIR. Quem controla a entrada e a conta Google do navegador — o GSL
 * nao tem sessao propria para encerrar. A tela diz a verdade.
 */
function sair() {
  const t = TOKEN;
  TOKEN = ''; gravarSessao(''); SESSAO = null; esquecerTelas(); apagarTelaDaPessoa(); avisoSessao(false);
  // Canal barrado: o sairDoSistema pelo google.script.run tambem seria
  // barrado e a sessao continuaria valida no servidor. Sair e um clique,
  // entao a pagina pode navegar: a saida vai por POST.
  if (t && CANAL_BARRADO && navegarPelaPagina({ sair: t })) return;
  if (t) { try { google.script.run.withFailureHandler(function () {}).sairDoSistema({ t: t }); } catch (e) {} }
  if (el('entrar')) { el('entrar-email').value = ''; return mostrarEntrada({ recado: 'Você saiu do GSL.' }); }
  abrirJanela('Sair do sistema', `
    <p style="line-height:1.7;margin-top:0">
      Você entrou pela sua conta Google (<b>${esc(SESSAO && SESSAO.usuario ? SESSAO.usuario.email : '')}</b>).
      Quem controla essa entrada é o navegador.
    </p>
    <p style="line-height:1.7">Se este é o seu computador, basta fechar a aba. Se for um computador
      compartilhado, saia também da conta Google para ninguém entrar como você.</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Fechar</button>
    <button class="botao" onclick="window.open('https:\/\/accounts.google.com/Logout','_blank')">Sair da conta Google</button>`);
}

async function instalarSistema() {
  const email = String(el('instalacao-email').value || '').trim().toLowerCase();
  if (!email || email.indexOf('@') === -1) { avisar('Informe seu e-mail de administrador.', true); return; }
  const b = el('botao-instalar');
  b.disabled = true; b.textContent = 'Criando…';
  try {
    await chamar('instalar', email);
    // Instalado: o proximo passo e entrar com e-mail e PIN. Sem recarregar
    // (na moldura do Google a pagina recarregada volta em branco).
    mostrarEntrada({ emailDigitado: email,
      recado: 'Sistema instalado. Digite um PIN de 4 a 6 números — ele passa a ser o seu.' });
  } catch (e) { b.disabled = false; b.textContent = 'Criar banco de dados'; avisar(e.message || e, true); }
}

/*
 * HTTP 403 no console nao e culpa do GSL: a pagina abriu (o doGet rodou),
 * o que foi barrado foi a conversa do google.script.run com o Google.
 */
function explicarErro(t) {
  const m = String((t && t.message) || t || '');
  if (MODO_LOCAL && RE_SEM_API.test(m)) return explicarSemApi(m);       // pagina local sem o servidor (ver chamarApi)
  if (/PERMISSION_DENIED|reading from storage/i.test(m)) {
    return 'O Google recusou a conversa com o servidor porque há mais de uma conta Google aberta neste ' +
           'navegador. Use uma janela só com a conta @bartofil.com.br (ou uma janela anônima). ' +
           'Detalhe técnico: ' + m;
  }
  if (falhaPassageira(m)) {
    return 'A conexão com o Google caiu no meio do pedido (rede instável ou servidor ocupado). ' +
           'Se era uma gravação, confira na tela se ela foi feita antes de repetir. Detalhe técnico: ' + m;
  }
  if (/HTTP 40[13]\b|NetworkError|Falha na conex/i.test(m)) {
    return 'Este computador abriu o sistema, mas o Google bloqueou (HTTP 403) a conversa '
         + 'com o servidor. Verifique: 1) a conta @bartofil.com.br é a PRIMEIRA conta logada no '
         + 'navegador (ou use uma janela só com ela); 2) cookies de terceiros liberados para '
         + 'script.google.com e *.googleusercontent.com; 3) data e hora do computador corretas. '
         + 'Detalhe técnico: ' + m;
  }
  return m || 'Erro desconhecido.';
}

function mostrarFalha(t) {
  soMostrar('falha');
  el('falha-texto').textContent = explicarErro(t);
}

/* Rede de seguranca: nada pode terminar na tela do logo girando para sempre. */
function travouCarregando() {
  const c = el('carregando');
  return c && !c.classList.contains('oculto');
}
window.addEventListener('unhandledrejection', function (ev) {
  if (travouCarregando()) mostrarFalha(ev.reason);
});
window.addEventListener('error', function (ev) {
  if (travouCarregando()) mostrarFalha(ev.message);
});
setTimeout(function () {
  if (travouCarregando()) mostrarFalha('O servidor nao respondeu em 25 segundos.');
}, 25000);

/*
 * MODULOS.
 *
 * O sistema abre no menu de modulos. A barra lateral so lista as telas do
 * modulo em que a pessoa esta — antes ela despejava as seis telas de uma
 * vez, misturando calendario com acessos.
 */
let moduloAtual = null;

/* 25/11 (redesenho): icones de linha (SVG, cor do texto) no lugar dos emojis — leitura igual em
   qualquer Windows e no tema escuro. Sem xmlns: dentro do HTML o navegador ja sabe que e SVG. */
const svgIcone = (d) => '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" ' +
  'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + d + '</svg>';
const ICONES = {
  calendario: svgIcone('<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4M8 14h2M14 14h2M8 17.5h2"/>'),
  pessoas: svgIcone('<circle cx="9" cy="8.5" r="3.5"/><path d="M2.5 20c.6-3.6 3.2-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M15.5 5.3a3.3 3.3 0 0 1 0 6.4M18 14.8c2 .7 3.2 2.4 3.5 5.2"/>'),
  tela: svgIcone('<rect x="2.5" y="4" width="19" height="12.5" rx="2"/><path d="M12 16.5V20M8 20h8M10 7.8v5.4l4.4-2.7z"/>'),
  engrenagem: svgIcone('<circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/>'),
  bateria: svgIcone('<rect x="3" y="7" width="16" height="10" rx="2"/><path d="M21 10.5v3M11.5 9l-2 3.2h3l-2 2.8"/>'),
  limpeza: svgIcone('<path d="M14.5 3.5l-4 8.5"/><path d="M6.5 12h8.5l1.5 8.5H5z"/><path d="M8.5 16.5v4M12 16.5v4"/>'),
  grafico: svgIcone('<path d="M3.5 20.5h17"/><rect x="5" y="11" width="3.2" height="7" rx=".8"/><rect x="10.4" y="6.5" width="3.2" height="11.5" rx=".8"/><rect x="15.8" y="13.5" width="3.2" height="4.5" rx=".8"/>'),
  computador: svgIcone('<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>'),
  aprendiz: svgIcone('<path d="M2.5 9L12 4.5 21.5 9 12 13.5z"/><path d="M6.5 11v4.5c1.6 1.6 3.4 2.4 5.5 2.4s3.9-.8 5.5-2.4V11M21.5 9v5"/>'),
  carga: svgIcone('<path d="M2.5 6.5h11v10h-11z"/><path d="M13.5 10h4l3 3.5v3h-7"/><circle cx="6.5" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>'),
  filial: svgIcone('<path d="M3.5 20.5h17M5 20.5V8.5l7-4.5 7 4.5v12"/><path d="M9.5 20.5v-5h5v5M8.5 11h1.5M14 11h1.5"/>')
};

function montarMenu(telas) {
  const dentro = moduloAtual && moduloAtual !== 'config'
    ? telas.filter((t) => t.modulo === moduloAtual)
    : [];
  // 4.2.2: as Configuracoes ficam sempre na barra lateral (mesmas telas e
  // permissoes de antes) em vez de um cartao no meio da tela de modulos.
  const config = telas.filter((t) => t.modulo === 'config');
  const item = (t) => `
    <button class="item-menu" data-pagina="${t.id}" onclick="abrirConfig(${jsArg(t.id)})">
      <span class="tag-cor ${t.cor}"></span>${esc(t.nome)}
    </button>`;
  el('menu').innerHTML =
    (moduloAtual ? `<button class="voltar-modulos" onclick="abrirModulos()">Voltar aos modulos</button>` : '') +
    dentro.map((t) => `
    <button class="item-menu" data-pagina="${t.id}" onclick="abrir(${jsArg(t.id)})">
      <span class="tag-cor ${t.cor}"></span>${esc(t.nome)}
    </button>`).join('') +
    (config.length ? `<div class="menu-secao">Configurações</div>` + config.map(item).join('') : '');
}

/* Tela de configuracao aberta pela barra lateral: entra no "modulo" config sem duplicar o menu. */
function abrirConfig(id) {
  moduloAtual = 'config';
  montarMenu(SESSAO.telas || []);
  abrir(id);
}

/* Menu sem cartao: quem liga os paineis ganha o caminho; os demais, a quem pedir. */
function menuVazioHtml() {
  if (!(SESSAO.telas || []).some((t) => t.id === 'filiais')) {
    return '<div class="vazio">Nenhum módulo liberado para você nesta filial. Fale com o administrador.</div>';
  }
  return '<div class="vazio">Nenhum painel ligado nesta filial. ' +
    '<button class="botao-texto" onclick="abrirConfig(\'filiais\')">Ligar em Configuração › Filiais e painéis</button></div>';
}

/** Tela inicial: os holocards. Nao chama o servidor. */
function abrirModulos() {
  if (!SESSAO || !SESSAO.usuario) {
    return mostrarFalha('Tentei abrir o menu sem uma sessão carregada. Recarregue a página.');
  }
  moduloAtual = null;
  paginaAtual = 'modulos'; paramsAtual = {};
  lembrarTelaDaAba('', {});
  montarMenu(SESSAO.telas || []);

  el('titulo-pagina').textContent = 'Sistema de Gestão Operacional';
  el('subtitulo-pagina').textContent = ((SESSAO.filial && SESSAO.filial.nome) || 'GSL') + ' \u00b7 ' + SESSAO.usuario.nome;
  el('acoes-topo').innerHTML = '';
  el('pagina').classList.remove('sem-entrada');
  el('pagina').setAttribute('data-tela', 'modulos');
  paginaAnterior = 'modulos';

  const mods = (SESSAO.modulos || []).filter((m) => m.id !== 'config');   // config mora na barra lateral
  el('pagina').innerHTML = `
    <div class="tela-modulos">
      <div class="modulos-titulo">Selecione um modulo para continuar</div>
      <div class="grade-modulos">
        ${mods.map((m) => `
          <button class="holocard ${m.cor}${m.oculto ? ' painel-oculto' : ''}" data-modulo="${esc(m.id)}" onclick="entrarModulo(${jsArg(m.id)})">
            ${m.oculto ? '<span class="selo-oculto" title="Oculto: só o administrador vê este painel nesta filial">oculto</span>' : ''}
            <div class="holo-icone">${ICONES[m.icone] || '\u25C6'}</div>
            <div class="holo-titulo">${esc(m.nome)}</div>
            <span class="holo-pendencia">${bolinhaHtml(m.id)}</span>
            <div class="holo-frase">${esc(m.frase)}</div>
            <div class="holo-rodape">
              <span class="holo-acao">${esc(m.acao)}</span>
              <span class="holo-seta">\u2192</span>
            </div>
            <span class="holo-marca">${ICONES[m.icone] || ''}</span>
          </button>`).join('') || menuVazioHtml()}
      </div>
    </div>`;
  // O menu ja esta na tela; os numeros so vao ao servidor se estiverem velhos (por tras, sem segurar o clique).
  if (!PENDENCIAS || PENDENCIAS.filial !== FILIAL || Date.now() - PENDENCIAS.quando > PENDENCIAS_IDADE) atualizarPendencias();
}

/* ------------------------------------------------------------------ */
/* BOLINHAS DO MENU (10/10) — acoes em aberto de cada modulo           */
/*                                                                     */
/* O numero e o "Em aberto" do plano (o servidor conta pelo mesmo      */
/* caminho da tela). Chega de tres jeitos: dentro da pagina da reserva */
/* (POST), numa chamada por tras depois do menu na tela, e das proprias*/
/* telas dos planos — ao chegar o Plano de Acao ou a Limpeza, a bolinha*/
/* passa a ser o numero que a pessoa acabou de ver. Nunca e consultada */
/* sozinha, por tempo: a sessao acaba em 1 h parada e uma consulta     */
/* periodica manteria viva a aba esquecida aberta.                     */
/* ------------------------------------------------------------------ */
let PENDENCIAS = null;             // { filial, quando, modulos: { calendario: {abertas, atrasadas, minhas} } }
let PENDENCIAS_PEDIDO = '';        // filial do pedido em voo ('' = nenhum)
let PENDENCIAS_SEM_PORTA = false;  // servidor antigo (sem a acao 'pendencias'): para de pedir nesta pagina
const PENDENCIAS_IDADE = 120000;   // mais velhas que isto: o menu pede de novo (por tras)
const BOLINHA_DA_TELA = {          // tela do plano -> modulo da bolinha e onde estao os numeros dela
  acoes: { modulo: 'calendario', contagens: (d) => d && d.contagens },
  limpeza: { modulo: 'limpeza', contagens: (d) => d && d.plano && d.plano.contagens }
};

function notarBolinhaDaTela(idTela, r) {
  const b = BOLINHA_DA_TELA[idTela];
  const c = b && r && b.contagens(r.dados);
  if (!c || typeof c.abertas !== 'number') return;
  if (!PENDENCIAS || PENDENCIAS.filial !== FILIAL) PENDENCIAS = { filial: FILIAL, quando: 0, modulos: {} };
  PENDENCIAS.modulos[b.modulo] = { abertas: c.abertas, atrasadas: c.atrasadas || 0, minhas: c.minhas || 0, parecer: c.parecer || 0 };
  pintarBolinhas();
}

const contarTexto = (n, um, varios) => n + ' ' + (n === 1 ? um : varios);
function textoPendencia(p) {
  return contarTexto(p.abertas, 'ação em aberto', 'ações em aberto') +
    (p.atrasadas ? ', ' + contarTexto(p.atrasadas, 'atrasada', 'atrasadas') : '') +
    (p.parecer ? ', ' + contarTexto(p.parecer, 'situação esperando o seu parecer', 'situações esperando o seu parecer') : '');
}

/* A bolinha de um modulo (vazio quando nao ha numero, ou e zero). 8.13: conta tambem as situacoes que esperam o MEU parecer. */
function bolinhaHtml(idModulo) {
  const p = PENDENCIAS && PENDENCIAS.filial === FILIAL ? PENDENCIAS.modulos[idModulo] : null;
  const n = p ? (p.abertas || 0) + (p.parecer || 0) : 0;
  if (!p || !(n > 0)) return '';
  const dica = textoPendencia(p) + (p.minhas && p.minhas !== p.abertas ? ' · ' + contarTexto(p.minhas, 'sua', 'suas') : '');
  return `<span class="holo-bolinha${p.atrasadas ? ' com-atraso' : ''}" aria-hidden="true" title="${esc(dica)}">${n > 99 ? '99+' : n}</span>` +
    `<span class="so-leitor">, ${esc(textoPendencia(p))}</span>`;
}

/* Troca so as bolinhas, no lugar: redesenhar o menu repetiria a entrada dos cartoes. */
function pintarBolinhas() {
  if (paginaAtual !== 'modulos') return;
  document.querySelectorAll('.holocard[data-modulo]').forEach((b) => {
    const alvo = b.querySelector('.holo-pendencia');
    const html = bolinhaHtml(b.dataset.modulo);
    if (alvo && alvo.innerHTML !== html) alvo.innerHTML = html;
  });
}

/* Por tras e calada: sem canal (reserva por POST) os numeros vem dentro da pagina, e erro aqui nao vira aviso. */
/*
 * A chamada traz tambem o MENU de agora: e por ela que quem ja estava dentro
 * ve a matriz nova (um menu que sumiu, uma tela que virou so leitura) ao
 * voltar ao menu — por isso vai mesmo para quem nao tem plano nenhum.
 */
async function atualizarPendencias() {
  if (PENDENCIAS_PEDIDO === FILIAL || PENDENCIAS_SEM_PORTA || CANAL_BARRADO || !SESSAO ||
      typeof google === 'undefined' || !google.script) return;
  const filial = FILIAL;
  PENDENCIAS_PEDIDO = filial;
  try {
    if (!(await filaLivre(10))) return;
    const pedido = ++MENU_PEDIDOS;
    const r = await executarAcaoSrv('pendencias', {});
    if (filial !== FILIAL || !SESSAO || !r || !r.pendencias) return;
    PENDENCIAS = { filial: FILIAL, quando: Date.now(), modulos: r.pendencias };
    if (!aplicarMenu(r.menu, pedido)) pintarBolinhas();      // menu novo: os cartoes ja voltam com as bolinhas
  } catch (e) {
    // A bolinha e um extra: sem ela o menu funciona igual. Codigo.gs antigo nao conhece a acao: para de pedir.
    // (Acoes.gs antigo com Codigo.gs novo: "aponta para acaoPendencias, que nao existe".)
    if (/desconhecida|que nao existe/i.test(String((e && e.message) || e))) PENDENCIAS_SEM_PORTA = true;
  } finally { if (PENDENCIAS_PEDIDO === filial) PENDENCIAS_PEDIDO = ''; }
}

/*
 * MENU NOVO (19/10). Vem do servidor depois de uma gravacao que muda paineis,
 * filiais ou acessos (executarAcaoETela) e junto com a bolinha (pendencias).
 * Sessao, barra lateral e cartoes ficam em dia sem F5; a tela que saiu do
 * menu leva de volta a ele, com o aviso (o de quem sabe a causa, ou o neutro).
 * Devolve true quando o menu mudou.
 * pedido: a ordem em que o pedido saiu. A resposta atrasada de um pedido mais
 * velho que o menu em uso nao volta com o painel recem-desligado (ou sem o
 * recem-ligado): a bolinha calculada antes de um alterarPainel, ou duas
 * gravacoes com as respostas trocadas.
 */
let MENU_PEDIDOS = 0, MENU_EM_USO = 0;
function aplicarMenu(m, pedido, aviso) {
  if (!SESSAO || !m || (m.filial && m.filial !== FILIAL)) return false;   // de outra filial: nao e este menu
  if (pedido < MENU_EM_USO) return false;                                  // retrato de antes do menu em uso
  MENU_EM_USO = pedido;
  if (Array.isArray(m.filiais)) atualizarFiliais(m.filiais);
  if (!Array.isArray(m.telas) || !Array.isArray(m.modulos)) return false;
  if (JSON.stringify([m.telas, m.modulos]) === JSON.stringify([SESSAO.telas, SESSAO.modulos])) return false;
  // A faixa da tela aberta mudou (Ver <-> Ver e editar): ela e pedida de novo e repinta com os botoes certos.
  const faixaAntes = nivelDoMenu(paginaAtual);
  SESSAO.telas = m.telas; SESSAO.modulos = m.modulos;
  const vivas = {};
  m.telas.forEach((t) => { vivas[t.id] = true; });
  Object.keys(CACHE_TELAS).forEach((k) => { if (!vivas[k.split('|')[1]]) delete CACHE_TELAS[k]; });
  envelhecerTelas();                      // as que ficaram revalidam ao abrir (ex.: Filiais e paineis mudada em outra aba)
  if (paginaAtual === 'modulos') abrirModulos();
  else if (!vivas[paginaAtual]) voltarAoMenuComAviso(aviso);
  else {
    montarMenu(m.telas);
    document.querySelectorAll('.item-menu').forEach((b) => b.classList.toggle('ativo', b.dataset.pagina === paginaAtual));
    if (faixaAntes && nivelDoMenu(paginaAtual) !== faixaAntes) {
      const p = ACESSO_DA_TELA[paginaAtual];
      if (!p || p.nivel !== nivelDoMenu(paginaAtual)) { fecharJanela(); esquecerTela(paginaAtual); abrir(paginaAtual, paramsAtual); }
    }
  }
  return true;
}

/* Filial criada, renomeada ou desligada: a troca de filial e a caixa da barra lateral em dia. */
function atualizarFiliais(filiais) {
  SESSAO.filiais = filiais;
  const atual = filiais.find((f) => f.codigo === FILIAL);
  if (atual && SESSAO.filial) { SESSAO.filial.nome = atual.nome; SESSAO.filial.cidade = atual.cidade; }
  pintarCaixaFilial();
}

/*
 * A filial em uso deixou de valer: nada dela vale mais — a pessoa escolhe outra.
 * motivo (menuDaSessao_): 'desligada' pelo administrador ou 'semAcesso' (ela saiu
 * da filial no proprio cadastro). Sem nenhuma filial ativa, a tela de sem acesso.
 */
function filialDesligada(filiais, motivo) {
  esquecerTelas();
  SESSAO.filiais = filiais || [];
  if (!SESSAO.filiais.length) {
    return mostrarSemAcesso({ entrada: 'SEM_FILIAL', conta: SESSAO.usuario && SESSAO.usuario.email,
      motivo: 'Seu cadastro não está ligado a nenhuma filial ativa. Fale com o administrador.' });
  }
  mostrarEscolhaFilial(SESSAO.filiais, SESSAO.usuario);
  avisar(motivo === 'semAcesso' ? 'Você não tem mais acesso a esta filial. Escolha outra para continuar.'
    : 'Esta filial foi desligada. Escolha outra para continuar.', true);
}

/*
 * PAINEL QUE SAIU com a pessoa dentro (19/10): o servidor recusou a tela ou a
 * acao porque o painel foi desligado na filial (ou o acesso da pessoa a ele
 * saiu) — e o cartao e a tela guardada ainda estavam aqui. Em vez da caixa de
 * erro (ou da tela velha), o menu e relido e a pessoa volta para ele com o
 * aviso da causa: painel desligado, ou acesso retirado (Sem acesso, nivel). O
 * menu novo sem a tela, que nao sabe a causa, usa o aviso neutro. false: e
 * outra recusa (a mensagem do servidor, como sempre).
 */
const RECUSA_DE_PAINEL = /painel não está ligado|não tem acesso ao módulo|não inclui a tela|é só para ver/i;
const AVISO_PAINEL_SAIU = 'Este painel foi desligado nesta filial.';
const AVISO_SEM_ACESSO = 'Este painel não está mais liberado para você nesta filial.';
const AVISO_SO_VER = 'Seu acesso a esta tela agora é só para ver: nada foi gravado.';
const avisoDaRecusa = (msg) => {
  const m = String(msg || '');
  // "Seu acesso (NIVEL) não inclui a tela X." ja diz a causa (a matriz, nao o painel): vai como o servidor disse.
  return /painel não está ligado/i.test(m) ? AVISO_PAINEL_SAIU
    : /não tem acesso ao módulo/i.test(m) ? AVISO_SEM_ACESSO
    : /é só para ver/i.test(m) ? AVISO_SO_VER : m;
};
function voltarAoMenuComAviso(aviso) { fecharJanela(); abrirModulos(); avisar(aviso || AVISO_SEM_ACESSO, true); }

async function painelSaiu(e, idTela) {
  const msg = String((e && e.message) || e || '');
  if (!RECUSA_DE_PAINEL.test(msg)) return false;
  esquecerTela(idTela);
  /*
   * A matriz mudou com a pessoa dentro e a tela ficou "Ver": o menu e a tela
   * sao relidos (a tela volta sem os botoes de gravar) e o aviso diz por que
   * nada foi gravado. A tela que sumiu do menu leva de volta a ele, como sempre.
   */
  if (/é só para ver/i.test(msg)) {
    try {
      const pedido = ++MENU_PEDIDOS;
      const s = await chamarJSON('abrirFilial', ctx());
      if (s && s.ok && s.entrada === 'APP') aplicarMenu({ filial: s.filial.codigo, telas: s.telas, modulos: s.modulos, filiais: s.filiais }, pedido);
    } catch (x) { /* sem o menu novo, a tela relida ja mostra a faixa certa */ }
    if (paginaAtual === idTela && (SESSAO.telas || []).some((t) => t.id === idTela)) {
      fecharJanela(); esquecerTela(idTela); abrir(idTela, paramsAtual);
    }
    avisar(AVISO_SO_VER, true);
    return true;
  }
  try {
    const pedido = ++MENU_PEDIDOS;
    const s = await chamarJSON('abrirFilial', ctx());
    if (s && s.ok && s.entrada === 'APP') aplicarMenu({ filial: s.filial.codigo, telas: s.telas, modulos: s.modulos, filiais: s.filiais }, pedido, avisoDaRecusa(msg));
  } catch (x) { /* sem o menu novo, volta assim mesmo: o aviso explica */ }
  if (paginaAtual === idTela) voltarAoMenuComAviso(avisoDaRecusa(msg));
  return true;
}

function entrarModulo(id) {
  const m = (SESSAO.modulos || []).find((x) => x.id === id);
  if (!m || !m.telas.length) return;
  moduloAtual = id;
  montarMenu(SESSAO.telas || []);
  abrir(m.telas[0]);
  // As demais telas DESTE modulo vao chegando por tras, sem atrapalhar.
  setTimeout(() => prebuscarModulo(id), 300);       // espera a primeira tela (filaLivre) e ja segue
}

/*
 * CACHE DE TELAS.
 *
 * Cada chamada ao servidor do Apps Script custa de 1 a 3 segundos, e isso
 * NAO depende do tamanho da resposta: e o custo de acordar o ambiente.
 * Sem cache, voltar para uma tela ja vista pagava esse preco de novo — era
 * a lentidao que se sentia no menu.
 *
 * Estrategia: mostra o que ja tem na hora e revalida por tras. A tela
 * aparece instantanea; se o servidor devolver algo diferente, ela se
 * corrige sozinha em silencio. Qualquer gravacao limpa o cache inteiro.
 */
const CACHE_TELAS = {};
const chaveTela = (id, params) => FILIAL + '|' + id + '|' + JSON.stringify(params || {});
function esquecerTelas() { Object.keys(CACHE_TELAS).forEach((k) => delete CACHE_TELAS[k]); }

/*
 * ENVELHECER em vez de APAGAR.
 *
 * Depois de uma gravacao, as outras telas podem ter mudado — mas apagar o
 * cache delas obrigava o app a buscar TODAS de novo na hora (era o que a
 * prebusca fazia depois de cada clique: 6 chamadas por botao apertado).
 * Envelhecendo, a tela guardada continua servindo para pintar na hora e
 * so revalida quando a pessoa realmente abre. Zero chamada extra agora,
 * dado fresco quando importa.
 */
function envelhecerTelas() {
  Object.keys(CACHE_TELAS).forEach((k) => { CACHE_TELAS[k].quando = 0; });
}

/*
 * FILA DO USUARIO.
 *
 * O Apps Script serializa as chamadas de uma mesma pessoa: se a prebusca
 * disparou seis, o clique dela entra atras das seis. Este contador marca
 * quando existe pedido do usuario em voo — a prebusca so anda com a fila
 * vazia, entao ela nunca mais atrasa um clique.
 */
let pedidosDoUsuario = 0;
const esperar = (ms) => new Promise((ok) => setTimeout(ok, ms));
async function filaLivre(limite) {
  for (let i = 0; i < (limite || 40) && pedidosDoUsuario > 0; i++) await esperar(300);
  return pedidosDoUsuario === 0;
}

async function abrir(idTela, params) {
  /*
   * 'modulos' e a tela inicial DO NAVEGADOR (os cartoes), nao uma tela do
   * servidor. Depois de uma acao feita ali (Reportar erro, Atualizar dados)
   * o agir() reabria a pagina atual e pedia ao servidor a tela "modulos":
   * caia num erro com a lateral vazia e sem botao de voltar.
   */
  if (!SESSAO) return;
  if (idTela === 'modulos') return abrirModulos();
  if (!(SESSAO.telas || []).some((t) => t.id === idTela)) {
    abrirModulos();
    return avisar('Esta tela não está liberada para você nesta filial.', true);   // pelo nivel ou pelo painel
  }
  paginaAtual = idTela; paramsAtual = params || {};
  lembrarTelaDaAba(idTela, paramsAtual);

  // Entrar por atalho (um botao da Central, por exemplo) tem que acender o
  // modulo certo na lateral, senao a pessoa fica sem saber onde esta.
  const dona = (SESSAO.telas || []).find((t) => t.id === idTela);
  if (dona && dona.modulo !== moduloAtual) { moduloAtual = dona.modulo; montarMenu(SESSAO.telas || []); }

  document.querySelectorAll('.item-menu').forEach((b) => b.classList.toggle('ativo', b.dataset.pagina === idTela));

  // O titulo muda ANTES da chamada. Se a tela falhar, o cabecalho tem que
  // mostrar onde voce esta, nao onde estava.
  const menu = (SESSAO.telas || []).find((t) => t.id === idTela);
  el('titulo-pagina').textContent = menu ? menu.nome : idTela;
  el('subtitulo-pagina').textContent = '';
  el('acoes-topo').innerHTML = '';

  const chave = chaveTela(idTela, paramsAtual);
  const guardado = CACHE_TELAS[chave];

  // Canal barrado: so a tela fresca (menos de 20 s) do cache serve; o resto vai pela pagina,
  // AINDA DENTRO DO CLIQUE (antes: uma chamada condenada de 1 a 6 s e, se o clique vencesse, o "Continuar").
  if (guardado && !(CANAL_BARRADO && Date.now() - guardado.quando >= 20000)) {
    // Vindo do cache do navegador: entra deslizando so quando a tela
    // MUDA de verdade; voltar para a mesma tela nao reanima nada.
    pintar(idTela, guardado.resposta, paginaAnterior === idTela);
    paginaAnterior = idTela;
    if (Date.now() - guardado.quando < 20000) return;  // fresco: nem revalida
    revalidar(idTela, paramsAtual, chave);      // por tras, sem "Carregando"
    return;
  }
  if (CANAL_BARRADO && abrirPorNavegacao(idTela, paramsAtual)) return;

  el('pagina').innerHTML = '<div class="vazio">Carregando…</div>';
  pedidosDoUsuario++;
  try {
    const filialPedida = FILIAL;
    const r = await carregarTelaSrv(idTela, paramsAtual);
    if (FILIAL !== filialPedida) return;                 // trocou de filial no meio
    CACHE_TELAS[chave] = { resposta: r, quando: Date.now() };
    // Clique rapido no menu: a resposta que chegou atrasada nao pinta por
    // cima da tela que a pessoa ja abriu.
    if (paginaAtual !== idTela || chaveTela(paginaAtual, paramsAtual) !== chave) return;
    pintar(idTela, r, paginaAnterior === idTela);
    paginaAnterior = idTela;
  } catch (e) {
    if (canalBloqueado(e) && abrirPorNavegacao(idTela, paramsAtual)) return;
    if (await painelSaiu(e, idTela)) return;
    el('pagina').innerHTML = `<div class="erro-caixa">${esc(explicarErro(e))}</div>`;
  } finally {
    pedidosDoUsuario--;
  }
}

/*
 * PREBUSCA — reescrita.
 *
 * Como era: logo depois do login, e de novo depois de CADA acao, o app
 * pedia TODAS as telas ao servidor, uma a uma. Sete telas = sete idas de
 * 1 a 3 s cada. E como o Apps Script atende uma chamada por vez para o
 * mesmo usuario, o clique da pessoa ficava atras dessa fila: o app abria
 * rapido e travava logo em seguida. Era a lentidao principal.
 *
 * Como ficou:
 *   - so as telas do MODULO em que a pessoa entrou (as outras ela pode
 *     nem abrir na sessao inteira);
 *   - so depois de a tela pedida ja estar na frente dela;
 *   - so com a fila do usuario vazia, e cedendo a vez a cada item;
 *   - para na hora se a pessoa trocar de modulo.
 */
let PREBUSCA_EM_CURSO = '';
async function prebuscarModulo(idModulo) {
  if (CANAL_BARRADO) return;                       // canal barrado: nada de chamada de fundo condenada
  // Uma volta por modulo (e por sessao: a de quem saiu ficou abandonada, ver GERACAO_SESSAO).
  const marca = GERACAO_SESSAO + '|' + idModulo;
  if (PREBUSCA_EM_CURSO === marca) return;
  PREBUSCA_EM_CURSO = marca;
  try {
    const alvo = (SESSAO && SESSAO.telas || []).filter((t) => t.modulo === idModulo);
    for (const t of alvo) {
      if (moduloAtual !== idModulo || CANAL_BARRADO || SAINDO_DA_PAGINA) return;   // a pessoa saiu do modulo
      if (!TOKEN || GERACAO_SESSAO + '|' + idModulo !== marca) return;          // saiu (ou entrou outra pessoa)
      const chave = chaveTela(t.id, {});
      if (CACHE_TELAS[chave]) continue;
      if (!(await filaLivre())) return;              // usuario ocupado: desiste
      // Conferido de novo DEPOIS da espera: a tela que a pessoa acabou de abrir chegou nesse meio tempo
      // (antes ela era pedida duas vezes).
      if (moduloAtual !== idModulo || CANAL_BARRADO || CACHE_TELAS[chave]) continue;
      try {
        const r = await carregarTelaSrv(t.id, {});
        if (!CACHE_TELAS[chave]) CACHE_TELAS[chave] = { resposta: r, quando: Date.now() };
      } catch (e) { /* tela sem permissao ou com erro: fica para o clique */ }
      await esperar(400);                            // deixa a fila respirar
    }
  } finally { if (PREBUSCA_EM_CURSO === marca) PREBUSCA_EM_CURSO = ''; }
}

/** Busca de novo em segundo plano e so repinta se mudou de verdade. */
async function revalidar(idTela, params, chave) {
  if (CANAL_BARRADO) return;
  try {
    const r = await carregarTelaSrv(idTela, params);
    const antes = CACHE_TELAS[chave];
    CACHE_TELAS[chave] = { resposta: r, quando: Date.now() };
    // Se o usuario ja saiu desta tela, atualiza so o cache.
    if (paginaAtual !== idTela || chaveTela(paginaAtual, paramsAtual) !== chave) return;
    if (!antes || !mesmaResposta(antes.resposta, r)) pintar(idTela, r, true);
  } catch (e) { painelSaiu(e, idTela); /* fora o painel desligado, e calada: a tela em uso continua valida */ }
}

/*
 * A hora da leitura das planilhas de fora (dados.atualizado, no Quadro e no
 * Jovem Aprendiz) muda a cada releitura sem o conteudo mudar. So ela nao e
 * motivo para redesenhar a tela por baixo de quem esta digitando na busca.
 */
function mesmaResposta(a, b) {
  const semHora = (r) => {
    if (!r || !r.dados || typeof r.dados !== 'object' || !('atualizado' in r.dados)) return JSON.stringify(r);
    const d = Object.assign({}, r.dados); delete d.atualizado;
    return JSON.stringify(Object.assign({}, r, { dados: d }));
  };
  return semHora(a) === semHora(b);
}

/* Resolvido na hora do uso, nao na leitura do arquivo. Uma tela sem pintor
   vira uma mensagem na tela — nao a pagina inteira em branco. */
const TELAS_PINTA = {
  inicio: 'pintarCentral', calendario: 'pintarCalendario', assiduidade: 'pintarAssiduidade',
  config: 'pintarConfig', acessos: 'pintarPessoas',
  apresentacao: 'pintarApresentacao',
  acoes: 'pintarAcoes', relatos: 'pintarRelatos',
  nobreaks: 'pintarNobreaks', limpeza: 'pintarLimpeza', quadro: 'pintarQuadro', filiais: 'pintarFiliais',
  estoque: 'pintarEstoque', aprendiz: 'pintarAprendiz', carga: 'pintarCarga'
};

/*
 * `silencioso` = esta e a repintura de fundo da revalidacao, nao uma
 * troca de tela. Sem esta distincao, o conteudo entrava deslizando UMA
 * VEZ ao abrir e DE NOVO meio segundo depois, quando o servidor
 * confirmava os dados — que e a "sensacao de lentidao" relatada: nao era
 * demora, era a animacao de entrada rodando duas vezes.
 */
/*
 * O QUE A PESSOA PODE EM CADA TELA — so o que o servidor disse (r.pode, que
 * vem junto com os dados de cada tela): nivel OCULTO/VER/EDITAR e editar.
 * Todo botao ou campo que grava depende de podeEditar(tela); com "Ver" a tela
 * abre so para leitura (e o servidor recusa qualquer gravacao do mesmo jeito).
 * Nunca pelo nome do nivel nem por capacidade.
 */
const ACESSO_DA_TELA = {};
function podeEditar(idTela) {
  const p = ACESSO_DA_TELA[idTela || paginaAtual];
  return !!(p && p.editar);
}
/* A faixa de um menu para esta pessoa, pelo menu que o servidor mandou ('' = nao esta no menu). */
function nivelDoMenu(idTela) {
  const t = ((SESSAO && SESSAO.telas) || []).find((x) => x.id === idTela);
  return t ? (t.nivel || 'VER') : '';
}
/* Botao de uma tela que grava em OUTRA (ex.: a Assiduidade levando a Configuracao): so com Ver e editar na outra. */
const editaMenu = (idTela) => nivelDoMenu(idTela) === 'EDITAR';
/*
 * A tela chegou com outro retrato do menu (r.menu: cada tela e a faixa dela)
 * que o menu desta pagina — a matriz mudou com a pessoa dentro: o menu e
 * relido (cartao que sumiu, tela que virou so leitura).
 */
const marcaDoMenuLocal = () => ((SESSAO && SESSAO.telas) || []).map((t) => t.id + ':' + (t.nivel || '')).join(',');
function conferirFaixaDoMenu(idTela, r) {
  if (r && typeof r.menu === 'string' && SESSAO && r.menu !== marcaDoMenuLocal()) atualizarPendencias();
}

function pintar(idTela, r, silencioso) {
  DADOS = r.dados;
  paginaAtual = idTela;
  ACESSO_DA_TELA[idTela] = r.pode || null;
  conferirFaixaDoMenu(idTela, r);
  if (ACAO_DO_LINK && ACAO_DO_LINK.tela !== idTela) ACAO_DO_LINK = null;     // a pessoa foi para outra tela antes de o plano do link abrir
  document.querySelectorAll('.item-menu').forEach((b) => b.classList.toggle('ativo', b.dataset.pagina === idTela));
  el('titulo-pagina').textContent = r.titulo;

  const pagina = el('pagina');
  pagina.classList.toggle('sem-entrada', !!silencioso);
  pagina.setAttribute('data-tela', idTela);          // 25/11: o estilo de cada tela (ex.: as de Configuracao) se prende aqui

  // O "modo filtrando" e so do calendario: nao pode vazar para outra tela.
  if (idTela !== 'calendario') pagina.classList.remove('filtrando');
  const pintor = window[TELAS_PINTA[idTela]];
  if (typeof pintor !== 'function') {
    pagina.innerHTML = `<div class="erro-caixa">A tela "${esc(idTela)}" ainda nao tem visual montado.</div>`;
    return;
  }
  /*
   * Cerca de protecao por tela. Antes, um erro no meio da montagem
   * deixava a area de conteudo VAZIA e sem mensagem — a "tela branca".
   * Agora o erro fica dentro da tela que o causou; o menu, a barra
   * lateral e o resto do sistema continuam de pe.
   */
  try {
    pintor(r);
  } catch (e) {
    pagina.innerHTML = `<div class="erro-caixa">
      <strong>Não consegui montar a tela "${esc(r.titulo || idTela)}".</strong>
      <div style="margin-top:8px">${esc(e.message || e)}</div>
      <div style="margin-top:12px">
        <button class="botao secundario" onclick="recarregarDados()">Tentar de novo</button>
        <button class="botao-texto" onclick="formFeedback()">Reportar este erro</button>
      </div></div>`;
  }
}

/*
 * Uma acao custava TRES viagens ao servidor: a acao, a remontagem da tela
 * e a prebusca de TODAS as outras telas. No Apps Script cada viagem custa
 * segundos — por isso o botao parecia travar.
 *
 * Agora:
 *   - so a tela ATUAL e invalidada (as outras revalidam sozinhas ao abrir);
 *   - a prebusca sai do caminho critico (roda depois, sem segurar ninguem);
 *   - o botao clicado mostra que esta trabalhando, entao a espera nao
 *     parece travamento.
 */
/* A reserva sabe gravar (Codigo.gs desta versao) e ha sessao para mandar junto. */
function podeGravarPelaPagina() { return !!(URL_APP && FILIAL && TOKEN); }
/*
 * Grava pela pagina (POST no /exec). Devolve uma promessa que nao se resolve
 * (a pagina vai embora), ou null quando nao ha como navegar. Lanca o erro ja
 * explicado na tela (Codigo.gs antigo, fotos grandes demais para um envio).
 */
const POST_MAXIMO = 30 * 1024 * 1024;
function gravarPelaPagina(acao, params, recado) {
  // Codigo.gs de antes de 10/10 (colado pela metade): ele trataria o POST como navegacao e nada seria gravado.
  if (!(SESSAO && SESSAO.app && SESSAO.app.gravarPelaPagina)) {
    const e = new Error('Atualização incompleta do GSL: gravar neste computador precisa do Codigo.gs desta versão. Avise o administrador do sistema.');
    avisar(e.message, true);
    throw e;
  }
  const corpo = JSON.stringify(params || {});
  if (corpo.length > POST_MAXIMO) {
    const e = new Error('As fotos passam do que dá para mandar de uma vez por este computador. Mande menos fotos (ou fotos menores) por vez.');
    avisar(e.message, true);
    throw e;
  }
  const tela = paginaAtual && paginaAtual !== 'modulos' ? paginaAtual : '';
  const temP = tela && paramsAtual && Object.keys(paramsAtual).length;
  if (navegarPelaPagina({ t: TOKEN, filial: FILIAL, tela: tela, p: temP ? JSON.stringify(paramsAtual) : '',
      acao: acao, ap: corpo, idem: novoIdem(), recado: recado || '' })) {
    return new Promise(() => {});      // a pagina vai embora; quem esperava o resultado nao roda
  }
  return null;
}

async function agir(acao, params, recado) {
  const botao = (typeof event !== 'undefined' && event && event.target)
    ? event.target.closest('button') : null;
  // Guarda o innerHTML, nao o texto: varios botoes tem icone dentro e
  // voltavam sem ele depois da acao.
  const rotulo = botao ? botao.innerHTML : '';
  if (botao) { botao.disabled = true; botao.textContent = 'Aguarde…'; }

  /*
   * 10/10 — CANAL BARRADO: a gravacao vai pela pagina (POST no /exec), dentro
   * do clique, pela mesma porta do servidor; a pagina volta com a tela atual
   * ja atualizada e o recado da acao. 20/10: as fotos vao junto (antes a tela
   * recusava: era a rota que funciona, e a foto ficava de fora).
   */
  if (CANAL_BARRADO && podeGravarPelaPagina()) {
    let indo = null;
    try { indo = gravarPelaPagina(acao, params, recado); }
    catch (e) { if (botao) { botao.disabled = false; botao.innerHTML = rotulo; } throw e; }
    if (indo) return indo;
  }

  pedidosDoUsuario++;
  const idTela = paginaAtual && paginaAtual !== 'modulos' ? paginaAtual : '';
  try {
    /*
     * 10/10 — UMA IDA SO: a acao e a tela atual ja atualizada voltam juntas
     * (executarAcaoETela), e a lista nao pisca em "Carregando…". Codigo.gs
     * antigo (sem essa porta): nada foi gravado, vai pelo caminho de antes.
     * 19/10: a gravacao que muda o menu (painel, filial, acesso) traz o menu novo.
     */
    const paramsTela = paramsAtual || {};
    const filialDoClique = FILIAL;
    const pedidoMenu = ++MENU_PEDIDOS;
    let r, tela = null, menu = null;
    if (SEM_ACAO_E_TELA) r = await executarAcaoSrv(acao, params);
    else {
      try {
        const x = await chamarJSON('executarAcaoETela', ctx(), acao, params || {}, idTela, paramsTela);
        r = x && x.r; tela = x && x.tela; menu = x && x.menu;
      } catch (e) {
        if (!/executarAcaoETela/.test(String((e && e.message) || e))) throw e;
        SEM_ACAO_E_TELA = true;
        r = await executarAcaoSrv(acao, params);
      }
    }
    if (menu && FILIAL === filialDoClique) {
      if (menu.semFilial) { fecharJanela(); filialDesligada(menu.filiais, menu.motivo); return r; }
      aplicarMenu(menu, pedidoMenu);
    }

    /*
     * Invalida a tela atual (essa tem que voltar do servidor) e apenas
     * ENVELHECE as outras. Antes daqui saia um `esquecerTelas()` seguido
     * de uma prebusca de todas as telas: aprovar uma atividade custava
     * oito idas ao servidor e ~15 s de fila. Agora custa uma.
     */
    // Acoes globais (parametros, perfis) mudam TODAS as telas: nesses
    // casos o cache inteiro cai, senao outra tela mostra dado velho.
    // esquecerTelas (a rotina mudou o calendario): o mesmo, sem o menu — e a tela atual ja voltou com a gravacao.
    if (r && (r.invalidarTudo || r.esquecerTelas)) esquecerTelas();
    else { esquecerTela(paginaAtual); envelhecerTelas(); }
    // A tela que ja voltou com a gravacao entra fresca no cache: o abrir() abaixo pinta sem ir ao servidor.
    // Trocou de filial enquanto gravava: a tela que voltou e da filial de antes (nao vai para a bolinha nem para o cache).
    if (tela && idTela && FILIAL === filialDoClique) notarBolinhaDaTela(idTela, tela);
    if (tela && idTela && FILIAL === filialDoClique && paginaAtual === idTela) CACHE_TELAS[chaveTela(idTela, paramsTela)] = { resposta: tela, quando: Date.now() };
    fecharJanela();

    /*
     * Se o servidor devolveu um aviso (tipico: a operacao gravou mas o
     * e-mail nao saiu), ele TEM que aparecer. Antes a falha de e-mail era
     * engolida e a tela dizia so "Atividade criada" — por isso ninguem
     * percebia que o coordenador nunca foi avisado.
     */
    if (r && r.avisoEmail) avisar(r.avisoEmail, true);
    // O servidor pode devolver um recado mais preciso que o do botao
    // (por exemplo: para QUAIS enderecos o aviso saiu). Ele tem prioridade.
    else if (r && r.recado) avisar(r.recado);
    else if (recado) avisar(recado);
    await abrir(paginaAtual, paramsAtual);
    return r;
  } catch (e) {
    if (idTela && await painelSaiu(e, idTela)) throw e;      // o painel saiu da filial: menu e aviso, sem a caixa de erro
    /*
     * 20/10 — O GOOGLE RECUSOU A CONVERSA (403, PERMISSION_DENIED): o pedido
     * nem chegou ao servidor, entao nada foi gravado. Em vez do erro (e de a
     * pessoa ter de clicar de novo), segue pela pagina na hora — a rota que
     * funciona. Sem o clique valendo, o "Continuar" pede o clique.
     */
    if (canalBarradoDeVez(e) && podeGravarPelaPagina()) {
      if (botao) { botao.disabled = false; botao.innerHTML = rotulo; }
      const indo = gravarPelaPagina(acao, params, recado);
      if (indo) return indo;
    }
    let msg = e.message || String(e);
    // "Acao desconhecida" e implantacao pela metade (Codigo.gs antigo com telas novas).
    // O Codigo.gs antigo nao explica isso — entao a tela explica.
    if (/A[cç][aã]o desconhecida/i.test(msg) && !/Nova vers/i.test(msg)) {
      msg += ' — o Codigo.gs publicado no Apps Script está numa versão anterior às telas. Cole todos os arquivos desta versão e crie uma "Nova versão" da implantação.';
    }
    // Erro de permissao de e-mail nao vira um aviso que some em 7s: vira uma
    // janela com o passo a passo e o botao que leva direto para autorizar.
    // O canal barrado (varias contas Google: "PERMISSION_DENIED") vem antes:
    // ele tambem diz "permission", mas nao tem nada a ver com o e-mail.
    // ("permiss" saiu da lista pelo mesmo motivo — e pegava ate o nosso
    // "Sem permissao para ..." das telas.)
    if (canalBloqueado(e)) avisar(explicarErro(e), true);
    else if (/MailApp|send_mail|autoriz/i.test(msg)) janelaAutorizarEmail(msg);
    else avisar(msg, true);
    throw e;
  } finally {
    pedidosDoUsuario--;
    if (botao) { botao.disabled = false; botao.innerHTML = rotulo; }
  }
}

let SEM_ACAO_E_TELA = false;     // Codigo.gs publicado sem executarAcaoETela (versao misturada)

/* Apaga do cache do cliente so as entradas de uma tela. */
function esquecerTela(idTela) {
  Object.keys(CACHE_TELAS).forEach(function (k) {
    if (k.indexOf(FILIAL + '|' + idTela + '|') === 0) delete CACHE_TELAS[k];
  });
}
const recarregarDados = () => agir('atualizarDados', {}, 'Dados atualizados');

/*
 * Guia de autorizacao de e-mail. Aparece quando um envio falha por falta de
 * permissao. O botao abre a pagina de permissoes da conta Google: la a
 * pessoa remove o acesso antigo e, ao voltar, o sistema pede a permissao
 * nova (incluindo o Gmail) automaticamente.
 */
function gerarProximoMes() {
  const hoje = new Date();
  const meses = ['JAN','FEV','MAR','ABR','MAI','JUN','JUL','AGO','SET','OUT','NOV','DEZ'];
  // proximos 6 meses como opcoes
  const opcoes = [];
  for (let i = 0; i <= 6; i++) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() + i, 1);
    opcoes.push(meses[d.getMonth()] + ' ' + d.getFullYear());
  }
  // O recado vem do servidor ("N criadas" ou "nada a gerar"): antes a
  // tela dizia "Mes gerado" mesmo quando nada tinha sido gerado.
  abrirJanela('Gerar um mês', `
    <p style="margin:0 0 14px;line-height:1.7;color:var(--tinta-media)">
      Cria as atividades do mês escolhido a partir das rotinas, sem esperar a geração automática do dia 20.
      Se o mês já existe, só cria o que estiver faltando, de hoje em diante — nada é duplicado.
    </p>
    <div class="campo"><label>Mes</label>
      <select id="gm-comp">${opcoes.map((c) => `<option>${c}</option>`).join('')}</select></div>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('gerarMes',{competencia:val('gm-comp')},'Pronto')">Gerar mês</button>`);
}

function restaurarPerfis() {
  abrirJanela('Restaurar níveis de acesso', `
    <p style="margin:0 0 14px;line-height:1.7;color:var(--tinta-media)">
      Volta a grade dos níveis padrão (Admin, Gerente, Coordenador, Supervisor, Consulta) ao que vem de fábrica:
      cada menu com <b>Oculto</b>, <b>Ver</b> ou <b>Ver e editar</b> como na instalação, e o alcance de cada nível.
      As pessoas continuam nos seus níveis, com os ajustes de cada uma; os níveis que você criou não mudam.
    </p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="confirmarRestauro()">Restaurar</button>`);
}

/* Pelo agir(): a resposta traz o menu novo e todas as telas sao relidas (invalidarTudo). */
function confirmarRestauro() {
  agir('restaurarPerfis', {}, 'Níveis de acesso restaurados ao padrão').catch(() => {});
}

async function diagnosticarAcesso() {
  abrirJanela('Diagnostico de acesso', '<div class="vazio">Analisando…</div>', '');
  try {
    const d = await executarAcaoSrv('diagnosticoAcesso', {});
    const problema = d.diagnostico.indexOf('PROBLEMA') === 0;
    abrirJanela('Diagnostico de acesso', `
      <div class="${problema ? 'erro-caixa' : 'cartao'}" style="margin-bottom:14px">
        <strong>${problema ? '\u26A0 ' : '\u2713 '}${esc(d.diagnostico)}</strong>
      </div>
      <table><tbody>
        <tr><td>Seu e-mail</td><td class="mono">${esc(d.voceEh.email)}</td></tr>
        <tr><td>Perfil</td><td><strong>${esc(d.voceEh.perfil)}</strong></td></tr>
        <tr><td>Seu turno (em Acessos)</td><td><strong>${esc(d.voceEh.turno)}</strong></td></tr>
        <tr><td>Escopo do perfil</td><td>${esc(d.voceEh.escopo)}</td></tr>
        <tr><td>Competência</td><td>${esc(d.competencia)}</td></tr>
        <tr><td>Atividades no mês</td><td>${d.totalNoMes}</td></tr>
        <tr><td>Visiveis para você</td><td><strong>${d.visiveisParaVoce}</strong></td></tr>
        <tr><td>Turnos das atividades</td><td>${esc(d.turnosDasAtividades.join(' · '))}</td></tr>
      </tbody></table>
      <p class="dica" style="margin-top:12px">Se o problema for de turno, corrija na aba <b>Acessos</b>: a coluna Turno da pessoa precisa bater (A, B ou C) com o turno das atividades.</p>`,
      '<button class="botao" onclick="fecharJanela()">Fechar</button>');
  } catch (e) { avisar(e.message || e, true); }
}

function janelaAutorizarEmail(msg) {
  abrirJanela('Falta autorizar o envio de e-mail', `
    ${msg ? `<div class="erro-caixa" style="margin:0 0 14px">${esc(msg)}</div>` : ''}
    <p style="margin:0 0 14px;line-height:1.7;color:var(--tinta-media)">
      O sistema tentou avisar por e-mail, mas o Google ainda não liberou o envio
      para esta conta. E rápido de resolver e só precisa ser feito <b>uma vez</b>.
    </p>
    <ol style="margin:0 0 16px;padding-left:22px;line-height:1.9">
      <li>Clique no botao <b>Abrir página de autorização</b> abaixo.</li>
      <li>Na lista, ache o app <b>GSL Bartofil</b> e clique nele.</li>
      <li>Clique em <b>Remover acesso</b>.</li>
      <li>Volte aqui, recarregue a página e o Google vai pedir a permissão de novo — aceite tudo, inclusive o <b>Gmail</b>.</li>
    </ol>
    <p class="dica">Isso vale só para você, o dono do sistema. Os coordenadores e o gerente não precisam autorizar nada — eles só recebem os e-mails.</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Fechar</button>
    <button class="botao" onclick="window.open('https:\/\/myaccount.google.com/permissions','_blank')">Abrir página de autorização</button>`);
}

/*
 * O recado fica o tempo de ler: ~60 ms por letra, no minimo 2,6 s (7 s o de
 * erro) e no maximo 15 s. Um recado novo leva o tempo dele — antes sumia no
 * prazo do anterior, que ainda corria.
 */
let RECADO_TEMPO = 0;
function avisar(texto, erro) {
  const r = el('recado');
  r.textContent = texto;
  r.className = 'recado' + (erro ? ' erro' : '');
  r.classList.remove('oculto');
  clearTimeout(RECADO_TEMPO);
  RECADO_TEMPO = setTimeout(() => r.classList.add('oculto'),
    Math.min(15000, Math.max(erro ? 7000 : 2600, 1200 + String(texto || '').length * 60)));
}

function abrirJanela(titulo, corpo, rodape) {
  el('janela-titulo').textContent = titulo;
  el('janela-corpo').innerHTML = corpo;
  el('janela-rodape').innerHTML = rodape;
  el('janela').classList.remove('oculto');
}
const fecharJanela = () => el('janela').classList.add('oculto');

/* ================= CENTRAL ================= */
function pintarCentral(r) {
  const d = r.dados, u = d.urgencias, g = d.geral;
  el('subtitulo-pagina').textContent = d.hoje + ' · ' + d.escopo;
  el('acoes-topo').innerHTML = '';

  el('pagina').innerHTML = `
    <div class="grade grade-kpi" style="margin-bottom:16px">
      ${kpi(u.atrasadas, 'Atrasadas agora', 'vermelho')}
      ${kpi(u.hoje, 'Vencem hoje', 'amarelo')}
      ${kpi(u.aguardando, 'Aguardando validacao', 'azul')}
      ${kpi(g.percentual + '%', 'Aprovadas no geral', 'verde')}
    </div>

    <div class="grade grade-dupla" style="margin-bottom:14px">
      <div class="cartao">
        <div class="cartao-titulo">Sua semana — ${esc(d.semana.inicio)} a ${esc(d.semana.fim)}</div>
        ${d.semana.itens.length ? d.semana.itens.map((a) => `
          <div class="linha-atividade">
            <div class="data-atividade"><div class="data-dia">${esc(a.prazo.slice(0,5))}</div>
              <div class="data-semana">${esc(a.diaSemana)}</div></div>
            <div class="texto-atividade"><div class="nome-atividade">${esc(a.atividade)}</div>
              <div class="meta-atividade">Turno ${esc(a.turno)}${a.setor ? ' · ' + esc(a.setor) : ''}</div></div>
            ${etiqueta(a.status)}
          </div>`).join('') : '<div class="vazio">Nada previsto para esta semana.</div>'}
      </div>
      <div class="cartao">
        <div class="cartao-titulo">Desempenho por turno</div>
        <table><thead><tr><th>Turno</th><th class="numero">Total</th><th class="numero">Aprov.</th>
          <th class="numero">Atrás.</th><th class="numero">%</th></tr></thead><tbody>
          ${d.porTurno.map((t) => `<tr><td><strong>${esc(t.turno)}</strong></td>
            <td class="numero">${t.total}</td><td class="numero">${t.aprovadas}</td>
            <td class="numero">${t.atrasadas}</td><td class="numero">${t.percentual}%</td></tr>`).join('')}
        </tbody></table>
      </div>
    </div>

    ${d.insights.length ? `
    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo">Insights — o que os dados estão dizendo</div>
      ${d.insights.map((i) => `
        <div class="insight ${esc(i.nivel)}">
          <div class="insight-texto">${esc(i.texto)}</div>
          <div class="insight-rec">${esc(i.recomendacao)}</div>
        </div>`).join('')}
    </div>` : ''}

    <div class="cartao">
      <div class="cartao-titulo">Andamento mês a mês</div>
      <table><thead><tr><th>Competência</th><th class="numero">Total</th><th class="numero">Aprov.</th>
        <th class="numero">Aguard.</th><th class="numero">Pend.</th><th class="numero">Atrás.</th>
        <th class="numero">%</th><th>Situação</th></tr></thead><tbody>
        ${d.porMes.map((m) => `<tr><td><strong>${esc(m.competencia)}</strong></td>
          <td class="numero">${m.total}</td><td class="numero">${m.aprovadas}</td>
          <td class="numero">${m.aguardando}</td><td class="numero">${m.pendentes}</td>
          <td class="numero">${m.atrasadas}</td><td class="numero">${m.percentual}%</td>
          <td>${esc(m.situacao)}</td></tr>`).join('')
          || '<tr><td colspan="8" class="vazio">Nenhuma competência gerada ainda.</td></tr>'}
      </tbody></table>
    </div>`;
}

/* ================= CALENDARIO ================= */
function pintarCalendario(r) {
  const d = r.dados, p = d.permissoes;
  el('subtitulo-pagina').textContent = d.competencia + ' · ' + r.escopo;

  // O seletor de mes saiu do cabecalho. Agora e uma tira de cartoes de mes
  // logo acima do calendario — da para ver todos os meses e trocar num toque.
  el('acoes-topo').innerHTML = '';

  const meses = d.competenciasDisponiveis.length ? d.competenciasDisponiveis : [d.competencia];

  /*
   * A tira de meses agora carrega TAMBEM os meses ja encerrados. Eles
   * ficam a esquerda, apagados e com um cadeado, separados por um traco
   * do mes atual em diante — da para consultar agosto sem confundi-lo
   * com um mes que ainda esta correndo.
   */
  const encerrados = d.competenciasEncerradas || [];
  const chip = (c) => {
    const fechado = encerrados.indexOf(c) !== -1;
    return `<button class="chip-mes ${c === d.competencia ? 'ativo' : ''}${fechado ? ' encerrado' : ''}"
              title="${fechado ? 'Mês encerrado — só consulta' : 'Abrir ' + esc(c)}"
              onclick="abrir('calendario',{competencia:${jsArg(c)}})">${fechado ? '🔒 ' : ''}${esc(c)}</button>`;
  };
  const emCurso = meses.filter((c) => encerrados.indexOf(c) === -1);

  el('pagina').innerHTML = `
    <div class="tira-meses">
      ${encerrados.map(chip).join('')}
      ${encerrados.length && emCurso.length ? '<span class="divisor-meses" aria-hidden="true"></span>' : ''}
      ${emCurso.map(chip).join('')}
    </div>

    ${d.encerrado ? `
      <div class="aviso-encerrado">
        <strong>🔒 ${esc(d.competencia)} é um mês encerrado.</strong>
        Você está consultando o histórico: os números abaixo são o resultado final do mês
        e nada mais é gerado nem cobrado aqui. Para trabalhar, volte ao mês em andamento.
      </div>` : ''}

    ${d.avisoGeracao ? `<div class="erro-caixa" style="margin-bottom:14px">${esc(d.avisoGeracao)}</div>` : ''}

    <div class="grade grade-kpi" style="margin-bottom:16px">
      ${kpiFiltro(d.resumo.total, 'Programadas', 'azul', 'todas')}
      ${kpiFiltro(d.resumo.aprovadas, 'Aprovadas', 'verde', 'aprovada')}
      ${kpiFiltro(d.resumo.aguardando, 'Entregues — aguardando validação', 'azul', 'aguardando')}
      ${kpiFiltro(d.resumo.atrasadas, 'Atrasadas', 'vermelho', 'atrasada')}
      ${kpiFiltro(d.resumo.reprovadas, 'Reprovadas', 'laranja', 'reprovada')}
    </div>

    <div class="faixa-andamento ${esc(d.andamento.nivel)}">
      <strong>${esc(d.andamento.titulo)}</strong> — ${esc(d.andamento.texto)}
    </div>

    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo">Calendário operacional</div>
      <div class="grade-mes">
        ${['DOM','SEG','TER','QUA','QUI','SEX','SAB'].map((n) => `<div class="dia-cabecalho">${n}</div>`).join('')}
        ${d.grade.map((semana) => semana.map((dia) => `
          <div class="dia${dia.doMes ? '' : ' fora'}${dia.hoje ? ' hoje' : ''}${
                dia.temAtraso ? ' com-atraso' : (dia.temPrazo ? ' com-prazo' : '')}${
                dia.reuniao ? ' reuniao' : ''}${
                dia.itens.some((i) => i.entregue) ? ' tem-entrega' : ''}">
            <div class="dia-numero">${dia.dia}</div>
            ${dia.itens.map((i) => `
              <button class="pilula ${classeStatus(i.status)}${i.entregue ? ' tem-anexo' : ''}" title="${esc(i.atividade)}${i.entregue ? ' — ENTREGUE (' + (i.qtdAnexos || 0) + ' arquivo)' : ''}"
                      data-turno="${esc(i.turno)}"
                      onclick="abrirAtividade(${jsArg(i.id)})">${esc(i.tipo)}${i.turno !== 'Todos' ? ' ' + esc(i.turno) : ''}</button>`).join('')}
          </div>`).join('')).join('')}
      </div>
      <div class="legenda-mes">
        <span><i class="amostra st st-pendente"></i>pendente</span>
        <span><i class="amostra st st-atrasada"></i>atrasada</span>
        <span><i class="amostra st st-aguardando"></i>entregue — aguardando validação</span>
        <span><i class="amostra st st-aprovada"></i>aprovada</span>
        <span><i class="amostra st st-reprovada"></i>reprovada</span>
        <span><i class="amostra st st-cancelada"></i>cancelada</span>
      </div>
      <div class="legenda-mes">
        <span><i class="amostra hoje"></i>hoje</span>
        <span><i class="amostra prazo"></i>dia com prazo</span>
        <span><i class="amostra atraso"></i>dia com atraso</span>
        <span><i class="amostra reuniao"></i>reunião com a gerência — o marco da semana</span>
      </div>
    </div>

    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo linha-titulo">
        <span>Gestao de atividades — ${d.atividades.length} no mes</span>
        <span style="display:flex;gap:8px">
          ${d.mesPassado && p.validar ? `<button class="botao secundario" onclick="encerrarMes(${jsArg(d.competencia)})">Encerrar mês passado</button>` : ''}
          ${p.programar && !d.mesPassado ? `<button class="botao" onclick="formNovaAtividade(${jsArg(d.competencia)})">+ Nova atividade</button>` : ''}
        </span>
      </div>
      ${d.mesPassado ? '<p class="dica" style="margin:-4px 0 12px">Mês encerrado — esta é a foto final. Se ficou algo pendente e você quer tirá-lo das contagens, use <b>Encerrar mês passado</b>.</p>' : ''}
      ${tiraDeTurnos(d.atividades)}
      <p class="dica" style="margin:-4px 0 12px">${p.entregar || p.validar
        ? 'Clique em <b>Abrir</b> na atividade para anexar entrega, remarcar, dar feedback, aprovar, reprovar ou cancelar.'
        : 'Clique em <b>Abrir</b> para ver a atividade e a entrega. Seu acesso ao Calendário é só para ver.'}</p>
      <div style="overflow-x:auto">
        <table class="tabela-gestao"><thead><tr>
          <th></th><th>ID</th><th>Sem.</th><th>Prazo</th><th>Atividade</th><th>Turno</th>
          <th>Coordenador</th><th>Setor</th><th>Entrega</th><th>Entregue em</th>
          <th>Validação</th><th>Motivo reprov./cancel.</th><th>Status</th>
        </tr></thead><tbody>
          ${d.atividades.map((a) => `
            <tr class="linha-status ${classeStatus(a.status)}" data-turno="${esc(a.turno)}">
              <td><button class="botao-abrir" onclick="abrirAtividade(${jsArg(a.id)})">Abrir</button></td>
              <td class="mono">${esc(a.id)}</td>
              <td>${esc(a.semana)}</td>
              <td>${esc(a.prazo)}</td>
              <td>${esc(a.atividade)}</td>
              <td>${esc(a.turno)}</td>
              <td>${esc(a.coordenador || '—')}</td>
              <td>${esc(a.setor || '—')}</td>
              <td>${a.entregue
                    ? `<span class="selo-entrega">\u{1F4CE} ${a.qtdAnexos || 0} arquivo(s)</span>`
                    : '<span class="pendente-entrega">aguardando</span>'}</td>
              <td>${esc(a.entregueEm || '—')}</td>
              <td>${esc(a.validacao || '—')}</td>
              <td class="motivo">${esc(a.motivo || '')}</td>
              <td>${etiqueta(a.status)}${a.diasAtraso ? `<div class="meta-atividade">${a.diasAtraso} dia(s)</div>` : ''}</td>
            </tr>`).join('') || '<tr><td colspan="13" class="vazio">Nenhuma atividade neste mês.</td></tr>'}
        </tbody></table>
      </div>
    </div>

    ${vagasDoMes(d).length ? `
    <div class="cartao bloco-treinamento">
      <div class="cartao-titulo">Treinamentos e vagas programados pelo gerente</div>
      <div class="dica" style="margin-bottom:10px">
        Vaga que o gerente marca — preencha o tema, o turno e a data. O coordenador e avisado por e-mail na hora.
      </div>
      ${vagasDoMes(d).map((a) => `
        <div class="linha-atividade">
          <div class="data-atividade">
            <div class="data-dia">${a.prazo ? esc(a.prazo.slice(0, 5)) : '--'}</div>
            <div class="data-semana">${a.prazo ? esc(a.diaSemana) : 'sem data'}</div>
          </div>
          <div class="texto-atividade">
            <div class="nome-atividade">${esc(a.atividade)}</div>
            <div class="meta-atividade mono">${esc(a.id)}${a.turno ? ' \u00b7 turno ' + esc(a.turno) : ''}</div>
          </div>
          ${a.prazo ? etiqueta(a.status) : '<span class="etiqueta iniciar">Não agendado</span>'}
          ${p.programar ? `<button class="icone-botao" onclick="formTreinamento(${jsArg(a.id)})">${a.prazo ? 'Alterar' : 'Agendar'}</button>` : ''}
          ${a.prazo ? `<button class="icone-botao" onclick="abrirAtividade(${jsArg(a.id)})">Abrir</button>` : ''}
        </div>`).join('')}
    </div>` : ''}

    ${(d.canceladas || []).length ? `
    <div class="cartao bloco-arquivo" style="margin-top:14px">
      <div class="cartao-titulo">Arquivo — atividades canceladas (${d.canceladas.length})</div>
      <p class="dica" style="margin:-4px 0 12px">Ficam fora do calendário e das contagens. Reative se precisar de volta.</p>
      ${d.canceladas.map((a) => `
        <div class="linha-atividade">
          <div class="texto-atividade">
            <div class="nome-atividade" style="text-decoration:line-through;opacity:.7">${esc(a.atividade)}</div>
            <div class="meta-atividade mono">${esc(a.id)} \u00b7 ${esc(a.prazo || 'sem data')} \u00b7 ${esc(a.motivo || '')}</div>
          </div>
          ${p.validar ? `<button class="icone-botao" onclick="agir('reativarAtividade',{id:${jsArg(a.id)}},'Atividade reativada')">Reativar</button>` : ''}
        </div>`).join('')}
    </div>` : ''}`;
  // Filtro de status/turno sobrevive a repintura (acao ou revalidacao de
  // fundo): antes a pilula continuava acesa, mas nada mais era filtrado.
  // Mas o turno so vale se a pastilha dele ainda existe (outro mes pode nao
  // ter aquele turno, ou nem ter a tira): senao o mes inteiro ficava apagado
  // sem nenhum botao para desfazer.
  const pastilhas = Array.from(el('pagina').querySelectorAll('.pastilha-turno'));
  if (filtroTurno && !pastilhas.some((b) => b.dataset.turnoFiltro === filtroTurno)) {
    filtroTurno = null;
    pastilhas.forEach((b) => b.classList.toggle('ativa', !b.dataset.turnoFiltro));
  }
  aplicarFiltro();
}

function encerrarMes(competencia) {
  abrirJanela('Encerrar ' + competencia, `
    <p style="margin:0 0 14px;line-height:1.7;color:var(--tinta-media)">
      Cancela as atividades de <b>${esc(competencia)}</b> que ficaram <b>pendentes ou atrasadas</b>
      (e as vagas de treinamento nunca agendadas).
      Elas somem do calendário e das contagens, mas ficam no arquivo — da para reativar depois.
    </p>
    <p class="dica" style="margin:0 0 14px">Entregas <b>aguardando validação</b> ou <b>reprovadas</b> não são
      canceladas: o coordenador já entregou — valide-as no calendário do mês.</p>
    <div class="campo"><label>Motivo</label>
      <textarea id="em-motivo" placeholder="Ex.: mês encerrado, não será mais cobrado">Mês encerrado pela gestão.</textarea></div>`, `
    <button class="botao secundario" onclick="fecharJanela()">Voltar</button>
    <button class="botao perigo" onclick="agir('cancelarCompetencia',{competencia:${jsArg(competencia)},motivo:val('em-motivo')},'Mes encerrado')">Encerrar mês</button>`);
}

function todasAtividades() {
  return [].concat(DADOS.atividades || [], DADOS.treinamentos || [], DADOS.naoAgendadas || []);
}

/*
 * A MESMA regra do servidor (podeGravarNaAtividade_): entrega quem tem
 * ENTREGAR ou ANEXAR e, se for coordenador, so no proprio turno ou em
 * atividade "Todos". Sem ela a tela mostrava o envio em qualquer
 * atividade e o coordenador subia todas as fotos para so no fim ouvir
 * "nao pode".
 */
function podeEntregarNa_(a, p) {
  if (!a || !p || !p.entregar) return false;
  const t = String(a.turno || '').toUpperCase();
  return !p.turnoEntrega || t === '' || t === 'TODOS' || t === p.turnoEntrega;
}

/* Remover anexo: quem entrega ali, e de atividade aprovada so quem valida. */
function podeRemoverAnexo_(a, p) {
  return podeEntregarNa_(a, p) && (a.status !== 'Aprovada' || !p.turnoEntrega);   // aprovada: so a gestao (alcance: operacao inteira)
}
/* Ninguem valida a propria entrega: quem mandou arquivo para a atividade nao aprova nem reprova (o servidor confere). */
const entreguePorMim = (a, p) => (a.entreguePor || []).indexOf(String((p && p.email) || meuEmail())) !== -1;

function abrirAtividade(id) {
  const d = DADOS, p = d.permissoes;
  const a = todasAtividades().find((x) => x.id === id);
  if (!a) return;

  // A entrega aparece na hora que a atividade abre — nada de "carregando",
  // nada de procurar. Se ha PDF entregue, um botao grande abre ele direto.
  const anexos = (a.entregue && a.anexoUrl)
    ? `<a class="anexo-entregue" href="${esc(a.anexoUrl)}" target="_blank">
         <span class="anexo-icone">\u{1F4C4}</span>
         <span class="anexo-texto">
           <span class="anexo-titulo">Entrega recebida</span>
           <span class="anexo-sub">Entregue em ${esc(a.entregueEm || '—')} \u00b7 toque para abrir o PDF</span>
         </span>
         <span class="anexo-seta">\u2192</span>
       </a>`
    : '<div class="dica">Nenhum arquivo entregue ainda.</div>';

  // "Exige setor" das rotinas (19/10). Servidor de antes (sem tiposComSetor): so a Vistoria, como era.
  const comSetor = (d.tiposComSetor || ['VIS']).indexOf(a.tipo) !== -1;
  const setor = p.programar && comSetor ? `
    <div class="campo">
      <label>${a.tipo === 'VIS' ? 'Setor da vistoria' : 'Setor'}</label>
      <select id="a-setor" onchange="agir('definirSetor',{id:${jsArg(a.id)},setor:this.value},'Setor definido — coordenador avisado')">
        <option value="">Escolher…</option>
        ${d.setores.map((s) => `<option ${a.setor === s ? 'selected' : ''}>${esc(s)}</option>`).join('')}
      </select>
      <p class="dica">Ao definir, o coordenador do turno recebe o aviso na hora.</p>
    </div>` : (a.setor ? `<div class="campo"><label>Setor</label><input value="${esc(a.setor)}" readonly></div>` : '');

  // Ja decidida (aprovada, reprovada ou cancelada): mostra o veredito, nao os
  // botoes de decidir de novo. So oferece "Reabrir" para desfazer.
  const jaDecidida = a.validacao === 'Aprovado' || a.validacao === 'Reprovado' || a.validacao === 'Cancelada';
  const entregueMinha = entreguePorMim(a, p);

  // A caixa de feedback comeca VAZIA. Vinha preenchida com o MOTIVO da linha
  // — a nota de remarcacao ou o motivo da reprovacao anterior — e aprovar
  // mandava esse texto como "feedback" no e-mail. O historico fica acima dela.
  const validacao = p.validar ? (jaDecidida ? `
    <div class="campo" style="border-top:1px solid var(--linha);padding-top:16px">
      <label>Validação do gerente</label>
      <div class="veredito ${classeStatus(a.status)}">
        <span>${esc(a.validacao)}</span>
        ${a.motivo ? `<div class="veredito-motivo">${esc(a.motivo)}</div>` : ''}
      </div>
      <button class="icone-botao" style="margin-top:10px" onclick="reabrirAtividade(${jsArg(a.id)})">Reabrir para nova validação</button>
    </div>` : `
    <div class="campo" style="border-top:1px solid var(--linha);padding-top:16px">
      <label>Validação do gerente</label>
      ${a.motivo ? `<p class="dica" style="margin:0 0 8px">Histórico: ${esc(a.motivo)}</p>` : ''}
      ${entregueMinha ? `<p class="dica" style="margin:0 0 8px">Você enviou arquivo para esta atividade: a validação fica com outra pessoa —
        ninguém valida a própria entrega.</p>` : `
      <textarea id="a-motivo" placeholder="Feedback ou motivo (obrigatório para reprovar)"></textarea>`}
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        ${entregueMinha ? '' : `<button class="botao" style="background:var(--verde)" onclick="validar(${jsArg(a.id)},'Aprovado')">Aprovar</button>
        <button class="botao perigo" onclick="validar(${jsArg(a.id)},'Reprovado')">Reprovar</button>`}
        <button class="botao secundario" onclick="cancelarAtividade(${jsArg(a.id)})">Cancelar atividade</button>
      </div>
    </div>`) : (a.motivo ? `<div class="campo"><label>Retorno da gerência</label>
      <div class="erro-caixa" style="background:var(--azul-tenue);border-color:var(--linha);color:var(--tinta)">${esc(a.motivo)}</div></div>` : '');

  abrirJanela(a.atividade, `
    <div class="campo-duplo">
      <div class="campo"><label>ID</label><input value="${esc(a.id)}" readonly></div>
      <div class="campo"><label>Prazo</label><input value="${esc(a.prazo || 'nao agendado')}" readonly></div>
    </div>
    <div class="campo-duplo">
      <div class="campo"><label>Turno</label><input value="${esc(a.turno)}" readonly></div>
      <div class="campo"><label>Responsavel</label><input value="${esc(a.coordenador || coordenadorDoTurno(a.turno) || 'a definir')}" readonly></div>
    </div>
    ${setor}
    <div class="campo">
      <label>Status</label>
      <div>${etiqueta(a.status)} ${a.entregueEm ? `<span class="meta-atividade">entregue em ${esc(a.entregueEm)}</span>` : ''}</div>
    </div>
    <div class="campo">
      <label>Entrega</label>
      ${anexos}
      <div id="lista-anexos" class="vazio">${a.qtdAnexos ? 'Carregando anexos…' : 'Nenhum arquivo ainda.'}</div>
      ${p.entregar && !podeEntregarNa_(a, p) ? `
        <p class="dica" style="margin-top:10px">Esta atividade é do turno ${esc(a.turno)}: quem entrega é o
          coordenador desse turno ou a gerência.</p>` : ''}
      ${podeEntregarNa_(a, p) ? `
        <div class="area-envio" style="margin-top:10px">
          <input type="file" id="a-arquivos" multiple
                 accept="image/\*,.heic,.heif,.hif,.tif,.tiff,.avif,.dng,.pdf,.docx,.doc,.odt,.rtf,.txt"
                 onchange="listarEscolhidos()" style="display:none">
          <button class="botao secundario" type="button" onclick="el('a-arquivos').click()">Escolher fotos ou arquivos</button>
          <div id="a-lista" class="lista-envio"></div>
          <button class="botao" id="a-enviar" type="button" style="margin-top:10px;display:none"
                  onclick="enviarEntrega(${jsArg(a.id)})">Gerar PDF e enviar entrega</button>
          <p class="dica">Varias fotos viram um PDF único, uma por página. Aceita JPG, PNG, HEIC, PDF e documentos.
             Ao enviar, a gestão e avisada e o status vira "Aguard. valid.".
             <b>Pode entregar mais de uma vez</b> na mesma atividade: cada envio vira um
             arquivo novo e os anteriores continuam lá.</p>
        </div>` : ''}
    </div>
    ${validacao}`, `
    ${p.programar && a.prazo ? `<button class="botao secundario" onclick="formRemarcar(${jsArg(a.id)})">\u{1F4C5} Remarcar data</button>` : ''}
    <button class="botao secundario" onclick="fecharJanela()">Fechar</button>`);

  /*
   * carregarDetalhes() (antes carregarAnexos) existia e NUNCA era chamada — e o elemento que ela
   * procurava (#lista-anexos) tinha saido da janela. Com isso as acoes
   * `detalhesAtividade`, `removerAnexo` e a funcao `baixar()` ficaram
   * inalcancaveis: quem anexou arquivo avulso nao conseguia mais ver nem
   * remover. A chamada e feita depois de a janela existir, e so quando ha
   * anexo — nenhuma ida ao Drive a mais nos outros casos. (Na 4.2 ela
   * passou a ir sempre, porque trazia a conversa; o chat saiu, a regra volta.)
   */
  if (a.qtdAnexos) carregarDetalhes(a.id, podeRemoverAnexo_(a, p));
}

/* Nome e tamanho de arquivo custam uma chamada ao Drive cada. Buscar isso
   para o mes inteiro travava a tela; aqui vem so da atividade aberta. */
async function carregarDetalhes(id, podeRemover) {
  try {
    const r = await executarAcaoSrv('detalhesAtividade', { id: id });

    const alvo = el('lista-anexos');
    if (alvo) {
      alvo.className = '';
      alvo.innerHTML = (r.anexos || []).map((f) => `
        <div class="anexo">
          <span class="anexo-nome">${esc(f.nome)}</span>
          <span class="anexo-tamanho">${esc(f.tamanho)}</span>
          <button class="icone-botao" onclick="baixar(${jsArg(f.id)})">Baixar</button>
          ${f.url ? `<a class="icone-botao" href="${esc(f.url)}" target="_blank">Abrir</a>` : ''}
          ${podeRemover ? `<button class="icone-botao perigo" onclick="agir('removerAnexo',{id:${jsArg(id)},idArquivo:${jsArg(f.id)}},'Anexo removido')">Remover</button>` : ''}
        </div>`).join('') || '<span class="vazio">Nenhum arquivo.</span>';
    }

  } catch (e) {
    const alvo = el('lista-anexos');
    if (alvo) alvo.textContent = 'Não consegui listar os anexos: ' + (e.message || e);
  }
}

// Coordenador do turno, vindo da EQUIPE cadastrada — a "teia": turno -> pessoa.
function coordenadorDoTurno(turno) {
  if (!turno || turno === 'Todos') return '';
  const eq = (SESSAO && SESSAO.equipe) || (DADOS && DADOS.equipe) || [];
  const p = eq.find((x) => String(x.turno).toUpperCase() === String(turno).toUpperCase());
  return p ? p.nome : '';
}

function reabrirAtividade(id) {
  agir('validar', { id: id, validacao: '', motivo: '' }, 'Atividade reaberta para nova validacao');
}

function validar(id, decisao) {
  agir('validar', { id: id, validacao: decisao, motivo: val('a-motivo') },
       decisao === 'Aprovado' ? 'Aprovada — coordenador avisado' : 'Registrado — coordenador avisado');
}

function cancelarAtividade(id) {
  const a = todasAtividades().find((x) => x.id === id);
  abrirJanela('Cancelar atividade', `
    <p style="margin:0 0 14px;color:var(--tinta-media);line-height:1.7">
      Cancelar <b>${esc(a.atividade)}</b> (${esc(a.semana)} \u00b7 Turno ${esc(a.turno)})?
      Ela sai do calendario e das contagens de atraso. O coordenador do turno e avisado.
    </p>
    <div class="campo"><label>Motivo do cancelamento</label>
      <textarea id="c-motivo" placeholder="Por que a atividade não precisa mais ser entregue"></textarea></div>`, `
    <button class="botao secundario" onclick="fecharJanela()">Voltar</button>
    <button class="botao perigo" onclick="agir('cancelarAtividade',{id:${jsArg(id)},motivo:val('c-motivo')},'Atividade cancelada — coordenador avisado')">Confirmar cancelamento</button>`);
}

function formNovaAtividade(competencia) {
  const d = DADOS;
  abrirJanela('Nova atividade', `
    <p style="margin:0 0 14px;color:var(--tinta-media);line-height:1.7">
      Atividade avulsa, fora das rotinas do mês. Ao salvar, o coordenador do turno recebe o aviso.
    </p>
    <div class="campo"><label>Nome da atividade</label>
      <input id="n-atividade" placeholder="Ex.: Conferencia extra de inventario"></div>
    <div class="campo-duplo">
      <div class="campo"><label>Data</label><input type="date" id="n-data"></div>
      <div class="campo"><label>Turno</label>
        <select id="n-turno">
          ${['Todos', 'A', 'B', 'C'].map((x) => `<option>${x}</option>`).join('')}
        </select></div>
    </div>
    <div class="campo"><label>Setor (opcional)</label>
      <select id="n-setor"><option value="">—</option>
        ${(d.setores || []).map((s) => `<option>${esc(s)}</option>`).join('')}</select></div>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('criarAtividade',{atividade:val('n-atividade'),prazo:val('n-data'),turno:val('n-turno'),setor:val('n-setor')},'Atividade criada — coordenador avisado')">Criar atividade</button>`);
}

function formRemarcar(id) {
  const a = todasAtividades().find((x) => x.id === id);
  abrirJanela('Remarcar ' + a.id, `
    <div class="campo"><label>Prazo atual</label><input value="${esc(a.prazo)}" readonly></div>
    <div class="campo"><label>Novo prazo</label><input type="date" id="r-data" value="${esc(a.prazoISO)}"></div>
    <div class="campo"><label>Motivo (obrigatorio)</label>
      <textarea id="r-motivo" placeholder="Por que o prazo mudou"></textarea></div>
    <label class="marcador"><input type="checkbox" id="r-avisar" checked> Avisar coordenador e gestão</label>`, `
    <button class="botao secundario" onclick="abrirAtividade(${jsArg(id)})">Voltar</button>
    <button class="botao" onclick="agir('remarcar',{id:${jsArg(id)},prazo:val('r-data'),motivo:val('r-motivo'),avisar:marcado('r-avisar')},'Prazo remarcado')">Remarcar</button>`);
}

/*
 * Vagas do mes: os treinamentos (TRE) e tambem as vagas de outras rotinas
 * AVULSAS ainda sem data. Estas eram geradas, contavam como pendentes e
 * nunca apareciam — nao havia onde agenda-las.
 */
function vagasDoMes(d) { return [].concat(d.treinamentos || [], d.naoAgendadas || []); }

function formTreinamento(id) {
  const a = todasAtividades().find((x) => x.id === id);
  // A lista "Treinamentos e vagas" tem tambem vagas avulsas de outros tipos.
  const tre = String(a.tipo || '').toUpperCase() === 'TRE';
  abrirJanela(tre ? 'Agendar treinamento' : 'Agendar atividade', `
    <div class="campo"><label>${tre ? 'Tema' : 'Atividade'}</label>
      <input id="t-atividade" value="${esc(a.atividade)}"></div>
    <div class="campo"><label>Data</label>
      <input type="date" id="t-data" value="${esc(a.prazoISO || '')}"></div>
    <div class="campo"><label>Turno</label>
      <select id="t-turno">
        ${['Todos', 'A', 'B', 'C'].map((x) => `<option ${x === (a.turno || 'Todos') ? 'selected' : ''}>${x}</option>`).join('')}
      </select></div>
    <p class="dica">Ao salvar, ${tre ? 'os três coordenadores' : 'o coordenador do turno'} e a gestão recebem o aviso.</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('agendarTreinamento',{id:${jsArg(id)},prazo:val('t-data'),atividade:val('t-atividade'),turno:val('t-turno')},${jsArg(tre ? 'Treinamento agendado' : 'Atividade agendada')})">Agendar</button>`);
}

/*
 * ENTREGA EM PDF — varias fotos/arquivos viram um PDF unico.
 *
 * Passo a passo, para nao estourar o limite de tamanho de uma chamada:
 *   1. o servidor cria uma pasta temporaria (iniciarEntrega)
 *   2. cada arquivo sobe sozinho (receberParte)
 *   3. o servidor junta tudo num PDF, arquiva e avisa (finalizarEntrega)
 */
function listarEscolhidos() {
  const fs = el('a-arquivos').files;
  const lista = el('a-lista'), botao = el('a-enviar');
  if (!fs.length) { lista.innerHTML = ''; botao.style.display = 'none'; return; }
  let html = '';
  for (let i = 0; i < fs.length; i++) {
    const mb = (fs[i].size / 1048576).toFixed(1);
    html += `<div class="item-envio"><span>${esc(fs[i].name)}</span><span class="item-mb">${mb} MB</span></div>`;
  }
  lista.innerHTML = html;
  botao.style.display = '';
  botao.textContent = fs.length > 1 ? `Gerar PDF com ${fs.length} arquivos e enviar` : 'Gerar PDF e enviar entrega';
}

const lerBase64 = (arquivo) => new Promise((ok, erro) => {
  const r = new FileReader();
  r.onload = () => ok(r.result.split(',')[1]);
  r.onerror = () => erro(new Error('Não consegui ler ' + arquivo.name));
  r.readAsDataURL(arquivo);
});

async function enviarEntrega(id) {
  const fs = el('a-arquivos').files;
  if (!fs.length) return;
  const botao = el('a-enviar');
  botao.disabled = true;
  try {
    avisar('Preparando envio…');
    const inicio = await executarAcaoSrv('iniciarEntrega', { id: id });
    const pasta = inicio.pasta;

    for (let i = 0; i < fs.length; i++) {
      botao.textContent = `Enviando ${i + 1} de ${fs.length}…`;
      const b64 = await lerBase64(fs[i]);
      await executarAcaoSrv('receberParte', { pasta: pasta, indice: i, nome: fs[i].name, mime: fs[i].type, b64: b64 });
    }

    botao.textContent = 'Montando o PDF — aguarde…';
    /*
     * O BUG DA ENTREGA DO COORDENADOR — "r is not defined".
     *
     * Esta linha foi copiada do agir(), onde `r` e a resposta do
     * servidor. Aqui `r` nunca existiu: a chamada acima jogava a
     * resposta fora. Resultado: a entrega ia ao Drive, o PDF era
     * montado, o status virava "Aguard. valid." — e SO ENTAO o
     * ReferenceError estourava, caia no catch e o coordenador via um
     * erro tecnico numa entrega que tinha dado certo. Muita gente
     * enviou duas e tres vezes por causa disto.
     */
    const feito = await executarAcaoSrv('finalizarEntrega', { id: id, pasta: pasta });

    // Acoes globais (parametros, perfis) mudam TODAS as telas: nesses
    // casos o cache inteiro cai, senao outra tela mostra dado velho.
    if (feito && feito.invalidarTudo) esquecerTelas();
    else { esquecerTela(paginaAtual); envelhecerTelas(); }
    fecharJanela();
    if (feito && feito.avisoEmail) avisar(feito.avisoEmail, true);
    else avisar(feito && feito.arquivos
      ? `Entrega enviada (${feito.arquivos} arquivo(s)) — gestão avisada`
      : 'Entrega enviada em PDF — gestão avisada');
    await abrir(paginaAtual, paramsAtual);
  } catch (e) {
    botao.disabled = false;
    listarEscolhidos();
    avisar(e.message || e, true);
  }
}

async function baixar(idArquivo) {
  avisar('Preparando download…');
  try {
    const geracao = GERACAO_SESSAO;
    const f = await chamar('obterAnexo', ctx(), idArquivo);
    if (geracao !== GERACAO_SESSAO) return;            // a pessoa saiu enquanto o arquivo vinha
    const link = document.createElement('a');
    link.href = 'data:' + f.tipo + ';base64,' + f.dados;
    link.download = f.nome; link.click();
  } catch (e) { avisar(e.message || e, true); }
}

/* ================= ASSIDUIDADE =================
   Três abas, e só três:
     PAINEL        — os números da competência escolhida + a tendência
                     contínua, que atravessa todas as competências
     COLABORADORES — a lista individual e os quadros que a tela de
                     Ranking mostrava (ela deixou de existir: era a
                     mesma informação em dois lugares)
     PERÍODO       — consulta por intervalo de datas, contínua, sem
                     quebra na virada de uma competência para a outra

   A aba ANÁLISE saiu. O único quadro dela que dizia algo — a tendência
   mês a mês — virou o gráfico contínuo do Painel.
   ============================================== */
let ABA_RH = 'colaboradores';   // colaboradores | periodo  (4.2.2: o painel de graficos saiu)
let COLAB_CACHE = null;         // resposta da aba Colaboradores

function pintarAssiduidade(r) {
  const d = r.dados;

  if (d.semRH || d.semDados) {
    el('subtitulo-pagina').textContent = d.semRH ? 'Nenhuma competência cadastrada'
                                                 : 'Competência sem dados importados';
    // O seletor fica: escolher o mes novo (ainda vazio) nao pode prender a
    // pessoa nesta tela sem caminho de volta para o mes anterior.
    el('acoes-topo').innerHTML = (d.competencias || []).length > 1 ? `
      <select onchange="abrir('assiduidade',{competencia:this.value})" title="Competência do painel">
        ${d.competencias.map((c) => `<option value="${esc(c.competencia)}" ${c.competencia === d.competencia ? 'selected' : ''}>
          ${esc(c.competencia)} — ${esc(c.situacao)}</option>`).join('')}
      </select>` : '';
    el('pagina').innerHTML = `
      <div class="cartao">
        <div class="cartao-titulo">${d.semRH ? 'Sem fonte de dados' : 'Importação pendente'}</div>
        <p style="margin:0 0 16px;color:var(--tinta-media);line-height:1.7">
          ${d.semRH
            ? 'Cadastre a competencia do RH em Configuracao &rsaquo; Fontes do RH: link da planilha, aba e situacao.'
            : (d.erroImport
                ? 'Tentei importar a competencia <strong>' + esc(d.competencia) + '</strong> automaticamente, mas deu erro:<br><span style="color:var(--alerta)">' + esc(d.erroImport) + '</span><br><br>Confira em Configuracao se o link e a aba da folha estao certos (a aba costuma ser <b>FOLHA DE PONTO</b>).'
                : 'A competencia <strong>' + esc(d.competencia) + '</strong> está cadastrada, mas a folha ainda nao foi lida.')}
        </p>
        ${editaMenu('config') ? (d.semRH
          ? `<button class="botao" onclick="abrir('config')">Ir para Configuração</button>`
          : `<button class="botao" onclick="importar(${jsArg(d.arquivo.id)})">Importar agora</button>
             <button class="botao secundario" onclick="previa(${jsArg(d.arquivo.id)})">Pré-visualizar</button>`)
          : '<div class="vazio">Peça ao administrador.</div>'}
      </div>`;
    return;
  }

  COLAB_CACHE = null;
  el('subtitulo-pagina').textContent =
    `${d.competencia} · ${d.arquivo.situacao}` +
    (d.arquivo.ultimaImportacao ? ` · lido em ${d.arquivo.ultimaImportacao.slice(0, 16).replace('T', ' ')}` : '');

  el('acoes-topo').innerHTML = `
    <select onchange="abrir('assiduidade',{competencia:this.value})" title="Competência do painel">
      ${d.competencias.map((c) => `<option value="${esc(c.competencia)}" ${c.competencia === d.competencia ? 'selected' : ''}>
        ${esc(c.competencia)} — ${esc(c.situacao)}</option>`).join('')}
    </select>
    ${d.podeGerir ? `<button class="botao secundario" onclick="atualizarRH()" title="Relê a planilha do RH agora">↻ Atualizar dados</button>` : ''}`;

  // 4.2.2: a tela e usada para consultar a situacao de cada colaborador —
  // ficou a consulta (com a ficha) e o Periodo. Os graficos sairam.
  if (ABA_RH !== 'periodo') ABA_RH = 'colaboradores';
  const abas = [['colaboradores', 'Colaboradores'], ['periodo', 'Período']];
  el('pagina').innerHTML = `
    <div class="abas">
      ${abas.map(([id, nome]) => `<button class="aba ${ABA_RH === id ? 'ativa' : ''}"
        onclick="trocarAbaRH(${jsArg(id)})">${nome}</button>`).join('')}
    </div>
    <div id="conteudo-rh"></div>`;

  pintarAbaRH(d);
}

function pintarAbaRH(d) {
  const alvo = el('conteudo-rh');
  if (!alvo) return;
  /*
   * Cada aba dentro de um try. Antes, um erro no meio da montagem
   * deixava a tela com o conteúdo da aba ANTERIOR e nenhuma mensagem —
   * foi assim que a aba Colaborador "nao carregava": ela quebrava, e o
   * painel continuava desenhado, como se o clique nao tivesse ocorrido.
   */
  try {
    if (ABA_RH === 'painel')        { alvo.innerHTML = rhKpis(d) + rhPainel(d); return; }
    if (ABA_RH === 'colaboradores') { rhColaboradoresTela(d); return; }
    if (ABA_RH === 'periodo')       { rhPeriodoTela(d); return; }
    alvo.innerHTML = rhKpis(d) + rhPainel(d);
  } catch (e) {
    alvo.innerHTML = `<div class="erro-caixa">Nao consegui montar esta aba: ${esc(e.message || e)}</div>`;
  }
}

function trocarAbaRH(aba) {
  ABA_RH = aba;
  const botoes = document.querySelectorAll('.abas .aba');
  const ordem = ['colaboradores', 'periodo'];
  botoes.forEach((b) => b.classList.remove('ativa'));
  const i = ordem.indexOf(aba); if (botoes[i]) botoes[i].classList.add('ativa');
  pintarAbaRH(DADOS);
}

/*
 * Os quatro KPIs do topo.
 *
 * A legenda do RH separa falta INJUSTIFICADA (16), JUSTIFICADA (28) e
 * DISCIPLINAR (18) de propósito — sao problemas de natureza diferente.
 * Por isso o cartão mostra a injustificada, que é a que gera cobrança, e
 * traz as outras duas na legenda em vez de somar tudo num numero so.
 */
function rhKpis(d) {
  const k = d.kpis || {};
  const temQuebra = k.faltasInjustificadas !== undefined;
  const rotuloFaltas = temQuebra
    ? 'Faltas injustificadas · ' + (k.faltasJustificadas || 0) + ' just. · ' +
      (k.faltasDisciplinares || 0) + ' disc.'
    : 'Faltas';
  return `<div class="grade grade-kpi" style="margin-bottom:16px">
      ${kpi(k.colaboradores, 'Colaboradores' + (k.registros ? ' · ' + k.registros + ' registros' : ''), 'azul')}
      ${kpi(k.taxa + '%', 'Absenteísmo · meta ' + k.meta + '%', k.acimaDaMeta ? 'vermelho' : 'verde')}
      ${kpi(temQuebra ? k.faltasInjustificadas : k.faltas, rotuloFaltas, 'vermelho')}
      ${kpi(k.atestados, 'Atestados', 'amarelo')}
    </div>` + avisoNaoDefinidos(d);
}

/*
 * Codigo fora da legenda vira AVISO, nao barra de grafico. Antes ele
 * aparecia como "A CONFIRMAR" no meio das categorias reais — na folha de
 * agosto eram 530 lançamentos, a segunda maior barra do painel, dizendo
 * exatamente nada.
 */
function avisoNaoDefinidos(d) {
  const n = d.naoDefinidos || {};
  if (!n.lancamentos) return '';
  return `<div class="cartao" style="margin-bottom:14px;border-left:4px solid var(--alerta)">
    <div class="cartao-titulo linha-titulo">
      <span>${n.lancamentos} lançamento(s) com codigo fora da legenda</span>
      ${editaMenu('config') ? `<button class="icone-botao" onclick="abrir('config')">Cadastrar no DE-PARA</button>` : ''}
    </div>
    <p class="dica" style="margin:0">
      Ficaram de fora dos gráficos e das contagens, de propósito — entrar como categoria
      inventada seria pior. Códigos:
      ${(n.codigos || []).map((c) => `<b>${esc(c.codigo)}</b> (${c.total})`).join(' · ')}
    </p></div>`;
}

function rhPainel(d) {
  const maxTurno = Math.max(1, ...d.porTurno.map((t) => t.taxa));
  const maxCat = Math.max(1, ...d.porCategoria.map((c) => c.total), 1);
  const maxDow = Math.max(1, ...d.porDiaSemana.map((c) => c.total), 1);
  const maxDia = Math.max(1, ...d.diaADia.map((c) => c.taxa), 1);
  const t = d.tendencia || { serie: [] };

  return `
    ${t.serie.length > 1 ? `
    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo linha-titulo">
        <span>Absenteísmo mês a mês — todas as competências</span>
        <span style="color:${t.direcao === 'melhorando' ? 'var(--verde)' : (t.direcao === 'piorando' ? 'var(--alerta)' : 'var(--tinta-media)')};font-weight:800">
          ${t.direcao === 'melhorando' ? '↓' : (t.direcao === 'piorando' ? '↑' : '→')} ${esc(t.direcao)}${t.variacao ? ' (' + (t.variacao > 0 ? '+' : '') + t.variacao + ' p.p.)' : ''}</span>
      </div>
      ${graficoLinha(t.serie, t.meta)}
      <p class="dica">Cada ponto é uma competência importada. A série é contínua: ela não
         começa nem termina na competência que está selecionada acima.</p>
    </div>` : ''}

    <div class="grade grade-dupla" style="margin-bottom:14px">
      <div class="cartao"><div class="cartao-titulo">% de ausência por turno</div>
        ${d.porTurno.map((t2) => barra(
            t2.turno + (t2.pessoas ? ' (' + t2.pessoas + ')' : ''),
            t2.taxa + '% de ' + (t2.registros || 0),
            maxTurno, t2.taxa, 'vermelho')).join('')}
        <p class="dica">% de ausência = ausências ÷ dias lançados do turno.</p></div>
      <div class="cartao"><div class="cartao-titulo">Dias por categoria</div>
        ${d.porCategoria.length
          ? d.porCategoria.map((c) => barra(c.categoria, c.total, maxCat, c.total, '')).join('')
          : '<div class="vazio">Sem categorias.</div>'}</div>
    </div>

    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo">% de ausencia dia a dia — ${esc(d.competencia)}</div>
      <div class="serie">
        ${d.diaADia.map((x) => `
          <div class="serie-col" title="${esc(x.data)} — ${x.ausencias} de ${x.total}">
            <div class="serie-barra" style="height:${Math.max(2, Math.round(x.taxa / maxDia * 100))}%"></div>
            <div class="serie-rotulo">${esc(String(x.data).slice(8, 10))}</div>
          </div>`).join('')}
      </div>
      <p class="dica">Este quadro é da competência selecionada. Para ver um intervalo que
         atravessa competências, use a aba <b>Período</b>.</p>
    </div>

    <div class="grade grade-dupla">
      <div class="cartao"><div class="cartao-titulo">Ausências por dia da semana</div>
        ${d.porDiaSemana.map((x) => barra(x.dia, x.total, maxDow, x.total, 'vermelho')).join('') || '<div class="vazio">Sem dados.</div>'}</div>
      <div class="cartao"><div class="cartao-titulo">Códigos mais lançados</div>
        <table><thead><tr><th>Cód.</th><th>Descrição</th><th>Categoria</th><th class="numero">Vezes</th></tr></thead>
        <tbody>${d.codigosTop.map((c) => `<tr><td class="mono">${esc(c.codigo)}</td>
          <td>${esc(c.descricao)}</td><td>${esc(c.categoria)}</td>
          <td class="numero">${c.total}</td></tr>`).join('')}</tbody></table></div>
    </div>`;
}

/* Linha do tempo em SVG — usada pela tendência e pelo Periodo. */
function graficoLinha(serie, meta, rotulo) {
  if (!serie || !serie.length) return '<div class="vazio">Sem histórico ainda.</div>';
  const campo = rotulo || 'taxa';
  const L = 660, A = 180, mL = 42, mB = 30, mT = 14;
  const valores = serie.map((p) => Number(p[campo]) || 0);
  const maxV = Math.max(...valores, (meta || 0) * 1.4, 1);
  const px = (i) => mL + (serie.length === 1 ? (L - mL) / 2 : i * (L - mL - 12) / (serie.length - 1));
  const py = (v) => mT + (A - mT - mB) * (1 - v / maxV);
  const pts = valores.map((v, i) => `${px(i)},${py(v)}`).join(' ');
  const passo = Math.ceil(serie.length / 12);

  return `<svg viewBox="0 0 ${L} ${A}" style="width:100%;height:auto" role="img">
    ${meta ? `<line x1="${mL}" y1="${py(meta)}" x2="${L - 6}" y2="${py(meta)}"
      stroke="var(--verde)" stroke-dasharray="5 4" stroke-width="1.5"/>
      <text x="${L - 8}" y="${py(meta) - 5}" text-anchor="end" font-size="10" fill="var(--verde)">meta ${meta}%</text>` : ''}
    <polyline points="${pts}" fill="none" stroke="var(--azul-vivo)" stroke-width="2.5"
      stroke-linejoin="round" stroke-linecap="round"/>
    ${serie.map((p, i) => `<circle cx="${px(i)}" cy="${py(valores[i])}" r="3.5"
      fill="${meta && valores[i] > meta ? 'var(--alerta)' : 'var(--verde)'}"><title>${esc(p.competencia || p.data)}: ${valores[i]}</title></circle>`).join('')}
    ${serie.map((p, i) => (i % passo === 0 || i === serie.length - 1)
      ? `<text x="${px(i)}" y="${A - 8}" text-anchor="middle" font-size="9.5"
           fill="var(--tinta-fraca)">${esc(String(p.competencia || p.data).slice(-5))}</text>` : '').join('')}
  </svg>`;
}

/* ---------------- ABA COLABORADORES ----------------
   Era uma pilha de quatro tabelas iguais, uma embaixo da outra, sem
   hierarquia e sem cor — muita informação apinhada e nenhuma pista de
   onde olhar primeiro. Agora são três sub-abas, cada uma com uma
   pergunta:

     TURNOS    — como está cada turno? (número grande + medidor + situação)
     DESTAQUES — quem puxa para cima e quem puxa para baixo?
     LISTA     — a tabela completa, para procurar uma pessoa

   A cor segue a regra do painel: grandeza usa rampa sequencial (uma
   matiz, mais é mais escuro) e situação vem sempre com ícone e palavra,
   nunca só com cor.
   ---------------------------------------------------- */
let ABA_COLAB = 'turnos';   // turnos | destaques | lista

async function rhColaboradoresTela(d) {
  const alvo = el('conteudo-rh');
  if (!d.mostraIndividual) {
    alvo.innerHTML = rhKpis(d) +
      '<div class="cartao"><div class="vazio">Seu nível de acesso vê apenas os números agregados.</div></div>';
    return;
  }
  // A lista ja veio com a tela (sem segunda chamada ao Google).
  if (d.colab && d.colab.competencia === d.competencia) {
    COLAB_CACHE = d.colab;
    desenharColaboradores(d);
    if (d.ficha) { FICHA = { matricula: d.ficha.matricula, de: (d.ficha.periodo || {}).de || '', ate: (d.ficha.periodo || {}).ate || '' };
      abrirJanela('', montarFicha(d.ficha), '<button class="botao" onclick="fecharJanela()">Fechar</button>');
      const t = el('janela-titulo'); if (t) t.textContent = ''; d.ficha = null; }
    return;
  }
  alvo.innerHTML = rhKpis(d) + '<div class="vazio">Carregando colaboradores…</div>';
  try {
    /*
     * A lista vem do AGR_COLAB, sob demanda. Ela NÃO viaja mais dentro
     * do payload do painel: com 341 pessoas aquilo dava 96 mil
     * caracteres, e uma célula do Google Sheets aceita 50 mil. Era essa
     * a razão de a aba não carregar.
     */
    // A resposta pode chegar depois de a pessoa trocar de competencia (ou
    // de aba): so desenha se a tela ainda for a mesma que pediu.
    const comp = d.competencia, filial = FILIAL;
    const r = COLAB_CACHE || await executarAcaoSrv('colaboradores', { competencia: comp, minimo: 10 });
    if (!DADOS || DADOS.competencia !== comp || FILIAL !== filial ||
        paginaAtual !== 'assiduidade' || ABA_RH !== 'colaboradores') return;
    COLAB_CACHE = r;
    desenharColaboradores(d);
  } catch (e) {
    alvo.innerHTML = rhKpis(d) + `<div class="erro-caixa">${esc(e.message || e)}</div>`;
  }
}

function desenharColaboradores(d) {
  const r = COLAB_CACHE;
  el('conteudo-rh').innerHTML = rhKpis(d) + '<div id="conteudo-colab"></div>';
  el('conteudo-colab').innerHTML = colabLista(r);
  const b = el('busca-colab'); if (b) b.focus();
}

function trocarAbaColab(aba) {
  ABA_COLAB = aba;
  document.querySelectorAll('.abas-internas .aba').forEach((b, i) => {
    b.classList.toggle('ativa', ['turnos', 'destaques', 'lista'][i] === aba);
  });
  pintarAbaColab();
}

function pintarAbaColab() {
  const alvo = el('conteudo-colab');
  if (!alvo || !COLAB_CACHE) return;
  const r = COLAB_CACHE;
  if (ABA_COLAB === 'turnos')    alvo.innerHTML = colabTurnos(r);
  else if (ABA_COLAB === 'destaques') alvo.innerHTML = colabDestaques(r);
  else alvo.innerHTML = colabLista(r);
}

/*
 * Situação de uma assiduidade. A cor é a última coisa: primeiro o ícone
 * e a palavra, que é o que um daltônico (e uma impressão em preto e
 * branco) enxerga.
 */
function situacaoAssid(pct, meta) {
  const limite = 100 - (meta === undefined ? 5 : meta);   // meta de absenteísmo
  if (pct >= limite) return { classe: 'bom', icone: '●', texto: 'dentro da meta' };
  if (pct >= limite - 3) return { classe: 'atencao', icone: '▲', texto: 'atenção' };
  // "Critico" soava a diagnostico de UTI para uma pessoa que faltou. A
  // palavra passa a ser a mesma medida do nivel bom, virada do avesso:
  // dentro da meta -> atencao -> fora da meta. A classe segue chamada
  // 'critico' porque e o nome do estilo, nao o que aparece na tela.
  return { classe: 'critico', icone: '■', texto: 'fora da meta' };
}
const selo = (s) => `<span class="situacao ${s.classe}"><b>${s.icone}</b>${s.texto}</span>`;

/* Degrau da rampa sequencial (1 a 4) para um valor dentro de um máximo. */
function degrau(valor, maximo) {
  if (!maximo || valor <= 0) return 1;
  const p = valor / maximo;
  return p > .75 ? 4 : p > .5 ? 3 : p > .25 ? 2 : 1;
}

/* ---- Sub-aba 1: como está cada turno ---- */
function colabTurnos(r) {
  const meta = (DADOS.kpis && DADOS.kpis.meta) || 5;
  const cartao = (t) => {
    const s = situacaoAssid(t.media, meta);
    const destaque = t.turno === 'CD';
    return `<div class="cartao cartao-turno"${destaque ? ' style="border-color:var(--azul-vivo)"' : ''}>
      <div class="turno-sigla">${destaque ? 'CD inteiro' : 'Turno ' + esc(t.turno)}</div>
      <div class="turno-valor" style="color:var(--sit-${s.classe === 'bom' ? 'bom' : s.classe === 'atencao' ? 'atencao' : 'fora'})">${t.media}%</div>
      <div class="turno-legenda">de assiduidade</div>
      <div class="medidor sit-${s.classe}" title="${t.media}% — a marca é a meta de ${100 - meta}%">
        <i style="width:${Math.max(2, Math.min(100, t.media))}%"></i>
        <span class="medidor-meta" style="left:${100 - meta}%"></span>
      </div>
      <div style="margin-top:4px">${selo(s)}</div>
      <div class="turno-numeros">
        <div><strong>${t.pessoas}</strong>pessoas</div>
        <div><strong>${t.registros}</strong>dias lanç.</div>
        <div><strong>${t.ausencias}</strong>ausências</div>
        <div><strong>${t.faltas}</strong>faltas inj.</div>
        <div><strong>${t.atestados}</strong>atestados</div>
      </div>
    </div>`;
  };

  const semCD = r.porTurno.filter((t) => t.turno !== 'CD');
  const cd = r.porTurno.filter((t) => t.turno === 'CD')[0];
  const maxAus = Math.max(1, ...semCD.map((t) => t.ausencias));

  return `
    <div class="grade-turnos">${(cd ? [cd] : []).concat(semCD).map(cartao).join('')}</div>

    <div class="cartao">
      <div class="cartao-titulo">Onde estão as ausências</div>
      <p class="dica" style="margin:-4px 0 12px">A barra compara o volume de ausências entre os
         turnos. Quanto mais escura, maior o peso — é a mesma cor em quatro tons, não uma cor
         por turno.</p>
      ${semCD.map((t) => `
        <div class="barra-linha">
          <div class="barra-rotulo">Turno ${esc(t.turno)}</div>
          <div class="barra-trilho">
            <div class="barra-preenchida" style="width:${Math.round(t.ausencias / maxAus * 100)}%;
                 background:var(--seq-ambar-${degrau(t.ausencias, maxAus)})"></div>
          </div>
          <div class="barra-valor">${t.ausencias}</div>
        </div>`).join('')}
    </div>`;
}

/* ---- Sub-aba 2: quem puxa para cima e para baixo ---- */
function colabDestaques(r) {
  const bloco = (titulo, dica, itens, campo, sufixo, rampa) => {
    if (!itens.length) return `<div class="cartao"><div class="cartao-titulo">${titulo}</div>
      <div class="vazio">Ninguém nesta lista.</div></div>`;
    const max = Math.max(1, ...itens.map((p) => Number(p[campo]) || 0));
    return `<div class="cartao">
      <div class="cartao-titulo">${titulo}</div>
      <p class="dica" style="margin:-4px 0 10px">${dica}</p>
      ${itens.slice(0, 10).map((p, i) => {
        const v = Number(p[campo]) || 0;
        return `<div class="destaque" onclick="fichaColaborador(${jsArg(p.matricula)})"
                     title="Abrir a ficha de ${esc(p.nome)}">
          <div class="pos">${i + 1}</div>
          <div class="nome">${esc(p.nome || p.matricula)}<br><span>turno ${esc(p.turno || '—')}</span></div>
          <div class="barra-trilho">
            <div class="barra-preenchida" style="width:${Math.max(3, Math.round(v / max * 100))}%;
                 background:var(--seq-${rampa}-${degrau(v, max)})"></div>
          </div>
          <div class="val">${v}${sufixo}</div>
        </div>`;
      }).join('')}
    </div>`;
  };

  return `
    <div class="grade grade-dupla" style="margin-bottom:14px">
      ${bloco('Maior assiduidade', 'Quem esteve presente em praticamente todos os dias lançados.',
              r.melhores, 'assiduidade', '%', 'verde')}
      ${bloco('Merecem atenção', 'Menor assiduidade do período. Vale uma conversa antes de virar processo.',
              r.atencao, 'assiduidade', '%', 'ambar')}
    </div>
    <div class="grade grade-dupla">
      ${bloco('Mais atestados', 'É saúde — trata-se de outro jeito que falta injustificada. Códigos 1, 21 e 130.',
              r.maisAtestados, 'valor', ' dias', 'verde')}
      ${bloco('Mais faltas injustificadas', 'É disciplina. Código 16 — faltou e não justificou.',
              r.maisFaltas, 'valor', '', 'ambar')}
    </div>`;
}

/* ---- Sub-aba 3: a tabela completa ---- */
let ORDEM_COLAB = { campo: 'ausencias', desc: true };

function colabLista(r) {
  const meta = (DADOS.kpis && DADOS.kpis.meta) || 5;
  const lista = r.lista.slice().sort((a, b) => {
    const c = ORDEM_COLAB.campo;
    const va = a[c], vb = b[c];
    const n = (typeof va === 'number') ? (va - vb) : String(va).localeCompare(String(vb));
    return ORDEM_COLAB.desc ? -n : n;
  });
  const col = (campo, rotulo, num) =>
    `<th class="${num ? 'numero' : ''}" style="cursor:pointer" onclick="ordenarColab(${jsArg(campo)})"
        title="Ordenar por ${rotulo}">${rotulo}${ORDEM_COLAB.campo === campo ? (ORDEM_COLAB.desc ? ' ↓' : ' ↑') : ''}</th>`;

  return `
    <div class="cartao">
      <div class="cartao-titulo linha-titulo">
        <span>${lista.length} colaborador(es) em ${esc((DADOS && DADOS.competencia) || '')} — clique numa linha para abrir a ficha (com filtro de período)</span>
        <span class="campo-busca">
          <input id="busca-colab" placeholder="Buscar nome ou matrícula" oninput="filtrarColab()"></span>
      </div>
      <p class="dica" style="margin:-4px 0 12px">Quem mais faltou aparece primeiro. Clique no título da coluna para ordenar.</p>
      <div style="overflow-x:auto"><table id="tabela-colab">
        <thead><tr>
          ${col('matricula', 'Matrícula')}${col('nome', 'Nome')}${col('turno', 'Turno')}
          ${col('ausencias', 'Ausências', 1)}${col('faltasInjustificadas', 'F. injust.', 1)}
          ${col('faltasJustificadas', 'F. just.', 1)}${col('faltasDisciplinares', 'F. discipl.', 1)}
          ${col('atestados', 'Atestados', 1)}
          ${col('assiduidade', 'Assiduidade', 1)}<th>Situação</th>
        </tr></thead>
        <tbody>${lista.map((c) => {
          const s = situacaoAssid(c.assiduidade, meta);
          return `<tr style="cursor:pointer" data-busca="${esc((c.nome + ' ' + c.matricula).toLowerCase())}"
              onclick="fichaColaborador(${jsArg(c.matricula)})">
            <td class="mono">${esc(c.matricula)}</td><td>${esc(c.nome)}</td><td>${esc(c.turno)}</td>
            <td class="numero"><strong>${c.ausencias}</strong></td><td class="numero">${c.faltasInjustificadas || 0}</td>
            <td class="numero">${c.faltasJustificadas || 0}</td><td class="numero">${c.faltasDisciplinares || 0}</td>
            <td class="numero">${c.atestados || 0}</td>
            <td class="celula-medidor">
              <div class="medidor-linha">
                <div class="medidor" style="margin:0">
                  <i style="width:${Math.max(2, Math.min(100, c.assiduidade))}%;
                       background:var(--seq-verde-${degrau(c.assiduidade, 100)})"></i>
                </div>
                <span class="faixa-assid">${c.assiduidade}%</span>
              </div>
            </td>
            <td>${selo(s)}</td>
          </tr>`;
        }).join('')}</tbody></table></div>
    </div>`;
}

function ordenarColab(campo) {
  if (ORDEM_COLAB.campo === campo) ORDEM_COLAB.desc = !ORDEM_COLAB.desc;
  else ORDEM_COLAB = { campo: campo, desc: (campo !== 'nome' && campo !== 'matricula' && campo !== 'turno') };
  pintarAbaColab();
}

function filtrarColab() {
  const t = String(val('busca-colab') || '').toLowerCase().trim();
  document.querySelectorAll('#tabela-colab tbody tr').forEach((tr) => {
    tr.style.display = (!t || (tr.dataset.busca || '').indexOf(t) !== -1) ? '' : 'none';
  });
}


/* ---------------- ABA PERÍODO ----------------
   Consulta por intervalo de datas. Ela varre a base por DATA, entao um
   intervalo que atravessa competencias vem inteiro, sem buraco na
   virada de uma planilha do RH para a outra.
   -------------------------------------------- */
let periodoParams = null;

async function rhPeriodoTela(d) {
  const alvo = el('conteudo-rh');
  const p = periodoParams || { de: '', ate: '', tipo: 'TODAS', turno: '' };
  alvo.innerHTML = `
    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo">Faltas e ausências por período</div>
      <p class="dica" style="margin:-4px 0 12px">O intervalo pode atravessar quantas
         competências forem necessárias — a consulta é por data, não por planilha.</p>
      <div class="periodo-atalhos">
        <button class="botao secundario" onclick="periodoRapido('hoje')">Hoje</button>
        <button class="botao secundario" onclick="periodoRapido('semana')">7 dias</button>
        <button class="botao secundario" onclick="periodoRapido('mes')">Este mês</button>
        <button class="botao secundario" onclick="periodoRapido('mespassado')">Mês passado</button>
        <button class="botao secundario" onclick="periodoRapido('trimestre')">3 meses</button>
        <button class="botao secundario" onclick="periodoRapido('semestre')">6 meses</button>
        <button class="botao secundario" onclick="periodoRapido('ano')">Ano todo</button>
        <button class="botao secundario" onclick="periodoRapido('tudo')">Tudo</button>
      </div>
      <div class="periodo-form">
        <div class="campo"><label>De</label><input type="date" id="pd-de" value="${esc(p.de)}"></div>
        <div class="campo"><label>Até</label><input type="date" id="pd-ate" value="${esc(p.ate)}"></div>
        <div class="campo"><label>Tipo de ausência</label>
          <select id="pd-tipo">
            ${(d.tipos || [{ id: 'TODAS', nome: 'Todas as ausências' }])
              .map((t) => `<option value="${esc(t.id)}" ${p.tipo === t.id ? 'selected' : ''}>${esc(t.nome)}</option>`).join('')}
          </select></div>
        <div class="campo"><label>Turno</label>
          <select id="pd-turno">
            <option value="">Todos os turnos</option>
            ${(d.turnos || []).map((t) => `<option value="${esc(t)}" ${p.turno === t ? 'selected' : ''}>${esc(t)}</option>`).join('')}
          </select></div>
        <button class="botao" onclick="consultarPeriodo()">Consultar</button>
      </div>
      <p class="dica">“Outros” reúne as ausências que não são falta, atestado nem licença legal.
         Um tipo zerado significa que não houve nenhum no intervalo — a opção continua na lista
         de propósito, para você poder confirmar isso.</p>
    </div>
    <div id="periodo-resultado"><div class="vazio">Escolha um período e consulte.</div></div>`;
  if (periodoParams) consultarPeriodo();
}

function periodoRapido(qual) {
  const hoje = new Date();
  const iso = (dt) => dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') +
                      '-' + String(dt.getDate()).padStart(2, '0');
  let de = hoje, ate = hoje;
  if (qual === 'semana')     { de = new Date(hoje); de.setDate(hoje.getDate() - 6); }
  if (qual === 'mes')        { de = new Date(hoje.getFullYear(), hoje.getMonth(), 1); }
  if (qual === 'mespassado') {
    de = new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1);
    ate = new Date(hoje.getFullYear(), hoje.getMonth(), 0);
  }
  if (qual === 'trimestre')  { de = new Date(hoje.getFullYear(), hoje.getMonth() - 2, 1); }
  if (qual === 'semestre')   { de = new Date(hoje.getFullYear(), hoje.getMonth() - 5, 1); }
  if (qual === 'ano')        { de = new Date(hoje.getFullYear(), 0, 1); }
  if (qual === 'tudo')       { de = new Date(hoje.getFullYear() - 3, 0, 1); }
  el('pd-de').value = iso(de); el('pd-ate').value = iso(ate);
  consultarPeriodo();
}

async function consultarPeriodo() {
  const de = val('pd-de'), ate = val('pd-ate');
  const tipo = val('pd-tipo'), turno = val('pd-turno');
  if (!de || !ate) return avisar('Escolha as duas datas.', true);
  periodoParams = { de, ate, tipo, turno };
  const alvo = el('periodo-resultado');
  alvo.innerHTML = '<div class="vazio">Consultando…</div>';
  try {
    const r = await executarAcaoSrv('periodo', periodoParams);

    /*
     * ZERO NÃO É RESPOSTA — a tela precisa dizer POR QUE deu zero.
     * O servidor conta quantas linhas varreu, quantas ficaram fora do
     * intervalo e quantas tinham data ilegível; com isso dá para
     * distinguir "não houve ausência" de "a base está vazia" e de
     * "a base tem dado, mas de outras datas".
     */
    if (r.registros === 0) { alvo.innerHTML = periodoVazio(r); return; }

    const maxDia = Math.max(1, ...(r.linhaDoTempo || []).map((x) => x.total));
    alvo.innerHTML = `
      <div class="grade grade-kpi" style="margin-bottom:14px">
        ${kpi(r.registros, 'Registros de ausência', 'vermelho')}
        ${kpi(r.colaboradores, 'Pessoas com ausência', 'azul')}
        ${kpi(r.diasNoPeriodo, 'Dias no intervalo', 'verde')}
        ${kpi((r.porCompetencia || []).length, 'Competências no intervalo', 'amarelo')}
      </div>

      ${(r.linhaDoTempo || []).length > 1 ? `
      <div class="cartao" style="margin-bottom:14px">
        <div class="cartao-titulo">Ausencias dia a dia — ${esc(r.de)} a ${esc(r.ate)}</div>
        <div class="serie">
          ${r.linhaDoTempo.map((x) => `
            <div class="serie-col" title="${esc(x.data)} — ${x.total} ausência(s)">
              <div class="serie-barra" style="height:${Math.max(1, Math.round(x.total / maxDia * 100))}%"></div>
            </div>`).join('')}
        </div>
        <p class="dica">Uma coluna por dia do intervalo, sem interrupção na virada de uma
           competência para a outra.</p>
      </div>` : ''}

      <div class="grade grade-dupla" style="margin-bottom:14px">
        ${(r.porCategoria || []).length ? `
        <div class="cartao"><div class="cartao-titulo">Por tipo de ausência</div>
          ${(() => { const mx = Math.max(1, ...r.porCategoria.map((c) => c.total));
             return r.porCategoria.map((c) => barra(c.categoria, c.total, mx, c.total,
               /INJUST|DISCIPL/i.test(c.categoria) ? 'vermelha'
               : /ATESTADO/i.test(c.categoria) ? 'amarela' : 'verde')).join(''); })()}
        </div>` : ''}
        ${(r.porTurno || []).length ? `
        <div class="cartao"><div class="cartao-titulo">Por turno</div>
          ${(() => { const mx = Math.max(1, ...r.porTurno.map((c) => c.total));
             return r.porTurno.map((c) => barra(c.turno, c.total, mx, c.total, '')).join(''); })()}
        </div>` : ''}
      </div>

      ${(r.porCompetencia || []).length > 1 ? `
      <div class="cartao" style="margin-bottom:14px">
        <div class="cartao-titulo">Por competencia — o intervalo cruza ${r.porCompetencia.length}</div>
        ${(() => { const mx = Math.max(1, ...r.porCompetencia.map((c) => c.total));
           return r.porCompetencia.map((c) =>
             barra(c.competencia, c.total + ' ausencia(s)', mx, c.total, 'vermelha')).join(''); })()}
      </div>` : ''}

      <div class="cartao">
        <div class="cartao-titulo linha-titulo">
          <span>Colaboradores com ausencia (${r.colaboradores})</span>
          <span class="dica">${esc(r.escopo)}${r.turno ? ' · turno ' + esc(r.turno) : ''} · ${esc(r.de)} a ${esc(r.ate)}</span>
        </div>
        ${r.mostraIndividual ? `<div style="overflow-x:auto"><table>
          <thead><tr><th>Nome</th><th>Turno</th><th class="numero">Registros</th>
            <th>Intensidade</th><th>Primeira</th><th>Última</th><th>Datas das ausências</th></tr></thead>
          <tbody>${r.lista.map((p) => `<tr style="cursor:pointer" onclick="fichaColaborador(${jsArg(p.matricula)})">
            <td>${esc(p.nome)}</td><td>${esc(p.turno)}</td><td class="numero"><strong>${p.registros}</strong></td>
            <td><div class="barra-trilho" style="max-width:120px"><div class="barra-preenchida vermelho" style="width:${p.barra}%"></div></div></td>
            <td>${esc(p.primeira)}</td><td>${esc(p.ultima)}</td>
            <td class="datas-aus">${p.datas.map((x) => esc(x.data)).join(', ')}</td>
          </tr>`).join('') || '<tr><td colspan="7" class="vazio">Nenhuma ausência no período.</td></tr>'}
          </tbody></table></div>`
          : '<div class="vazio">Seu nível de acesso vê apenas os números agregados.</div>'}
        ${r.mais ? `<p class="dica">… e mais ${r.mais} colaborador(es). Refine o periodo ou o turno.</p>` : ''}
      </div>`;
  } catch (e) { alvo.innerHTML = `<div class="erro-caixa">${esc(e.message || e)}</div>`; }
}

/* O que dizer quando a consulta volta sem nada. */
function periodoVazio(r) {
  const q = r.porque || {};
  let titulo, texto, acao = '';

  if (q.baseVazia) {
    titulo = 'A base de assiduidade está vazia';
    texto = 'Não há nenhum lançamento importado. Provavelmente a última importação falhou no meio do caminho.';
    acao = `<button class="botao" onclick="verDiagnosticoRH()">Ver o diagnóstico da base</button>
            ${DADOS.podeGerir ? `<button class="botao secundario" onclick="atualizarRH()">↻ Importar de novo</button>` : ''}`;
  } else if (q.tudoForaDoIntervalo) {
    titulo = 'Nenhum lançamento neste intervalo';
    texto = 'A base tem ' + q.linhasNaBase + ' lançamento(s), mas todos de outras datas. ' +
            'Veja no diagnóstico qual período está importado e ajuste as datas.';
    acao = `<button class="botao secundario" onclick="verDiagnosticoRH()">Ver o que está importado</button>`;
  } else if (q.semDataValida && q.semDataValida === q.linhasNaBase) {
    titulo = 'As datas da base não estão legíveis';
    texto = 'Os ' + q.linhasNaBase + ' lançamentos existem, mas a coluna de data não está num ' +
            'formato que dá para comparar. Reimportar a competência regrava as datas como texto.';
    acao = `${DADOS.podeGerir ? `<button class="botao" onclick="atualizarRH()">↻ Reimportar</button>` : ''}
            <button class="botao secundario" onclick="verDiagnosticoRH()">Ver o diagnóstico</button>`;
  } else {
    titulo = 'Nenhuma ausência no período';
    texto = 'A consulta rodou e não encontrou ausência com estes filtros — o que é uma boa notícia. ' +
            'Foram ' + (q.linhasNaBase || 0) + ' lançamento(s) verificados.' +
            (r.tipo && r.tipo !== 'TODAS' ? ' Experimente “Todas as ausências” para conferir.' : '');
    acao = `<button class="botao secundario" onclick="verDiagnosticoRH()">Ver o que está importado</button>`;
  }

  return `<div class="cartao vazio-explicado">
    <div class="titulo">${esc(titulo)}</div>
    <p>${esc(texto)}</p>
    <p class="dica">Intervalo consultado: ${esc(r.de)} a ${esc(r.ate)}${r.turno ? ' · turno ' + esc(r.turno) : ''}</p>
    <div style="display:flex;gap:8px;justify-content:center;margin-top:14px;flex-wrap:wrap">${acao}</div>
  </div>`;
}

/*
 * Diagnóstico da base: o que existe de verdade no banco agora.
 * Nasceu porque a consulta mostrou 0 sem dizer por quê, e não havia como
 * saber de fora se a base estava vazia, com data ilegível ou fora do
 * intervalo pedido.
 */
async function verDiagnosticoRH() {
  abrirJanela('Diagnóstico da base de assiduidade', '<div class="vazio">Conferindo…</div>', '');
  try {
    const d = await executarAcaoSrv('diagnosticoRH', {});
    abrirJanela('Diagnóstico da base de assiduidade', `
      <div class="grade grade-kpi" style="margin-bottom:14px">
        ${kpi(d.totalLinhas, 'Lançamentos na base', d.totalLinhas ? 'azul' : 'vermelho')}
        ${kpi(d.colaboradores, 'Colaboradores', 'verde')}
        ${kpi(d.agrColab, 'Linhas de agregado', 'amarelo')}
      </div>
      ${d.totalLinhas ? `<p class="dica" style="margin:0 0 12px">Período coberto pela base:
        <b>${esc(d.intervalo.de)} a ${esc(d.intervalo.ate)}</b>.</p>` : ''}
      ${d.semDataValida ? `<div class="erro-caixa" style="margin-bottom:12px">
        ${d.semDataValida} lançamento(s) com data ilegível — reimporte a competência.</div>` : ''}
      ${d.celulasComoData ? `<p class="dica" style="margin:0 0 12px">${d.celulasComoData} célula(s)
        de data vieram como objeto de data em vez de texto. O sistema lida com as duas formas,
        mas reimportar deixa tudo como texto.</p>` : ''}

      <div class="cartao-titulo">Por competência</div>
      <table><thead><tr><th>Competência</th><th class="numero">Lançamentos</th>
        <th class="numero">Ausências</th><th>De</th><th>Até</th></tr></thead>
      <tbody>${d.competencias.map((c) => `<tr><td><strong>${esc(c.competencia)}</strong>${c.semCadastro
          ? ' <span class="pendente-entrega">sem cadastro</span>' : ''}</td>
        <td class="numero">${c.linhas}</td><td class="numero">${c.ausencias}</td>
        <td>${esc(c.de)}</td><td>${esc(c.ate)}</td></tr>`).join('')
        || '<tr><td colspan="5" class="vazio">Nada importado.</td></tr>'}</tbody></table>

      ${(d.orfas || []).length ? `<div class="erro-caixa" style="margin-top:12px">
        Sobras sem cadastro (ficam fora de todas as contas):
        ${d.orfas.map((o) => esc(o.competencia) + ' (' + o.linhas + ' linha(s))').join(', ')}.
        ${d.podeLimpar ? `<div style="margin-top:8px"><button class="botao"
          onclick="fecharJanela(); agir('limparOrfasRH', {}, '')">Limpar sobras</button></div>` : ''}
      </div>` : ''}

      <div class="cartao-titulo" style="margin-top:14px">Competências cadastradas</div>
      <table><thead><tr><th>Competência</th><th>Situação</th><th class="numero">Declarado</th>
        <th class="numero">Na base</th><th>Última leitura</th></tr></thead>
      <tbody>${d.arquivos.map((a) => `<tr>
        <td><strong>${esc(a.competencia)}</strong></td><td>${esc(a.situacao)}</td>
        <td class="numero">${a.linhasDeclaradas}</td>
        <td class="numero"><strong style="color:${a.linhasNaBase === a.linhasDeclaradas ? 'var(--verde)' : 'var(--alerta)'}">${a.linhasNaBase}</strong></td>
        <td class="meta-atividade">${esc(a.ultimaImportacao)}</td></tr>`).join('')}</tbody></table>
      <p class="dica">Se “na base” não bater com “declarado”, a última importação não terminou.</p>

      ${d.ultimosErros.length ? `
        <div class="cartao-titulo" style="margin-top:14px">Últimos erros de importação</div>
        ${d.ultimosErros.map((e) => `<div class="erro-caixa" style="margin-bottom:8px">
          <b>${esc(e.competencia)}</b> — ${esc(e.quando)}<br>${esc(e.erro)}</div>`).join('')}`
        : '<p class="dica" style="margin-top:14px">Nenhum erro de importação registrado.</p>'}`,
      `<button class="botao secundario" onclick="fecharJanela()">Fechar</button>
       ${editaMenu('assiduidade') || editaMenu('config') ? `<button class="botao" onclick="fecharJanela();atualizarRH()">↻ Reimportar agora</button>` : ''}`);
  } catch (e) { avisar(e.message || e, true); }
}

/* ---------------- FICHA E IMPORTAÇÃO ---------------- */

/* ---------------- FICHA DO COLABORADOR ----------------
   Era um formulário: dois campos desabilitados e duas tabelas finas,
   sem hierarquia. Virou um perfil, com quatro blocos e uma pergunta
   cada:

     quem é         — identidade, no topo
     como está      — a assiduidade como número herói, com medidor e
                      selo de situação (ícone + palavra)
     como os dias   — barra de composição: trabalhados, outros dias,
       se dividem     ausências, com rótulo direto em cada faixa
     o que faltou   — só aparece quando há ausência: os números por
                      família e a lista, com marcador de categoria

   O histórico mês a mês só vira tabela quando há MAIS DE UMA
   competência. Com uma só, uma tabela de uma linha não informa nada que
   o herói já não tenha dito — vira gráfico e tabela quando houver série.
   ------------------------------------------------------ */

/* Iniciais para o avatar: primeira e última palavra do nome. */
function iniciaisDe(nome) {
  const p = String(nome || '').trim().split(/\s+/).filter(Boolean);
  if (!p.length) return '?';
  return (p[0][0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase();
}

/* Cor do marcador de categoria da ausência. Falta e atestado são coisas
   diferentes e a gestão trata cada uma de um jeito. */
function corCategoria(cat) {
  const c = String(cat || '').toUpperCase();
  if (c.indexOf('ATESTADO') === 0) return 'var(--faixa-outros)';
  if (c.indexOf('FALTA') === 0) return 'var(--faixa-aus)';
  return 'var(--tinta-fraca)';
}

/*
 * FICHA DO COLABORADOR (4.2.2) — foco nas ausencias e nos tipos de
 * ausencia, com filtro de periodo. Os graficos sairam.
 */
let FICHA = { matricula: '', de: '', ate: '' };
async function fichaColaborador(matricula, de, ate) {
  FICHA = { matricula: matricula, de: de || '', ate: ate || '' };
  if (CANAL_BARRADO && URL_APP) return fichaPelaPagina();   // ainda dentro do clique
  abrirJanela('Ficha do colaborador', '<div class="vazio">Carregando…</div>', '');
  try {
    const f = await executarAcaoSrv('fichaColaborador', { matricula: matricula, de: FICHA.de, ate: FICHA.ate });
    if (FICHA.matricula !== matricula) return;
    abrirJanela('', montarFicha(f), '<button class="botao" onclick="fecharJanela()">Fechar</button>');
    const t = el('janela-titulo'); if (t) t.textContent = '';
  } catch (e) {
    // Google barrando a chamada (HTTP 403): a ficha vem pela navegacao de pagina (a pagina local nao tem reserva).
    if (canalBloqueado(e) && !MODO_LOCAL) {
      CANAL_BARRADO = true;
      abrirJanela('Ficha do colaborador', `<p style="margin-top:0;line-height:1.7">Este computador bloqueia a conversa direta com o Google.
        A ficha abre recarregando a página.</p>`, `<button class="botao" onclick="fichaPelaPagina()">Abrir a ficha</button>`);
      return;
    }
    avisar(MODO_LOCAL ? explicarErro(e) : (e.message || e), true);
  }
}
function fichaPelaPagina() {
  fecharJanela();
  const comp = (DADOS && DADOS.competencia) || '';
  if (!navegarPelaPagina({ t: TOKEN, filial: FILIAL, tela: 'assiduidade',
      p: JSON.stringify({ competencia: comp, ficha: FICHA.matricula, de: FICHA.de, ate: FICHA.ate }) })) {
    avisar('Não consegui abrir a ficha: o endereço do sistema não está configurado.', true);
  }
}
function fichaPeriodo(de, ate) { fichaColaborador(FICHA.matricula, de, ate); }
function fichaAtalho(meses) {
  if (!meses) return fichaPeriodo('', '');
  const h = new Date(); const ini = new Date(h.getFullYear(), h.getMonth() - meses + 1, 1);
  const iso = (d) => d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  fichaPeriodo(iso(ini), iso(h));
}

function montarFicha(f) {
  const p = f.periodo || { porTipo: [], ausencias: 0, diasLancados: 0 };
  const corTipo = { 'Falta injustificada': 'var(--alerta)', 'Falta justificada': '#D97706', 'Falta disciplinar': '#7C3AED',
    'Atestado': '#2563EB', 'Licença legal': '#0891B2', 'Outras ausências': 'var(--tinta-media)' };
  const rotuloPeriodo = (p.de || p.ate)
    ? (p.de ? pnDataLonga(p.de) : 'o início') + ' a ' + (p.ate ? pnDataLonga(p.ate) : 'hoje')
    : 'todo o histórico' + (p.primeiroDia ? ' (' + pnDataLonga(p.primeiroDia) + ' a ' + pnDataLonga(p.ultimoDia) + ')' : '');
  const pctAus = p.diasLancados ? Math.round(p.ausencias / p.diasLancados * 1000) / 10 : 0;
  return `
    <div class="ficha-topo">
      <div class="ficha-inicial">${esc(iniciaisDe(f.nome))}</div>
      <div style="min-width:0">
        <div class="ficha-nome">${esc(f.nome || f.matricula)}</div>
        <div class="ficha-meta">
          <span class="ficha-chip mono">${esc(f.matricula)}</span>
          <span class="ficha-chip">Turno ${esc(f.turno || '—')}</span>
        </div>
      </div>
    </div>

    <div class="ficha-periodo">
      <div class="campo"><label>De</label><input type="date" id="fp-de" value="${esc(p.de || '')}"></div>
      <div class="campo"><label>Até</label><input type="date" id="fp-ate" value="${esc(p.ate || '')}"></div>
      <button class="botao" onclick="fichaPeriodo(val('fp-de'), val('fp-ate'))">Filtrar</button>
      <span class="ficha-atalhos">
        <button class="lp-filtro" onclick="fichaAtalho(1)">Este mês</button>
        <button class="lp-filtro" onclick="fichaAtalho(3)">3 meses</button>
        <button class="lp-filtro" onclick="fichaAtalho(12)">12 meses</button>
        <button class="lp-filtro" onclick="fichaAtalho(0)">Tudo</button></span>
    </div>

    <div class="ficha-secao">Ausências em ${rotuloPeriodo}</div>
    <div class="ficha-tiles ficha-tiles-tipos">
      <div class="ficha-tile"><div class="n" style="color:${p.ausencias ? 'var(--alerta)' : 'var(--sit-bom)'}">${p.ausencias}</div>
        <div class="r">ausência(s) em ${p.diasLancados} dia(s) lançados${p.diasLancados ? ' · ' + String(pctAus).replace('.', ',') + '%' : ''}</div></div>
      ${p.porTipo.filter((t) => t.total || ['Falta injustificada', 'Atestado'].indexOf(t.tipo) !== -1).map((t) =>
        `<div class="ficha-tile"><div class="n" style="color:${t.total ? corTipo[t.tipo] : 'var(--tinta-fraca)'}">${t.total}</div><div class="r">${esc(t.tipo)}</div></div>`).join('')}
    </div>

    ${(f.ausencias || []).length ? `
      <div class="ficha-secao">Dia a dia</div>
      <div style="max-height:320px;overflow-y:auto"><table class="ficha-ausencias">
        <thead><tr><th>Data</th><th>Tipo</th><th>Código</th><th>Descrição</th></tr></thead>
        <tbody>${f.ausencias.map((a) => `<tr>
          <td style="white-space:nowrap"><span class="ponto" style="background:${corTipo[a.tipo] || corCategoria(a.categoria)}"></span> ${esc(a.data)}</td>
          <td><b style="color:${corTipo[a.tipo] || 'inherit'}">${esc(a.tipo || a.categoria)}</b></td>
          <td class="mono">${esc(a.codigo)}</td><td>${esc(a.descricao || '—')}</td></tr>`).join('')}</tbody></table></div>
      ${f.ausencias.length >= 500 ? '<p class="dica">Mostrando as 500 ausências mais recentes do período.</p>' : ''}`
      : `<div class="cartao" style="text-align:center;padding:22px">
           <div style="font-size:28px;line-height:1;color:var(--sit-bom)">✓</div>
           <p style="margin:8px 0 0;font-weight:600">Nenhuma ausência no período</p></div>`}

    ${(f.historico || []).length ? `
      <div class="ficha-secao">Mês a mês</div>
      <div style="overflow-x:auto"><table>
        <thead><tr><th>Competência</th><th class="numero">Dias lanç.</th><th class="numero">Ausências</th><th class="numero">F. injust.</th>
          <th class="numero">F. just.</th><th class="numero">F. discipl.</th><th class="numero">Atestados</th><th class="numero">Assiduidade</th></tr></thead>
        <tbody>${f.historico.slice().reverse().map((x) => `<tr>
          <td><strong>${esc(x.competencia)}</strong></td><td class="numero">${x.registros}</td>
          <td class="numero"><strong>${x.ausencias}</strong></td><td class="numero">${x.faltasInjustificadas}</td>
          <td class="numero">${x.faltasJustificadas}</td><td class="numero">${x.faltasDisciplinares}</td>
          <td class="numero">${x.atestados}</td><td class="numero">${x.assiduidade}%</td></tr>`).join('')}</tbody></table></div>` : ''}`;
}


/* Botão "Atualizar dados": relê a planilha do RH agora. */
/*
 * Botão "Atualizar dados": relê a planilha do RH agora.
 *
 * Antes ele dizia "Dados atualizados:" mesmo quando a importação tinha
 * falhado — o erro era engolido no servidor e a lista de competências
 * voltava vazia. Agora a falha sobe com o motivo, e o sucesso diz
 * quantos lançamentos entraram, para dar para conferir que mudou.
 */
async function atualizarRH() {
  const antes = (DADOS && DADOS.kpis) ? DADOS.kpis.registros : null;
  try {
    avisar('Relendo a planilha do RH — isso leva alguns segundos…');
    const r = await agir('atualizarRH', {}, '');
    COLAB_CACHE = null;
    const depois = (DADOS && DADOS.kpis) ? DADOS.kpis.registros : null;
    let msg = (r && r.aviso) ? r.aviso : 'Dados atualizados.';
    if (antes !== null && depois !== null) {
      msg += (depois === antes)
        ? ' · o total continua em ' + depois + ' lançamentos'
        : ' · de ' + antes + ' para ' + depois + ' lançamentos';
    }
    avisar(msg);
  } catch (e) { /* agir já mostrou o erro com o motivo */ }
}

async function importar(id) {
  avisar('Importando a folha — isso pode levar um minuto…');
  try {
    const r = await executarAcaoSrv('importarCompetencia', { id: id });
    COLAB_CACHE = null;
    esquecerTela('assiduidade');
    avisar(r.registros + ' lançamentos lidos. ' + (r.aviso || ''));
    await abrir('assiduidade', paramsAtual);
  } catch (e) { avisar(e.message || e, true); }
}

async function previa(id) {
  abrirJanela('Pré-visualização da folha', '<div class="vazio">Lendo a planilha…</div>', '');
  try {
    const p = await executarAcaoSrv('previewImportacao', { id: id });
    abrirJanela('Pré-visualização da folha', `
      ${p.erros.length ? `<div class="erro-caixa" style="margin-bottom:12px">
        ${p.erros.map((x) => esc(x)).join('<br>')}</div>` : ''}
      ${p.avisos.length ? `<p class="dica" style="margin:0 0 12px">${p.avisos.map((x) => esc(x)).join('<br>')}</p>` : ''}
      <table><tbody>
        <tr><td>Linha do cabeçalho</td><td><strong>${esc(p.linhaCabecalho)}</strong></td></tr>
        <tr><td>Colunas de data</td><td><strong>${p.colunasData}</strong></td></tr>
        <tr><td>Período</td><td><strong>${esc(p.primeiraData)} a ${esc(p.ultimaData)}</strong></td></tr>
        <tr><td>Lançamentos</td><td><strong>${p.registros}</strong></td></tr>
        <tr><td>Pessoas</td><td><strong>${p.pessoas}</strong></td></tr>
      </tbody></table>
      <div class="cartao-titulo" style="margin-top:14px">Por turno</div>
      <table><thead><tr><th>Turno</th><th class="numero">Pessoas</th><th class="numero">Células</th></tr></thead>
      <tbody>${p.porTurno.map((t) => `<tr><td><strong>${esc(t.turno)}</strong></td>
        <td class="numero">${t.pessoas}</td><td class="numero">${t.celulas}</td></tr>`).join('')}</tbody></table>
      ${p.codigosPendentes.length ? `
        <div class="cartao-titulo" style="margin-top:14px">Códigos fora da legenda</div>
        <p class="dica" style="margin:0 0 8px">Vão ficar de fora dos graficos ate serem
           cadastrados em Configuracao &rsaquo; DE-PARA.</p>
        <p>${p.codigosPendentes.map((c) => `<b>${esc(c.codigo)}</b> (${c.vezes})`).join(' · ')}</p>`
        : '<p class="dica" style="margin-top:12px">Todos os códigos da folha estão na legenda.</p>'}`,
      `<button class="botao secundario" onclick="fecharJanela()">Fechar</button>
       <button class="botao" onclick="importar(${jsArg(id)})">Importar</button>`);
  } catch (e) { avisar(e.message || e, true); }
}


/* ================= CONFIGURAÇÃO =================
   Era um depósito: equipe, rotinas, setores, dezessete parâmetros
   soltos, arquivos do RH, DE-PARA, links de apresentacao e botões de
   sistema, tudo empilhado numa tela so. Agora sao quatro abas, cada uma
   com um assunto — e as PESSOAS saíram daqui para uma tela propria.
   =============================================== */
// rh | calendario | apresentacao | sistema. Guardada na aba (19/10): com o canal barrado, gravar uma
// rotina recarrega a pagina, e ela voltava em "Fontes do RH" em vez de na lista que acabou de mudar.
const CHAVE_ABA_CFG = 'gsl_aba_cfg';
let ABA_CFG = lerSs(CHAVE_ABA_CFG) || 'rh';

function seloRotinas(r) {
  if (!r) return '';
  const mapa = {
    ligado:      ['selo-verde', 'Ligadas'],
    parcial:     ['selo-amarelo', 'Parciais'],
    desligado:   ['selo-vermelho', 'Desligadas'],
    desconhecido:['selo-cinza', 'Nao consegui verificar']
  };
  const s = mapa[r.estado] || mapa.desconhecido;
  return `<span class="selo ${s[0]}"><i></i>${s[1]} — ${r.ligados} de ${r.total}</span>`;
}

function pintarConfig(r) {
  const d = r.dados;
  el('subtitulo-pagina').textContent = 'Fontes do RH, calendário e sistema';
  el('acoes-topo').innerHTML = '';

  const abas = [['rh', 'Fontes do RH'], ['calendario', 'Calendário'],
                ['apresentacao', 'Apresentação'], ['sistema', 'Sistema']];
  el('pagina').innerHTML = `
    <div class="abas">
      ${abas.map(([id, nome]) => `<button class="aba ${ABA_CFG === id ? 'ativa' : ''}"
        onclick="trocarAbaCfg(${jsArg(id)})">${nome}</button>`).join('')}
    </div>
    <div id="conteudo-cfg"></div>`;
  pintarAbaCfg(d);
}

function trocarAbaCfg(aba) {
  ABA_CFG = aba;
  gravarSs(CHAVE_ABA_CFG, aba);
  const botoes = document.querySelectorAll('.abas .aba');
  const ordem = ['rh', 'calendario', 'apresentacao', 'sistema'];
  botoes.forEach((b) => b.classList.remove('ativa'));
  const i = ordem.indexOf(aba); if (botoes[i]) botoes[i].classList.add('ativa');
  pintarAbaCfg(DADOS);
}

function pintarAbaCfg(d) {
  const alvo = el('conteudo-cfg');
  if (!alvo) return;
  try {
    if (ABA_CFG === 'rh')           alvo.innerHTML = cfgRH(d);
    else if (ABA_CFG === 'calendario')   alvo.innerHTML = cfgCalendario(d);
    else if (ABA_CFG === 'apresentacao') alvo.innerHTML = cfgApresentacao(d);
    else alvo.innerHTML = cfgSistema(d);
  } catch (e) {
    alvo.innerHTML = `<div class="erro-caixa">${esc(e.message || e)}</div>`;
  }
}

/* Um parametro: campo que grava ao sair dele — ou so o valor, com a Configuracao em "Ver". */
const campoParam = (p) => `
  <div class="campo"><label>${esc(p.descricao || p.chave)}</label>
    ${podeEditar('config') ? `<input id="par-${p.id}" value="${esc(p.valor)}"
           onchange="agir('salvarParametro',{id:${jsArg(p.id)},valor:this.value},'Parâmetro salvo')">`
      : `<input id="par-${p.id}" value="${esc(p.valor)}" readonly>`}
    <p class="dica mono" style="margin-top:4px">${esc(p.chave)}</p></div>`;
/* A Configuracao em "Ver" (so leitura): a faixa no alto de cada aba. */
const avisoSoVer = (nome) => `<div class="aviso-so-ver" role="note">Seu acesso a <b>${esc(nome)}</b> é só para ver: os botões de gravar não aparecem.</div>`;

/* ---- Aba 1: de onde vêm os dados de assiduidade ---- */
function cfgRH(d) {
  const pRh = (d.parametros || []).filter((p) => p.grupo === 'rh');
  const ed = podeEditar('config');
  return `${ed ? '' : avisoSoVer('Configuração')}
    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo linha-titulo">
        <span>Competências do RH — uma planilha por mês</span>
        ${ed ? '<button class="icone-botao" onclick="formArquivoRH()">Cadastrar competência</button>' : ''}
      </div>
      <p class="dica" style="margin:-4px 0 12px">A competência marcada como <strong>Aberta</strong>
         é relida automaticamente todo dia às ${esc(valorPar(d, 'HORA_ATUALIZACAO_RH') || '10')}h,
         porque é a que o RH ainda atualiza. As fechadas ficam paradas.</p>
      <div style="overflow-x:auto">
        <table><thead><tr><th>Competência</th><th>Aba</th><th>Situação</th>
          <th class="numero">Linhas</th><th>Última leitura</th><th></th></tr></thead>
        <tbody>${d.arquivosRH.map((a) => `<tr>
          <td><strong>${esc(a.competencia)}</strong>
            <div class="meta-atividade">${esc(a.observacao)}</div></td>
          <td>${esc(a.aba)}</td>
          <td>${a.situacao.toUpperCase() === 'ABERTA'
              ? '<span class="etiqueta aguardando">Aberta</span>'
              : '<span class="etiqueta aprovada">Fechada</span>'}</td>
          <td class="numero">${esc(a.linhas)}</td>
          <td class="meta-atividade">${esc(a.ultimaImportacao)}</td>
          <td>${ed ? `<button class="icone-botao" onclick="formArquivoRH(${jsArg(a.id)})">Editar</button>
              <button class="icone-botao" onclick="previa(${jsArg(a.id)})">Conferir</button>
              <button class="icone-botao" onclick="importar(${jsArg(a.id)})">Importar</button>` : ''}</td>
        </tr>`).join('') || '<tr><td colspan="6" class="vazio">Nenhuma competência cadastrada.</td></tr>'}</tbody></table>
      </div>
      <div class="cartao-rodape">
        ${ed ? '<button class="botao" onclick="atualizarRH()">↻ Atualizar agora</button>' : ''}
        <button class="botao secundario" onclick="verDiagnosticoRH()">Diagnóstico da base</button>
      </div>
    </div>

    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo linha-titulo">
        <span>DE-PARA — o que cada código da folha significa</span>
        ${ed ? '<button class="icone-botao" onclick="formDePara()">Novo código</button>' : ''}
      </div>
      <p class="dica" style="margin:-4px 0 12px">
        Esta tabela decide o BI inteiro: a <b>categoria</b> define se o dia conta como
        trabalhado, e <b>conta como ausência</b> define se ele entra no absenteísmo.
        Escreva a categoria sempre pela lista. Código que não estiver aqui vira
        <b>“Não definido”</b> e fica fora dos gráficos.
      </p>
      <div style="overflow-x:auto;max-height:360px">
        <table><thead><tr><th>Cód.</th><th>Descrição</th><th>Categoria</th>
          <th>Ausência</th><th></th></tr></thead>
        <tbody>${(d.dePara || []).map((c) => `<tr>
          <td class="mono"><strong>${esc(c.codigo)}</strong></td>
          <td>${esc(c.descricao)}</td>
          <td>${esc(c.categoria)}</td>
          <td>${c.ausencia ? '<span class="etiqueta atrasada">sim</span>' : '—'}</td>
          <td>${ed ? `<button class="icone-botao" onclick="formDePara(${jsArg(c.id)})">Editar</button>
              <button class="icone-botao perigo" onclick="agir('excluirDePara',{id:${jsArg(c.id)}},'Código removido')">Remover</button>` : ''}</td>
        </tr>`).join('') || '<tr><td colspan="5" class="vazio">Nenhum código cadastrado.</td></tr>'}</tbody></table>
      </div>
      <p class="dica">Depois de mexer no DE-PARA, use <b>Reclassificar a base</b>: ele reaplica a
         tradução em toda a folha já importada e refaz os painéis.</p>
      <div class="cartao-rodape">
        <button class="botao secundario" onclick="verCodigosPendentes()">Códigos fora da legenda</button>
        ${ed ? `<button class="botao secundario" onclick="confirmarRestaurarDePara()">Restaurar tabela padrão</button>
        <button class="botao secundario" onclick="confirmarReclassificar()">Reclassificar a base</button>` : ''}
      </div>
    </div>

    <div class="cartao">
      <div class="cartao-titulo">Como a folha é lida</div>
      <p class="dica" style="margin:-4px 0 12px">Só mexa aqui se a pré-visualização acusar erro —
         os valores já vêm certos para a folha da Bartofil.</p>
      <div class="grade grade-dupla">${pRh.map(campoParam).join('')}</div>
    </div>`;
}

/* ---- Aba 2: o que nasce em cada mês do calendário ---- */
function cfgCalendario(d) {
  const pCal = (d.parametros || []).filter((p) => p.grupo === 'calendario' || p.grupo === 'avisos');
  const ed = podeEditar('config');
  return `${ed ? '' : avisoSoVer('Configuração')}
    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo linha-titulo">
        <span>Rotinas — o que é gerado todo mês</span>
        ${ed ? '<button class="icone-botao" onclick="formRotina()">Nova rotina</button>' : ''}
      </div>
      <div style="overflow-x:auto">
      <table><thead><tr><th>Sigla</th><th>Atividade</th><th>Quando</th><th>Por turno</th><th>Ativa</th><th></th></tr></thead>
      <tbody>${d.rotinas.map((t) => `<tr>
        <td class="mono">${esc(t.tipo)}</td><td>${esc(t.atividade)}</td>
        <td>${esc(descreverQuando(t))}${t.problema ? ` <span class="etiqueta atrasada" title="${esc(t.problema)}">revisar</span>` : ''}</td>
        <td>${t.porTurno ? 'sim' : '—'}</td>
        <td>${t.ativo ? '<span class="selo-entrega">ativa</span>' : pendentesDe(t)
          ? `<span class="pendente-entrega rot-ainda">parada · ${pendentesDe(t)} ainda no calendário</span>`
          : '<span class="pendente-entrega">parada</span>'}</td>
        <td>${ed ? `<div class="rot-botoes">
          <button class="icone-botao" onclick="formRotina(${jsArg(t.id)})">Editar</button>
          <button class="icone-botao" onclick="alternarRotina(${jsArg(t.id)})">${t.ativo ? 'Desativar' : 'Ativar'}</button>
          ${!t.ativo && pendentesDe(t) ? `<button class="icone-botao" onclick="tirarDoCalendario(${jsArg(t.id)})">Tirar do calendário (${pendentesDe(t)})</button>` : ''}
          <button class="icone-botao perigo" onclick="removerRotina(${jsArg(t.id)})">Remover</button></div>` : ''}</td></tr>`).join('') ||
        '<tr><td colspan="6" class="vazio">Nenhuma rotina cadastrada.</td></tr>'}
      </tbody></table></div>
      ${blocoOrfas(d.orfas || [])}
      <p class="dica">${esc(dicaRotinas(d))}</p>
    </div>

    <div class="grade grade-dupla">
      <div class="cartao">
        <div class="cartao-titulo">Setores do CD</div>
        <p class="dica" style="margin:-4px 0 10px">São as opções do campo “setor” das rotinas que exigem setor (como a Vistoria).</p>
        ${d.setores.map((s) => `<div class="anexo"><span class="anexo-nome">${esc(s.setor)}</span>
          ${ed ? `<button class="icone-botao perigo" onclick="agir('excluirSetor',{id:${jsArg(s.id)}},'Setor removido')">Remover</button>` : ''}</div>`).join('')}
        ${ed ? `<div class="campo" style="margin-top:12px"><input id="novo-setor" placeholder="Novo setor"></div>
        <button class="botao secundario" onclick="agir('salvarSetor',{setor:val('novo-setor'),ativo:true},'Setor adicionado')">Adicionar</button>` : ''}
      </div>
      <div class="cartao">
        <div class="cartao-titulo">Prazos e avisos</div>
        ${pCal.map(campoParam).join('') || '<div class="vazio">Sem parâmetros.</div>'}
      </div>
    </div>`;
}

/* ---- Aba 3: os links da reuniao ---- */
/*
 * O botao de salvar vivia dentro de uma celula de tabela, encostado num
 * campo com `width:100%`: o campo transbordava a celula e cobria o
 * botao, entao o clique nunca chegava nele. Ninguem conseguia gravar
 * link nenhum — e por isso a tela de Apresentacao continuava vazia,
 * ainda que o texto tivesse sido digitado.
 *
 * Agora cada turno e uma linha flex: rotulo com largura fixa, campo
 * elastico, botao com largura propria e nada por cima. E o salvamento
 * tem tres portas: o botao, a tecla Enter e a saida do campo.
 */
function cfgApresentacao(d) {
  const ed = podeEditar('config');
  const linha = (a) => ed ? `
    <div class="linha-apres">
      <div class="apres-turno">Turno ${esc(a.turno)}</div>
      <input id="ap-${esc(a.turno)}" class="apres-link" value="${esc(a.link)}"
             placeholder="https:\/\/docs.google.com/presentation/d/..."
             onkeydown="if (event.key === 'Enter') { event.preventDefault(); salvarApresentacao(${jsArg(a.turno)}, ${jsArg(a.id)}); }"
             onblur="salvarApresentacaoSeMudou(${jsArg(a.turno)}, ${jsArg(a.id)}, this.defaultValue)">
      <button class="botao" onclick="salvarApresentacao(${jsArg(a.turno)}, ${jsArg(a.id)})">Salvar link</button>
      ${a.link ? `<button class="icone-botao" title="Abrir a apresentação em outra aba"
             onclick="window.open(${jsArg(a.link)},'_blank')">Abrir</button>` : ''}
    </div>` : `
    <div class="linha-apres">
      <div class="apres-turno">Turno ${esc(a.turno)}</div>
      <input id="ap-${esc(a.turno)}" class="apres-link" value="${esc(a.link)}" readonly>
      ${a.link ? `<button class="icone-botao" title="Abrir a apresentação em outra aba"
             onclick="window.open(${jsArg(a.link)},'_blank')">Abrir</button>` : ''}
    </div>`;
  return `${ed ? '' : avisoSoVer('Configuração')}
    <div class="cartao">
      <div class="cartao-titulo">Apresentações da reunião — um link por turno</div>
      <p class="dica" style="margin:-4px 0 16px">Abra a apresentação do turno no Google, copie o endereço da
         barra do navegador, cole aqui e clique em <b>Salvar link</b> (ou aperte Enter).
         Os cartões da tela de Apresentação passam a abrir este link.</p>
      ${(d.apresentacoes || []).map(linha).join('') || '<div class="vazio">Nenhum turno cadastrado.</div>'}
    </div>`;
}

/* Grava o link de um turno. Recusa endereco que nao seja do Google
   Apresentacoes — colar o link errado e o engano mais comum, e antes ele
   era gravado do mesmo jeito e so aparecia na reuniao. */
let _apresEmVoo = '';
async function salvarApresentacao(turno, id) {
  const campo = el('ap-' + turno);
  if (!campo) return;
  const valor = String(campo.value || '').trim();
  /*
   * Clicar no botao dispara DOIS eventos: o blur do campo (no mousedown)
   * e o click (no mouseup). Sem esta trava o mesmo link ia duas vezes ao
   * servidor e o app remontava a tela duas vezes seguidas.
   */
  if (_apresEmVoo === turno + '|' + valor) return;
  _apresEmVoo = turno + '|' + valor;
  setTimeout(function () { _apresEmVoo = ''; }, 4000);
  if (valor && !/docs\.google\.com\/presentation/i.test(valor)) {
    avisar('Este endereço não é de uma apresentação do Google. Abra a apresentação do turno ' +
           turno + ' e copie o endereço da barra do navegador.', true);
    campo.focus();
    return;
  }
  campo.defaultValue = valor;
  await agir('salvarParametro', { id: id, chave: 'APRESENTACAO_' + turno, valor: valor },
             valor ? 'Link do turno ' + turno + ' salvo' : 'Link do turno ' + turno + ' apagado');
}

/* Sair do campo tambem grava — mas so se o texto mudou de verdade, senao
   cada clique na tela viraria uma ida ao servidor. */
function salvarApresentacaoSeMudou(turno, id, original) {
  const campo = el('ap-' + turno);
  if (!campo) return;
  if (String(campo.value || '').trim() === String(original || '').trim()) return;
  salvarApresentacao(turno, id);
}

/* ---- Aba 4: manutenção ---- */
function cfgSistema(d) {
  const pSis = (d.parametros || []).filter((p) => p.grupo === 'sistema');
  const ed = podeEditar('config');
  return `${ed ? '' : avisoSoVer('Configuração')}
    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo">Estado do sistema</div>
      <table class="tabela-chave"><tbody>
        <tr><td>Fuso em uso</td><td><strong>${esc(d.fuso.atual)}</strong></td></tr>
        <tr><td>Hora do sistema</td><td><strong>${esc(d.fuso.hora)}</strong></td></tr>
        <tr><td>Rotinas automáticas</td><td>${seloRotinas(d.sistema.rotinas)}</td></tr>
      </tbody></table>
      <p class="dica">As rotinas rodam às 5h (digesto, fila de validacao, geracao do mes seguinte
         no dia ${esc(valorPar(d, 'GERAR_MES_NO_DIA') || '20')}) e às
         ${esc(valorPar(d, 'HORA_ATUALIZACAO_RH') || '10')}h (releitura da planilha do RH).</p>
    </div>

    <div class="cartao" style="margin-bottom:14px">
      <div class="cartao-titulo">Manutenção</div>
      <div class="cfg-botoes">
        ${ed ? `<button class="botao secundario" onclick="agir('ligarGatilhos',{},'Rotinas automáticas ligadas')">Ligar rotinas automáticas</button>
        <button class="botao secundario" onclick="agir('corrigirFuso',{},'Fuso alinhado')">Corrigir fuso</button>
        <button class="botao secundario" onclick="agir('enviarDigesto',{},'Digesto enviado')">Enviar digesto agora</button>
        <button class="botao secundario" onclick="gerarProximoMes()">Gerar próximo mês</button>` : ''}
        <button class="botao secundario" onclick="janelaAutorizarEmail()">E-mail não chega?</button>
        <button class="botao secundario" onclick="alternarModoLeve()">${document.documentElement.classList.contains('modo-leve') ? '⚡ Modo leve: LIGADO' : '⚡ Modo leve: desligado'}</button>
        ${d.pastaAnexos ? `<button class="botao secundario" onclick="window.open(${jsArg(d.pastaAnexos)},'_blank')">📁 Abrir pasta das entregas</button>` : ''}
      </div>
      <p class="dica"><b>Modo leve</b>: desliga as animações de entrada e as transições, mantendo cores e
      layout. O app liga sozinho quando percebe que a maquina nao está dando conta dos quadros;
      este botão serve para forçar ou desfazer, e vale so neste computador.</p>
    </div>

    ${pSis.length ? `<div class="cartao">
      <div class="cartao-titulo">Outros parâmetros</div>
      <div class="grade grade-dupla">${pSis.map(campoParam).join('')}</div>
    </div>` : ''}`;
}

const valorPar = (d, chave) =>
  ((d.parametrosTodos || d.parametros || []).find((p) => p.chave === chave) || {}).valor;

/* "toda quarta", "todo sábado", "1ª segunda do mês", "todo dia 15", "5 vagas sem data". */
const DIAS_ROTINA = ['', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado', 'domingo'];
function descreverQuando(t) {
  const f = String(t.frequencia || '').toUpperCase(), d = String(t.dia == null ? '' : t.dia).toUpperCase().trim();
  if (f === 'SEMANAL') return /^[1-7]$/.test(d) ? (Number(d) >= 6 ? 'todo ' : 'toda ') + DIAS_ROTINA[d] : 'sem dia da semana';
  if (f === 'MENSAL') return d === 'PRIMEIRA_SEGUNDA' ? '1ª segunda do mês' : d === 'ULTIMA_SEXTA' ? 'última sexta do mês' : 'todo dia ' + d;
  const q = Number(t.quantidade) || 1;
  return q + (q === 1 ? ' vaga sem data' : ' vagas sem data');
}

/* A dica embaixo da lista: onde mudar uma rotina mexe nas atividades que ja existem. */
function dicaRotinas(d) {
  const m = d.mesesGerados || [];
  const meses = m.length > 1 ? m.slice(0, -1).join(', ') + ' e ' + m[m.length - 1] : m.join('');
  return 'Mudar o dia, desativar ou remover vale de hoje em diante' + (meses ? ', também nos meses já gerados (' + meses + ')' : '') +
    '. Entregues, validadas e datas que já passaram não mudam.';
}

/* Rotinas removidas pela versao anterior (so a linha de ROTINAS saia): as pendentes que ficaram no calendario. */
function blocoOrfas(orfas) {
  if (!orfas.length) return '';
  return `<div class="rot-orfas"><p class="rot-orfas-titulo">Atividades de rotinas removidas</p>
    ${orfas.map((o) => `<div class="rot-orfa">
      <span><b class="mono">${esc(o.sigla)}</b> — ${o.pendentes.total} ${o.pendentes.total === 1 ? 'pendente' : 'pendentes'} de hoje em diante</span>
      ${podeEditar('config') ? `<button class="icone-botao" onclick="tirarOrfa(${jsArg(o.sigla)})">Tirar do calendário</button>` : ''}</div>`).join('')}</div>`;
}

function formArquivoRH(id) {
  const a = id ? DADOS.arquivosRH.find((x) => x.id === id) : null;
  const agora = new Date();
  const sugestao = agora.getFullYear() + '-' + String(agora.getMonth() + 1).padStart(2, '0');
  abrirJanela(a ? ('Competencia ' + a.competencia) : 'Cadastrar competencia do RH', `
    <div class="campo-duplo">
      <div class="campo"><label>Competencia (aaaa-mm)</label>
        <input id="rh-comp" value="${esc(a ? a.competencia : sugestao)}" placeholder="2026-08"></div>
      <div class="campo"><label>Situação</label>
        <select id="rh-situacao">
          <option ${a && a.situacao === 'Aberta' ? 'selected' : ''}>Aberta</option>
          <option ${a && a.situacao !== 'Aberta' ? 'selected' : ''}>Fechada</option>
        </select></div>
    </div>
    <div class="campo"><label>Link da planilha do RH</label>
      <input id="rh-link" value="${esc(a ? a.link : '')}" placeholder="https:\/\/docs.google.com/spreadsheets/..."></div>
    <div class="campo"><label>Aba da folha</label>
      <input id="rh-aba" value="${esc(a ? a.aba : 'FOLHA DE PONTO')}"></div>
    <div class="campo"><label>Observação</label>
      <input id="rh-obs" value="${esc(a ? a.observacao : '')}" placeholder="Ex.: período de 21/07 a 20/08"></div>
    <p class="dica"><b>Aberta</b> = o RH ainda mexe nela; o sistema relê essa competencia
       automaticamente uma vez por dia. <b>Fechada</b> = mês encerrado, não é mais relido.</p>`, `
    ${a ? `<button class="botao perigo" onclick="agir('excluirArquivoRH',{id:${jsArg(id)}},'Competência removida')">Remover</button>` : ''}
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('salvarArquivoRH',{id:${jsArg(id || '')},competencia:val('rh-comp'),link:val('rh-link'),aba:val('rh-aba'),situacao:val('rh-situacao'),observacao:val('rh-obs')},'Competência salva')">Salvar</button>`);
}

/* ---- Rotinas (19/10) ----
   O "Quando" era um campo de texto que pedia numero ("1 a 5"), e salvar so
   gravava a rotina: o calendario ja gerado ficava como estava. Agora o dia sai
   de botoes (radios de verdade: teclado e leitor de tela), a janela mostra as
   proximas datas e, quando a rotina tem pendentes no calendario, confirma o
   que vai mudar antes de gravar. Os numeros da confirmacao ja vieram com a
   Configuracao: com o canal barrado, so a gravacao (agir) chega ao servidor. */
const DIAS_ROTINA_CURTOS = ['', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
const nomeDoDia = (n) => DIAS_ROTINA[n] + (n >= 6 ? '' : '-feira');
let ROT_FORM = null;      // a janela aberta: { id, versao, escolha: o dia (ou vagas) escolhido em cada "Repete" }
let ROT_PEDIDO = null;    // o que a janela de confirmacao grava: { acao, params, recado, rascunho }

const rotinaDaLista = (id) => (id && DADOS && DADOS.rotinas || []).find((x) => x.id === id) || null;
const pendentesDe = (t) => (t && t.pendentes && t.pendentes.total) || 0;
// Das pendentes: as remarcadas a mao (a troca de dia nao as move) e as fora do dia da regra, sem nota (servidor de antes: 0).
const remarcadasDe = (t) => Math.min(pendentesDe(t), Number(t && t.pendentes && t.pendentes.remarcadas) || 0);
const foraDoDiaDe = (t) => Number(t && t.pendentes && t.pendentes.foraDoDia) || 0;
const porMesDe = (t) => Object.keys(t.pendentes.porMes).map((c) => c + ': ' + t.pendentes.porMes[c]).join(' · ');
/* As remarcadas a mao tambem saem quando a regra nao as gera: ", inclusive as 2 remarcadas a mao" (so quando ha). */
const inclusiveRemarcadas = (r) => r ? ', inclusive ' + (r === 1 ? 'a remarcada à mão' : 'as ' + r + ' remarcadas à mão') : '';

function formRotina(id, rascunho) {
  // Sem id = rotina nova. rascunho = o que a pessoa ja tinha escolhido (Voltar da confirmacao).
  const salva = rotinaDaLista(id);
  const t = rascunho || salva || { id: '', tipo: '', atividade: '', frequencia: 'SEMANAL', dia: '',
                                   quantidade: 5, porTurno: false, exigeSetor: false, ativo: true };
  const freq = ['SEMANAL', 'MENSAL', 'AVULSA'].indexOf(t.frequencia) === -1 ? 'SEMANAL' : t.frequencia;
  // versao: a da rotina quando a janela abriu (o Voltar da confirmacao a traz no rascunho).
  ROT_FORM = { id: id || '', versao: String(t.versao || ''), escolha: { SEMANAL: '', MENSAL: '', AVULSA: String(t.quantidade || 5) } };
  if (freq !== 'AVULSA') ROT_FORM.escolha[freq] = String(t.dia || '');
  const travada = !!(salva && salva.temAtividades);
  const n = pendentesDe(salva);
  abrirJanela(id ? 'Editar rotina' : 'Nova rotina', `
    <div class="campo"><label for="ro-tipo">Sigla (2 ou 3 letras — entra no código)</label>
      <input id="ro-tipo" value="${esc(t.tipo)}" maxlength="3" ${travada ? 'disabled' : ''}>
      ${travada ? `<p class="dica">A sigla não muda depois que a rotina gerou atividades — ela está no código delas.
        Para outra sigla, crie uma rotina nova e desative esta.</p>` : ''}</div>
    <div class="campo"><label for="ro-atividade">Atividade</label><input id="ro-atividade" value="${esc(t.atividade)}"></div>
    <fieldset class="rot-grupo"><legend>Repete</legend>
      <div class="rot-pilulas">${[['SEMANAL', 'Toda semana'], ['MENSAL', 'Todo mês'], ['AVULSA', 'Vagas sem data']].map(([v, r]) => `
        <label><input type="radio" name="ro-freq" value="${v}" ${v === freq ? 'checked' : ''} onchange="trocarRepeticao()"><span>${r}</span></label>`).join('')}
      </div>
    </fieldset>
    <div id="ro-quando">${blocoQuando(freq)}</div>
    <label class="marcador rot-opcao"><input type="checkbox" id="ro-turno" ${t.porTurno ? 'checked' : ''}>
      <span><b>Uma por turno (A, B e C)</b> — desmarcado: uma só, para a gestão e os coordenadores (turno Todos)</span></label>
    <label class="marcador rot-opcao"><input type="checkbox" id="ro-setor" ${t.exigeSetor ? 'checked' : ''}>
      <span><b>Exige setor</b> — no calendário, o gerente escolhe o setor de cada atividade (como na Vistoria)</span></label>
    <label class="marcador rot-opcao"><input type="checkbox" id="ro-ativo" ${t.ativo ? 'checked' : ''}>
      <span><b>Ativa</b> — desmarcada, a rotina para de gerar e as pendentes de hoje em diante saem do calendário</span></label>
    ${n ? `<p class="dica rot-agora">No calendário agora: ${n} ${n === 1 ? 'pendente' : 'pendentes'} de hoje em diante (${esc(porMesDe(salva))}).</p>` : ''}`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="salvarRotina()">Salvar</button>`);
  previaRotina();
}

/* O bloco do "quando" de cada "Repete": dia da semana, dia do mes ou numero de vagas. */
function blocoQuando(freq) {
  const e = ROT_FORM.escolha;
  if (freq === 'SEMANAL') return `
    <fieldset class="rot-grupo"><legend>Dia da semana</legend>
      <div class="rot-pilulas rot-dias">${[1, 2, 3, 4, 5, 6, 7].map((n) => `
        <label><input type="radio" name="ro-dia-semana" value="${n}" aria-label="${nomeDoDia(n)}" ${String(n) === e.SEMANAL ? 'checked' : ''}
          onchange="escolherQuando()"><span>${DIAS_ROTINA_CURTOS[n]}</span></label>`).join('')}
      </div>
      <p class="dica" id="ro-previa" aria-live="polite"></p>
    </fieldset>`;
  if (freq === 'MENSAL') {
    const fixo = /^\d+$/.test(e.MENSAL) ? e.MENSAL : '';
    const opcao = (v, rotulo) => `<label class="marcador"><input type="radio" name="ro-dia-mes" value="${v}"
      ${(v === 'FIXO' ? !!fixo : e.MENSAL === v) ? 'checked' : ''} onchange="escolherQuando()"> ${rotulo}</label>`;
    return `
    <fieldset class="rot-grupo"><legend>Dia do mês</legend>
      ${opcao('PRIMEIRA_SEGUNDA', '1ª segunda-feira do mês')}
      ${opcao('ULTIMA_SEXTA', 'Última sexta-feira do mês')}
      <div class="rot-fixo">${opcao('FIXO', 'Dia fixo')}
        <select id="ro-dia-fixo" aria-label="Dia fixo do mês" onchange="escolherDiaFixo()">${Array.from({ length: 31 }, (x, i) => i + 1)
          .map((d) => `<option ${String(d) === (fixo || '15') ? 'selected' : ''}>${d}</option>`).join('')}</select></div>
      <p class="dica">Se o mês não tiver esse dia (31 em setembro), vale o último dia do mês.</p>
      <p class="dica" id="ro-previa" aria-live="polite"></p>
    </fieldset>`;
  }
  return `
    <div class="campo"><label for="ro-qtd">Vagas por mês</label>
      <input id="ro-qtd" type="number" min="1" max="10" step="1" value="${esc(e.AVULSA)}" oninput="escolherQuando()">
      <p class="dica">As vagas aparecem sem data em “Treinamentos e vagas”; o gerente agenda.</p></div>`;
}

const freqDoForm = () => (document.querySelector('input[name="ro-freq"]:checked') || {}).value || 'SEMANAL';
function quandoDoForm(freq) {
  if (freq === 'SEMANAL') return (document.querySelector('input[name="ro-dia-semana"]:checked') || {}).value || '';
  if (freq === 'AVULSA') return val('ro-qtd');
  const v = (document.querySelector('input[name="ro-dia-mes"]:checked') || {}).value || '';
  return v === 'FIXO' ? val('ro-dia-fixo') : v;
}
function escolherQuando() { ROT_FORM.escolha[freqDoForm()] = quandoDoForm(freqDoForm()); previaRotina(); }
function escolherDiaFixo() {
  const fixo = document.querySelector('input[name="ro-dia-mes"][value="FIXO"]');
  if (fixo) fixo.checked = true;
  escolherQuando();
}
/* Trocar o "Repete" redesenha so o bloco do dia; a escolha de antes fica guardada (ROT_FORM.escolha). */
function trocarRepeticao() { el('ro-quando').innerHTML = blocoQuando(freqDoForm()); previaRotina(); }

/* A data cai na regra? A mesma conta do servidor (datasDaRotina), para a previa. */
function caiNaRegra(freq, dia, d) {
  if (freq === 'SEMANAL') return (d.getDay() || 7) === Number(dia);
  const ultimo = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  if (dia === 'PRIMEIRA_SEGUNDA') return d.getDay() === 1 && d.getDate() <= 7;
  if (dia === 'ULTIMA_SEXTA') return d.getDay() === 5 && d.getDate() + 7 > ultimo;
  return d.getDate() === Math.min(Number(dia), ultimo);
}

/* "Toda quarta-feira · próximas: 21/10, 28/10, 04/11" — de hoje em diante. */
function previaRotina() {
  const alvo = el('ro-previa');
  if (!alvo) return;
  const freq = freqDoForm(), dia = quandoDoForm(freq);
  if (!dia) { alvo.textContent = freq === 'SEMANAL' ? 'Escolha o dia da semana.' : 'Escolha o dia do mês.'; return; }
  const hoje = new Date(), proximas = [];
  for (let i = 0; i < 400 && proximas.length < 3; i++) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + i);
    if (caiNaRegra(freq, dia, d)) proximas.push(String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0'));
  }
  const regra = freq === 'SEMANAL' ? (Number(dia) >= 6 ? 'Todo ' : 'Toda ') + nomeDoDia(Number(dia))
    : descreverQuando({ frequencia: freq, dia: dia }).replace(/^./, (x) => x.toUpperCase());
  alvo.textContent = regra + ' · próximas: ' + proximas.join(', ');
}

function paramsDaRotina() {
  const freq = freqDoForm(), quando = quandoDoForm(freq);
  return { id: ROT_FORM.id, versao: ROT_FORM.versao, tipo: val('ro-tipo'), atividade: val('ro-atividade'), frequencia: freq,
           dia: freq === 'AVULSA' ? '' : quando, quantidade: freq === 'AVULSA' ? quando : '',
           porTurno: marcado('ro-turno'), exigeSetor: marcado('ro-setor'), ativo: marcado('ro-ativo') };
}

const mudouARegra = (t, p) => t.frequencia !== p.frequencia || String(t.dia) !== String(p.dia) || !!t.porTurno !== !!p.porTurno ||
  (p.frequencia === 'AVULSA' && Number(t.quantidade) !== Number(p.quantidade));

/*
 * Salvar: com pendentes no calendario, desativar ou mudar a regra passa antes pela confirmacao. Sem mudar a
 * regra, as pendentes fora do dia dela (versao anterior, planilha) so vao para o dia da regra se a pessoa quiser.
 */
function salvarRotina() {
  const p = paramsDaRotina();
  if (p.frequencia === 'SEMANAL' && !p.dia) return avisar('Escolha o dia da semana.', true);
  if (p.frequencia === 'MENSAL' && !p.dia) return avisar('Rotina mensal: escolha 1ª segunda, última sexta ou um dia de 1 a 31.', true);
  const t = rotinaDaLista(p.id);
  if (pendentesDe(t) && !p.ativo) return janelaDesativarRotina(t, p);
  if (pendentesDe(t) && mudouARegra(t, p)) return janelaMudarRotina(t, p);
  if (foraDoDiaDe(t)) return janelaForaDoDia(t, p);
  agir('salvarRotina', p, 'Rotina salva').catch(() => {});
}

/* A regra em palavras; o turno entra so quando e ele que muda. */
const regraEmPalavras = (a, b) => descreverQuando(a) +
  (!!a.porTurno !== !!b.porTurno ? (a.porTurno ? ', uma por turno' : ', uma só (turno Todos)') : '');

/* Troca so do dia da semana: as pendentes vao para o dia novo da mesma semana; as remarcadas a mao ficam. */
function destinoDaTrocaDeDia(t, oDia) {
  const n = pendentesDe(t), r = remarcadasDe(t), vao = n - r, meses = ' (' + esc(porMesDe(t)) + ')';
  if (!r) return (n === 1 ? 'A <b>única</b> atividade pendente' : 'As <b>' + n + '</b> atividades pendentes') +
    ' de hoje em diante' + meses + ' ' + (n === 1 ? 'vai' : 'vão') + ' para ' + oDia + ' da mesma semana.';
  if (!vao) return n === 1 ? 'A <b>única</b> pendente de hoje em diante' + meses + ' foi remarcada à mão e fica onde está.'
    : 'As <b>' + n + '</b> pendentes de hoje em diante' + meses + ' foram remarcadas à mão e ficam onde estão.';
  return 'Das <b>' + n + '</b> pendentes de hoje em diante' + meses + ', <b>' + vao + '</b> ' + (vao === 1 ? 'vai' : 'vão') +
    ' para ' + oDia + ' da mesma semana e ' + (r === 1 ? '1 remarcada à mão fica onde está.' : r + ' remarcadas à mão ficam onde estão.');
}

function janelaMudarRotina(t, p) {
  ROT_PEDIDO = { acao: 'salvarRotina', params: p, recado: 'Rotina salva', rascunho: true };
  const n = pendentesDe(t), r = remarcadasDe(t);
  // So o dia da semana mudou: as pendentes vao para o dia novo da mesma semana.
  const soODia = t.frequencia === 'SEMANAL' && p.frequencia === 'SEMANAL' && !!t.porTurno === !!p.porTurno;
  const oDia = soODia ? (Number(p.dia) >= 6 ? 'o ' : 'a ') + DIAS_ROTINA[p.dia] : '';
  // Turno ou frequencia: o que a regra nova nao gera e cancelado, remarcada a mao ou nao (o servidor faz assim).
  const destino = soODia ? destinoDaTrocaDeDia(t, oDia)
    : (n === 1 ? 'A <b>única</b> atividade pendente' : 'As <b>' + n + '</b> atividades pendentes') + ' de hoje em diante (' +
      esc(porMesDe(t)) + ') ' + (n === 1 ? 'segue' : 'seguem') + ' a regra nova: o que ela não gera é cancelado (fica no Arquivo de canceladas)' +
      inclusiveRemarcadas(r) + ', e o que falta é criado, só de hoje em diante.';
  const naoMudam = 'Não mudam: as já entregues ou validadas' + (soODia && !r ? ', as remarcadas à mão' : '') +
    (t.frequencia === 'AVULSA' ? ', as vagas já agendadas' : '') + ' e as de datas que já passaram.';
  abrirJanela('Mudar a rotina no calendário?', `
    <p class="rot-texto">“${esc(t.atividade)}” passa de <b>${esc(regraEmPalavras(t, p))}</b> para <b>${esc(regraEmPalavras(p, t))}</b>.
      ${destino} ${naoMudam}${soODia ? ' Se ' + oDia + ' desta semana já passou, a desta semana fica como está.' : ''}</p>
    <label class="marcador"><input type="checkbox" id="ro-ajustar" checked onchange="el('ro-confirmar').textContent = this.checked
      ? 'Salvar e ajustar o calendário' : 'Salvar só a rotina'"> Ajustar também as atividades já geradas</label>
    <p class="dica">Desmarcado: vale só para os meses que ainda vão ser gerados.</p>`, `
    <button class="botao secundario" onclick="voltarDaConfirmacao()">Voltar</button>
    <button class="botao" id="ro-confirmar" onclick="confirmarRotina()">Salvar e ajustar o calendário</button>`);
}

/*
 * Sem mudar a regra, ha pendentes fora do dia dela (a versao anterior deixou no dia antigo, ou alguem mudou na
 * planilha): a pessoa escolhe. "Deixar" manda alinharForaDoDia: false e o servidor nao as move.
 */
function janelaForaDoDia(t, p) {
  ROT_PEDIDO = { acao: 'salvarRotina', params: p, recado: 'Rotina salva' };
  const n = foraDoDiaDe(t);
  const dia = t.frequencia === 'SEMANAL' ? DIAS_ROTINA[t.dia] : 'o dia da rotina';
  abrirJanela('Levar para o dia da rotina?', `
    <p class="rot-texto">${n === 1 ? '<b>1</b> atividade pendente de hoje em diante está' : '<b>' + n + '</b> atividades pendentes de hoje em diante estão'}
      fora do dia da rotina (${esc(descreverQuando(t))}): ${n === 1 ? 'ficou' : 'ficaram'} no dia antigo na versão anterior
      ou ${n === 1 ? 'foi mudada' : 'foram mudadas'} direto na planilha.</p>`, `
    <button class="botao secundario" onclick="confirmarRotina({ alinharForaDoDia: false })">Deixar como ${n === 1 ? 'está' : 'estão'}</button>
    <button class="botao" onclick="confirmarRotina({ alinharForaDoDia: true })">Levar para ${esc(dia)}</button>`);
}

/* p = os campos do formulario (desmarcou "Ativa"); sem p, e o "Desativar" (ou o "Tirar do calendario") da lista. */
function janelaDesativarRotina(t, p) {
  ROT_PEDIDO = p ? { acao: 'salvarRotina', params: p, recado: 'Rotina salva', rascunho: true }
                 : { acao: 'alternarRotina', params: { id: t.id, ativo: false }, recado: t.ativo ? 'Rotina desativada' : 'Rotina parada' };
  const n = pendentesDe(t), r = remarcadasDe(t), meses = esc(porMesDe(t));
  // Ja parada: a versao anterior so gravava ATIVO=NAO, e as pendentes ficaram no calendario.
  if (!t.ativo) {
    abrirJanela('Tirar “' + t.atividade + '” do calendário?', `
      <p class="rot-texto">A rotina já está parada, mas ${n === 1
        ? '<b>1</b> atividade pendente de hoje em diante (' + meses + ') continua no calendário — ficou da versão anterior. Ela será <b>cancelada</b> e fica'
        : '<b>' + n + '</b> atividades pendentes de hoje em diante (' + meses + ') continuam no calendário — ficaram da versão anterior. Elas serão <b>canceladas</b> e ficam'}
        no Arquivo de canceladas do mês.</p>`, `
      <button class="botao secundario" onclick="voltarDaConfirmacao()">Voltar</button>
      <button class="botao perigo" onclick="confirmarRotina()">Tirar do calendário</button>`);
    return;
  }
  abrirJanela('Desativar “' + t.atividade + '”?', `
    <p class="rot-texto">A rotina para de gerar atividades. ${n === 1
      ? 'A <b>única</b> pendente de hoje em diante (' + meses + ') será <b>cancelada</b>: sai do calendário e fica'
      : 'As <b>' + n + '</b> pendentes de hoje em diante (' + meses + ')' + (r ? inclusiveRemarcadas(r) + ',' : '') +
        ' serão <b>canceladas</b>: saem do calendário e ficam'}
      no Arquivo de canceladas do mês. Se você ativar a rotina de novo, ${n === 1 ? 'ela volta' : 'elas voltam'}.
      Entregues, validadas${t.frequencia === 'AVULSA' ? ', vagas já agendadas' : ''} e de datas que já passaram não mudam.</p>`, `
    <button class="botao secundario" onclick="voltarDaConfirmacao()">Voltar</button>
    <button class="botao perigo" onclick="confirmarRotina()">Desativar e cancelar ${n}</button>`);
}

/* Desativar / Ativar da lista. Ativar nao precisa de confirmacao: o que a rotina cancelou volta. */
function alternarRotina(id) {
  const t = rotinaDaLista(id);
  if (!t) return;
  if (!t.ativo) return agir('alternarRotina', { id: t.id, ativo: true }, 'Rotina ativada').catch(() => {});
  if (pendentesDe(t)) return janelaDesativarRotina(t, null);
  agir('alternarRotina', { id: t.id, ativo: false }, 'Rotina desativada').catch(() => {});
}

/* Parada pela versao anterior com pendentes ainda no calendario: "Tirar do calendario (6)" na lista. */
function tirarDoCalendario(id) {
  const t = rotinaDaLista(id);
  if (t) janelaDesativarRotina(t, null);
}

function removerRotina(id) {
  const t = rotinaDaLista(id);
  if (!t) return;
  const n = pendentesDe(t), r = remarcadasDe(t);
  ROT_PEDIDO = { acao: 'excluirRotina', params: { id: t.id }, recado: 'Rotina removida' };
  abrirJanela('Remover “' + t.atividade + '”?', `
    <p class="rot-texto">A rotina sai da lista e para de gerar atividades.${!n ? '' : n === 1
      ? ' A <b>única</b> pendente de hoje em diante será cancelada (fica no Arquivo de canceladas).'
      : ' As <b>' + n + '</b> pendentes de hoje em diante' + (r ? inclusiveRemarcadas(r) + ',' : '') +
        ' serão canceladas (ficam no Arquivo de canceladas).'}
      ${t.frequencia === 'AVULSA' ? 'As vagas já agendadas ficam. ' : ''}O histórico — entregues, validadas e passadas — continua.</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Voltar</button>
    <button class="botao perigo" onclick="confirmarRotina()">Remover rotina</button>`);
}

/* Rotina removida pela versao anterior: as pendentes que ficaram saem do calendario (canceladas, como no Remover). */
function tirarOrfa(sigla) {
  const o = ((DADOS && DADOS.orfas) || []).find((x) => x.sigla === sigla);
  if (!o) return;
  const n = o.pendentes.total, meses = esc(porMesDe(o));
  ROT_PEDIDO = { acao: 'limparSiglaOrfa', params: { sigla: sigla }, recado: 'Atividades tiradas do calendário' };
  abrirJanela('Tirar as atividades da rotina removida ' + sigla + '?', `
    <p class="rot-texto">${n === 1 ? 'A <b>única</b> pendente de hoje em diante (' + meses + ') será <b>cancelada</b> e fica'
      : 'As <b>' + n + '</b> pendentes de hoje em diante (' + meses + ') serão <b>canceladas</b> e ficam'}
      no Arquivo de canceladas do mês.</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Voltar</button>
    <button class="botao perigo" onclick="confirmarRotina()">Tirar do calendário</button>`);
}

/* O botao da confirmacao grava (dentro do clique: com o canal barrado o agir vai pela pagina). extra: a escolha do botao. */
function confirmarRotina(extra) {
  const x = ROT_PEDIDO;
  if (!x) return;
  if (el('ro-ajustar')) x.params.ajustarCalendario = marcado('ro-ajustar');
  Object.assign(x.params, extra || {});
  agir(x.acao, x.params, x.recado).catch(() => {});
}

/* Voltar da confirmacao: para o formulario com o que a pessoa escolheu, ou para a lista. */
function voltarDaConfirmacao() {
  const x = ROT_PEDIDO;
  if (x && x.rascunho) formRotina(x.params.id, x.params);
  else fecharJanela();
}

/* ---- DE-PARA ---- */

function formDePara(id) {
  const d = DADOS;
  const c = id ? (d.dePara || []).find((x) => x.id === id) : null;
  const cats = d.categorias || [];
  abrirJanela(c ? ('Codigo ' + c.codigo) : 'Novo codigo do RH', `
    <div class="campo-duplo">
      <div class="campo"><label>Código na folha</label>
        <input id="dp-codigo" value="${esc(c ? c.codigo : '')}" placeholder="Ex.: 16"></div>
      <div class="campo"><label>Categoria</label>
        <select id="dp-categoria">
          ${cats.map((x) => `<option ${c && c.categoria === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}
        </select></div>
    </div>
    <div class="campo"><label>Descrição</label>
      <input id="dp-descricao" value="${esc(c ? c.descricao : '')}" placeholder="Como aparece na legenda do RH"></div>
    <label class="marcador"><input type="checkbox" id="dp-ausencia" ${c && c.ausencia ? 'checked' : ''}>
      Conta como ausencia (entra no absenteísmo)</label>
    <p class="dica">Turnos (ADM, A, B, C, J, BC) tambem sao codigos: na folha, o dia trabalhado
       vem com a letra do turno. Eles precisam estar aqui como <b>Presença</b>.
       Use <b>Ignorar</b> para o que nao é lançamento (traço, anotação).</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('salvarDePara',{id:${jsArg(id || '')},codigo:val('dp-codigo'),descricao:val('dp-descricao'),categoria:val('dp-categoria'),ausencia:marcado('dp-ausencia')},'Código salvo')">Salvar</button>`);
}

async function verCodigosPendentes() {
  abrirJanela('Códigos fora da legenda', '<div class="vazio">Procurando…</div>', '');
  try {
    const lista = await executarAcaoSrv('codigosPendentes', {});
    const faltaReclassificar = lista.some((c) => c.jaNaLegenda);
    abrirJanela('Códigos fora da legenda', lista.length ? `
      <p class="dica" style="margin:0 0 12px">Estes códigos apareceram na folha importada fora do
         DE-PARA. Eles ficam <b>fora dos gráficos e das contagens</b> — entrar como
         categoria inventada seria pior que não entrar.</p>
      ${faltaReclassificar ? `<p class="dica" style="margin:0 0 12px">Os marcados como <b>já cadastrado</b>
         estão no DE-PARA: falta só rodar o <b>Reclassificar</b>. Não cadastre de novo.</p>` : ''}
      <table><thead><tr><th>Código</th><th class="numero">Vezes</th><th></th></tr></thead>
      <tbody>${lista.map((c) => `<tr><td class="mono"><strong>${esc(c.codigo)}</strong></td>
        <td class="numero">${c.vezes}</td>
        <td>${c.jaNaLegenda ? '<span class="etiqueta aguardando">já cadastrado — falta Reclassificar</span>' : ''}</td></tr>`).join('')}</tbody></table>`
      : '<div class="cartao">Nenhum código pendente — a folha inteira está traduzida.</div>',
      '<button class="botao" onclick="fecharJanela()">Fechar</button>');
  } catch (e) { avisar(e.message || e, true); }
}

function confirmarRestaurarDePara() {
  abrirJanela('Restaurar a tabela padrão do DE-PARA', `
    <p style="margin:0 0 14px;line-height:1.7;color:var(--tinta-media)">
      Reaplica a legenda oficial da folha de ponto da Bartofil: corrige os códigos que
      estiverem com categoria diferente da padrão e cria os que faltarem.
    </p>
    <p style="margin:0 0 14px;line-height:1.7;color:var(--tinta-media)">
      <b>Não apaga nada</b> que você tenha acrescentado. Se você editou algum código de
      propósito, ele volta ao padrão — confira a lista depois.
    </p>
    <p class="dica">Em seguida rode <b>Reclassificar a base</b>: é ela que reaplica a
       tradução na folha já importada.</p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="restaurarDePara()">Restaurar tabela</button>`);
}

async function restaurarDePara() {
  try {
    const r = await executarAcaoSrv('restaurarDePara', {});
    fecharJanela();
    esquecerTela('config');
    avisar(r.corrigidos + ' codigo(s) corrigido(s), ' + r.criados +
           ' criado(s) — ' + r.total + ' na tabela. Agora rode Reclassificar a base.');
    await abrir('config', paramsAtual);
  } catch (e) { avisar(e.message || e, true); }
}

function confirmarReclassificar() {
  abrirJanela('Reclassificar a base', `
    <p style="margin:0 0 14px;line-height:1.7;color:var(--tinta-media)">
      Reaplica o DE-PARA atual em toda a folha já importada e refaz o painel de cada
      competência. Use depois de corrigir uma categoria. Pode demorar alguns minutos se
      houver muitos meses importados — não feche a página.
    </p>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('reclassificar',{},'Base reclassificada')">Reclassificar</button>`);
}

/* ================= PESSOAS E ACESSOS =================
   Uma tela so. Antes eram duas — o cartão “Equipe” da Configuracao (com
   o botão “Nova pessoa”) e a tela “Acessos” (com “Novo usuario”) — para
   as MESMAS pessoas, em dois cadastros que nao conversavam. Dava para
   ter o Gerente cadastrado como COORDENADOR e ninguem percebia.
   ==================================================== */
let ABA_PESSOAS = 'pessoas';   // pessoas | ajustes | niveis

/*
 * AS TRES FAIXAS DE CADA MENU (8.12). Oculto: o menu nao existe para a
 * pessoa. Ver: abre e le tudo (exportar inclusive), sem gravar. Ver e editar:
 * grava tudo o que a tela oferece. O nivel da a faixa de cada menu (aba
 * Niveis de acesso); o ajuste da pessoa, se houver, vale por cima (aba
 * Ajustes por pessoa). Antes de tudo vale o painel na filial.
 */
const NOME_FAIXA = { OCULTO: 'Oculto', VER: 'Ver', EDITAR: 'Ver e editar' };
const FAIXAS = ['OCULTO', 'VER', 'EDITAR'];
const NOME_ESCOPO = { TODOS: 'Operação inteira', TURNO: 'O próprio turno', PROPRIAS: 'Somente as suas' };
const seloFaixa = (f, extra) => `<span class="nv-selo nv-${String(f || 'OCULTO').toLowerCase()}">${esc(NOME_FAIXA[f] || 'Oculto')}${extra || ''}</span>`;

function pintarAcessos(r) { pintarPessoas(r); }

function pintarPessoas(r) {
  const d = r.dados;
  const ed = podeEditar('acessos');
  const semNivel = (d.pessoas || []).filter((p) => p.semNivel && p.ativo !== false).length;
  el('subtitulo-pagina').textContent = semNivel
    ? `${semNivel} pessoa(s) sem nível de acesso definido`
    : 'Quem entra no sistema, em quais filiais, e o que cada nível vê em cada menu';
  el('acoes-topo').innerHTML = ed ? `<button class="botao" onclick="formUsuario()">Cadastrar pessoa</button>` : '';

  const abas = [['pessoas', 'Pessoas'], ['ajustes', 'Ajustes por pessoa'], ['niveis', 'Níveis de acesso']];
  el('pagina').innerHTML = `${ed ? '' : avisoSoVer('Pessoas e acessos')}
    <div class="abas">
      ${abas.map(([id, nome]) => `<button class="aba ${ABA_PESSOAS === id ? 'ativa' : ''}" data-aba="${id}"
        onclick="trocarAbaPessoas(${jsArg(id)})">${nome}</button>`).join('')}
    </div>
    <div id="conteudo-pessoas"></div>`;
  pintarAbaPessoas(d);
}

function trocarAbaPessoas(aba) {
  ABA_PESSOAS = aba;
  document.querySelectorAll('.abas .aba').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === aba));
  pintarAbaPessoas(DADOS);
}

function pintarAbaPessoas(d) {
  const alvo = el('conteudo-pessoas');
  if (!alvo) return;
  alvo.innerHTML = ABA_PESSOAS === 'niveis' ? blocoNiveis(d)
    : ABA_PESSOAS === 'ajustes' ? blocoAjustesPessoas(d) : blocoPessoas(d);
}

/* Os menus, um por linha, agrupados por modulo (o servidor manda a ordem). */
const linhasDeMenus = (d, linha) => (d.modulos || []).map((m) => `
  <tr class="nv-grupo"><th colspan="99">${esc(m.nome)}</th></tr>
  ${m.telas.map((t) => linha(t, m)).join('')}`).join('');

/* A faixa que fica valendo para a pessoa num menu: o ajuste dela, senao o nivel (com a trava do ADMIN). */
function faixaDaPessoa(p, idTela) {
  if (p.perfil === 'ADMIN' && idTela === 'acessos') return 'EDITAR';
  return (p.ajustes || {})[idTela] || (p.doNivel || {})[idTela] || 'OCULTO';
}

/* --- Aba "Ajustes por pessoa": quem tem ajuste e onde, ao lado do nivel --- */
function blocoAjustesPessoas(d) {
  const ed = podeEditar('acessos');
  const ativos = (d.pessoas || []).filter((p) => p.ativo && !p.semNivel);
  const nomeTela = {};
  (d.telas || []).forEach((t) => { nomeTela[t.id] = t.nome; });
  return `
    <div class="cartao">
      <div class="cartao-titulo linha-titulo"><span>Ajuste desta pessoa — por cima do nível</span>
        <span class="campo-busca"><input id="busca-ajpes" placeholder="Buscar pessoa" oninput="filtrarAjustesPessoas()"></span></div>
      <p class="dica" style="margin:-4px 0 12px">O ponto de partida é o <b>nível</b> da pessoa (aba Níveis de acesso).
        Aqui você muda um menu só para ela, sem mexer no nível: <b>Oculto</b>, <b>Ver</b> ou <b>Ver e editar</b>.
        <b>Igual ao nível</b> tira o ajuste. Vale na hora, também para quem já está dentro.</p>
      <div class="pn-tabela-rolagem"><table id="tabela-ajpes">
        <thead><tr><th>Pessoa</th><th>Nível</th><th>Ajustes desta pessoa</th><th></th></tr></thead>
        <tbody>${ativos.map((p) => {
          const ajustes = Object.keys(p.ajustes || {});
          return `<tr data-busca="${esc((p.nome + ' ' + p.email + ' ' + p.perfil).toLowerCase())}" data-email="${esc(p.email)}">
          <td><strong>${esc(p.nome || p.email)}</strong><div class="lp-sub">${esc(p.email)}${p.turno ? ' · turno ' + esc(p.turno) : ''}</div></td>
          <td><span class="selo-entrega">${esc(p.perfil)}</span></td>
          <td>${ajustes.length ? ajustes.map((t) => `<span class="nv-ajuste">${esc(nomeTela[t] || t)}: ${seloFaixa(p.ajustes[t])}
              <span class="lp-sub">(nível: ${esc(NOME_FAIXA[(p.doNivel || {})[t]] || 'Oculto')})</span></span>`).join(' ')
            : '<span class="lp-sub">Igual ao nível em todos os menus</span>'}</td>
          <td><button class="icone-botao" onclick="janelaAjustes(${jsArg(p.id)})">${ed ? 'Ajustar' : 'Ver por menu'}</button></td>
        </tr>`;
        }).join('') || '<tr><td colspan="4" class="vazio">Ninguém cadastrado ainda.</td></tr>'}</tbody>
      </table></div>
      <p class="dica">Antes do nível e do ajuste vale o painel na filial (Configuração › Filiais e painéis):
        painel <b>Desativado</b> ou <b>Não usar nesta filial</b> some para todos; <b>Oculto</b>, só o administrador vê.</p>
    </div>`;
}

function filtrarAjustesPessoas() {
  const t = String(val('busca-ajpes') || '').toLowerCase().trim();
  document.querySelectorAll('#tabela-ajpes tbody tr').forEach((tr) => {
    tr.style.display = (!t || (tr.dataset.busca || '').indexOf(t) !== -1) ? '' : 'none';
  });
}

/*
 * A grade de UMA pessoa: menu · do nivel · ajuste desta pessoa · fica valendo.
 * imediato: cada troca grava na hora (definirAjustePessoa); senao os
 * seletores sao lidos no Salvar do cadastro (salvarUsuario).
 */
function gradeDaPessoa(d, p, imediato) {
  const ed = podeEditar('acessos');
  const soDoAdmin = d.soDoAdmin || [];
  const linha = (t) => {
    const travada = p.perfil === 'ADMIN' && t.id === 'acessos';
    const presa = travada || !ed || soDoAdmin.indexOf(t.id) !== -1 || (p.perfil === 'ADMIN' && !d.souAdmin);
    const atual = (p.ajustes || {})[t.id] || '';
    const doNivel = (p.doNivel || {})[t.id] || 'OCULTO';
    const titulo = travada ? 'No nível ADMIN, Pessoas e acessos é sempre “Ver e editar” — assim ninguém se tranca do lado de fora.'
      : (soDoAdmin.indexOf(t.id) !== -1 || (p.perfil === 'ADMIN' && !d.souAdmin)) ? 'Só um administrador muda este acesso.' : '';
    return `<tr>
      <td>${esc(t.nome)}</td>
      <td>${seloFaixa(doNivel)}</td>
      <td>${presa ? `<span title="${esc(titulo)}">${atual ? seloFaixa(atual) : '<span class="lp-sub">Igual ao nível</span>'}${travada ? ' <span class="nv-trava">&#128274; trava do ADMIN</span>' : ''}</span>`
        : `<select class="aj-celula" data-tela="${esc(t.id)}" aria-label="Ajuste de ${esc(p.nome || p.email)} em ${esc(t.nome)}"
            ${imediato ? `onchange="agir('definirAjustePessoa',{id:${jsArg(p.id)},tela:${jsArg(t.id)},nivel:this.value},${jsArg('Acesso de ' + (p.nome || p.email) + ' atualizado')}).catch(()=>{})"` : 'onchange="previaAjuste(this)"'}>
            <option value="PADRAO" ${!atual ? 'selected' : ''}>Igual ao nível</option>
            ${FAIXAS.map((f) => `<option value="${f}" ${atual === f ? 'selected' : ''}>${NOME_FAIXA[f]}</option>`).join('')}
          </select>`}</td>
      <td class="aj-fica" data-nivel="${esc(doNivel)}">${seloFaixa(faixaDaPessoa(p, t.id))}</td>
    </tr>`;
  };
  return `<div class="pn-tabela-rolagem"><table class="nv-tabela aj-tabela">
    <thead><tr><th>Menu</th><th>Do nível ${esc(p.perfil || '')}</th><th>Ajuste desta pessoa</th><th>Fica valendo</th></tr></thead>
    <tbody>${linhasDeMenus(d, linha)}</tbody></table></div>`;
}

/* No cadastro (antes do Salvar), a coluna "Fica valendo" acompanha o seletor. */
function previaAjuste(sel) {
  const td = sel.closest('tr') && sel.closest('tr').querySelector('.aj-fica');
  if (td) td.innerHTML = seloFaixa(sel.value === 'PADRAO' ? td.dataset.nivel : sel.value);
}

function janelaAjustes(id) {
  const d = DADOS;
  const p = (d.pessoas || []).find((x) => x.id === id);
  if (!p) return;
  abrirJanela('Acesso de ' + (p.nome || p.email), `
    <p class="dica" style="margin:0 0 12px">Nível <b>${esc(p.perfil)}</b>. ${podeEditar('acessos')
      ? 'Cada troca vale na hora. <b>Igual ao nível</b> tira o ajuste desta pessoa naquele menu.'
      : 'Seu acesso a Pessoas e acessos é só para ver.'}</p>
    ${gradeDaPessoa(d, p, true)}`, `<button class="botao" onclick="fecharJanela()">Fechar</button>`);
}

/* Texto curto das filiais de uma pessoa: vazio = só a principal. */
function filiaisDaPessoa(p, d) {
  if (p.perfil === 'ADMIN') return 'Todas';
  const t = String(p.filiais || '').trim();
  if (!t) {
    const pr = (d.filiais || []).find((f) => f.principal);
    return pr ? pr.codigo : '—';
  }
  if (t === '*' || t === 'TODAS') return 'Todas';
  if (t === 'NENHUMA') return 'Nenhuma';
  return t.split(',').join(' · ');
}

function blocoPessoas(d) {
  const ed = podeEditar('acessos');
  const situacao = (p) => {
    if (!p.ativo) return '<span class="etiqueta cancelada">desativado</span>';
    if (p.semNivel) return '<span class="etiqueta aguardando">sem nível</span>';
    return '<span class="etiqueta aprovada">ativo</span>';
  };
  const variasFiliais = (d.filiais || []).length > 1;

  return `
    <div class="cartao">
      <div class="cartao-titulo linha-titulo">
        <span>${(d.pessoas || []).length} pessoa(s) no cadastro</span>
        <span class="campo-busca">
          <input id="busca-pessoa" placeholder="Buscar nome, e-mail, turno ou filial" oninput="filtrarPessoas()"></span>
      </div>
      <p class="dica" style="margin:-4px 0 12px">Não existe mais pedido de acesso: o Google já barra quem é
         de fora da Bartofil, e quem está aqui entra direto com a conta dele. Para liberar alguém,
         <b>Cadastrar pessoa</b>.</p>
      <div style="overflow-x:auto"><table id="tabela-pessoas">
        <thead><tr><th>Pessoa</th><th>E-mail</th><th>Turno</th>
          ${variasFiliais ? '<th>Filiais</th>' : ''}<th>Nível</th><th>Situação</th><th>PIN</th><th></th></tr></thead>
        <tbody>${(d.pessoas || []).map((p) => `<tr
            data-busca="${esc((p.nome + ' ' + p.email + ' ' + p.turno + ' ' + p.perfil + ' ' + filiaisDaPessoa(p, d)).toLowerCase())}">
          <td><div class="pessoa-celula"><span class="pessoa-iniciais" aria-hidden="true">${esc(iniciaisPessoa(p.nome || p.email))}</span>
            <span><strong>${esc(p.nome || '—')}</strong><span class="lp-sub">${esc(p.papel || '—')}</span></span></div></td>
          <td class="mono">${esc(p.email)}</td>
          <td>${p.turno ? '<strong>' + esc(p.turno) + '</strong>' : '<span class="pendente-entrega">sem turno</span>'}</td>
          ${variasFiliais ? `<td>${esc(filiaisDaPessoa(p, d))}</td>` : ''}
          <td>${p.semNivel ? '—' : `<span class="selo-entrega">${esc(p.perfil)}</span>${Object.keys(p.ajustes || {}).length
            ? ` <span class="lp-sub" title="Esta pessoa tem ajuste em algum menu (aba Ajustes por pessoa)">+ ajuste</span>` : ''}`}</td>
          <td>${situacao(p)}</td>
          <td>${p.temPin ? '<span class="selo-entrega">criado</span>' : '<span class="pendente-entrega">cria no 1º acesso</span>'}</td>
          <td>${ed ? `<button class="icone-botao" onclick="formUsuario(${jsArg(p.id)})">Editar</button>
              ${p.email !== d.eu ? `<button class="icone-botao" title="${p.temPin
                  ? 'Apaga o PIN e gera um código para a pessoa criar outro'
                  : 'Gera um código para a pessoa criar o PIN sem precisar do e-mail'}"
                onclick="gerarCodigoAcesso(${jsArg(p.id)}, ${jsArg(p.nome || p.email)}, ${p.temPin ? 'true' : 'false'})">${p.temPin ? 'Zerar PIN' : 'Código de acesso'}</button>` : ''}
              ${p.email === d.eu ? '' :
                `<button class="icone-botao" onclick="agir('alternarAtivo',{id:${jsArg(p.id)}},'Acesso alterado')">${p.ativo ? 'Desativar' : 'Reativar'}</button>`}` : ''}</td>
        </tr>`).join('') || '<tr><td colspan="8" class="vazio">Ninguém cadastrado ainda.</td></tr>'}</tbody></table></div>
      <p class="dica">O <b>turno</b> liga a pessoa às atividades: o coordenador do turno A recebe
         o digesto do A e aparece como responsável nas atividades do A — dentro de cada filial.</p>
    </div>`;
}

/* As iniciais da tabela de pessoas (aceita o e-mail no lugar do nome): "Maria Souza" -> "MS", "joao.lima@..." -> "JL". */
function iniciaisPessoa(nome) {
  const partes = String(nome || '').replace(/@.*$/, '').split(/[\s.]+/).filter(Boolean);
  return ((partes[0] || '?')[0] + (partes.length > 1 ? partes[partes.length - 1][0] : '')).toUpperCase();
}

function filtrarPessoas() {
  const t = String(val('busca-pessoa') || '').toLowerCase().trim();
  document.querySelectorAll('#tabela-pessoas tbody tr').forEach((tr) => {
    tr.style.display = (!t || (tr.dataset.busca || '').indexOf(t) !== -1) ? '' : 'none';
  });
}

function formUsuario(id) {
  const d = DADOS;
  const u = id ? (d.pessoas || []).find((x) => x.id === id) : null;
  const filiais = d.filiais || [];
  const atuais = u ? String(u.filiais || '').split(',').filter(Boolean) : [];
  const todas = u ? (u.filiais === '*' || u.filiais === 'TODAS') : false;
  const principal = (filiais.find((f) => f.principal) || {}).codigo;
  const marcadaFilial = (f) => todas || atuais.indexOf(f.codigo) !== -1 || (!atuais.length && !todas && f.codigo === principal);
  // O nivel escolhido no seletor: a coluna "Do nivel" da grade de ajuste e a do nivel que esta marcado.
  const nivelDe = (perfil) => ((d.perfis || []).find((x) => x.perfil === perfil) || {}).niveis || {};
  const perfilInicial = u ? u.perfil : 'COORDENADOR';
  const pessoaGrade = Object.assign({ perfil: perfilInicial, ajustes: {}, nome: '' }, u || {}, { doNivel: nivelDe(perfilInicial) });

  abrirJanela(u ? ('Editar ' + (u.nome || u.email)) : 'Cadastrar pessoa', `
    ${u ? '' : `<p class="dica" style="margin:0 0 14px">A pessoa entra direto com a conta Google dela —
       não precisa pedir nada nem criar senha. Ela recebe um e-mail avisando que o acesso foi liberado.</p>`}
    <div class="campo-duplo">
      <div class="campo"><label>Nome completo</label>
        <input id="u-nome" value="${esc(u ? u.nome : '')}" placeholder="Como deve aparecer no sistema"></div>
      <div class="campo"><label>Função</label>
        <input id="u-papel" value="${esc(u ? u.papel : '')}" placeholder="Ex.: Coordenador · Turno A"></div>
    </div>
    <div class="campo"><label>E-mail</label>
      <input id="u-email" type="email" value="${esc(u ? u.email : '')}" placeholder="nome@bartofil.com.br"
        ${u ? 'readonly' : ''}></div>
    <div class="campo-duplo">
      <div class="campo"><label>Nível de acesso</label>
        <select id="u-perfil" onchange="trocarNivelDoForm(this.value)">
          ${(d.niveis || []).map((n) => `<option ${n === perfilInicial ? 'selected' : ''}>${esc(n)}</option>`).join('')}
        </select></div>
      <div class="campo"><label>Turno</label>
        <select id="u-turno"><option value="">—</option>
          ${(d.turnos || []).map((t) => `<option ${u && u.turno === t ? 'selected' : ''}>${esc(t)}</option>`).join('')}
        </select></div>
    </div>
    ${filiais.length > 1 ? `
    <div class="campo"><label>Filiais que esta pessoa vê</label>
      <div class="lista-marcadores">
        <label class="marcador"><input type="checkbox" id="u-todas" ${todas ? 'checked' : ''}
          onchange="document.querySelectorAll('.u-filial').forEach((c) => { c.disabled = this.checked; })"> Todas as filiais (inclusive as que forem criadas depois)</label>
        ${filiais.map((f) => `<label class="marcador"><input type="checkbox" class="u-filial" value="${esc(f.codigo)}"
          ${marcadaFilial(f) ? 'checked' : ''} ${todas ? 'disabled' : ''}> ${esc(f.nome)} <span class="mono">${esc(f.codigo)}</span>${f.ativa ? '' : ' (desligada)'}</label>`).join('')}
      </div>
      <p class="dica">O nível ADMIN vê todas as filiais sempre.</p>
    </div>` : ''}
    <div class="campo"><label>Acesso por menu — ajuste desta pessoa</label>
      <p class="dica" style="margin:0 0 8px">“Igual ao nível” segue o nível escolhido acima. As outras opções valem só para esta pessoa.</p>
      <div id="u-grade">${gradeDaPessoa(d, pessoaGrade, false)}</div>
    </div>
    <label class="marcador"><input type="checkbox" id="u-ativo" ${!u || u.ativo ? 'checked' : ''}> Acesso liberado</label>`, `
    ${u && u.email !== d.eu ? `<button class="botao perigo" onclick="agir('excluirUsuario',{id:${jsArg(id)},email:${jsArg(u.email)}},'Pessoa removida')">Remover</button>` : ''}
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="salvarUsuario(${jsArg(id || '')})">Salvar</button>`);
}

/* Trocou o nivel no cadastro: a coluna "Do nivel" e o "Fica valendo" passam a ser do nivel novo (os ajustes escolhidos ficam). */
function trocarNivelDoForm(perfil) {
  const n = ((DADOS.perfis || []).find((x) => x.perfil === perfil) || {}).niveis || {};
  document.querySelectorAll('#u-grade tbody tr').forEach((tr) => {
    const sel = tr.querySelector('.aj-celula'), fica = tr.querySelector('.aj-fica');
    if (!sel || !fica) return;
    const doNivel = (perfil === 'ADMIN' && sel.dataset.tela === 'acessos') ? 'EDITAR' : (n[sel.dataset.tela] || 'OCULTO');
    fica.dataset.nivel = doNivel;
    tr.children[1].innerHTML = seloFaixa(doNivel);
    previaAjuste(sel);
  });
}

function salvarUsuario(id) {
  let filiais = '';
  if (el('u-todas')) {
    if (marcado('u-todas')) filiais = '*';
    else {
      filiais = [...document.querySelectorAll('.u-filial')].filter((c) => c.checked).map((c) => c.value).join(',');
      if (!filiais) return avisar('Marque pelo menos uma filial.', true);
    }
  }
  const params = { id: id, nome: val('u-nome'), papel: val('u-papel'), email: val('u-email'),
    perfil: val('u-perfil'), turno: val('u-turno'), ativo: marcado('u-ativo') };
  if (el('u-todas')) params.filiais = filiais;
  else if (id) params.filiais = ((DADOS.pessoas || []).find((x) => x.id === id) || {}).filiais || '';
  // So os menus que tem seletor (a tela nao manda o que nao pode mudar): "Igual ao nivel" vai como PADRAO.
  const seletores = document.querySelectorAll('#u-grade .aj-celula');
  if (seletores.length) {
    params.ajustes = {};
    seletores.forEach((s) => { params.ajustes[s.dataset.tela] = s.value; });
  }
  agir('salvarUsuario', params, 'Pessoa salva').catch(() => {});
}

/*
 * --- A MATRIZ: menus (linhas, agrupados por modulo) x niveis (colunas) ---
 * Cada celula e um seletor de tres opcoes; a troca vale na hora, inclusive
 * para quem ja esta dentro (o menu dele acompanha no proximo clique).
 */
function blocoNiveis(d) {
  const ed = podeEditar('acessos');
  const soDoAdmin = d.soDoAdmin || [];
  const perfis = d.perfis || [];
  const celula = (p, t) => {
    const f = (p.niveis || {})[t.id] || 'OCULTO';
    const trava = (p.travas || {})[t.id];
    const soAdmin = (p.perfil === 'ADMIN' && !d.souAdmin) || soDoAdmin.indexOf(t.id) !== -1;
    if (trava) return `<td class="nv-cel"><span class="nv-fixa" title="${esc(trava)}">${seloFaixa(f, ' &#128274;')}</span></td>`;
    if (!ed || soAdmin) {
      return `<td class="nv-cel"><span title="${soAdmin && ed ? 'Só um administrador muda esta célula.' : ''}">${seloFaixa(f)}</span></td>`;
    }
    return `<td class="nv-cel"><select class="nv-celula nv-${f.toLowerCase()}" data-perfil="${esc(p.perfil)}" data-tela="${esc(t.id)}"
        aria-label="${esc(p.perfil)} em ${esc(t.nome)}"
        onchange="agir('alterarPermissao',{id:${jsArg(p.id)},coluna:${jsArg('TELA_' + t.id.toUpperCase())},valor:this.value},${jsArg(p.perfil + ': ' + t.nome + ' atualizado')}).catch(()=>{})">
        ${FAIXAS.map((x) => `<option value="${x}" ${x === f ? 'selected' : ''}>${NOME_FAIXA[x]}</option>`).join('')}</select></td>`;
  };
  const linha = (t) => `<tr data-tela="${esc(t.id)}"><td class="nv-menu">${esc(t.nome)}${t.soLeitura
      ? ' <span class="lp-sub" title="Esta tela não tem gravação: Ver e Ver e editar dão o mesmo">só leitura</span>' : ''}</td>
    ${perfis.map((p) => celula(p, t)).join('')}</tr>`;
  const alcance = (p) => {
    const soAdmin = p.perfil === 'ADMIN' && !d.souAdmin;
    if (!ed || soAdmin) return `<td class="nv-cel">${esc(NOME_ESCOPO[p.escopo] || p.escopo)}</td>`;
    return `<td class="nv-cel"><select class="nv-escopo" data-perfil="${esc(p.perfil)}"
      onchange="agir('alterarPermissao',{id:${jsArg(p.id)},coluna:'ESCOPO',valor:this.value},${jsArg('Alcance de ' + p.perfil + ' atualizado')}).catch(()=>{})">
      ${(d.escopos || ['TODOS', 'TURNO', 'PROPRIAS']).map((e) => `<option value="${e}" ${p.escopo === e ? 'selected' : ''}>${NOME_ESCOPO[e] || e}</option>`).join('')}
      </select></td>`;
  };
  return `
    <div class="cartao">
      <div class="cartao-titulo linha-titulo"><span>Níveis de acesso — o que cada nível vê em cada menu</span>
        ${ed && d.souAdmin ? '<button class="icone-botao" onclick="restaurarPerfis()">Restaurar o padrão</button>' : ''}</div>
      <p class="dica" style="margin:-4px 0 12px">Cada menu tem três faixas:
        <b>Oculto</b> — o menu não existe para o nível (sem cartão, sem item, sem link);
        <b>Ver</b> — abre e lê tudo o que a tela mostra, exportar inclusive, sem gravar nada;
        <b>Ver e editar</b> — grava tudo o que a tela oferece.
        Vale na hora, também para quem já está dentro. O <b>alcance</b> decide quanto dado o nível enxerga.</p>
      <div class="pn-tabela-rolagem"><table class="nv-tabela" id="tabela-niveis">
        <thead><tr><th>Menu</th>${perfis.map((p) => `<th class="nv-cel"><strong>${esc(p.perfil)}</strong>
          <div class="meta-atividade">${esc(p.descricao || '')}</div></th>`).join('')}</tr></thead>
        <tbody>
          <tr class="nv-alcance"><td class="nv-menu"><b>Alcance</b></td>${perfis.map(alcance).join('')}</tr>
          ${linhasDeMenus(d, linha)}
        </tbody></table></div>
      <p class="dica">A ordem é sempre esta: primeiro o <b>painel na filial</b> (Configuração › Filiais e painéis —
        Desativado ou Não usar nesta filial some para todos; Oculto, só o administrador vê), depois o <b>ajuste da pessoa</b>
        (aba Ajustes por pessoa), senão a <b>faixa do nível</b> aqui. No nível ADMIN, Pessoas e acessos é sempre
        Ver e editar (&#128274;), para ninguém se trancar do lado de fora.
        No Plano de Ação (do Calendário e da Limpeza) cada pessoa vê só as ações em que está citada, qualquer que seja o nível.</p>
    </div>`;
}


/* ================= PECAS ================= */
/*
 * APRESENTACAO — modo reuniao.
 *
 * Mesmo conteudo do briefing que a planilha manda por e-mail na vespera:
 * quadro por turno, atrasos a cobrar, fila de validacao e a leitura dos
 * dados. Aqui em tela cheia, para projetar na reuniao de sexta.
 */
function pintarApresentacao(r) {
  const d = r.dados, g = d.geral;
  el('subtitulo-pagina').textContent = 'Semana de ' + d.semana.inicio + ' a ' + d.semana.fim;
  el('acoes-topo').innerHTML = '';

  const lista = (itens, sobra) => itens.length ? `
    <div>${itens.map((a) => `
      <div class="linha-atividade">
        <div class="texto-atividade">
          <div class="nome-atividade">${esc(a.atividade)}</div>
          <div class="meta-atividade">Turno ${esc(a.turno)} \u00b7 prazo ${esc(a.prazo || '—')}</div>
        </div>${etiqueta(a.status)}
      </div>`).join('')}
      ${sobra ? `<div class="vazio">\u2026 e mais ${sobra}</div>` : ''}
    </div>` : '<div class="vazio">Nada por aqui.</div>';

  el('pagina').innerHTML = `
    <div class="cartao" style="margin-bottom:16px">
      <div class="cartao-titulo">Apresentações da reunião</div>
      <div class="cartoes-apresentacao">
        ${(d.apresentacoes || []).map((a) => a.link
          ? `<button class="card-apres turno-${esc(a.turno)}" onclick="window.open(${jsArg(a.link)},'_blank')">
               <div class="card-capa">
                 ${a.miniatura
                    ? `<img src="${esc(a.miniatura)}" alt="Capa da apresentacao do turno ${esc(a.turno)}">`
                    : `<div class="capa-vazia"><span>${esc(a.turno)}</span></div>`}
                 <span class="card-selo">${esc(a.turno)}</span>
               </div>
               <div class="card-pe">
                 <strong>${esc(a.titulo || ('Apresentacao — Turno ' + a.turno))}</strong>
                 <small>Toque para abrir \u2192</small>
               </div>
             </button>`
          : `<button class="card-apres sem-link" onclick="avisar(${jsArg(`Cadastre o link da apresentação do turno ${a.turno} em Configuração.`)}, true)">
               <div class="card-capa"><div class="capa-vazia"><span>${esc(a.turno)}</span></div></div>
               <div class="card-pe">
                 <strong>Turno ${esc(a.turno)} — sem link</strong>
                 <small>cadastre em Configuração</small>
               </div>
             </button>`).join('')}
      </div>
    </div>

    <div class="grade grade-kpi">
      ${kpi(g.total, 'Programadas', 'azul')}
      ${kpi(g.aprovadas, 'Aprovadas', 'verde')}
      ${kpi(g.atrasadas, 'Atrasadas', 'vermelho')}
      ${kpi(g.percentual + '%', 'Conclusao', 'amarelo')}
    </div>

    <div class="cartao" style="margin-top:18px">
      <div class="cartao-titulo">Desempenho por turno</div>
      <table><thead><tr><th>Turno</th><th class="numero">Total</th><th class="numero">Aprov.</th>
        <th class="numero">Atrás.</th><th class="numero">%</th></tr></thead><tbody>
        ${d.porTurno.map((t) => `<tr><td><strong>${esc(t.turno)}</strong></td>
          <td class="numero">${t.total}</td><td class="numero">${t.aprovadas}</td>
          <td class="numero">${t.atrasadas}</td><td class="numero">${t.percentual}%</td></tr>`).join('')}
      </tbody></table>
    </div>

    <div class="grade grade-dupla" style="margin-top:18px">
      <div class="cartao">
        <div class="cartao-titulo">Atrasos a cobrar (${d.atrasadas.length + d.maisAtrasadas})</div>
        ${lista(d.atrasadas, d.maisAtrasadas)}
      </div>
      <div class="cartao">
        <div class="cartao-titulo">Aguardando validacao (${d.aguardando.length + d.maisAguardando})</div>
        ${lista(d.aguardando, d.maisAguardando)}
      </div>
    </div>

    ${d.insights.length ? `
    <div class="cartao" style="margin-top:18px">
      <div class="cartao-titulo">O que os dados estão dizendo</div>
      ${d.insights.map((i) => `
        <div class="insight ${esc(i.nivel || '')}">
          <div class="insight-texto">${esc(i.texto)}</div>
          ${i.recomendacao ? `<div class="insight-rec">${esc(i.recomendacao)}</div>` : ''}
        </div>`).join('')}
    </div>` : ''}`;
}

let filtroAtivo = null;
let filtroTurno = null;     // 'A' | 'B' | 'C' | ... | null = todos

/*
 * FILTRO POR TURNO — pedido de reuniao.
 *
 * Roda INTEIRO no navegador: os turnos ja vieram junto com as
 * atividades, entao filtrar nao custa nenhuma ida ao servidor (que
 * custa de 1 a 3 segundos por chamada). Trocar de turno e instantaneo.
 *
 * Pastilha com fundo e contagem, nao link discreto: "olhou, viu".
 */
function tiraDeTurnos(atividades) {
  const lista = atividades || [];
  if (!lista.length) return '';

  const contagem = {};
  lista.forEach((a) => {
    const t = String(a.turno || 'Todos');
    contagem[t] = (contagem[t] || 0) + 1;
  });

  const turnos = Object.keys(contagem).sort();
  if (turnos.length < 2) return '';   // um turno so: a tira nao serve para nada

  const pastilha = (chave, rotulo, n) => `
    <button class="pastilha-turno ${filtroTurno === chave ? 'ativa' : ''}"
            data-turno-filtro="${esc(chave)}" onclick="alternarTurno(${chave === null ? 'null' : jsArg(chave)})">
      ${esc(rotulo)}<span class="pastilha-conta">${n}</span></button>`;

  return `
    <div class="tira-turnos">
      <span class="tira-rotulo">Turno</span>
      ${pastilha(null, 'Todos', lista.length)}
      ${turnos.map((t) => pastilha(t, t === 'Todos' ? 'Geral' : 'Turno ' + t, contagem[t])).join('')}
    </div>`;
}

function alternarTurno(turno) {
  filtroTurno = (filtroTurno === turno) ? null : turno;
  document.querySelectorAll('.pastilha-turno').forEach((b) => {
    const meu = b.dataset.turnoFiltro || '';
    b.classList.toggle('ativa', (filtroTurno === null && meu === '') || meu === filtroTurno);
  });
  aplicarFiltro();
}

// KPI clicavel: ao tocar, ilumina as atividades daquele status no calendario
// e na tabela; tocar de novo desliga. E o filtro pedido.
const kpiFiltro = (valor, rotulo, cor, chave) => `<div class="cartao kpi ${cor} kpi-clicavel"
  data-filtro="${chave}" onclick="alternarFiltro(${jsArg(chave)})">
  <div class="kpi-valor">${esc(valor)}</div><div class="kpi-rotulo">${esc(rotulo)}</div></div>`;

function alternarFiltro(chave) {
  filtroAtivo = (filtroAtivo === chave || chave === 'todas') ? null : chave;
  aplicarFiltro();
}

/*
 * Os DOIS filtros valem ao mesmo tempo: "atrasadas do turno B" e uma
 * pergunta que a gestao faz toda semana. Antes o filtro de status
 * mandava sozinho; agora quem nao passa nos dois fica de fora.
 */
function aplicarFiltro() {
  const pagina = el('pagina');
  document.querySelectorAll('.kpi-clicavel').forEach((k) =>
    k.classList.toggle('kpi-ativo', k.dataset.filtro === filtroAtivo));

  const casaTurno = (elemento) => {
    if (!filtroTurno) return true;
    return String(elemento.dataset.turno || '') === filtroTurno;
  };

  if (!filtroAtivo && !filtroTurno) {
    pagina.classList.remove('filtrando');
    document.querySelectorAll('.pilula.destacada').forEach((p) => p.classList.remove('destacada'));
    document.querySelectorAll('.dia.tem-destaque').forEach((d) => d.classList.remove('tem-destaque'));
    document.querySelectorAll('.tabela-gestao tr.apagada').forEach((r) => r.classList.remove('apagada'));
    return;
  }
  pagina.classList.add('filtrando');

  document.querySelectorAll('.dia.tem-destaque').forEach((d) => d.classList.remove('tem-destaque'));

  // calendario: destaca a pilula que passa nos dois filtros
  document.querySelectorAll('.grade-mes .pilula').forEach((p) => {
    const bate = (!filtroAtivo || p.classList.contains(filtroAtivo)) && casaTurno(p);
    p.classList.toggle('destacada', bate);
    if (bate) { const dia = p.closest('.dia'); if (dia) dia.classList.add('tem-destaque'); }
  });

  // tabela: apaga as linhas que nao batem
  document.querySelectorAll('.tabela-gestao tbody tr').forEach((r) => {
    const et = r.querySelector('.etiqueta');
    const statusOk = !filtroAtivo || (et && et.classList.contains(filtroAtivo));
    r.classList.toggle('apagada', !(statusOk && casaTurno(r)));
  });
}

const kpi = (valor, rotulo, cor) => `<div class="cartao kpi ${cor}">
  <div class="kpi-valor">${esc(valor)}</div><div class="kpi-rotulo">${esc(rotulo)}</div></div>`;

function barra(rotulo, texto, maximo, numero, cor) {
  const n = (numero === undefined) ? Number(texto) : Number(numero);
  const larg = maximo ? Math.max(1, Math.round(n / maximo * 100)) : 0;
  return `<div class="barra-linha">
    <div class="barra-rotulo">${esc(rotulo)}</div>
    <div class="barra-trilho"><div class="barra-preenchida ${cor || ''}" style="width:${larg}%"></div></div>
    <div class="barra-valor">${esc(texto)}</div></div>`;
}

/* ================= PLANO DE AÇÃO =================
   As ações que saem da reunião de turno. O papel do gerente virou tela:

     Ação: Iluminação do Flow — Verificar e acompanhar a iluminação para
     garantir que todas as lâmpadas foram trocadas
     Responsável Hércules — Entregar até dia 25/09

   Quem cria é o gerente. O coordenador conclui as que são dele — não há
   validação, foi o combinado: concluiu, acabou.

   QUEM VÊ (21/10): cada ação aparece só para quem está citado nela — os
   responsáveis e quem foi marcado num comentário. A gestão, o administrador
   e a consulta também: nenhum deles vê a ação em que não está citado (a
   lista já vem filtrada do servidor). Ver acoesNoAlcance, no Acoes.gs.

   DOIS PLANOS, O MESMO DESENHO (4.2.2). O Plano de Ação da Limpeza CD é
   este mesmo, desenhado pelas mesmas funções: PLANO diz qual está na tela
   (de onde vem o dado e que ação do servidor chamar). Os nomes das ações
   vão "assados" no HTML de cada botão — uma janela aberta continua
   falando com o plano em que foi aberta.
   ================================================= */

/*
 * 8.13 — SITUACOES E PARECER DO GERENTE. O plano ganhou o modelo do
 * "Relatorio de Ocorrencias e Acoes" do gerente: cada cartao e uma
 * SITUACAO (titulo, prioridade, descricao em texto rico, fotos com legenda)
 * que o gerente destinatario decide: Tratar / Incluir acao (como sera
 * tratado, responsaveis e prazo — vira acao, com comentarios e conclusao),
 * Outro momento ou Nada a fazer. Os filtros (parecer, situacao, prioridade,
 * turno, busca) sao feitos aqui, nos dois planos: o servidor manda tudo o
 * que a pessoa ve (so o que a cita).
 */
const CAL_FILTRO = { parecer: '', situacao: 'ABERTAS', turno: '', busca: '', zona: '', crit: '', prio: '', ordem: 'urgentes' };
let CAL_FILTRO_DA_TELA = null;           // os parametros da tela que ja foram aplicados no filtro (abrir('acoes', {...}))
const PLANO_CAL = {
  id: 'CALENDARIO',
  dados: () => DADOS,
  acoes: { salvar: 'salvarAcao', concluir: 'concluirAcao', comentar: 'comentarAcao', reabrir: 'reabrirAcao',
           cancelar: 'cancelarAcao', excluir: 'excluirAcao', foto: 'fotoAcao', removerFoto: 'removerFotoAcao',
           situacao: 'salvarSituacao', parecer: 'parecerSituacao' },
  local: CAL_FILTRO,
  filtrar: (m) => { Object.assign(CAL_FILTRO, m); paRepintar(); },
  extras: null,
  nome: 'Plano de Ação'
};
let PLANO = PLANO_CAL;
const planoD = () => PLANO.dados() || {};
const planoAcaoPorId = (id) => (planoD().lista || []).find((x) => x.id === id) || null;
const planoAcao = (nome) => jsArg(PLANO.acoes[nome]);      // nome da ação, pronto para o onclick
const ANDAMENTOS_ACAO = ['Em andamento', 'Aguardando', 'Concluída'];
/* O plano tem o modelo de situacoes (Instalacao.gs desta versao) e a pessoa grava nele. */
const paTemSituacoes = (d) => !!(d && d.modelo && d.modelo.situacoes);

function pintarAcoes(r) {
  PLANO = PLANO_CAL;
  const d = r.dados, p = d.permissoes;
  const c = d.contagens;
  // Os filtros que vieram na tela (link, abrir('acoes', {situacao})) valem uma vez; depois, os da pessoa.
  const chave = JSON.stringify(d.filtro || {});
  if (chave !== CAL_FILTRO_DA_TELA) {
    CAL_FILTRO_DA_TELA = chave;
    const f = d.filtro || {};
    if (paramsAtual && paramsAtual.situacao) CAL_FILTRO.situacao = String(f.situacao || 'TODAS');
    if (f.turno !== undefined) CAL_FILTRO.turno = f.turno || '';
    if (f.busca !== undefined) CAL_FILTRO.busca = f.busca || '';
  }
  el('subtitulo-pagina').textContent =
    `${c.abertas} em aberto · ${c.atrasadas} atrasada(s) · ${c.minhas} sua(s)` + (c.parecer ? ` · ${c.parecer} esperando o seu parecer` : '');
  el('acoes-topo').innerHTML = paBotoesTopo(d);
  el('pagina').innerHTML = (p.editar ? '' : avisoSoVer('Plano de Ação')) + planoHtml(d);
  paDepoisDePintar();
  abrirAcaoDoLink();
}

/* Os botoes do topo do plano: Relatorio (PDF), ação direta e a situação nova (o amarelo). */
function paBotoesTopo(d) {
  const p = d.permissoes || {};
  return `<button class="botao secundario" onclick="paFormRelatorio()">&#128424; Relatório</button>` +
    (p.editar ? `<button class="botao secundario" onclick="formAcao()" title="Já se sabe o que fazer: a ação nasce com responsáveis e prazo, sem esperar parecer">+ Nova ação direta</button>` : '') +
    (p.editar && paTemSituacoes(d) ? `<button class="botao pa-amarelo" onclick="formSituacao()">+ Nova situação</button>` : '');
}

/* Repinta so o plano que esta na tela (o filtro mudou), sem ir ao servidor. */
function paRepintar() {
  if (PLANO === PLANO_CAL) {
    if (paginaAtual !== 'acoes') return;
    el('pagina').innerHTML = ((planoD().permissoes || {}).editar ? '' : avisoSoVer('Plano de Ação')) + planoHtml(planoD());
  } else if (typeof pintarAbaLP === 'function') { pintarAbaLP(DADOS); return; }
  paDepoisDePintar();
}


/*
 * LINK DO E-MAIL DE MENCAO (19/10): ?tela=acoes&acao=ID (ou tela=limpeza)
 * abre o historico daquela acao, uma vez, assim que o plano DESSA tela
 * aparece. A que a pessoa nao ve mais (excluida, de outra filial) vira so o
 * aviso — que nomeia a filial para quem tem mais de uma.
 */
function abrirAcaoDoLink() {
  const x = ACAO_DO_LINK;
  if (!x || x.tela !== paginaAtual) return;
  ACAO_DO_LINK = null;
  const id = x.id;
  const a = planoAcaoPorId(id);
  if (!a) {
    const filial = (SESSAO.filiais || []).length > 1 && SESSAO.filial ? SESSAO.filial.nome : '';
    return avisar(filial ? 'Esta ação não está nesta filial (' + filial + ') ou não está mais disponível para você.'
      : 'Esta ação não está mais disponível para você.', true);
  }
  // Limpeza (o filtro e da tela): a acao concluida nao esta em "Em aberto" — a lista passa a mostrar todas.
  if (PLANO.local && !planoFiltrarLista([a], PLANO.local).length) PLANO.filtrar({ situacao: 'TODAS' });
  abrirComentarios(id, podeComentarAcao(a, planoD().permissoes));
}

/* ---------- O SELO DE COMENTARIO NO CARTAO (19/10) ---------- */

/* So o que alguem ESCREVEU: o registro automatico de concluir, reabrir ou cancelar nao conta. */
const comentariosEscritos = (a) => (a.comentarios || []).filter((c) => !c.automatico);
const meuEmail = () => String((SESSAO && SESSAO.usuario && SESSAO.usuario.email) || '').toLowerCase();
const ehMeu = (c) => String(c.autor || '').toLowerCase() === meuEmail();

/*
 * Responsavel pela acao ou gestao do plano: comenta e muda a situacao. Tudo
 * so com "Ver e editar" na tela do plano (p.editar, do servidor): com "Ver"
 * a pessoa le a acao e o historico, sem gravar nada — nem sendo a responsavel.
 */
const cuidaDaAcao = (a, p) => !!p.editar && (a.parecer === undefined || a.parecer === 'TRATAR') &&
  ((a.responsaveisEmails || [a.responsavelEmail]).indexOf(p.email) !== -1 || !!p.gerir);
/*
 * Comentam: quem cuida da acao, quem foi marcado num comentario dela e (8.13)
 * quem registrou a situacao e o gerente destinatario — nunca na cancelada.
 * Na situacao que ainda espera o parecer, o comentario e so conversa.
 */
const podeComentarAcao = (a, p) => !!p.editar && a.situacao !== 'CANCELADA' && (cuidaDaAcao(a, p) ||
  (a.marcadosEmails || []).indexOf(p.email) !== -1 || (!!p.email && (a.autorEmail === p.email || a.destinatarioEmail === p.email)) ||
  (!!p.gerir && (a.responsaveisEmails || []).indexOf(p.email) !== -1));

/*
 * "NOVO" NESTE APARELHO. O que o aparelho ja abriu fica no localStorage so
 * com IDs ({ idDaAcao: idDoUltimoRegistroVisto }) — nada que identifique a
 * pessoa. Guarda as ultimas 400 acoes abertas (sai a aberta ha mais tempo):
 * podar pela lista da tela apagaria as do outro plano e as concluidas que o
 * filtro "Em aberto" esconde. Sem localStorage (cookie de terceiros
 * bloqueado), o que foi aberto vale ate a pagina recarregar (VISTOS_NA_PAGINA,
 * so na memoria e so com IDs).
 */
const CHAVE_VISTOS = 'gsl_coment_vistos', VISTOS_MAX = 400;
const COMENT_NOVO_MS = 72 * 3600 * 1000;           // cobre o fim de semana
const VISTOS_NA_PAGINA = {};
function comentVistos() {
  let v = {};
  try { v = JSON.parse(lerLocal(CHAVE_VISTOS) || '{}') || {}; } catch (e) { v = {}; }
  Object.keys(VISTOS_NA_PAGINA).forEach((k) => { if (!(k in v)) v[k] = VISTOS_NA_PAGINA[k]; });
  return v;
}
function marcarComentVisto(a) {
  const lista = a.comentarios || [];
  if (!lista.length) return;
  const vistos = comentVistos();
  delete vistos[a.id];                              // vai para o fim: a ultima aberta e a ultima a sair
  vistos[a.id] = VISTOS_NA_PAGINA[a.id] = lista[lista.length - 1].id;
  Object.keys(vistos).slice(0, -VISTOS_MAX).forEach((k) => { delete vistos[k]; });
  gravarLocal(CHAVE_VISTOS, JSON.stringify(vistos));
  document.querySelectorAll('.selo-coment.novo').forEach((b) => {
    if (b.dataset.acao !== a.id) return;
    b.classList.remove('novo');
    b.querySelectorAll('.selo-novo, .selo-novo-leitor').forEach((n) => n.remove());
  });
}
/* 'dd/MM/yyyy HH:mm' (como o servidor grava) -> milissegundos. */
function msDoCarimbo(em) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})/.exec(String(em || ''));
  return m ? new Date(+m[3], +m[2] - 1, +m[1], +m[4], +m[5]).getTime() : 0;
}
/*
 * "novo": o ultimo comentario escrito por OUTRA pessoa, das ultimas 72 h, depois do que este aparelho abriu
 * — e que eu ainda nao respondi (de outro aparelho, inclusive).
 */
function temComentarioNovo(a) {
  const escritos = comentariosEscritos(a), ultimo = escritos.filter((c) => !ehMeu(c)).pop();
  if (!ultimo || Date.now() - msDoCarimbo(ultimo.em) > COMENT_NOVO_MS) return false;
  if (escritos.map(ehMeu).lastIndexOf(true) > escritos.indexOf(ultimo)) return false;
  const lista = a.comentarios || [], visto = comentVistos()[a.id];
  return lista.findIndex((c) => c.id === visto) < lista.findIndex((c) => c.id === ultimo.id);
}
/* A mencao a mim que ainda espera resposta: a mais recente, se eu nao escrevi nada depois dela. */
function mencaoParaMim(a) {
  const lista = a.comentarios || [], eu = meuEmail();
  for (let i = lista.length - 1; i >= 0; i--) {
    if (ehMeu(lista[i])) return null;
    if ((lista[i].mencoes || []).some((m) => m.email === eu)) return lista[i];
  }
  return null;
}

/*
 * Os selos do topo do cartao: "@ voce" enquanto a pessoa marcada nao
 * responde (e pode responder: na cancelada ninguem comenta) e "N"
 * comentarios (cheio, com "novo", quando ha um de outra pessoa que este
 * aparelho nao abriu; o leitor de tela ouve "2 comentarios, com comentario
 * novo"). Sem comentario escrito, nada. Clicar abre o historico.
 */
function seloComentarios(a, podeComentar) {
  const escritos = comentariosEscritos(a), n = escritos.length, mencao = podeComentar ? mencaoParaMim(a) : null;
  const abre = `abrirComentarios(${jsArg(a.id)}, ${podeComentar ? 'true' : 'false'})`;
  const quando = (c) => String(c.em || '').slice(0, 16);
  let html = mencao ? `<button type="button" class="selo-mencao" onclick="${abre}" title="${esc(mencao.nome + ' marcou você em ' + quando(mencao))}">
    <span aria-hidden="true">@</span> você<span class="so-leitor"> — ${esc(mencao.nome)} marcou você num comentário</span></button>` : '';
  if (!n) return html;
  const novo = temComentarioNovo(a), ultimo = escritos[n - 1];
  const dica = n + (n === 1 ? ' comentário' : ' comentários') + ' — o último de ' + ultimo.nome + ' em ' + quando(ultimo);
  return html + `<button type="button" class="selo-coment${novo ? ' novo' : ''}" data-acao="${esc(a.id)}" onclick="${abre}" title="${esc(dica)}">
    <span aria-hidden="true">&#128172;</span> ${n}<span class="so-leitor"> ${n === 1 ? 'comentário' : 'comentários'}</span>${novo && n > 1 ? '<span class="so-leitor selo-novo-leitor">, com comentário</span>' : ''}${novo ? ' <span class="selo-novo">novo</span>' : ''}</button>`;
}

/* O texto do comentario com quem foi marcado em destaque — os nomes vem do servidor, nunca do texto. */
function textoComMencoes(c) {
  const html = esc(c.texto);
  const porAlvo = {};
  (c.mencoes || []).forEach((m) => { if (m.nome) porAlvo[esc('@' + m.nome)] = m; });
  // O nome mais longo primeiro: "@Ana Paula" nao vira "@Ana" + " Paula".
  const alvos = Object.keys(porAlvo).sort((x, y) => y.length - x.length);
  if (!alvos.length) return html;
  const re = new RegExp(alvos.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'g');
  return html.replace(re, (t) => `<span class="coment-mencao${porAlvo[t].email === meuEmail() ? ' para-voce' : ''}">${t}</span>`);
}
const linhaMarcou = (c) => ((c.mencoes || []).length ? `<div class="coment-mencoes">Marcou: ${c.mencoes.map((m) =>
  `<span class="coment-mencao${m.email === meuEmail() ? ' para-voce' : ''}">@${esc(m.nome)}</span>`).join(' ')}</div>` : '');

/*
 * MARCAR PESSOA NO COMENTARIO (19/10). "@" no campo (no comeco ou depois de
 * um espaco) abre as sugestoes; o botao "@ Marcar pessoa" faz o mesmo. A
 * linha "Vai avisar por e-mail" e a verdade do que vai para o servidor, e o
 * texto nao a contradiz: apagar o "@Nome" tira a pessoa da linha, e o nome
 * de alguem do plano escrito inteiro sem escolher na lista entra nela no
 * Registrar, que pede para conferir antes de gravar.
 * Sugestoes: as pessoas do plano (as do campo Responsaveis) que abrem o
 * painel dele, menos quem escreve e quem ja foi escolhido, por nome, funcao
 * ou turno, sem acento. tiradas: quem saiu pelo x (o texto nao a traz de volta).
 */
const MENCAO = { acao: null, escolhidas: [], tiradas: [], lista: [], ativo: 0, inicio: -1, fim: -1 };
const MENCOES_MAX = 10, SUGESTOES_MAX = 8;
const semAcento = (t) => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const pessoaDoPlano = (email) => (planoD().pessoas || []).find((p) => p.email === email) || { email: email, nome: email };

function mencaoCandidatos(filtro) {
  const a = MENCAO.acao || {}, eu = meuEmail(), f = semAcento(filtro);
  // Ja veem a acao: quem esta citado nela e, na acao sem responsavel, quem gere o plano (21/10).
  // veTodas: o Acoes.gs de antes de 21/10, em que a gestao e a consulta viam todas.
  const jaVeem = (a.responsaveisEmails || []).concat(a.marcadosEmails || []);
  const semResponsavel = !(a.responsaveisEmails || []).length;
  const todas = (planoD().pessoas || [])
    .filter((p) => p.email !== eu && p.abre !== false && MENCAO.escolhidas.indexOf(p.email) === -1)
    .filter((p) => !f || semAcento([p.nome, p.papel, p.turno ? 'turno ' + p.turno : ''].join(' ')).indexOf(f) !== -1);
  // Sem filtro ("@" sozinho, o botao): todas, na lista que rola. Filtrando: as primeiras.
  return (f ? todas.slice(0, SUGESTOES_MAX) : todas)
    .map((p) => Object.assign({}, p, { passaAVer: !p.veTodas && jaVeem.indexOf(p.email) === -1 && !(semResponsavel && p.gere) }));
}
function mencaoPintarLista() {
  const caixa = el('cm-sugestoes'), campo = el('cm-texto');
  if (!caixa || !campo) return;
  caixa.innerHTML = MENCAO.lista.length ? MENCAO.lista.map((p, i) => `
    <div role="option" id="cm-sug-${i}" class="mencao-opcao${i === MENCAO.ativo ? ' ativa' : ''}" aria-selected="${i === MENCAO.ativo}"
         onmousedown="event.preventDefault(); mencaoEscolher(${i})"><b>${esc(p.nome)}</b>
      <span class="mencao-papel">${esc([p.papel, p.turno ? 'turno ' + p.turno : ''].filter(Boolean).join(' · '))}</span>
      ${p.passaAVer ? '<span class="mencao-acesso">passa a ver esta ação</span>' : ''}</div>`).join('')
    : '<div class="mencao-vazia">Ninguém com esse nome no plano.</div>';
  caixa.classList.remove('oculto');
  // A ativa (setas) fica a vista dentro da lista que rola, sem rolar a pagina.
  const ativa = el('cm-sug-' + MENCAO.ativo);
  if (ativa && ativa.offsetTop < caixa.scrollTop) caixa.scrollTop = ativa.offsetTop;
  else if (ativa && ativa.offsetTop + ativa.offsetHeight > caixa.scrollTop + caixa.clientHeight) caixa.scrollTop = ativa.offsetTop + ativa.offsetHeight - caixa.clientHeight;
  campo.setAttribute('aria-expanded', 'true');
  if (MENCAO.lista.length) campo.setAttribute('aria-activedescendant', 'cm-sug-' + MENCAO.ativo);
  else campo.removeAttribute('aria-activedescendant');
}
function mencaoFechar() {
  MENCAO.inicio = -1; MENCAO.fim = -1; MENCAO.lista = [];
  const caixa = el('cm-sugestoes'); if (caixa) { caixa.classList.add('oculto'); caixa.innerHTML = ''; }
  const campo = el('cm-texto'); if (campo) { campo.setAttribute('aria-expanded', 'false'); campo.removeAttribute('aria-activedescendant'); }
}
/*
 * O "@..." que esta sendo digitado: logo antes do cursor, com ate quatro
 * palavras (nomes compostos). "@" sozinho abre a lista inteira; "@ " (o
 * espaco logo depois) nao e marcacao.
 */
const RE_MENCAO_DIGITADA = /(^|\s)@((?:[^\s@]{1,30}(?: [^\s@]{0,30}){0,3})?)$/;
/*
 * { inicio (o "@"), fim (o cursor), filtro, pontuacao } do "@..." no cursor;
 * null se o cursor nao esta num (ou ha texto selecionado). "@Pedro,": a
 * pontuacao logo depois do nome fica fora do filtro e volta depois do nome.
 */
function mencaoNoCursor(campo) {
  if (campo.selectionStart !== campo.selectionEnd) return null;
  const antes = campo.value.slice(0, campo.selectionStart);
  const m = RE_MENCAO_DIGITADA.exec(antes);
  if (!m) return null;
  const p = /[^\s.,;:!?]([.,;:!?]+)$/.exec(m[2]);
  return { inicio: antes.length - m[2].length - 1, fim: antes.length,
           filtro: p ? m[2].slice(0, -p[1].length) : m[2], pontuacao: p ? p[1] : '' };
}
/* A cada tecla: o "@..." no cursor abre (ou filtra) as sugestoes; quem saiu do texto sai da linha "Vai avisar". */
function mencaoDigitando(campo) {
  mencaoPodar(campo.value);
  const t = mencaoNoCursor(campo);
  if (!t) return mencaoFechar();
  const lista = mencaoCandidatos(t.filtro);
  if (!lista.length && /\s/.test(t.filtro)) return mencaoFechar();      // a palavra seguinte ja e o resto da frase
  MENCAO.inicio = t.inicio; MENCAO.fim = t.fim;
  MENCAO.lista = lista; MENCAO.ativo = 0;
  mencaoPintarLista();
}
/*
 * O "@..." que abriu a lista, se o cursor continua nele. O cursor andou
 * (clique ou toque no texto, setas, Home/End): a lista fecha e volta null —
 * o Enter quebra a linha e o Tab sai do campo, sem marcar ninguem.
 */
function mencaoConferirCursor(campo) {
  if (MENCAO.inicio < 0) return null;
  const t = mencaoNoCursor(campo);
  if (t && t.inicio === MENCAO.inicio && t.fim === MENCAO.fim) return t;
  mencaoFechar();
  return null;
}
function mencaoTeclas(ev) {
  if (MENCAO.inicio < 0) return;
  if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); mencaoFechar(); return; }
  if (!MENCAO.lista.length) return;
  if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
    ev.preventDefault();
    MENCAO.ativo = (MENCAO.ativo + (ev.key === 'ArrowDown' ? 1 : MENCAO.lista.length - 1)) % MENCAO.lista.length;
    mencaoPintarLista();
  } else if ((ev.key === 'Enter' || ev.key === 'Tab') && mencaoConferirCursor(ev.target)) {
    ev.preventDefault();
    mencaoEscolher(MENCAO.ativo);
  }
}
/* Troca exatamente o "@texto" que abriu a lista por "@Nome " e poe a pessoa na lista de quem vai ser avisado. */
function mencaoEscolher(i) {
  const p = MENCAO.lista[i], campo = el('cm-texto');
  if (!p || !campo) return;
  const t = mencaoConferirCursor(campo);
  if (!t) return;
  if (MENCAO.escolhidas.length >= MENCOES_MAX) { mencaoFechar(); return avisar('Marque no máximo ' + MENCOES_MAX + ' pessoas por comentário.', true); }
  const nome = '@' + p.nome + t.pontuacao + ' ';
  campo.value = campo.value.slice(0, t.inicio) + nome + campo.value.slice(t.fim);
  campo.selectionStart = campo.selectionEnd = t.inicio + nome.length;
  MENCAO.escolhidas.push(p.email);
  MENCAO.tiradas = MENCAO.tiradas.filter((e) => e !== p.email);
  mencaoFechar(); mencaoPintarEscolhidas(); campo.focus();
}
/* O botao "@ Marcar pessoa": poe o "@" no cursor e abre a lista inteira. */
function mencaoBotao() {
  const campo = el('cm-texto'); if (!campo) return;
  const pos = campo.selectionStart, antes = campo.value.slice(0, pos);
  const sep = antes && !/\s$/.test(antes) ? ' ' : '';
  campo.value = antes + sep + '@' + campo.value.slice(pos);
  campo.selectionStart = campo.selectionEnd = pos + sep.length + 1;
  campo.focus(); mencaoDigitando(campo);
}
/* Saiu do campo (clique fora, Tab): a lista fecha — menos quando o foco voltou para ele (o botao "@ Marcar pessoa"). */
function mencaoAoSair() { setTimeout(() => { if (document.activeElement !== el('cm-texto')) mencaoFechar(); }, 150); }
function mencaoTirar(email) {
  MENCAO.escolhidas = MENCAO.escolhidas.filter((e) => e !== email);
  if (MENCAO.tiradas.indexOf(email) === -1) MENCAO.tiradas.push(email);
  mencaoPintarEscolhidas();
}
/*
 * Os nomes (sem acento) de pessoas do plano escritos com "@" no texto, do
 * maior para o menor: cada um achado sai do texto, e "@Ana Paula Ribeiro"
 * nao cita tambem a "Ana Paula". Depois do nome, pontuacao ou espaco.
 */
function nomesCitados(texto) {
  let t = ' ' + semAcento(texto) + ' ';
  const nomes = (planoD().pessoas || []).map((p) => semAcento(p.nome))
    .filter((n, i, l) => n && l.indexOf(n) === i).sort((x, y) => y.length - x.length);
  return nomes.filter((n) => {
    const re = new RegExp('(\\s)@' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?![a-z0-9])', 'g');
    if (!re.test(t)) return false;
    t = t.replace(re, '$1');
    return true;
  });
}
/* Quem saiu do texto (o "@Nome" apagado ou editado) sai da linha "Vai avisar": so tira, nunca poe. */
function mencaoPodar(texto) {
  if (!MENCAO.escolhidas.length) return;
  const citados = nomesCitados(texto);
  const ficam = MENCAO.escolhidas.filter((e) => citados.indexOf(semAcento(pessoaDoPlano(e).nome)) !== -1);
  if (ficam.length !== MENCAO.escolhidas.length) { MENCAO.escolhidas = ficam; mencaoPintarEscolhidas(); }
}
/*
 * Pessoas do plano com o "@Nome" escrito sem escolher na lista, na ordem do
 * texto. Nao entram quem escreve, quem nao abre o plano, as ja escolhidas,
 * as tiradas no x e os homonimos (qual dos dois seria?).
 */
function mencoesSoEscritas(texto) {
  const eu = meuEmail(), citados = nomesCitados(texto), pessoas = planoD().pessoas || [], t = semAcento(texto);
  const nome = (p) => semAcento(p.nome), onde = (p) => t.indexOf('@' + nome(p));
  return pessoas.filter((p) => citados.indexOf(nome(p)) !== -1 && pessoas.filter((x) => nome(x) === nome(p)).length === 1 &&
    p.email !== eu && p.abre !== false && MENCAO.escolhidas.indexOf(p.email) === -1 && MENCAO.tiradas.indexOf(p.email) === -1)
    .sort((x, y) => onde(x) - onde(y));
}
/*
 * Registrar comentario. O "@Nome" escrito sem escolher na lista nao some
 * calado: a pessoa entra na linha "Vai avisar", com a nota, e so o clique
 * seguinte grava. Sem confirm(): ele gastaria o clique de que a gravacao
 * pela pagina (canal barrado) precisa. acao: o nome da acao do plano em que
 * a janela foi aberta.
 */
function registrarComentario(id, acao) {
  if (!fotosProntas('cm')) return;
  const texto = val('cm-texto');
  mencaoPodar(texto);
  const faltam = mencoesSoEscritas(texto).slice(0, Math.max(0, MENCOES_MAX - MENCAO.escolhidas.length));
  if (faltam.length) {
    faltam.forEach((p) => MENCAO.escolhidas.push(p.email));
    mencaoPintarEscolhidas();
    const nomes = faltam.map((p) => '@' + p.nome);
    const quem = nomes.length > 1 ? nomes.slice(0, -1).join(', ') + ' e ' + nomes[nomes.length - 1] : nomes[0];
    el('cm-marcados').insertAdjacentHTML('beforeend', '<div class="mencao-nota">' + esc('Você escreveu ' + quem + ' sem escolher na lista. ' +
      (faltam.length > 1 ? 'As pessoas entraram' : 'A pessoa entrou') + ' em “Vai avisar por e-mail”: confira (o × tira) e clique de novo em Registrar comentário.') + '</div>');
    return;
  }
  agir(acao, { id: id, texto: texto, situacao: val('cm-sit'), depende: val('cm-dep'), fotos: fotosParaEnviar('cm'),
    mencoes: MENCAO.escolhidas.slice() }).catch(() => {});
}
function mencaoPintarEscolhidas() {
  const alvo = el('cm-marcados'); if (!alvo) return;
  alvo.innerHTML = MENCAO.escolhidas.length ? 'Vai avisar por e-mail: ' + MENCAO.escolhidas.map((e) => {
    const p = pessoaDoPlano(e);
    return `<span class="mencao-chip">@${esc(p.nome)}<button type="button" class="mencao-tirar" onclick="mencaoTirar(${jsArg(e)})"
      aria-label="Não marcar ${esc(p.nome)}">&times;</button></span>`;
  }).join(' ') : '';
}

/* ---------- FILTROS (feitos na tela, nos dois planos) ---------- */

/* O parecer do cartao para o filtro: TRATAR, DEPOIS, NADA ou 'pendente' (sem definicao). */
const paParecerDe = (a) => a.parecer === undefined ? 'TRATAR' : (a.parecer || 'pendente');
/* Fechada: concluida, cancelada ou "nada a fazer". O resto esta em aberto (inclusive a que espera o parecer). */
const paFechada = (a) => a.situacao === 'CONCLUIDA' || a.situacao === 'CANCELADA' || a.situacao === 'SEM_ACAO';
const PA_SITUACOES = [['ABERTAS', 'Em aberto'], ['ATRASADAS', 'Atrasadas'], ['CONCLUIDAS', 'Concluídas'],
                      ['CANCELADAS', 'Canceladas'], ['TODAS', 'Todas']];
const PA_PARECERES = [['', 'Todas', ''], ['TRATAR', '&#10003; Tratar / Incluir ação', 'tratar'], ['DEPOIS', '&#9203; Outro momento', 'depois'],
                      ['NADA', '&#10005; Nada a fazer', 'nada'], ['pendente', '&#8226; Sem definição', 'pendente']];
const PA_NOME_PRIO = { ALTA: 'Alta', MEDIA: 'Média', NORMAL: 'Normal' };
const paTexto = (v) => (String(v || '').charAt(0) === '<' ? paHtmlParaTexto(v) : String(v || ''));

function paPassaSituacao(a, s) {
  if (!s || s === 'TODAS') return true;
  if (s === 'ABERTAS') return !paFechada(a);
  if (s === 'CONCLUIDAS') return a.situacao === 'CONCLUIDA';
  if (s === 'CANCELADAS') return a.situacao === 'CANCELADA';
  if (s === 'ATRASADAS') return a.status === 'Atrasada';
  return true;
}
/* Tudo menos o parecer e a situacao (os dois tem contador proprio). */
function paPassaResto(a, f) {
  const busca = semAcento(f.busca || '').trim();
  if (f.turno && String(a.turno).toUpperCase() !== String(f.turno).toUpperCase()) return false;
  if (f.zona && a.zona !== f.zona) return false;
  if (f.crit && a.criticidade !== f.crit) return false;
  if (f.prio && (a.prioridade || 'NORMAL') !== f.prio) return false;
  if (busca && semAcento([a.acao, paTexto(a.descricao), paTexto(a.tratativa), a.responsavel, a.origem, a.zona, a.local,
    a.relatorio, (pessoaDoPlano(a.autorEmail) || {}).nome, (pessoaDoPlano(a.destinatarioEmail) || {}).nome].join(' ')).indexOf(busca) === -1) return false;
  return true;
}
function planoFiltrarLista(lista, f) {
  return (lista || []).filter((a) => paPassaResto(a, f) && paPassaSituacao(a, f.situacao) &&
    (!f.parecer || paParecerDe(a) === f.parecer));
}
function planoFiltrar(mudanca) { PLANO.filtrar(mudanca); }

/* O numero do cartao: a ordem de registro (fica o mesmo com qualquer filtro). */
function paNumeros(lista) {
  const ordem = (lista || []).slice().sort((x, y) => (msDoCarimbo(x.criadoEm) - msDoCarimbo(y.criadoEm)) || String(x.id).localeCompare(String(y.id)));
  const n = {}; ordem.forEach((a, i) => { n[a.id] = i + 1; });
  return n;
}
const PA_PESO_PRIO = { ALTA: 0, MEDIA: 1, NORMAL: 2 };
function paOrdenar(lista, ordem, eu) {
  const peso = (a) => {
    if (a.status === 'Atrasada') return 0;
    if (a.situacao === 'AGUARDANDO_PARECER' && a.destinatarioEmail === eu) return 1;
    if (a.situacao === 'PENDENTE') return 2;
    if (a.situacao === 'AGUARDANDO_PARECER') return 3;
    if (a.situacao === 'POSTERGADA') return 4;
    return 5;
  };
  return lista.slice().sort((a, b) => {
    if (ordem === 'recentes') return msDoCarimbo(b.criadoEm) - msDoCarimbo(a.criadoEm);
    if (ordem === 'antigas') return msDoCarimbo(a.criadoEm) - msDoCarimbo(b.criadoEm);
    return (peso(a) - peso(b)) || ((PA_PESO_PRIO[a.prioridade] || 2) - (PA_PESO_PRIO[b.prioridade] || 2)) ||
      String(a.prazoISO || '9999').localeCompare(String(b.prazoISO || '9999')) || msDoCarimbo(b.criadoEm) - msDoCarimbo(a.criadoEm);
  });
}

/* ---------- O PLANO NA TELA ---------- */
function planoHtml(d) {
  const p = d.permissoes || {}, c = d.contagens || {};
  const f = PLANO.local || {};
  const todas = d.lista || [];
  const ex = PLANO.extras ? PLANO.extras() : null;
  const base = todas.filter((a) => paPassaResto(a, f));
  const porParecer = (k) => base.filter((a) => paPassaSituacao(a, f.situacao) && (!k || paParecerDe(a) === k)).length;
  const porSituacao = (s) => base.filter((a) => paPassaSituacao(a, s) && (!f.parecer || paParecerDe(a) === f.parecer)).length;
  const lista = paOrdenar(planoFiltrarLista(todas, f), f.ordem, p.email);
  const numeros = paNumeros(todas);
  // O placar (como o do relatorio do gerente): sobre tudo o que a pessoa ve, sem filtro.
  const conta = (k) => todas.filter((a) => paParecerDe(a) === k).length;
  const tratar = conta('TRATAR'), depois = conta('DEPOIS'), nada = conta('NADA'), pendentes = conta('pendente');
  const avaliadas = tratar + depois + nada;
  const limpeza = PLANO.id === 'LIMPEZA';
  const tile = (classe, rot, n, sub, filtro) => `<button type="button" class="pa-tile ${classe}${f.parecer === filtro && filtro ? ' ativo' : ''}"
      onclick="planoFiltrar({parecer:${jsArg(f.parecer === filtro ? '' : filtro)}})"><b>${rot}</b><span class="pa-num">${n}</span><small>${sub}</small></button>`;
  const turnos = [''].concat(d.turnos || []);
  const sel = (v, atual) => (String(v) === String(atual || '') ? 'selected' : '');

  return `<div class="pa">
    <div class="pa-topo">
      <span class="pa-tag">BARTOFIL · ${limpeza ? 'LIMPEZA CD' : 'PLANO DE AÇÃO'}</span>
      <h2>${limpeza ? 'Ocorrências e ações da limpeza' : 'Ocorrências e ações'}</h2>
      <p>Cada situação é registrada com fotos do local; o gerente define a tratativa. Aqui aparecem só as que citam você${d.modelo && d.modelo.filial ? ' · ' + esc(d.modelo.filial) : ''}.</p>
      <div class="pa-listras" aria-hidden="true"><i></i><i></i></div>
    </div>

    <div class="pa-placar">
      ${tile('', 'Total registrado', todas.length, 'situação(ões)', '')}
      ${tile('verde', 'Tratar / Ação', tratar, (c.abertas || 0) + ' em aberto' + (c.atrasadas ? ' · <em>' + c.atrasadas + ' atrasada(s)</em>' : ''), 'TRATAR')}
      ${tile('amarelo', 'Outro momento', depois, 'postergada(s)', 'DEPOIS')}
      ${tile('cinza', 'Sem ação / Pendente', nada + pendentes, pendentes + ' sem definição' + (c.parecer ? ' · <em>' + c.parecer + ' com você</em>' : ''), 'pendente')}
    </div>
    <div class="pa-acoes-linha">
      <span class="pa-pilula"><b>${c.abertas || 0}</b> ações em aberto</span>
      <span class="pa-pilula${c.atrasadas ? ' alerta' : ''}"><b>${c.atrasadas || 0}</b> atrasada(s)</span>
      <span class="pa-pilula"><b>${c.minhas || 0}</b> sob sua responsabilidade</span>
      <span class="pa-pilula ok"><b>${c.concluidas || 0}</b> concluída(s)</span>
      ${d.geral ? `<span class="pa-nota">No plano inteiro: <b>${d.geral.abertas}</b> em aberto, <b>${d.geral.atrasadas}</b> atrasada(s) — só os números.</span>` : ''}
    </div>

    <div class="pa-secao">
      <div class="pa-sinal" aria-hidden="true">§</div>
      <div><h3>Situações levantadas e parecer da gerência</h3>
        <p>Aparecem só as situações em que você está citado: quem registrou, o gerente, os responsáveis e quem foi marcado.</p></div>
      <div class="pa-selo-secao">${avaliadas} / ${todas.length} avaliadas</div>
    </div>

    <div class="pa-filtros" role="region" aria-label="Filtrar situações">
      <div class="pa-filtro-linha">
        <span class="pa-filtro-rot">Parecer</span>
        ${PA_PARECERES.map(([k, nome, cls]) => `<button type="button" class="pa-chip ${cls}${(f.parecer || '') === k ? ' ativo' : ''}"
          data-parecer="${esc(k)}" onclick="planoFiltrar({parecer:${jsArg(k)}})">${nome} <span class="pa-cnt">${porParecer(k)}</span></button>`).join('')}
      </div>
      <div class="pa-filtro-linha">
        <span class="pa-filtro-rot">Situação</span>
        ${PA_SITUACOES.map(([k, nome]) => `<button type="button" class="pa-chip ${k === 'ATRASADAS' ? 'atrasadas' : ''}${f.situacao === k ? ' ativo' : ''}"
          data-situacao="${k}" onclick="planoFiltrar({situacao:${jsArg(k)}})">${nome} <span class="pa-cnt">${porSituacao(k)}</span></button>`).join('')}
      </div>
      <div class="pa-filtro-linha pa-quebra">
        <select aria-label="Prioridade" onchange="planoFiltrar({prio:this.value})"><option value="">Toda prioridade</option>
          ${['ALTA', 'MEDIA', 'NORMAL'].map((x) => `<option value="${x}" ${sel(x, f.prio)}>Prioridade ${PA_NOME_PRIO[x].toLowerCase()}</option>`).join('')}</select>
        <select aria-label="Turno" onchange="planoFiltrar({turno:this.value})">
          ${turnos.map((t) => `<option value="${esc(t)}" ${sel(t, f.turno)}>${t === '' ? 'Todos os turnos' : t === 'Todos' ? 'Geral (CD)' : 'Turno ' + esc(t)}</option>`).join('')}</select>
        ${ex ? `<select aria-label="Zona" onchange="planoFiltrar({zona:this.value})"><option value="">Todas as zonas</option>
          ${(ex.zonas || []).map((z) => `<option value="${esc(z.zona)}" ${sel(z.zona, f.zona)}>${esc(z.zona)}${z.descricao ? ' — ' + esc(z.descricao) : ''}</option>`).join('')}</select>` : ''}
        <select aria-label="Ordem" onchange="planoFiltrar({ordem:this.value})">
          <option value="urgentes" ${sel('urgentes', f.ordem || 'urgentes')}>Mais urgentes primeiro</option>
          <option value="recentes" ${sel('recentes', f.ordem)}>Mais recentes primeiro</option>
          <option value="antigas" ${sel('antigas', f.ordem)}>Mais antigas primeiro</option></select>
        <div class="pa-busca"><span aria-hidden="true">&#128269;</span>
          <input id="busca-acao" placeholder="Buscar título, descrição, responsável${ex ? ', local' : ''} ou origem" value="${esc(f.busca || '')}"
                 onkeydown="if(event.key==='Enter')planoFiltrar({busca:this.value})" onchange="if(this.value!==String((PLANO.local||{}).busca||''))planoFiltrar({busca:this.value})"></div>
      </div>
    </div>

    <div class="pa-lista">
      ${lista.length ? lista.map((a) => cartaoAcao(a, p, numeros[a.id])).join('')
        : `<div class="pa-vazio"><p>${todas.length ? 'Nenhuma situação com estes filtros.' : 'Nenhuma situação ainda.' +
            (p.editar && paTemSituacoes(d) ? ' Registre a primeira em <b>+ Nova situação</b>.' : '')}</p>
           ${todas.length ? `<button type="button" class="botao secundario" onclick="planoFiltrar({parecer:'',situacao:'TODAS',prio:'',turno:'',zona:'',busca:''})">Mostrar todas</button>` : ''}</div>`}
    </div>

    ${(d.ranking || []).length ? `
    <div class="pa-ranking">
      <h3>Ranking de ações por turno — para as auditorias</h3>
      <p class="pa-nota" style="margin:0 0 10px">Quantas ações (parecer “Tratar”) cada turno recebeu e quantas fechou. O percentual é de
         <b>conclusão</b>: propor muito e concluir pouco não é desempenho, é fila. Ações canceladas ficam fora da conta.
         ${d.geral ? 'Conta todas as ações do plano, também as em que você não está citado (só os números).' : 'Conta as ações em que você está citado.'}</p>
      <div style="overflow-x:auto">
        <table><thead><tr>
          <th>Turno</th><th class="numero">Propostas</th><th class="numero">Concluídas</th>
          <th class="numero">Em aberto</th><th class="numero">Atrasadas</th><th class="numero">%</th>
        </tr></thead><tbody>
          ${d.ranking.map((l) => `
            <tr><td><strong>${esc(l.turno)}</strong></td><td class="numero">${l.total}</td><td class="numero">${l.concluidas}</td>
              <td class="numero">${l.pendentes}</td>
              <td class="numero">${l.atrasadas ? `<span style="color:var(--alerta)">${l.atrasadas}</span>` : '0'}</td>
              <td class="numero"><strong>${l.percentual}%</strong></td></tr>`).join('')}
        </tbody></table>
      </div>
    </div>` : ''}
  </div>`;
}

/* "faltam 3 dias", "vence hoje", "atrasada 2 dias" — da ação ainda aberta. */
function planoPrazoTexto(a) {
  if (a.situacao !== 'PENDENTE' || a.dias === null || a.dias === undefined) return '';
  if (a.dias < 0) return 'atrasada ' + (-a.dias) + ' dia(s)';
  if (a.dias === 0) return 'vence hoje';
  return 'faltam ' + a.dias + ' dia(s)';
}

const seloFotos = (n, onclick) => n
  ? `<button class="selo-foto" onclick="${onclick}" title="Ver as fotos">&#128247; ${n} foto${n > 1 ? 's' : ''}</button>` : '';

/* ---------- TEXTO RICO ---------- */

/*
 * O HTML que vai para a tela passa por aqui (o servidor ja limpou ao gravar;
 * aqui e a segunda barreira — alguem pode ter mexido na planilha). Ficam so
 * b, strong, i, em, u, mark, br, div, p, ul, ol, li, sem atributo nenhum. O
 * span do marca-texto (o execCommand do Chrome) vira mark; negrito, italico
 * e sublinhado por estilo viram a etiqueta. script, style e companhia saem
 * com o conteudo; o resto sai e o texto fica.
 */
const PA_TAGS = { B: 'b', STRONG: 'b', I: 'i', EM: 'i', U: 'u', MARK: 'mark', BR: 'br', DIV: 'div', P: 'p', UL: 'ul', OL: 'ol', LI: 'li' };
const PA_FORA = { SCRIPT: 1, STYLE: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, NOSCRIPT: 1, TEMPLATE: 1, TEXTAREA: 1, SELECT: 1, SVG: 1, MATH: 1, HEAD: 1, TITLE: 1 };
function paHtmlSeguro(html) {
  const t = document.createElement('template');
  t.innerHTML = String(html || '');
  const limpar = (no) => {
    [...no.childNodes].forEach((filho) => {
      if (filho.nodeType === 3) return;
      if (filho.nodeType !== 1) { filho.remove(); return; }
      const nome = filho.tagName.toUpperCase();
      if (PA_FORA[nome]) { filho.remove(); return; }
      limpar(filho);
      let tag = PA_TAGS[nome];
      if (!tag && (nome === 'SPAN' || nome === 'FONT')) {
        const s = filho.style || {};
        if (s.backgroundColor && !/transparent|rgba\(0, 0, 0, 0\)/.test(s.backgroundColor)) tag = 'mark';
        else if (s.fontWeight === 'bold' || Number(s.fontWeight) >= 600) tag = 'b';
        else if (s.fontStyle === 'italic') tag = 'i';
        else if (/underline/.test(s.textDecoration || s.textDecorationLine || '')) tag = 'u';
      }
      if (!tag) { while (filho.firstChild) no.insertBefore(filho.firstChild, filho); filho.remove(); return; }
      const novo = document.createElement(tag);
      while (filho.firstChild) novo.appendChild(filho.firstChild);
      no.replaceChild(novo, filho);
    });
  };
  limpar(t.content);
  return t.innerHTML;
}
function paHtmlParaTexto(html) {
  const d = document.createElement('div');
  d.innerHTML = paHtmlSeguro(String(html || '').replace(/<br\s*\x2f?>/gi, '\n').replace(/<\x2f(div|p|li)>/gi, '\n'));
  return (d.textContent || '').replace(/\n{3,}/g, '\n\n').trim();
}
/* O valor da planilha na tela: HTML (comeca com "<") limpo, ou o texto simples de antes, escapado. */
function paRico(valor) {
  const s = String(valor || '').trim();
  if (!s) return '';
  return s.charAt(0) === '<' ? paHtmlSeguro(s) : esc(s).replace(/\n/g, '<br>');
}
/* Texto longo no cartao: mostra o comeco e o "Ver tudo". */
function paRicoNoCartao(valor, id) {
  const html = paRico(valor);
  const longo = paHtmlParaTexto(html).length > 420 || (html.match(/<li>|<br>|<div>/g) || []).length > 9;
  return `<div class="pa-rico${longo ? ' pa-curto' : ''}" id="${esc(id)}">${html}</div>` +
    (longo ? `<button type="button" class="pa-mais" onclick="const e=document.getElementById(${jsArg(id)});e.classList.toggle('pa-curto');this.textContent=e.classList.contains('pa-curto')?'Ver tudo':'Ver menos'">Ver tudo</button>` : '');
}

/* O editor (barra + campo). verde: o "Como sera tratado". */
function paEditorHtml(id, valor, placeholder, verde) {
  const b = (cmd, rot, titulo, cls) => `<button type="button" class="pa-fmt${cls ? ' ' + cls : ''}" data-cmd="${cmd}" title="${titulo}"
    onmousedown="event.preventDefault();paFormatar(${jsArg(id)},${jsArg(cmd)})">${rot}</button>`;
  return `<div class="pa-barra-fmt" role="toolbar" aria-label="Formatação do texto" data-editor="${esc(id)}">
      ${b('bold', '<b>B</b>', 'Negrito (Ctrl+B)')}${b('italic', '<i>I</i>', 'Itálico (Ctrl+I)')}${b('underline', '<u>U</u>', 'Sublinhado (Ctrl+U)')}
      <span class="pa-fmt-sep"></span>${b('insertUnorderedList', '&#8226; Lista', 'Lista com marcadores')}${b('insertOrderedList', '1. Lista', 'Lista numerada')}
      ${b('marca', 'Destaque', 'Marca-texto no trecho escolhido', 'marca')}${b('removeFormat', 'Tx', 'Tirar a formatação')}</div>
    <div class="pa-editor${verde ? ' verde' : ''}" id="${esc(id)}" contenteditable="true" role="textbox" aria-multiline="true"
      data-placeholder="${esc(placeholder)}" onpaste="paColar(event)" onkeyup="paBarraEstado(${jsArg(id)})"
      onmouseup="paBarraEstado(${jsArg(id)})" oninput="paEditorVazio(this)">${paRico(valor)}</div>`;
}
function paEditorVazio(ed) {
  if (!ed.textContent.trim() && !ed.querySelector('li') && ed.innerHTML !== '') ed.innerHTML = '';
}
function paFormatar(id, cmd) {
  const ed = el(id); if (!ed) return;
  if (document.activeElement !== ed) ed.focus();
  if (cmd === 'marca') paMarcaTexto(ed);
  else {
    try { document.execCommand(cmd, false, null); } catch (e) { /* navegador sem o comando */ }
    if (cmd === 'removeFormat') {
      const sel = window.getSelection();
      let no = sel && sel.rangeCount ? sel.getRangeAt(0).commonAncestorContainer : null;
      if (no && no.nodeType === 3) no = no.parentNode;
      const m = no && no.closest ? no.closest('mark') : null;
      if (m && ed.contains(m)) { while (m.firstChild) m.parentNode.insertBefore(m.firstChild, m); m.remove(); }
    }
  }
  paBarraEstado(id);
}
/* Marca-texto: liga (mark em volta do trecho) ou desliga (o mark em que o cursor esta). */
function paMarcaTexto(ed) {
  const sel = window.getSelection();
  if (!sel || !sel.rangeCount) return;
  const r = sel.getRangeAt(0);
  let no = r.commonAncestorContainer;
  if (no.nodeType === 3) no = no.parentNode;
  const m = no && no.closest ? no.closest('mark') : null;
  if (m && ed.contains(m)) { while (m.firstChild) m.parentNode.insertBefore(m.firstChild, m); m.remove(); return; }
  if (r.collapsed) return;
  try { const mk = document.createElement('mark'); r.surroundContents(mk); }
  catch (e) { try { document.execCommand('hiliteColor', false, '#fff4d1'); } catch (x) { /* sem marca-texto */ } }
}
function paBarraEstado(id) {
  const barra = document.querySelector('.pa-barra-fmt[data-editor="' + id + '"]');
  if (!barra) return;
  barra.querySelectorAll('.pa-fmt[data-cmd]').forEach((b) => {
    const cmd = b.dataset.cmd;
    let ativo = false;
    if (cmd === 'marca') {
      const sel = window.getSelection();
      let no = sel && sel.rangeCount ? sel.getRangeAt(0).commonAncestorContainer : null;
      if (no && no.nodeType === 3) no = no.parentNode;
      ativo = !!(no && no.closest && no.closest('mark'));
    } else if (cmd !== 'removeFormat') { try { ativo = document.queryCommandState(cmd); } catch (e) { ativo = false; } }
    b.classList.toggle('ativo', ativo);
  });
}
/* Colar: so o texto (estilo de outro programa nao entra), com as quebras de linha. */
function paColar(ev) {
  ev.preventDefault();
  const t = (ev.clipboardData || window.clipboardData).getData('text/plain');
  try { document.execCommand('insertText', false, t); } catch (e) { /* sem insertText */ }
}
/* O que o editor manda ao servidor: HTML limpo, ou '' se nao ha texto. */
function paEditorValor(id) {
  const ed = el(id);
  if (!ed) return '';
  if (!ed.textContent.trim() && !ed.querySelector('li')) return '';
  const h = paHtmlSeguro(ed.innerHTML).trim();
  return h.charAt(0) === '<' ? h : '<div>' + h + '</div>';
}

/* ---------- FOTOS DO CARTAO: grade com legenda e miniaturas que carregam quando aparecem ---------- */
const PA_MINIS = new Map();            // id do arquivo -> data URL pequena (480 px)
const PA_FILA = [];
let PA_BAIXANDO = 0, PA_OLHO = null;

function paGradeFotos(a, fotos) {
  if (!fotos.length) return '';
  return `<div class="pa-grade-fotos">${fotos.map((f, i) => {
    const mini = PA_MINIS.get(f.id);
    return `<button type="button" class="pa-foto" onclick="paVerFoto(${jsArg(a.id)}, ${i})" title="${esc(f.legenda || f.nome || 'foto')}">
      <span class="pa-foto-img${mini ? '' : ' carregando'}" data-arquivo="${esc(f.id)}" data-acao="${esc(a.id)}" data-porta="${esc(PLANO.acoes.foto)}"
        ${mini ? `style="background-image:url('${mini}')"` : ''} aria-hidden="true">${mini ? '' : '&#128247;'}</span>
      <span class="pa-foto-leg${f.legenda ? '' : ' vazia'}">${esc(f.legenda || 'Foto ' + (i + 1))}</span></button>`;
  }).join('')}</div>`;
}
function paVerFoto(idAcao, i) {
  const a = planoAcaoPorId(idAcao); if (!a) return;
  verFotos(idAcao, a.fotos || [], !!((planoD().permissoes || {}).gerir), i);
}
/*
 * As miniaturas vem pela porta de sempre (a foto passa pelo servidor, que
 * confere quem ve a acao), duas por vez, so quando o cartao aparece na tela.
 * A foto inteira fica no FOTO_CACHE (o visor abre na hora). Com o canal
 * barrado nao ha como buscar: fica o icone, e o clique abre o visor.
 */
function paDepoisDePintar() {
  if (CANAL_BARRADO || typeof IntersectionObserver === 'undefined') {
    document.querySelectorAll('.pa-foto-img.carregando').forEach((e) => e.classList.remove('carregando'));
    return;
  }
  if (!PA_OLHO) {
    PA_OLHO = new IntersectionObserver((itens) => {
      itens.forEach((it) => {
        if (!it.isIntersecting) return;
        PA_OLHO.unobserve(it.target);
        const x = it.target.dataset;
        if (PA_MINIS.has(x.arquivo)) { paPorMini(x.arquivo); return; }
        if (!PA_FILA.some((q) => q.arquivo === x.arquivo)) PA_FILA.push({ arquivo: x.arquivo, acao: x.acao, porta: x.porta });
      });
      paBaixarMinis();
    }, { rootMargin: '300px' });
  }
  document.querySelectorAll('.pa-foto-img.carregando[data-arquivo]').forEach((e) => PA_OLHO.observe(e));
}
async function paBaixarMinis() {
  while (PA_BAIXANDO < 2 && PA_FILA.length) {
    const q = PA_FILA.shift();
    PA_BAIXANDO++;
    paMini(q).catch(() => {
      document.querySelectorAll('.pa-foto-img[data-arquivo="' + q.arquivo + '"]').forEach((e) => { e.classList.remove('carregando'); });
    }).finally(() => { PA_BAIXANDO--; paBaixarMinis(); });
  }
}
async function paMini(q) {
  let url = FOTO_CACHE.get(q.arquivo);
  if (!url) {
    const r = await executarAcaoSrv(q.porta, { id: q.acao, arquivo: q.arquivo });
    url = 'data:' + (r.tipo || 'image/jpeg') + ';base64,' + r.dados;
    if (!ehUrlHeic(url)) { FOTO_CACHE.set(q.arquivo, url); if (FOTO_CACHE.size > 24) FOTO_CACHE.delete(FOTO_CACHE.keys().next().value); }
  }
  if (ehUrlHeic(url)) throw new Error('heic');
  PA_MINIS.set(q.arquivo, await paReduzir(url, 480));
  if (PA_MINIS.size > 300) PA_MINIS.delete(PA_MINIS.keys().next().value);
  paPorMini(q.arquivo);
}
function paPorMini(arquivo) {
  const mini = PA_MINIS.get(arquivo);
  document.querySelectorAll('.pa-foto-img[data-arquivo="' + arquivo + '"]').forEach((e) => {
    e.classList.remove('carregando'); e.textContent = ''; e.style.backgroundImage = "url('" + mini + "')";
  });
}
/* A foto em JPEG com o lado maior em `lado` px (miniatura e relatorio). */
function paReduzir(url, lado) {
  return new Promise((ok, erro) => {
    const i = new Image();
    i.onload = () => {
      const k = Math.min(1, lado / Math.max(i.naturalWidth || 1, i.naturalHeight || 1));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(i.naturalWidth * k)); c.height = Math.max(1, Math.round(i.naturalHeight * k));
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(i, 0, 0, c.width, c.height);
      ok(c.toDataURL('image/jpeg', 0.8));
    };
    i.onerror = () => erro(new Error('foto'));
    i.src = url;
  });
}

/* ---------- O CARTAO ---------- */

/* Quem decide o parecer desta situacao: o destinatario; sem ele, quem deu o parecer que esta la. */
function paDecideParecer(a, p) {
  if (!p.editar || a.situacao === 'CANCELADA' || a.parecer === undefined) return false;
  return a.destinatarioEmail ? a.destinatarioEmail === p.email : (!!a.parecerPor && a.parecerPor === p.email);
}
const paNome = (email) => (email ? (pessoaDoPlano(email).nome || email) : '');
const paData = (iso) => (iso ? String(iso).slice(8, 10) + '/' + String(iso).slice(5, 7) + '/' + String(iso).slice(0, 4) : '');
const PA_STATUS_CLASSE = { 'Concluída': 'Concluida', 'Aguardando parecer': 'Aguardando', 'Outro momento': 'Outro', 'Nada a fazer': 'Nada' };

function cartaoAcao(a, p, numero) {
  const minha = (a.responsaveisEmails || [a.responsavelEmail]).indexOf(p.email) !== -1;
  const ehAcao = paParecerDe(a) === 'TRATAR';
  const podeConcluir = ehAcao && !!p.editar && a.situacao === 'PENDENTE' && (minha || p.gerir);
  const podeComentar = podeComentarAcao(a, p);
  const escritos = comentariosEscritos(a).length;
  const onde = [a.zona, a.local].filter(Boolean).join(' · ');
  const decide = paDecideParecer(a, p);
  const parecer = a.parecer === undefined ? 'TRATAR' : (a.parecer || '');
  const situacaoNova = !!(a.autorEmail || a.destinatarioEmail);

  let aviso = '';
  if (a.situacao === 'PENDENTE' && a.dias !== null && a.dias !== undefined) {
    if (a.dias < 0) aviso = `<span class="prazo-aviso atraso">${Math.abs(a.dias)} dia(s) em atraso</span>`;
    else if (a.dias === 0) aviso = `<span class="prazo-aviso hoje">vence hoje</span>`;
    else if (a.dias <= 3) aviso = `<span class="prazo-aviso perto">vence em ${a.dias} dia(s)</span>`;
  }
  const quem = [];
  if (a.autorEmail) quem.push(`Registrada por <b>${esc(paNome(a.autorEmail))}</b>${a.autorEmail === p.email ? ' <span class="marca-voce">você</span>' : ''}`);
  else if (a.criadoPorNome) quem.push(`Criada por <b>${esc(a.criadoPorNome)}</b>`);
  if (a.criadoEm) quem.push('em ' + esc(String(a.criadoEm).slice(0, 10)));
  if (a.destinatarioEmail) quem.push(`para <b>${esc(paNome(a.destinatarioEmail))}</b>${a.destinatarioEmail === p.email ? ' <span class="marca-voce">você</span>' : ''}`);
  const extras = [a.turno ? 'Turno ' + esc(a.turno === 'Todos' ? 'Geral (CD)' : a.turno) : '', onde ? 'Local: ' + esc(onde) : '',
    a.origem ? 'Origem: ' + esc(a.origem) : '', a.plano === 'LIMPEZA' && a.abertaEm ? 'aberta em ' + paData(a.abertaEm) : '',
    a.relatorio ? 'Levantamento: <b>' + esc(a.relatorio) + '</b>' : ''].filter(Boolean);
  // A acao de antes (sem "como sera tratado"): o que precisa ser feito esta na descricao.
  const descricao = a.tratativaNaDescricao ? '' : a.descricao;
  const tratativa = a.tratativa || (a.tratativaNaDescricao ? a.descricao : '');
  const fotos = a.fotos || [];
  const statusCls = PA_STATUS_CLASSE[a.status] || a.status;
  const opcao = (k, rot) => {
    const sel = parecer === k ? ' sel-' + k : '';
    return decide
      ? `<button type="button" class="pa-opcao${sel}" data-parecer="${k}" onclick="formParecer(${jsArg(a.id)}, ${jsArg(k)})" aria-pressed="${parecer === k}">
          <span class="pa-bolha">&#10003;</span><span>${rot}</span></button>`
      : `<div class="pa-opcao${sel}${parecer === k ? '' : ' inerte'}" data-parecer="${k}"><span class="pa-bolha">&#10003;</span><span>${rot}</span></div>`;
  };
  const decidiu = a.parecerPor ? `${esc(paNome(a.parecerPor))}${a.parecerEm ? ' · ' + esc(String(a.parecerEm).slice(0, 16)) : ''}` : '';

  return `
    <div class="cartao-acao pa-card ${classeStatus(a.status)} pa-p-${parecer || 'sem'}" data-id="${esc(a.id)}">
      <div class="pa-cab acao-topo">
        <div class="pa-numero" title="Situação nº ${numero || ''}">${numero || '•'}</div>
        <div class="pa-cab-txt">
          <div class="pa-titulo-txt acao-titulo">${esc(a.acao)}</div>
          ${quem.length ? `<div class="pa-sub">${quem.join(' ')}</div>` : ''}
          ${extras.length ? `<div class="pa-sub">${extras.join(' · ')}</div>` : ''}
        </div>
        <div class="pa-selos acao-selos">${seloComentarios(a, podeComentar)}
          <span class="pa-prio ${esc(a.prioridade || 'NORMAL')}" title="Prioridade">${PA_NOME_PRIO[a.prioridade] || 'Normal'}</span>
          <span class="pa-status ${esc(statusCls)}">${esc(a.status)}</span></div>
      </div>

      ${descricao ? `<span class="pa-rotulo">Descrição da situação</span>${paRicoNoCartao(descricao, 'pa-desc-' + a.id)}` : ''}

      ${fotos.length ? `<div class="pa-fotos"><div class="pa-rotulo-linha"><span class="pa-rotulo" style="margin:0">Evidências / fotos do local (${fotos.length})</span>${seloFotos(fotos.length, 'verFotosDaAcao(' + jsArg(a.id) + ')')}</div>
        ${paGradeFotos(a, fotos)}</div>` : ''}

      <div class="pa-parecer">
        <div class="pa-parecer-cab"><span>Parecer / decisão do gerente</span>
          <small>${parecer ? (decidiu ? 'por ' + decidiu : (situacaoNova ? '' : 'ação registrada antes do parecer')) :
            (a.destinatarioEmail ? (decide ? 'Sua decisão: escolha uma opção' : 'Aguardando ' + esc(paNome(a.destinatarioEmail))) : 'Sem definição')}</small></div>
        <div class="pa-opcoes">${opcao('TRATAR', 'Tratar / Incluir ação')}${opcao('DEPOIS', 'Deixar para outro momento')}${opcao('NADA', 'Nada a fazer')}</div>
        ${parecer === 'TRATAR' ? `<div class="pa-tratado">
          <span class="pa-rotulo">Como será tratado / plano de ação</span>
          ${tratativa ? paRicoNoCartao(tratativa, 'pa-trat-' + a.id) : '<div class="pa-nota">—</div>'}
          <div class="pa-meta acao-meta">
            <span><b>${(a.responsaveisEmails || []).length > 1 ? 'Responsáveis' : 'Responsável'}:</b> ${esc(a.responsavel || '—')}${minha ? ' <span class="marca-voce">você</span>' : ''}</span>
            <span><b>Prazo:</b> ${esc(a.prazo || '—')}</span>
            ${aviso}
          </div>
          ${a.situacao === 'PENDENTE' && (a.andamento || a.depende) ? `<div class="acao-andamento">
            ${a.andamento ? `<span class="pill-andamento">${esc(a.andamento)}</span>` : ''}
            ${a.depende ? `<span><b>Depende de:</b> ${esc(a.depende)}</span>` : ''}</div>` : ''}
        </div>` : ''}
        ${parecer === 'DEPOIS' ? `<div class="pa-depois">Postergada${a.reverEm ? ' — <b>rever em ' + paData(a.reverEm) + '</b>' : ''}.${a.parecerObs ? ' ' + esc(a.parecerObs) : ''}</div>` : ''}
        ${parecer === 'NADA' ? `<div class="pa-nada">Encerrada sem ação.${a.parecerObs ? ' ' + esc(a.parecerObs) : ''}</div>` : ''}
        ${parecer === 'TRATAR' && a.parecerObs ? `<div class="pa-parecer-nota">${esc(a.parecerObs)}</div>` : ''}
      </div>

      ${(a.marcados || []).length ? `<div class="pa-sub" style="margin-top:9px"><b>Marcados:</b> ${a.marcados.map((m) =>
        esc(m.nome) + (m.email === p.email ? ' <span class="marca-voce">você</span>' : '')).join(', ')}</div>` : ''}
      ${p.gerir && !(a.responsaveisEmails || []).length && !situacaoNova ? `<div class="acao-origem">Sem responsável com e-mail: só a gestão do plano vê esta ação.
        Marque o responsável em <b>Editar</b>.</div>` : ''}
      ${ultimoComentario(a.comentarios)}
      ${a.situacao === 'CONCLUIDA' ? `
        <div class="acao-conclusao">
          Concluída em ${esc((a.concluidoEm || '').slice(0, 16).replace('T', ' '))}
          ${a.observacao ? ` — ${esc(a.observacao)}` : ''}
        </div>` : ''}
      <div class="acao-botoes">
        ${podeComentar || (a.comentarios || []).length
          ? `<button class="botao secundario" onclick="abrirComentarios(${jsArg(a.id)}, ${podeComentar ? 'true' : 'false'})">Comentários${escritos ? ' (' + escritos + ')' : ''}</button>` : ''}
        ${podeConcluir ? `<button class="botao" onclick="formConcluirAcao(${jsArg(a.id)})">Marcar como concluída</button>` : ''}
        ${ehAcao && p.gerir && a.situacao === 'CONCLUIDA' ? `<button class="botao secundario" onclick="agir(${planoAcao('reabrir')},{id:${jsArg(a.id)}},'Ação reaberta')">Reabrir</button>` : ''}
        ${p.gerir ? `<button class="botao-texto" onclick="${ehAcao ? 'formAcao' : 'formSituacao'}(${jsArg(a.id)})">Editar</button>` : ''}
        ${ehAcao && p.gerir && a.situacao !== 'CANCELADA' ? `<button class="botao-texto" onclick="formCancelarAcao(${jsArg(a.id)})">Cancelar</button>` : ''}
      </div>
    </div>`;
}


/* ---------- COMENTARIOS DAS ACOES (os dois planos) ---------- */
function ultimoComentario(lista) {
  const c = (lista || [])[(lista || []).length - 1];
  if (!c) return '';
  return `<div class="coment-ultimo"><b>${esc(c.nome)}</b>${c.papel ? ' <span class="coment-papel">(' + esc(c.papel) + ')</span>' : ''}
    · ${esc((c.em || '').slice(0, 16))}${COMENT_TIPO[c.tipo] ? ' · ' + COMENT_TIPO[c.tipo] : ''}: ${esc(c.texto)}${(c.fotos || []).length ? ' &#128247;' : ''}</div>`;
}
const COMENT_TIPO = { CONCLUSAO: 'concluiu a ação', REABERTURA: 'reabriu a ação', CANCELAMENTO: 'cancelou a ação', STATUS: 'mudou a situação',
                      PARECER: 'deu o parecer' };

/*
 * Historico + novo comentario. Quem avancou registra o que fez, em que
 * situacao a acao ficou, o que ela ainda espera para concluir — e pode
 * anexar foto e marcar pessoas (19/10). Quem so foi marcado na acao comenta,
 * mas a situacao e o "depende de" ficam com os responsaveis e a gestao.
 */
function abrirComentarios(id, podeComentar) {
  const a = planoAcaoPorId(id);
  if (!a) return;
  const atual = a.andamento || 'Em andamento';
  const cuida = cuidaDaAcao(a, planoD().permissoes || {});
  // Cada registro mostra QUEM fez (nome, funcao e e-mail da pessoa que estava
  // logada — vem da sessao, nao de um campo da tela) e QUANDO.
  const hist = (a.comentarios || []).map((c) => `
    <div class="coment-item ${c.tipo && c.tipo !== 'COMENTARIO' ? 'coment-evento' : ''}">
      <div class="coment-cab">
        <span class="coment-autor"><b>${esc(c.nome)}</b>${c.papel ? `<span class="coment-papel">${esc(c.papel)}</span>` : ''}
          <span class="coment-email">${esc(c.autor)}</span></span>
        <span class="coment-quando">${esc((c.em || '').slice(0, 16))}</span>
        ${COMENT_TIPO[c.tipo] ? `<span class="coment-tipo">${COMENT_TIPO[c.tipo]}</span>` : ''}
        ${c.situacao ? `<span class="pill-andamento">${esc(c.situacao)}</span>` : ''}</div>
      <div class="coment-texto">${textoComMencoes(c)}</div>
      ${linhaMarcou(c)}
      ${c.depende ? `<div class="coment-depende">Depende de: ${esc(c.depende)}</div>` : ''}
      ${seloFotos((c.fotos || []).length, 'verFotosDoComentario(' + jsArg(a.id) + ',' + jsArg(c.id) + ')')}
    </div>`).join('');
  const situacao = !!(a.autorEmail || a.destinatarioEmail);
  const criada = a.criadoEm ? `<div class="coment-criada">${situacao ? 'Situação registrada' : 'Ação criada'}${a.criadoPorNome ? ' por <b>' + esc(a.criadoPorNome) + '</b>' : ''} em ${esc(String(a.criadoEm).slice(0, 16))}${a.destinatarioEmail ? ' para <b>' + esc(paNome(a.destinatarioEmail)) + '</b>' : ''}
    ${seloFotos((a.fotos || []).length, 'verFotosDaAcao(' + jsArg(a.id) + ')')}</div>` : '';
  fotosLimpar('cm', a.id);
  MENCAO.acao = a; MENCAO.escolhidas = []; MENCAO.tiradas = []; mencaoFechar();
  marcarComentVisto(a);
  abrirJanela('Comentários — ' + a.acao, `
    <div class="coment-historico">${criada}${hist || '<div class="vazio">Nenhum comentário ainda. O primeiro abre o histórico desta ação.</div>'}</div>
    ${podeComentar ? `<p class="dica" style="margin:-6px 0 10px">O comentário fica registrado com o seu nome, a sua função, o seu e-mail e a data e hora — e não pode ser apagado.</p>` : ''}
    ${podeComentar ? `
      <div class="campo mencao-campo"><label for="cm-texto">O que avançou</label>
        <textarea id="cm-texto" rows="3" placeholder="Ex.: Lâmpadas compradas, troca agendada com a manutenção para quinta. Digite @ para marcar alguém."
          role="combobox" aria-autocomplete="list" aria-controls="cm-sugestoes" aria-expanded="false" aria-describedby="cm-dica-mencao"
          oninput="mencaoDigitando(this)" onkeydown="mencaoTeclas(event)" onkeyup="mencaoConferirCursor(this)" onclick="mencaoConferirCursor(this)"
          onblur="mencaoAoSair()"></textarea>
        <div id="cm-sugestoes" class="mencao-sugestoes oculto" role="listbox" aria-label="Pessoas para marcar"></div>
        <div class="mencao-barra"><button type="button" class="botao-texto" onclick="mencaoBotao()">@ Marcar pessoa</button>
          <span id="cm-dica-mencao" class="dica">Quem você marcar recebe um e-mail com esta ação e pode responder aqui.</span></div>
        <div id="cm-marcados" class="mencao-escolhidas" aria-live="polite"></div></div>
      ${cuida ? `<div class="campo-duplo">
        <div class="campo"><label>Situação da ação</label><select id="cm-sit">
          ${ANDAMENTOS_ACAO.map((x) => `<option ${x === atual ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
        <div class="campo"><label>Depende de (o que falta para concluir)</label>
          <input id="cm-dep" value="${esc(a.depende || '')}" placeholder="Ex.: chegada do material, liberação do SESMT"></div>
      </div>` : `<p class="dica" style="margin:0 0 12px">${a.parecer !== undefined && a.parecer !== 'TRATAR'
        ? 'Esta situação ainda não é uma ação em andamento: o comentário entra no histórico (o gerente decide no parecer).'
        : 'Marcaram você nesta ação: o seu comentário entra no histórico, e a situação dela fica com os responsáveis.'}</p>`}
      ${fotosCampoHtml('cm', 'Foto (opcional) — do que foi feito, do antes e depois')}` : ''}`, `
    <button class="botao secundario" onclick="fecharJanela()">Fechar</button>
    ${podeComentar ? `<button class="botao" onclick="registrarComentario(${jsArg(id)}, ${planoAcao('comentar')})">Registrar comentário</button>` : ''}`);
  const h = document.querySelector('.coment-historico'); if (h) h.scrollTop = h.scrollHeight;
}

/* Tela de antes chamava o filtro do servidor: agora e o da tela (os dois planos). */
function filtrarAcoes(mudanca) { planoFiltrar(mudanca); }

/* ---------- FORMULARIOS: situacao, acao direta, parecer ---------- */

/* Prioridade em chips (Alta, Media, Normal). */
function paEscolhaPrioridade(nome, atual) {
  const v = atual || 'NORMAL';
  return `<div class="pa-escolha" role="radiogroup" aria-label="Prioridade">${['ALTA', 'MEDIA', 'NORMAL'].map((x) => `
    <label class="${x}${v === x ? ' marcada' : ''}"><input type="radio" name="${esc(nome)}" value="${x}" ${v === x ? 'checked' : ''}
      onchange="this.closest('.pa-escolha').querySelectorAll('label').forEach((l)=>l.classList.toggle('marcada',l.querySelector('input').checked))">
      ${PA_NOME_PRIO[x]}</label>`).join('')}</div>`;
}
const paPrioridadeEscolhida = (nome) => { const x = document.querySelector('input[name="' + nome + '"]:checked'); return x ? x.value : 'NORMAL'; };

/* As fotos que ja estao na situacao, com a legenda de cada uma para editar. */
function paFotosExistentes(a) {
  const fotos = (a && a.fotos) || [];
  if (!fotos.length) return '';
  return `<div class="campo"><label>Fotos da situação (${fotos.length}) — a legenda aparece no cartão e no relatório</label>
    <div class="pa-previas">${fotos.map((f, i) => {
      const mini = PA_MINIS.get(f.id);
      return `<div class="pa-previa"><span class="pa-foto-img" ${mini ? `style="background-image:url('${mini}')"` : ''}
          role="button" tabindex="0" onclick="paVerFoto(${jsArg(a.id)}, ${i})">${mini ? '' : '&#128247;'}</span>
        <input class="pa-leg-existente" data-id="${esc(f.id)}" maxlength="140" value="${esc(f.legenda || '')}" placeholder="Legenda (opcional)"></div>`;
    }).join('')}</div>
    <span class="dica">Toque na foto para ver${(planoD().permissoes || {}).gerir ? ' ou remover' : ''}.</span></div>`;
}
const paLegendasExistentes = () => {
  const o = {};
  document.querySelectorAll('.pa-leg-existente').forEach((i) => { o[i.dataset.id] = i.value; });
  return Object.keys(o).length ? o : undefined;
};

/* Os campos da limpeza: zona, local e "aberta em". */
function paCamposLimpeza(a, prefixo) {
  const ex = PLANO.extras ? PLANO.extras() : null;
  if (!ex) return '';
  const d = planoD();
  return `<div class="campo-duplo">
      <div class="campo"><label>Zona</label><select id="${prefixo}-zona"><option value="">—</option>
        ${a && a.zona && !(ex.zonas || []).some((z) => z.zona === a.zona) ? `<option value="${esc(a.zona)}" selected>${esc(a.zona)}</option>` : ''}
        ${(ex.zonas || []).filter((z) => z.ativo || (a && a.zona === z.zona)).map((z) => `<option value="${esc(z.zona)}" ${a && a.zona === z.zona ? 'selected' : ''}>${esc(z.zona)}${z.descricao ? ' — ' + esc(z.descricao) : ''}</option>`).join('')}</select></div>
      <div class="campo"><label>Local exato</label><input id="${prefixo}-local" value="${esc(a ? a.local : '')}" placeholder="Ex.: Banheiro da central"></div>
    </div>
    <div class="campo"><label>Aberta em</label><input type="date" id="${prefixo}-aberta" value="${esc(a ? a.abertaEm : (d.hoje || (DADOS && DADOS.hoje) || ''))}"></div>`;
}
function paCamposLimpezaValores(params, prefixo) {
  if (!PLANO.extras) return;
  params.zona = val(prefixo + '-zona'); params.local = val(prefixo + '-local'); params.abertaEm = val(prefixo + '-aberta');
}
/* Levantamento (o "relatorio" a que a situacao pertence) e origem. */
function paCamposOrigem(a, prefixo) {
  const ex = PLANO.extras ? PLANO.extras() : null;
  const rels = ((planoD().modelo || {}).relatorios) || [];
  return `<div class="campo-duplo">
    <div class="campo"><label>Origem (opcional)</label>
      <input id="${prefixo}-origem" value="${a ? esc(a.origem) : ''}" ${ex ? 'list="' + prefixo + '-origens"' : ''}
             placeholder="${ex ? 'Ex.: Vistoria setorial' : 'Ex.: Reunião turno A — 05/09'}">
      ${ex ? `<datalist id="${prefixo}-origens">${(ex.origens || []).map((o) => `<option value="${esc(o)}">`).join('')}</datalist>` : ''}</div>
    ${paTemSituacoes(planoD()) ? `<div class="campo"><label>Levantamento (opcional)</label>
      <input id="${prefixo}-relatorio" maxlength="80" list="${prefixo}-relatorios" value="${a ? esc(a.relatorio || '') : ''}" placeholder="Ex.: Auditoria externa — nov/2026">
      <datalist id="${prefixo}-relatorios">${rels.map((r) => `<option value="${esc(r)}">`).join('')}</datalist></div>` : ''}
  </div>`;
}
/* Gerente / destinatario: quem tem "Ver e editar" no plano; os gerentes primeiro. O ultimo escolhido vem marcado. */
function paOpcoesDestinatario(atual) {
  const d = planoD(), eu = (d.permissoes || {}).email;
  const lembrado = lerLocal('gsl_pa_destinatario_' + PLANO.id) || '';
  const escolhido = atual || lembrado;
  const pessoas = (d.pessoas || []).filter((p) => p.edita !== false && p.abre !== false)
    .sort((x, y) => (Number(!!y.gerente) - Number(!!x.gerente)) || String(x.nome).localeCompare(String(y.nome)));
  if (atual && !pessoas.some((p) => p.email === atual)) pessoas.unshift({ email: atual, nome: paNome(atual), papel: 'sem acesso a esta tela' });
  return `<option value="">Escolha o gerente…</option>` + pessoas.map((p) => `<option value="${esc(p.email)}" ${p.email === escolhido ? 'selected' : ''}>
    ${esc(p.nome)}${p.email === eu ? ' (você)' : ''}${p.papel ? ' · ' + esc(p.papel) : ''}</option>`).join('');
}

/*
 * REGISTRAR SITUACAO (8.13). Titulo, prioridade, descricao em texto rico,
 * fotos com legenda e o gerente que da o parecer. Quem registra continua
 * vendo a situacao (fica citado como autor); o gerente recebe o e-mail.
 */
function formSituacao(id) {
  const d = planoD();
  const a = id ? planoAcaoPorId(id) : null;
  const semParecer = !a || !a.parecer;
  fotosLimpar('st', a ? a.id : '');
  abrirJanela(a ? 'Editar situação' : 'Nova situação', `
    <p class="pa-nota" style="margin:0 0 14px">Registre o que foi observado, com fotos do local. O gerente escolhido recebe um e-mail e dá o parecer:
      <b>Tratar / Incluir ação</b>, <b>Outro momento</b> ou <b>Nada a fazer</b>. A situação aparece só para você, para o gerente e, depois, para os responsáveis.</p>
    <div class="campo"><label for="st-titulo">Título da situação</label>
      <input id="st-titulo" maxlength="160" value="${a ? esc(a.acao) : ''}" placeholder="Ex.: Estrutura avariada no corredor B"></div>
    <div class="campo"><label>Prioridade</label>${paEscolhaPrioridade('st-prio', a && a.prioridade)}</div>
    <div class="pa-campo-rico campo"><div class="pa-rotulo-linha"><label for="st-descricao">Descrição da situação</label></div>
      ${paEditorHtml('st-descricao', a ? a.descricao : '', 'Descreva o que foi observado no local, impactos na operação, riscos ou detalhes importantes…')}</div>
    ${semParecer ? `<div class="campo"><label for="st-dest">Gerente / destinatário (dá o parecer)</label>
      <select id="st-dest">${paOpcoesDestinatario(a && a.destinatarioEmail)}</select></div>`
      : `<p class="pa-nota">Parecer dado por <b>${esc(paNome(a.parecerPor || a.destinatarioEmail))}</b>: o gerente não muda mais.</p>`}
    ${paCamposLimpeza(a, 'st')}
    <div class="campo"><label for="st-turno">Turno</label><select id="st-turno">
      ${(d.turnos || []).map((t) => `<option value="${esc(t)}" ${(a ? a.turno : 'Todos') === t ? 'selected' : ''}>${t === 'Todos' ? 'Geral (CD)' : esc(t)}</option>`).join('')}</select></div>
    ${paCamposOrigem(a, 'st')}
    ${paFotosExistentes(a)}
    ${fotosCampoHtml('st', a ? 'Acrescentar fotos (opcional)' : 'Evidências / fotos do local (opcional)')}`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    ${a && (d.permissoes || {}).gerir ? `<button class="botao-texto perigo" onclick="excluirAcao(${jsArg(a.id)}, true)">Excluir</button>` : ''}
    <button class="botao pa-amarelo" onclick="salvarSituacao(${a ? jsArg(a.id) : 'null'})">${a ? 'Salvar' : 'Registrar situação'}</button>`);
}

function salvarSituacao(id) {
  if (!fotosProntas('st')) return;
  const params = {
    titulo: val('st-titulo'), prioridade: paPrioridadeEscolhida('st-prio'), descricao: paEditorValor('st-descricao'),
    turno: val('st-turno'), origem: val('st-origem'), relatorio: val('st-relatorio'),
    fotos: fotosParaEnviar('st'), legendas: paLegendasExistentes()
  };
  if (el('st-dest')) params.destinatario = val('st-dest');
  paCamposLimpezaValores(params, 'st');
  if (id) params.id = id;
  if (!params.titulo) return avisar('Informe o título da situação.', true);
  if (el('st-dest') && !params.destinatario) return avisar('Escolha o gerente que vai dar o parecer.', true);
  if (params.destinatario) gravarLocal('gsl_pa_destinatario_' + PLANO.id, params.destinatario);
  agir(PLANO.acoes.situacao, params, id ? 'Situação atualizada' : 'Situação registrada').catch(() => {});
}

/*
 * ACAO DIRETA / EDITAR ACAO. Quando ja se sabe o que fazer (a reuniao de
 * turno): a acao nasce com responsaveis e prazo, sem esperar parecer. A
 * mesma janela edita a acao que veio de um parecer "Tratar".
 */
function formAcao(id) {
  const d = planoD();
  const a = id ? planoAcaoPorId(id) : null;
  // Responsavel que ja estava na acao e saiu da lista (perdeu o acesso): continua marcado.
  // Responsavel novo: so quem tem "Ver e editar" no plano (o responsavel conclui; com "Ver" nao conseguiria).
  const jaEram = (a && a.responsaveisEmails) || [];
  const pessoas = (d.pessoas || []).filter((p) => p.edita !== false || jaEram.indexOf(p.email) !== -1);
  jaEram.forEach((e) => {
    if (!pessoas.some((p) => p.email === e)) pessoas.push({ email: e, nome: e, turno: '', papel: 'sem acesso a esta tela' });
  });
  // Acao que veio da tabela antiga da limpeza: o responsavel era so um nome, sem e-mail.
  const antigo = a && !jaEram.length && a.responsavel ? a.responsavel : '';
  const modelo = paTemSituacoes(d);
  // A acao de antes guardava o "o que precisa ser feito" na descricao: aqui ele vai para o "Como sera tratado".
  const descricao = a ? (modelo && a.tratativaNaDescricao ? '' : a.descricao) : '';
  const tratativa = a ? (a.tratativa || (a.tratativaNaDescricao ? a.descricao : '')) : '';
  fotosLimpar('ac', a ? a.id : '');

  abrirJanela(a ? 'Editar ação' : 'Nova ação direta', `
    <p class="pa-nota" style="margin:0 0 14px">
      ${a ? '' : 'A ação direta nasce já tratada (sem esperar parecer) — para o que já foi decidido, como numa reunião de turno. '}
      O responsável recebe um e-mail com a ação e o prazo assim que você salvar.
      A ação aparece só para quem está citado nela (os responsáveis e quem for marcado num comentário):
      se você não estiver entre os responsáveis, ela sai da sua lista.</p>
    <div class="campo"><label for="ac-acao">Ação</label>
      <input id="ac-acao" value="${a ? esc(a.acao) : ''}" placeholder="${PLANO.extras ? 'Ex.: Banheiro da central sem papel toalha' : 'Ex.: Iluminação do Flow'}"></div>
    ${modelo ? `<div class="campo"><label>Prioridade</label>${paEscolhaPrioridade('ac-prio', a && a.prioridade)}</div>` : ''}
    <div class="pa-campo-rico campo"><div class="pa-rotulo-linha"><label for="ac-descricao">${modelo ? 'Descrição da situação (opcional)' : 'O que precisa ser feito'}</label></div>
      ${paEditorHtml('ac-descricao', descricao, PLANO.extras ? 'Ex.: dispenser vazio desde a ronda da manhã' : 'Ex.: as lâmpadas do corredor do Flow queimaram')}</div>
    ${modelo ? `<div class="pa-campo-rico campo"><div class="pa-rotulo-linha"><label for="ac-tratativa">Como será tratado / plano de ação</label></div>
      ${paEditorHtml('ac-tratativa', tratativa, PLANO.extras ? 'Ex.: repor o papel toalha e conferir o dispenser nas rondas' : 'Ex.: verificar e acompanhar a troca de todas as lâmpadas', true)}</div>` : ''}
    ${paCamposLimpeza(a, 'ac')}
    <div class="campo"><label>Responsáveis (marque um ou mais — ação conjunta)</label>
      ${antigo ? `<p class="dica" style="margin:0 0 8px">Registrado antes como <b>${esc(antigo)}</b>, sem e-mail — por isso, por enquanto, só a gestão do plano vê esta ação. Marque quem acompanha esta ação para ela aparecer para a pessoa (ou deixe como está).</p>` : ''}
      <input placeholder="Procurar pessoa…" oninput="const t=this.value.toLowerCase();document.querySelectorAll('.ac-pessoa').forEach((l)=>{l.style.display=l.textContent.toLowerCase().indexOf(t)===-1?'none':''})">
      <div class="ac-pessoas">
        ${pessoas.map((pe) => `
          <label class="marcador ac-pessoa"><input type="checkbox" class="ac-resp" value="${esc(pe.email)}"
            ${a && jaEram.indexOf(pe.email) !== -1 ? 'checked' : ''}>
            ${esc(pe.nome)}${pe.turno ? ' · turno ' + esc(pe.turno) : ''}${pe.papel ? ' · ' + esc(pe.papel) : ''}</label>`).join('')}
      </div></div>
    ${a && (a.marcados || []).length ? `<fieldset class="mencao-marcados"><legend>Marcados (veem e comentam esta ação)</legend>
      ${a.marcados.map((m) => `<label class="marcador"><input type="checkbox" class="ac-marcado" value="${esc(m.email)}" checked> ${esc(m.nome)}</label>`).join('')}
      <p class="dica">Desmarque quem foi marcado por engano: a pessoa deixa de ver esta ação.</p></fieldset>` : ''}
    <div class="campo-duplo">
      <div class="campo"><label for="ac-prazo">Entregar até</label>
        <input type="date" id="ac-prazo" value="${a ? esc(a.prazoISO) : ''}"></div>
      <div class="campo"><label for="ac-turno">Turno</label>
        <select id="ac-turno">
          ${(d.turnos || []).map((t) => `<option ${(a ? a.turno : 'Todos') === t ? 'selected' : ''}>${esc(t)}</option>`).join('')}
        </select></div>
    </div>
    ${paCamposOrigem(a, 'ac')}
    ${paFotosExistentes(a)}
    ${fotosCampoHtml('ac', a ? 'Acrescentar fotos (opcional)' : 'Fotos (opcional) — do que foi encontrado')}`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    ${a ? `<button class="botao-texto perigo" onclick="excluirAcao(${jsArg(a.id)})">Excluir</button>` : ''}
    <button class="botao" onclick="salvarAcao(${a ? jsArg(a.id) : 'null'})">${a ? 'Salvar' : 'Criar ação'}</button>`);
}

function salvarAcao(id) {
  if (!fotosProntas('ac')) return;
  const a = id ? planoAcaoPorId(id) : null;
  const modelo = paTemSituacoes(planoD());
  const params = {
    acao: val('ac-acao'),
    descricao: paEditorValor('ac-descricao'),
    rico: true,
    responsaveisEmails: [...document.querySelectorAll('.ac-resp')].filter((c) => c.checked).map((c) => c.value),
    prazo: val('ac-prazo'),
    turno: val('ac-turno'),
    origem: val('ac-origem'),
    fotos: fotosParaEnviar('ac')
  };
  if (modelo) {
    params.prioridade = paPrioridadeEscolhida('ac-prio');
    params.tratativa = paEditorValor('ac-tratativa');
    params.relatorio = val('ac-relatorio');
    params.legendas = paLegendasExistentes();
  }
  paCamposLimpezaValores(params, 'ac');
  // Quem a gestao desmarcou (19/10): vai so quem saiu — o servidor so tira, e quem outra pessoa marcou com o formulario aberto fica.
  if (document.querySelector('.ac-marcado')) params.desmarcados = [...document.querySelectorAll('.ac-marcado')].filter((c) => !c.checked).map((c) => c.value);
  if (id) params.id = id;
  const antigo = a && !(a.responsaveisEmails || []).length ? a.responsavel : '';
  if (!params.responsaveisEmails.length) {
    if (!antigo) return avisar('Marque pelo menos um responsável.', true);
    params.responsavel = antigo;
  }
  agir(PLANO.acoes.salvar, params, id ? 'Ação atualizada' : (params.responsaveisEmails.length > 1 ? 'Ação criada — responsáveis avisados' : 'Ação criada — responsável avisado'))
    .catch(() => {});
}

/*
 * O PARECER DO GERENTE (8.13). Tratar: como sera tratado, responsaveis e
 * prazo — a situacao vira acao. Outro momento: data para rever (opcional).
 * Nada a fazer: o porque (opcional). So o gerente destinatario decide.
 */
function formParecer(id, parecer) {
  const a = planoAcaoPorId(id); if (!a) return;
  const d = planoD();
  const nomes = { TRATAR: 'Tratar / Incluir ação', DEPOIS: 'Deixar para outro momento', NADA: 'Nada a fazer' };
  const jaEram = a.responsaveisEmails || [];
  const pessoas = (d.pessoas || []).filter((p) => p.edita !== false || jaEram.indexOf(p.email) !== -1);
  const tratativa = a.tratativa || (a.tratativaNaDescricao ? a.descricao : '');
  let corpo = `<p class="pa-nota" style="margin:0 0 12px"><b>${esc(a.acao)}</b>${a.autorEmail ? ' — registrada por ' + esc(paNome(a.autorEmail)) : ''}.</p>`;
  if (parecer === 'TRATAR') {
    corpo += `<div class="pa-campo-rico campo"><div class="pa-rotulo-linha"><label for="pr-tratativa">Como será tratado / plano de ação</label></div>
        ${paEditorHtml('pr-tratativa', tratativa, 'Descreva qual ação será tomada para resolver ou tratar esta situação…', true)}</div>
      <div class="campo"><label>Responsáveis (marque um ou mais — eles recebem o e-mail e concluem a ação)</label>
        <input placeholder="Procurar pessoa…" oninput="const t=this.value.toLowerCase();document.querySelectorAll('.pr-pessoa').forEach((l)=>{l.style.display=l.textContent.toLowerCase().indexOf(t)===-1?'none':''})">
        <div class="ac-pessoas">${pessoas.map((pe) => `
          <label class="marcador pr-pessoa"><input type="checkbox" class="pr-resp" value="${esc(pe.email)}" ${jaEram.indexOf(pe.email) !== -1 ? 'checked' : ''}>
            ${esc(pe.nome)}${pe.turno ? ' · turno ' + esc(pe.turno) : ''}${pe.papel ? ' · ' + esc(pe.papel) : ''}</label>`).join('')}</div></div>
      <div class="campo-duplo">
        <div class="campo"><label for="pr-prazo">Prazo</label><input type="date" id="pr-prazo" value="${esc(a.prazoISO || '')}"></div>
        <div class="campo"><label for="pr-turno">Turno</label><select id="pr-turno">
          ${(d.turnos || []).map((t) => `<option value="${esc(t)}" ${(a.turno || 'Todos') === t ? 'selected' : ''}>${t === 'Todos' ? 'Geral (CD)' : esc(t)}</option>`).join('')}</select></div>
      </div>`;
  } else if (parecer === 'DEPOIS') {
    corpo += `<div class="campo"><label for="pr-rever">Rever em (opcional)</label><input type="date" id="pr-rever" value="${esc(a.reverEm || '')}"></div>`;
  }
  if (parecer !== 'TRATAR') {
    corpo += `<div class="campo"><label for="pr-obs">${parecer === 'NADA' ? 'Por que não há nada a fazer (opcional)' : 'Observação (opcional)'}</label>
      <textarea id="pr-obs" rows="3" maxlength="1000">${esc(a.parecer === parecer ? a.parecerObs || '' : '')}</textarea></div>`;
  }
  const retirar = a.parecer && a.situacao !== 'CONCLUIDA' && a.parecer !== 'TRATAR';
  abrirJanela('Parecer: ' + nomes[parecer], corpo, `
    <button class="botao secundario" onclick="fecharJanela()">Voltar</button>
    ${retirar ? `<button class="botao-texto" onclick="agir(${planoAcao('parecer')},{id:${jsArg(id)},parecer:''},'Parecer retirado').catch(()=>{})">Voltar para “Sem definição”</button>` : ''}
    <button class="botao${parecer === 'DEPOIS' ? ' pa-amarelo' : ''}" onclick="enviarParecer(${jsArg(id)}, ${jsArg(parecer)})">Registrar parecer</button>`);
}

function enviarParecer(id, parecer) {
  const params = { id: id, parecer: parecer };
  if (parecer === 'TRATAR') {
    params.tratativa = paEditorValor('pr-tratativa');
    params.responsaveisEmails = [...document.querySelectorAll('.pr-resp')].filter((c) => c.checked).map((c) => c.value);
    params.prazo = val('pr-prazo'); params.turno = val('pr-turno');
    if (!params.tratativa) return avisar('Descreva como a situação será tratada.', true);
    if (!params.responsaveisEmails.length) return avisar('Marque pelo menos um responsável.', true);
    if (!params.prazo) return avisar('Informe o prazo.', true);
  } else {
    params.observacao = val('pr-obs');
    if (parecer === 'DEPOIS') params.reverEm = val('pr-rever');
  }
  agir(PLANO.acoes.parecer, params, 'Parecer registrado').catch(() => {});
}


/* ---------- RELATORIO (PDF A4) NO MODELO DO GERENTE ---------- */

/*
 * "Relatorio de Ocorrencias e Acoes": as situacoes escolhidas (as da tela,
 * as de um periodo de registro ou as de um levantamento) numa folha A4 em
 * pe, no desenho do relatorio do gerente — faixa azul com o circulo amarelo,
 * listras verde e amarela, logo, os campos de identificacao, o placar, os
 * cartoes numerados com as fotos e o parecer. A janela abre no clique (o
 * navegador nao barra) e as fotos chegam depois; "Imprimir / Salvar como PDF".
 */
function paFormRelatorio() {
  const d = planoD(), f = PLANO.local || {};
  const naTela = planoFiltrarLista(d.lista || [], f).length;
  const rels = ((d.modelo || {}).relatorios) || [];
  const eu = (SESSAO && SESSAO.usuario && (SESSAO.usuario.nome || SESSAO.usuario.email)) || '';
  const dests = {};
  (d.lista || []).forEach((a) => { if (a.destinatarioEmail) dests[a.destinatarioEmail] = (dests[a.destinatarioEmail] || 0) + 1; });
  const gerente = Object.keys(dests).sort((x, y) => dests[y] - dests[x])[0];
  const hoje = d.hoje || (DADOS && DADOS.hoje) || new Date().toISOString().slice(0, 10);
  abrirJanela('Relatório de ocorrências e ações (PDF)', `
    <p class="pa-nota" style="margin:0 0 12px">Sai no modelo do relatório da gerência, em A4: cabeçalho Bartofil, identificação, placar e os cartões com fotos e parecer.</p>
    <div class="campo"><label>Quais situações</label>
      <label class="marcador"><input type="radio" name="rel-quais" value="tela" checked> As da tela, com os filtros de agora (${naTela})</label>
      <label class="marcador"><input type="radio" name="rel-quais" value="periodo"> Registradas num período</label>
      <div class="campo-duplo" style="margin:4px 0 6px 26px">
        <div class="campo"><label for="rel-de">De</label><input type="date" id="rel-de" value="${esc(hoje.slice(0, 8) + '01')}" onchange="document.querySelector('input[name=rel-quais][value=periodo]').checked=true"></div>
        <div class="campo"><label for="rel-ate">Até</label><input type="date" id="rel-ate" value="${esc(hoje)}" onchange="document.querySelector('input[name=rel-quais][value=periodo]').checked=true"></div></div>
      ${rels.length ? `<label class="marcador"><input type="radio" name="rel-quais" value="levantamento"> Do levantamento
        <select id="rel-levantamento" style="width:auto;margin-left:6px" onchange="document.querySelector('input[name=rel-quais][value=levantamento]').checked=true">
          ${rels.map((r) => `<option value="${esc(r)}">${esc(r)}</option>`).join('')}</select></label>` : ''}
    </div>
    <div class="campo"><label for="rel-titulo">Título</label><input id="rel-titulo" value="Relatório de Ocorrências e Ações"></div>
    <div class="campo"><label for="rel-sub">Subtítulo</label><input id="rel-sub" value="Levantamento de situações · ${esc(PLANO.id === 'LIMPEZA' ? 'Limpeza CD' : 'Centro de Distribuição')}"></div>
    <div class="campo-duplo">
      <div class="campo"><label for="rel-unidade">Unidade / setor</label><input id="rel-unidade" value="${esc((d.modelo && d.modelo.filial) || '')}"></div>
      <div class="campo"><label for="rel-data">Data</label><input type="date" id="rel-data" value="${esc(hoje)}"></div></div>
    <div class="campo-duplo">
      <div class="campo"><label for="rel-autor">Elaborado por</label><input id="rel-autor" value="${esc(eu)}"></div>
      <div class="campo"><label for="rel-gerente">Gerente / destinatário</label><input id="rel-gerente" value="${esc(gerente ? paNome(gerente) : '')}"></div></div>
    <label class="marcador"><input type="checkbox" id="rel-fotos" checked> Com as fotos (o relatório espera elas chegarem)</label>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="paImprimir()">Gerar relatório</button>`);
}

function paImprimir() {
  const d = planoD(), f = PLANO.local || {};
  const quais = (document.querySelector('input[name="rel-quais"]:checked') || {}).value || 'tela';
  let lista;
  if (quais === 'periodo') {
    const de = val('rel-de'), ate = val('rel-ate');
    const iso = (a) => { const m = /^(\d{2})\/(\d{2})\/(\d{4})/.exec(String(a.criadoEm || '')); return m ? m[3] + '-' + m[2] + '-' + m[1] : ''; };
    lista = (d.lista || []).filter((a) => { const x = iso(a); return x && (!de || x >= de) && (!ate || x <= ate); });
  } else if (quais === 'levantamento') {
    const r = val('rel-levantamento');
    lista = (d.lista || []).filter((a) => a.relatorio === r);
  } else lista = planoFiltrarLista(d.lista || [], f);
  if (!lista.length) return avisar('Nenhuma situação para o relatório com esta escolha.', true);
  const cab = { titulo: val('rel-titulo') || 'Relatório de Ocorrências e Ações', sub: val('rel-sub'), unidade: val('rel-unidade'),
                data: val('rel-data'), autor: val('rel-autor'), gerente: val('rel-gerente'), fotos: !!(el('rel-fotos') || {}).checked };
  const numeros = paNumeros(d.lista || []);
  lista = lista.slice().sort((a, b) => (numeros[a.id] || 0) - (numeros[b.id] || 0));
  const w = window.open('', '_blank');
  if (!w) return avisar('O navegador bloqueou a janela do relatório. Libere pop-ups para este site e tente de novo.', true);
  fecharJanela();
  w.document.open();
  w.document.write('<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>Preparando o relatório…</title></head>' +
    '<body style="font-family:Arial,sans-serif;color:#111785;padding:40px">Preparando o relatório…</body></html>');
  w.document.close();
  paMontarRelatorio(w, lista, cab, numeros).catch((e) => {
    try { w.document.body.textContent = 'Não foi possível montar o relatório: ' + (e.message || e); } catch (x) { /* janela fechada */ }
  });
}

async function paMontarRelatorio(w, lista, cab, numeros) {
  const fotos = {};
  if (cab.fotos && !CANAL_BARRADO) {
    const todas = [];
    lista.forEach((a) => (a.fotos || []).forEach((f) => todas.push({ a: a, f: f })));
    let feitas = 0;
    const aviso = () => { try { w.document.body.textContent = 'Preparando o relatório… fotos ' + feitas + ' de ' + todas.length; } catch (e) { /* fechada */ } };
    aviso();
    const fila = todas.slice();
    const trabalhador = async () => {
      while (fila.length) {
        const x = fila.shift();
        try {
          let url = FOTO_CACHE.get(x.f.id);
          if (!url) {
            const r = await executarAcaoSrv(PLANO.acoes.foto, { id: x.a.id, arquivo: x.f.id });
            url = 'data:' + (r.tipo || 'image/jpeg') + ';base64,' + r.dados;
          }
          if (!ehUrlHeic(url)) fotos[x.f.id] = await paReduzir(url, 900);
        } catch (e) { /* a foto fica de fora, com o aviso no cartao */ }
        feitas++; aviso();
      }
    };
    await Promise.all([trabalhador(), trabalhador(), trabalhador()]);
  }
  if (w.closed) return;
  w.document.open();
  w.document.write(paHtmlRelatorio(lista, cab, numeros, fotos));
  w.document.close();
  w.focus();
  setTimeout(() => { try { w.print(); } catch (e) { /* janela fechada */ } }, 600);
}

function paHtmlRelatorio(lista, cab, numeros, fotos) {
  const logo = typeof pnLogoMarca === 'function' ? pnLogoMarca() : '';
  const conta = (k) => lista.filter((a) => paParecerDe(a) === k).length;
  const tratar = conta('TRATAR'), depois = conta('DEPOIS'), nada = conta('NADA'), pend = conta('pendente');
  const filial = (SESSAO && SESSAO.filial && SESSAO.filial.nome) || '';
  const gerado = new Date().toLocaleString('pt-BR');
  const campo = (rot, v) => `<div class="field"><label>${rot}</label><span>${esc(v || '—')}</span></div>`;
  const opc = (a, k, rot) => `<div class="mgr-opt${(a.parecer === undefined ? 'TRATAR' : a.parecer) === k ? ' sel-' + k : ''}"><span class="bub">&#10003;</span><span>${rot}</span></div>`;
  const cartoes = lista.map((a) => {
    const parecer = a.parecer === undefined ? 'TRATAR' : (a.parecer || '');
    const desc = a.tratativaNaDescricao ? '' : a.descricao;
    const trat = a.tratativa || (a.tratativaNaDescricao ? a.descricao : '');
    const fs = a.fotos || [];
    const com = fs.filter((f) => fotos[f.id]);
    return `<div class="q status-${parecer || 'sem'}">
      <div class="qh"><div class="num">${numeros[a.id] || ''}</div><div class="sit">${esc(a.acao)}
        <small>${[a.autorEmail ? 'Registrada por ' + esc(paNome(a.autorEmail)) : '', a.criadoEm ? 'em ' + esc(String(a.criadoEm).slice(0, 10)) : '',
          a.zona || a.local ? esc([a.zona, a.local].filter(Boolean).join(' · ')) : '', a.relatorio ? esc(a.relatorio) : ''].filter(Boolean).join(' · ')}</small></div>
        <span class="prio p-${esc(a.prioridade || 'NORMAL')}">${PA_NOME_PRIO[a.prioridade] || 'Normal'}</span></div>
      ${desc ? `<div class="lbl">Descrição da situação</div><div class="rich">${paRico(desc)}</div>` : ''}
      ${fs.length ? `<div class="lbl">Evidências / fotos do local (${fs.length})</div>
        ${com.length ? `<div class="grid">${com.map((f) => `<figure><img src="${fotos[f.id]}" alt="">${f.legenda ? '<figcaption>' + esc(f.legenda) + '</figcaption>' : ''}</figure>`).join('')}</div>` : ''}
        ${com.length < fs.length ? `<div class="obs">${fs.length - com.length} foto(s) não incluída(s) — veja no GSL.</div>` : ''}` : ''}
      <div class="mgr"><div class="mgr-h">Parecer / decisão do gerente${a.parecerPor ? ' <small>· ' + esc(paNome(a.parecerPor)) + (a.parecerEm ? ' · ' + esc(String(a.parecerEm).slice(0, 10)) : '') + '</small>' : ''}</div>
        <div class="mgr-opts">${opc(a, 'TRATAR', 'Tratar / Incluir ação')}${opc(a, 'DEPOIS', 'Deixar para outro momento')}${opc(a, 'NADA', 'Não fazer nada')}</div>
        ${parecer === 'TRATAR' ? `<div class="plan"><div class="lbl">Como será tratado / plano de ação</div><div class="rich">${trat ? paRico(trat) : '—'}</div>
          <div class="meta"><span><b>Responsável:</b> ${esc(a.responsavel || '—')}</span><span><b>Prazo:</b> ${esc(a.prazo || '—')}</span>
          <span><b>Situação:</b> ${esc(a.status)}${a.situacao === 'CONCLUIDA' && a.concluidoEm ? ' em ' + esc(String(a.concluidoEm).slice(0, 10)) : ''}</span></div></div>` : ''}
        ${parecer === 'DEPOIS' ? `<div class="obs">Postergada${a.reverEm ? ' — rever em ' + paData(a.reverEm) : ''}.${a.parecerObs ? ' ' + esc(a.parecerObs) : ''}</div>` : ''}
        ${parecer === 'NADA' && a.parecerObs ? `<div class="obs">${esc(a.parecerObs)}</div>` : ''}
        ${!parecer ? `<div class="obs">Sem definição${a.destinatarioEmail ? ' — aguardando ' + esc(paNome(a.destinatarioEmail)) : ''}.</div>` : ''}
      </div></div>`;
  }).join('');
  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(cab.titulo)} · Bartofil</title>
  <link rel="stylesheet" href="${'https:'}${'/'}${'/'}fonts.googleapis.com/css2?family=Poppins:wght@600;700;800&family=Inter:wght@400;500;600;700&display=swap">
  <style>${PA_CSS_RELATORIO}</style></head><body>
  <div class="barra"><button onclick="window.print()">Imprimir / Salvar como PDF</button></div>
  <div class="sheet">
    <div class="top"><div class="top-left"><span class="tag">BARTOFIL · RELATÓRIO OPERACIONAL</span>
      <h1>${esc(cab.titulo)}</h1><div class="subt">${esc(cab.sub || '')}</div><div class="stripe"><i></i><i></i></div></div>
      ${logo ? `<div class="top-logo"><img src="${esc(logo)}" alt="Bartofil Distribuidora"></div>` : ''}</div>
    <div class="ident">${campo('Unidade / setor', cab.unidade)}${campo('Data', paData(cab.data))}${campo('Elaborado por', cab.autor)}${campo('Gerente / destinatário', cab.gerente)}</div>
    <div class="score">
      <div><b>Total registrado</b><span class="val">${lista.length}</span>situação(ões)</div>
      <div class="sc-green"><b>Tratar / Ação</b><span class="val">${tratar}</span>com plano definido</div>
      <div><b>Outro momento</b><span class="val">${depois}</span>postergada(s)</div>
      <div class="sc-last"><b>Sem ação / Pendente</b><span class="val">${nada + pend}</span>aguardando ou encerrada</div></div>
    <div class="part"><div class="pn">§</div><div><h2>Situações levantadas e parecer da gerência</h2>
      <p>Cada ocorrência com as fotos do local e, abaixo, a tratativa definida pelo gerente.</p></div>
      <div class="pp">${tratar + depois + nada} / ${lista.length} avaliadas</div></div>
    ${cartoes}
    <div class="end"><b>Bartofil · Registro interno de acompanhamento</b><span>GSL Bartofil · ${esc(filial)} · gerado em ${esc(gerado)}</span></div>
  </div></body></html>`;
}

/* O CSS da folha (o do relatorio do gerente, enxuto). */
const PA_CSS_RELATORIO = [
  '@page { size: A4; margin: 12mm 12mm 14mm 12mm; }',
  '* { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }',
  'body { font-family: Inter, Arial, sans-serif; color: #1b1b33; font-size: 10.5pt; line-height: 1.4; background: #e9ebf3; margin: 0; padding: 16px 10px 40px; }',
  'h1, h2, .num, .val, .tag, .sit, .mgr-h, .prio, .pp, .pn, .field label, .lbl, .mgr-opt { font-family: Poppins, Arial, sans-serif; }',
  '.barra { text-align: center; margin-bottom: 12px; } .barra button { font: 700 13px Poppins, Arial, sans-serif; padding: 9px 18px; background: #111785; color: #fff; border: 0; border-bottom: 3px solid #1e9e57; border-radius: 9px; cursor: pointer; }',
  '.sheet { max-width: 196mm; margin: 0 auto; background: #fff; padding: 13mm 12mm 15mm; border-radius: 16px; box-shadow: 0 6px 24px rgba(17,23,133,.09); }',
  '.top { background: linear-gradient(120deg, #0d126b 0%, #111785 45%, #1e27a8 100%); color: #fff; border-radius: 16px; padding: 18px 22px; position: relative; overflow: hidden; display: flex; align-items: center; justify-content: space-between; gap: 18px; }',
  '.top::after { content: ""; position: absolute; right: -45px; top: -45px; width: 175px; height: 175px; border-radius: 50%; background: #fbb917; opacity: .95; }',
  '.top-left { position: relative; z-index: 1; flex: 1; min-width: 0; }',
  '.tag { display: inline-block; background: #fbb917; color: #111785; font-weight: 700; font-size: 8.5pt; padding: 3px 11px; border-radius: 20px; letter-spacing: .5px; }',
  'h1 { font-size: 20pt; font-weight: 800; line-height: 1.15; margin: 8px 0 4px; }',
  '.subt { font-size: 10pt; opacity: .92; }',
  '.stripe { display: flex; gap: 6px; margin-top: 12px; } .stripe i { height: 5px; width: 62px; border-radius: 3px; background: #1e9e57; display: inline-block; } .stripe i + i { background: #fbb917; }',
  '.top-logo { position: relative; z-index: 1; background: #111785; border-radius: 14px; padding: 6px; box-shadow: 0 4px 14px rgba(0,0,0,.22); border: 2px solid rgba(255,255,255,.16); }',
  '.top-logo img { width: 120px; height: auto; display: block; border-radius: 8px; }',
  '.ident { display: grid; grid-template-columns: 1.6fr 1fr 1.4fr 1.4fr; gap: 10px 14px; margin: 14px 0 12px; }',
  '.field { border-bottom: 1.6px solid #111785; padding: 4px 0 3px; display: flex; flex-direction: column; }',
  '.field label { font-size: 7.8pt; color: #666b80; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; margin-bottom: 2px; }',
  '.field span { font-size: 10pt; font-weight: 600; }',
  '.score { display: grid; grid-template-columns: repeat(4, 1fr); border: 1.5px solid #111785; border-radius: 12px; overflow: hidden; margin-bottom: 14px; }',
  '.score div { padding: 7px 11px; border-right: 1px solid #d8dbea; font-size: 8.5pt; color: #666b80; background: #fff; } .score div.sc-last { border-right: 0; background: #fff4d1; } .score div.sc-green { background: #e3f6eb; }',
  '.score b { display: block; color: #111785; font-size: 9.5pt; font-family: Poppins, Arial, sans-serif; } .val { display: block; font-weight: 800; font-size: 14pt; color: #1b1b33; line-height: 1.15; margin-top: 2px; } .sc-green .val { color: #1e9e57; }',
  '.part { display: flex; align-items: center; gap: 14px; border-radius: 14px; padding: 10px 16px; margin: 12px 0; background: linear-gradient(120deg, #0d126b, #111785 50%, #1e27a8); color: #fff; break-after: avoid; }',
  '.pn { font-weight: 800; font-size: 20pt; line-height: 1; opacity: .92; } .part h2 { margin: 0; font-size: 13.5pt; line-height: 1.15; } .part p { margin: 2px 0 0; font-size: 8.8pt; opacity: .9; }',
  '.pp { margin-left: auto; font-weight: 700; font-size: 9pt; background: rgba(255,255,255,.18); padding: 4px 11px; border-radius: 20px; white-space: nowrap; }',
  '.q { border: 1.5px solid #d8dbea; border-left: 5px solid #4fb6e8; border-radius: 14px; padding: 13px 15px 14px; margin: 12px 0; background: #fff; break-inside: avoid; page-break-inside: avoid; }',
  '.q.status-TRATAR { border-left-color: #1e9e57; } .q.status-DEPOIS { border-left-color: #fbb917; } .q.status-NADA { border-left-color: #9aa0b8; }',
  '.qh { display: flex; align-items: center; gap: 10px; } .num { flex: 0 0 30px; height: 30px; border-radius: 8px; background: #111785; color: #fff; font-weight: 700; display: flex; align-items: center; justify-content: center; font-size: 11.5pt; }',
  '.sit { flex: 1; min-width: 0; font-weight: 700; font-size: 11.5pt; color: #111785; } .sit small { display: block; font: 400 8.3pt Inter, Arial, sans-serif; color: #666b80; }',
  '.prio { font-size: 8pt; font-weight: 700; border-radius: 20px; padding: 4px 10px; border: 1px solid #d8dbea; } .p-ALTA { background: #fdeaea; color: #d93a3a; border-color: #f3baba; } .p-MEDIA { background: #fff4d1; color: #8a5d00; border-color: #f4d47c; } .p-NORMAL { background: #e6f5fd; color: #156691; border-color: #b7e1f7; }',
  '.lbl { display: block; font-size: 8pt; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; color: #666b80; margin: 10px 0 4px; }',
  '.rich { border: 1px solid #d8dbea; border-radius: 8px; padding: 7px 10px; background: #fcfcfe; font-size: 10pt; line-height: 1.45; } .rich mark { background: #fff4d1; padding: 0 3px; border-radius: 3px; } .rich ul, .rich ol { margin: 4px 0 4px 20px; padding: 0; } .rich p { margin: 0 0 4px; }',
  '.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; } figure { margin: 0; border: 1.3px solid #d8dbea; border-radius: 10px; overflow: hidden; background: #f4f5fb; break-inside: avoid; }',
  'figure img { width: 100%; height: 120px; object-fit: cover; display: block; } figcaption { font-size: 8.5pt; padding: 4px 7px; border-top: 1px solid #d8dbea; background: #fff; min-height: 18px; } figcaption:empty { display: none; }',
  '.mgr { margin-top: 12px; background: #f4f5fb; border: 1.4px solid #d8dbea; border-radius: 12px; padding: 10px 12px; } .mgr-h { font-weight: 700; font-size: 9pt; color: #111785; text-transform: uppercase; letter-spacing: .4px; margin-bottom: 8px; } .mgr-h small { text-transform: none; color: #666b80; font-weight: 500; letter-spacing: 0; }',
  '.mgr-opts { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; } .mgr-opt { display: flex; align-items: center; gap: 8px; padding: 7px 10px; border-radius: 10px; border: 1.6px solid #d8dbea; background: #fff; font-weight: 600; font-size: 9pt; }',
  '.bub { flex: 0 0 18px; height: 18px; border: 1.8px solid #111785; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 8pt; font-weight: 800; color: transparent; }',
  '.sel-TRATAR { background: #e3f6eb; border-color: #1e9e57; color: #116637; } .sel-TRATAR .bub { background: #1e9e57; border-color: #1e9e57; color: #fff; }',
  '.sel-DEPOIS { background: #fff4d1; border-color: #e09e00; color: #704c00; } .sel-DEPOIS .bub { background: #fbb917; border-color: #c98d00; color: #111785; }',
  '.sel-NADA { background: #ebedf5; border-color: #7c829c; color: #3a3f54; } .sel-NADA .bub { background: #666b80; border-color: #666b80; color: #fff; }',
  '.plan { margin-top: 10px; background: #e3f6eb; border: 1.5px solid #9ad9b6; border-left: 4px solid #1e9e57; border-radius: 10px; padding: 9px 12px; } .plan .lbl { color: #136b3a; margin-top: 0; } .plan .rich { background: #fff; border-color: #9ad9b6; }',
  '.meta { display: flex; flex-wrap: wrap; gap: 4px 16px; margin-top: 7px; font-size: 9pt; } .obs { margin-top: 8px; font-size: 9pt; color: #4a4f6a; }',
  '.end { text-align: center; margin-top: 16px; padding: 10px 14px; break-inside: avoid; border-radius: 14px; background: #111785; color: #fff; } .end b { font-size: 11pt; display: block; font-family: Poppins, Arial, sans-serif; } .end span { font-size: 8.8pt; opacity: .88; }',
  '@media screen and (max-width: 720px) { .ident, .score { grid-template-columns: 1fr 1fr; } .mgr-opts { grid-template-columns: 1fr; } .grid { grid-template-columns: 1fr 1fr; } }',
  '@media print { body { background: #fff; padding: 0; } .sheet { max-width: 100%; margin: 0; padding: 0; box-shadow: none; border-radius: 0; } .barra { display: none; } }'
].join('\n');


function excluirAcao(id, situacao) {
  abrirJanela(situacao ? 'Excluir situação' : 'Excluir ação', situacao ? `
    <p style="line-height:1.7">Isso apaga a situação do plano, com as fotos e o histórico dela fora da lista.
       Se ela só não precisa de ação, o gerente pode dar o parecer <b>Nada a fazer</b> — assim ela fica registrada.</p>` : `
    <p style="line-height:1.7">Isso apaga a ação do plano. Se ela apenas deixou de fazer
       sentido, prefira <b>Cancelar</b> — assim ela some das contagens mas fica no histórico.</p>`, `
    <button class="botao secundario" onclick="${situacao ? 'formSituacao' : 'formAcao'}(${jsArg(id)})">Voltar</button>
    <button class="botao perigo" onclick="agir(${planoAcao('excluir')},{id:${jsArg(id)}},${situacao ? "'Situação excluída'" : "'Ação excluída'"}).catch(()=>{})">Excluir mesmo assim</button>`);
}

function formConcluirAcao(id) {
  const a = planoAcaoPorId(id) || {};
  fotosLimpar('cc', id);
  abrirJanela('Concluir ação', `
    <div class="campo"><label>Ação</label><input value="${esc(a.acao || '')}" readonly></div>
    <div class="campo"><label>O que foi feito (opcional)</label>
      <textarea id="cc-obs" rows="3" placeholder="Ex.: 14 lâmpadas trocadas, conferido com o Márcio em 24/09"></textarea></div>
    ${fotosCampoHtml('cc', 'Foto de como ficou (opcional)')}`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="fotosProntas('cc') && agir(${planoAcao('concluir')},{id:${jsArg(id)},observacao:val('cc-obs'),fotos:fotosParaEnviar('cc')},'Ação concluída').catch(()=>{})">Concluir</button>`);
}

function formCancelarAcao(id) {
  abrirJanela('Cancelar ação', `
    <div class="campo"><label>Motivo</label>
      <textarea id="ca-motivo" rows="3" placeholder="Por que esta ação não vai mais acontecer"></textarea></div>`, `
    <button class="botao secundario" onclick="fecharJanela()">Voltar</button>
    <button class="botao" onclick="agir(${planoAcao('cancelar')},{id:${jsArg(id)},motivo:val('ca-motivo')},'Ação cancelada').catch(()=>{})">Cancelar ação</button>`);
}

/* ---------- FOTOS NA AÇÃO E NO COMENTÁRIO (4.2.2) ----------
   A foto é reduzida aqui no navegador (lado maior 1600 px, JPEG) antes de
   subir: a do celular tem 4-8 MB e vira ~300 KB, sem perder o que importa.
   Fica no Drive, na pasta da ação (Anexos/ACOES/<id>), como os outros
   anexos do GSL. Para ver, a foto passa pelo servidor, que confere se a
   pessoa enxerga aquela ação. A HEIC do iPhone, que o Chrome não abre,
   passa antes pelo servidor, que a converte (19/10). */
const FOTOS_PENDENTES = {};          // por formulário: 'ac' (ação), 'cm' (comentário), 'cc' (conclusão)
const FOTOS_PREPARANDO = {};         // formulário com foto ainda sendo reduzida
const FOTO_LADO_MAX = 1600;
const fotosPorVez = () => (planoD().fotos && planoD().fotos.porVez) || 5;
const FOTOS_CONTEXTO = {};           // onde a foto vai: o servidor so converte a HEIC para quem pode anexar ali

function fotosLimpar(chave, idAcao) {
  FOTOS_PENDENTES[chave] = []; FOTOS_PREPARANDO[chave] = 0;
  FOTOS_CONTEXTO[chave] = { plano: PLANO.id, uso: chave, id: idAcao || '' };
}
/* Foto ainda sendo reduzida: nao envia pela metade — avisa e a janela fica aberta. */
function fotosProntas(chave) {
  if (!FOTOS_PREPARANDO[chave]) return true;
  avisar('Espere as fotos terminarem de ser preparadas e clique de novo.', true);
  return false;
}
function fotosParaEnviar(chave) {
  // 8.13: a legenda de cada foto vai junto (o servidor guarda em LEGENDAS).
  return (FOTOS_PENDENTES[chave] || []).map((f) => ({ nome: f.nome, tipo: f.tipo, dados: f.dados, legenda: f.legenda || '' }));
}

/*
 * No Windows o filtro "Arquivos de imagem" do Chrome nao lista .heic: as
 * extensoes vao no accept. No celular e no tablet, nao: no Android a extensao
 * derruba o seletor de fotos do sistema (e o HEIF aparece nele assim mesmo);
 * no iPhone e no iPad ela pode fazer o iOS mandar a HEIC crua em vez de
 * converter para JPEG sozinho. O iPadOS se diz Mac: o toque (maxTouchPoints)
 * o separa do Mac de verdade. O asterisco vai com a barra invertida: regra do
 * HtmlService.
 */
const ACEITA_FOTOS = (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ||
  (/Macintosh/i.test(navigator.userAgent) && navigator.maxTouchPoints > 1)) ? 'image/\*' : 'image/\*,.heic,.heif';
const fotosDica = () => 'até ' + fotosPorVez() + ' por vez · JPG, PNG ou HEIC';

function fotosCampoHtml(chave, rotulo) {
  return `<div class="campo"><label>${esc(rotulo)}</label>
    <label class="botao secundario fotos-escolher">&#128247; Escolher ou tirar foto
      <input type="file" id="${chave}-fotos" accept="${ACEITA_FOTOS}" multiple style="display:none"
             onchange="fotosEscolhidas(this, ${jsArg(chave)})"></label>
    <span class="dica" id="${chave}-fotos-situacao" role="status" aria-live="polite">${fotosDica()}</span>
    <div class="fotos-previas" id="${chave}-previas"></div></div>`;
}

async function fotosEscolhidas(input, chave) {
  const lista = FOTOS_PENDENTES[chave] = FOTOS_PENDENTES[chave] || [];
  const arquivos = [...(input.files || [])];
  input.value = '';
  const situacao = el(chave + '-fotos-situacao');
  // A escolha vale enquanto a janela dela esta aberta: Cancelar, Fechar, o clique fora ou outra janela
  // no lugar param tudo (a HEIC leva segundos no servidor) — sem foto e sem recado por cima de outra janela.
  const vale = () => FOTOS_PENDENTES[chave] === lista && input.isConnected && !el('janela').classList.contains('oculto');
  FOTOS_PREPARANDO[chave] = (FOTOS_PREPARANDO[chave] || 0) + 1;
  try {
  for (const [k, arquivo] of arquivos.entries()) {
    if (!vale()) break;
    // A vaga e reservada antes da espera: as fotos que outra escolha ainda prepara ja contam no limite.
    if (lista.length + (lista.reservadas || 0) >= fotosPorVez()) { avisar('No máximo ' + fotosPorVez() + ' fotos de cada vez.', true); break; }
    lista.reservadas = (lista.reservadas || 0) + 1;
    let foto = null, erro = null;
    try {
      const heic = await ehHeic(arquivo);
      if (!heic && String(arquivo.type || '').toLowerCase().indexOf('image') !== 0 && !/\.(jpe?g|png|webp|gif)$/i.test(arquivo.name || '')) {
        throw new Error('"' + arquivo.name + '" não é uma foto. Envie JPG, PNG ou HEIC.');
      }
      // O "Preparando" (instantaneo) so quando nenhuma outra escolha esta em andamento: a conversao dela fica na situacao.
      if (situacao && heic) {
        situacao.textContent = 'Convertendo ' + arquivo.name + ' para JPG' +
          (arquivos.length > 1 ? ' (' + (k + 1) + ' de ' + arquivos.length + ')' : '') + ' — leva alguns segundos…';
      } else if (situacao && FOTOS_PREPARANDO[chave] === 1) situacao.textContent = 'Preparando ' + arquivo.name + '…';
      foto = await comprimirFoto(arquivo, heic, FOTOS_CONTEXTO[chave]);
    } catch (e) { erro = e; }
    finally { lista.reservadas--; }
    if (!vale()) break;
    if (erro) { avisar(erro.message || String(erro), true); continue; }
    lista.push(foto);
    if (foto.aviso) avisar(foto.aviso, true);
  }
  } finally {
    // So a contagem desta janela: a de uma janela aberta depois (fotosLimpar) nao e desta escolha.
    if (FOTOS_PENDENTES[chave] === lista) FOTOS_PREPARANDO[chave] = Math.max(0, (FOTOS_PREPARANDO[chave] || 1) - 1);
  }
  // Outra escolha ainda preparando: a situacao e dela (o "Convertendo…") ate ela terminar.
  if (situacao && !(FOTOS_PENDENTES[chave] === lista && FOTOS_PREPARANDO[chave] > 0)) {
    situacao.textContent = lista.length ? lista.length + ' foto(s) prontas para enviar' : fotosDica();
  }
  fotosPintarPrevias(chave);
}

function fotosPintarPrevias(chave) {
  const alvo = el(chave + '-previas'); if (!alvo) return;
  // Situacao e acao (8.13): cada foto com a legenda (aparece no cartao e no relatorio). Comentario e conclusao: so a foto.
  if (chave === 'st' || (chave === 'ac' && paTemSituacoes(planoD()))) {
    alvo.classList.add('pa-previas');
    alvo.innerHTML = (FOTOS_PENDENTES[chave] || []).map((f, i) => `
      <span class="foto-previa pa-previa">${f.previa ? `<img src="${f.previa}" alt="" class="pa-foto-img" style="object-fit:cover;padding:0">`
        : `<span class="foto-sem-previa pa-foto-img" style="font-size:12px">${f.heic ? 'HEIC · ' : ''}${esc(f.nome)}</span>`}
        <input maxlength="140" placeholder="Legenda da foto (opcional)" value="${esc(f.legenda || '')}"
          oninput="(FOTOS_PENDENTES[${jsArg(chave)}][${i}]||{}).legenda=this.value">
        <button type="button" class="pa-tirar" title="Tirar esta foto" onclick="fotosTirar(${jsArg(chave)}, ${i})">&times;</button></span>`).join('');
    return;
  }
  alvo.innerHTML = (FOTOS_PENDENTES[chave] || []).map((f, i) => `
    <span class="foto-previa">${f.previa ? `<img src="${f.previa}" alt="">` : `<span class="foto-sem-previa">${f.heic ? 'HEIC · ' : ''}${esc(f.nome)}</span>`}
      <button type="button" title="Tirar esta foto" onclick="fotosTirar(${jsArg(chave)}, ${i})">&times;</button></span>`).join('');
}
function fotosTirar(chave, i) {
  (FOTOS_PENDENTES[chave] || []).splice(i, 1);
  fotosPintarPrevias(chave);
  const s = el(chave + '-fotos-situacao');
  if (s) s.textContent = (FOTOS_PENDENTES[chave] || []).length ? FOTOS_PENDENTES[chave].length + ' foto(s) prontas para enviar' : fotosDica();
}

/*
 * HEIC/HEIF (iPhone; alguns Android): pelo tipo, pela extensao ou pelos
 * primeiros bytes ('ftyp' e a marca) — no Windows sem a extensao HEIF o
 * tipo vem vazio, e o seletor de fotos do Android manda o nome sem extensao.
 */
const MARCAS_HEIC = ['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'hevm', 'hevs', 'mif1', 'msf1'];
async function ehHeic(arquivo) {
  if (/^image\/hei[cf]/i.test(arquivo.type || '') || /\.hei[cf]$/i.test(arquivo.name || '')) return true;
  try {
    const t = String.fromCharCode(...new Uint8Array(await arquivo.slice(0, 12).arrayBuffer()));
    return t.slice(4, 8) === 'ftyp' && MARCAS_HEIC.includes(t.slice(8, 12));
  } catch (e) { return false; }
}

/*
 * HEIC que o navegador nao abre (Chrome): sobe sozinha, uma por chamada, com o
 * contexto da janela (plano, uso e acao: o servidor confere quem pode anexar
 * ali), e o servidor devolve a miniatura de 1600 px do Drive, que segue como
 * qualquer outra foto (com previa). O Google sem a miniatura ainda, ou a rede
 * que piscou: a foto vai como veio, com o aviso (quem mostra e fotosEscolhidas,
 * se a janela ainda for a mesma), e o visor converte quando alguem abrir.
 * Servidor de antes desta versao (sem converterFoto): vai como ia antes. Canal
 * barrado: foto nenhuma passa — a explicacao de sempre.
 */
async function converterHeicNoServidor(arquivo, contexto) {
  if (arquivo.size > 10 * 1024 * 1024) throw new Error('A foto "' + arquivo.name + '" passa de 10 MB.');
  const dados = await lerBase64(arquivo);
  const comoVeio = { nome: arquivo.name, tipo: 'image/heic', dados: dados, previa: '', heic: true };
  const vaiComoEsta = (porque) => Object.assign(comoVeio,
    { aviso: 'A foto "' + arquivo.name + '" vai como está: ' + porque + ' Ela aparece normalmente quando alguém abrir a ação.' });
  let r;
  try { r = await executarAcaoSrv('converterFoto', Object.assign({}, contexto, { foto: { nome: arquivo.name, tipo: 'image/heic', dados: dados } })); }
  catch (e) {
    if (/desconhecida|que nao existe/i.test(String((e && e.message) || e))) return comoVeio;
    // Canal barrado: a foto vai crua pela pagina (o agir grava por POST) e o visor converte depois.
    if (canalBarradoDeVez(e) || (e && e.message === SEM_CANAL_PARA_ARQUIVO)) return vaiComoEsta('este computador não deixa o Google convertê-la agora.');
    if (falhaPassageira(e)) return vaiComoEsta('a conexão com o Google falhou na conversão.');
    throw e;
  }
  if (!r || !r.dados) return vaiComoEsta('o Google ainda não terminou de convertê-la.');
  const bytes = Uint8Array.from(atob(r.dados), (c) => c.charCodeAt(0));
  return comprimirFoto(new File([bytes], arquivo.name, { type: r.tipo || 'image/jpeg' }), false);    // sai IMG_0001.jpg
}

/* Reduz para JPEG (lado maior 1600 px). A HEIC que o navegador nao abre vai antes ao servidor. */
async function comprimirFoto(arquivo, heic, contexto) {
  const url = URL.createObjectURL(arquivo);
  try {
    const img = await new Promise((ok, erro) => {
      const i = new Image();
      i.onload = () => ok(i);
      i.onerror = () => erro(new Error('formato'));
      i.src = url;
    });
    const k = Math.min(1, FOTO_LADO_MAX / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.naturalWidth * k));
    c.height = Math.max(1, Math.round(img.naturalHeight * k));
    const g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);     // PNG transparente nao fica preto
    g.drawImage(img, 0, 0, c.width, c.height);
    const dataUrl = c.toDataURL('image/jpeg', 0.82);
    return { nome: String(arquivo.name || 'foto').replace(/\.[^.]+$/, '') + '.jpg', tipo: 'image/jpeg',
             dados: dataUrl.split(',')[1], previa: dataUrl };
  } catch (e) {
    if (heic) return converterHeicNoServidor(arquivo, contexto);
    throw new Error('"' + arquivo.name + '" não abre como foto neste navegador. Envie JPG, PNG ou HEIC.');
  } finally {
    URL.revokeObjectURL(url);
  }
}

/*
 * VISOR — abre por cima de qualquer janela: o comentário que está sendo
 * escrito não se perde quando a pessoa para para ver uma foto.
 */
let VISOR = null;
const FOTO_CACHE = new Map();        // id do arquivo -> data URL (as últimas vistas)

function verFotosDaAcao(idAcao) {
  const a = planoAcaoPorId(idAcao); if (!a) return;
  verFotos(idAcao, a.fotos || [], !!(planoD().permissoes || {}).gerir);
}
function verFotosDoComentario(idAcao, idComentario) {
  const a = planoAcaoPorId(idAcao); if (!a) return;
  const c = (a.comentarios || []).find((x) => x.id === idComentario);
  if (c) verFotos(idAcao, c.fotos || [], false);
}

function verFotos(idAcao, fotos, podeRemover, inicio) {
  if (!fotos.length) return;
  VISOR = { idAcao: idAcao, fotos: fotos.slice(), i: Math.min(Math.max(0, Number(inicio) || 0), fotos.length - 1), podeRemover: podeRemover, pedido: 0,
            acaoFoto: PLANO.acoes.foto, acaoRemover: PLANO.acoes.removerFoto };
  let v = el('visor-fotos');
  if (!v) {
    v = document.createElement('div');
    v.id = 'visor-fotos';
    v.className = 'visor-fotos';
    v.innerHTML = `<div class="visor-caixa">
        <div class="visor-topo"><span id="visor-legenda"></span>
          <button class="fechar" onclick="visorFechar()" aria-label="Fechar">&times;</button></div>
        <div class="visor-palco"><button class="visor-seta" onclick="visorAndar(-1)" aria-label="Anterior">&#8249;</button>
          <div id="visor-imagem" class="visor-imagem"></div>
          <button class="visor-seta" onclick="visorAndar(1)" aria-label="Próxima">&#8250;</button></div>
        <div class="visor-rodape" id="visor-rodape"></div></div>`;
    v.addEventListener('click', (e) => { if (e.target === v) visorFechar(); });
    document.body.appendChild(v);
  }
  v.classList.remove('oculto');
  v.classList.toggle('uma', VISOR.fotos.length < 2);
  visorMostrar();
}
function visorFechar() { const v = el('visor-fotos'); if (v) v.classList.add('oculto'); VISOR = null; }
function visorAndar(passo) {
  if (!VISOR) return;
  VISOR.i = (VISOR.i + passo + VISOR.fotos.length) % VISOR.fotos.length;
  visorMostrar();
}
document.addEventListener('keydown', (e) => {
  if (!VISOR) return;
  if (e.key === 'Escape') { e.stopPropagation(); visorFechar(); }
  else if (e.key === 'ArrowRight') visorAndar(1);
  else if (e.key === 'ArrowLeft') visorAndar(-1);
});

async function visorMostrar() {
  const V = VISOR; if (!V) return;
  const f = V.fotos[V.i];
  const pedido = ++V.pedido;
  V.url = '';
  // 8.13: a legenda da foto, quando ha; senao o nome do arquivo.
  el('visor-legenda').textContent = (f.legenda || f.nome || 'foto') + (V.fotos.length > 1 ? ' · ' + (V.i + 1) + ' de ' + V.fotos.length : '');
  el('visor-rodape').innerHTML = `
    ${V.podeRemover ? `<button class="botao-texto perigo" onclick="visorRemover()">Remover esta foto</button>` : ''}
    <button class="botao secundario" id="visor-baixar" disabled onclick="visorBaixar()">Baixar</button>
    <button class="botao" onclick="visorFechar()">Fechar</button>`;
  const alvo = el('visor-imagem');
  let url = FOTO_CACHE.get(f.id);
  if (!url) {
    alvo.innerHTML = '<div class="vazio">Carregando a foto…</div>';
    try {
      const r = await executarAcaoSrv(V.acaoFoto, { id: V.idAcao, arquivo: f.id });
      url = 'data:' + (r.tipo || 'image/jpeg') + ';base64,' + r.dados;
      // HEIC sem converter: o porque vai para o texto do visor. So a que o Google ainda esta preparando
      // fica fora do cache — a proxima abertura tenta de novo; as outras nao baixam a HEIC a cada clique.
      if (ehUrlHeic(url)) HEIC_SEM_PREVIA[f.id] = !r.semMiniatura ? 'servidor' : r.desistiu ? 'desistiu' : 'preparando';
      if (!ehUrlHeic(url) || HEIC_SEM_PREVIA[f.id] !== 'preparando') FOTO_CACHE.set(f.id, url);
      if (FOTO_CACHE.size > 24) FOTO_CACHE.delete(FOTO_CACHE.keys().next().value);
    } catch (e) {
      if (VISOR === V && V.pedido === pedido) {
        alvo.innerHTML = `<div class="erro-caixa">${esc(canalBloqueado(e) ? explicarErro(e) : (e.message || e))}
          <button class="botao-texto" onclick="visorMostrar()">Tentar de novo</button></div>`;
      }
      return;
    }
  }
  if (VISOR !== V || V.pedido !== pedido) return;      // trocou de foto ou fechou no meio
  alvo.innerHTML = ehUrlHeic(url) ? `<div class="vazio">${HEIC_SEM_PREVIA_TEXTO[HEIC_SEM_PREVIA[f.id]] || HEIC_SEM_PREVIA_TEXTO.servidor}</div>`
    : `<img src="${url}" alt="${esc(f.nome || 'foto')}">`;
  V.url = url;          // o Baixar usa a foto que esta na tela (o cache pode ja ter soltado ela)
  const b = el('visor-baixar'); if (b) b.disabled = false;
}
const ehUrlHeic = (url) => /^data:image\/hei[cf]/i.test(url);
/*
 * A HEIC que chegou sem converter, por foto: 'preparando' (o Google ainda gera
 * a miniatura), 'desistiu' (teve tempo e nao gerou) ou 'servidor' (Acoes.gs de
 * antes desta versao, que nao converte).
 */
const HEIC_SEM_PREVIA = {};
const HEIC_SEM_PREVIA_TEXTO = {
  preparando: 'O Google ainda está preparando esta foto HEIC. Feche e abra de novo em alguns segundos — ou use <b>Baixar</b>.',
  desistiu: 'O Google não conseguiu converter esta foto HEIC para mostrar aqui. Use <b>Baixar</b> para abrir no computador.',
  servidor: 'Este navegador não mostra fotos HEIC. Use <b>Baixar</b> para abrir no computador.'
};

function visorBaixar() {
  if (!VISOR) return;
  const f = VISOR.fotos[VISOR.i], url = VISOR.url || FOTO_CACHE.get(f.id);
  if (!url) return;
  const a = document.createElement('a');
  a.href = url; a.download = nomeParaBaixar(f.nome, url);
  document.body.appendChild(a); a.click(); a.remove();
}

/* Com a extensao do que esta na tela: a HEIC antiga, convertida pelo servidor, sai .jpg (o Windows abre). */
const EXTENSAO_DA_FOTO = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' };
function nomeParaBaixar(nome, url) {
  const ext = EXTENSAO_DA_FOTO[(/^data:([^;,]+)/.exec(url) || [])[1]];
  const base = String(nome || 'foto');
  return ext ? base.replace(/\.(heic|heif|jpe?g|png|webp)$/i, '') + ext : base;
}

async function visorRemover() {
  const V = VISOR; if (!V || !V.podeRemover) return;
  const f = V.fotos[V.i];
  if (!confirm('Remover a foto "' + (f.nome || 'foto') + '" desta ação? Ela vai para a lixeira do Drive.')) return;
  /*
   * Direto no servidor, sem o agir(): o agir fecha a janela de baixo — e a
   * "Editar ação" aberta perdia o que ainda nao tinha sido salvo.
   */
  try { await executarAcaoSrv(V.acaoRemover, { id: V.idAcao, arquivo: f.id }); }
  catch (e) { avisar(e.message || String(e), true); return; }
  const a = planoAcaoPorId(V.idAcao);
  if (a) a.fotos = (a.fotos || []).filter((x) => x.id !== f.id);
  FOTO_CACHE.delete(f.id);
  esquecerTela(paginaAtual); envelhecerTelas();
  avisar('Foto removida');
  V.fotos = V.fotos.filter((x) => x.id !== f.id);
  if (!V.fotos.length) visorFechar();
  else { V.i = Math.min(V.i, V.fotos.length - 1); el('visor-fotos').classList.toggle('uma', V.fotos.length < 2); visorMostrar(); }
  // Sem janela aberta por baixo, a tela volta do servidor ja sem a foto.
  if (el('janela').classList.contains('oculto')) abrir(paginaAtual, paramsAtual);
}

/* ================= RELATOS DE ERRO =================
   Conversas saiu na 4.2 (projeto para depois). Os relatos de erro, que
   ficavam numa aba da tela Conversas, ganharam tela propria em
   Configuracao › Relatos de erro.
   =================================================== */

function pintarRelatos(r) {
  el('pagina').innerHTML = `${podeEditar('relatos') ? '' : avisoSoVer('Relatos de erro')}${blocoFeedback(r.dados || {})}`;
}

/* --- Relatos de erro da plataforma --- */

function blocoFeedback(d) {
  const lista = d.feedbacks || [];
  const abertos = lista.filter((f) => f.situacao === 'ABERTO').length;
  return `
    <div class="grade grade-kpi relatos-numeros">
      <div class="cartao kpi alerta"><div class="kpi-valor">${abertos}</div><div class="kpi-rotulo">Em aberto</div></div>
      <div class="cartao kpi verde"><div class="kpi-valor">${lista.length - abertos}</div><div class="kpi-rotulo">Resolvidos</div></div>
      <div class="cartao kpi"><div class="kpi-valor">${lista.length}</div><div class="kpi-rotulo">Relatos no total</div></div>
    </div>
    <div class="cartao">
      <div class="cartao-titulo">${lista.length} relato(s)</div>
      <p class="dica" style="margin:-4px 0 12px">Chega pelo botão flutuante do canto da tela.
         Cada relato guarda quem reportou, em que tela estava e o navegador — o que faltava
         toda vez que alguém dizia "deu erro" sem dizer onde.</p>
      ${lista.length ? lista.map((f) => `
        <div class="cartao-acao ${f.situacao === 'ABERTO' ? 'atrasada' : 'concluido'}">
          <div class="acao-topo">
            <div class="acao-titulo">${esc(f.tipo)} — ${esc(f.tela || 'tela não informada')}</div>
            <span class="etiqueta ${f.situacao === 'ABERTO' ? 'aguardando' : 'concluido'}">
              ${f.situacao === 'ABERTO' ? 'aberto' : 'resolvido'}</span>
          </div>
          <div class="acao-descricao">${esc(f.texto)}</div>
          <div class="acao-meta">
            <span><b>Quem:</b> ${esc(f.autorNome)}</span>
            <span><b>Quando:</b> ${esc((f.quando || '').slice(0, 16).replace('T', ' '))}</span>
          </div>
          ${f.resposta ? `<div class="acao-conclusao">Resposta: ${esc(f.resposta)}</div>` : ''}
          ${f.situacao === 'ABERTO' && podeEditar('relatos') ? `
            <div class="acao-botoes">
              <button class="botao" onclick="formResolverFeedback(${jsArg(f.id)})">Marcar como resolvido</button>
            </div>` : ''}
        </div>`).join('') : '<div class="vazio">Nenhum relato. Bom sinal.</div>'}
    </div>`;
}

function formResolverFeedback(id) {
  abrirJanela('Resolver relato', `
    <div class="campo"><label>O que foi feito</label>
      <textarea id="fb-resposta" rows="3" placeholder="Quem reportou recebe esta resposta por e-mail"></textarea></div>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="agir('resolverFeedback',{id:${jsArg(id)},resposta:val('fb-resposta')},'Relato resolvido')">Resolver</button>`);
}

/* --- O botão de reportar erro, disponível em qualquer tela --- */

function formFeedback() {
  abrirJanela('Reportar um problema', `
    <p style="margin:0 0 14px;color:var(--tinta-media);line-height:1.7">
      Conte o que aconteceu. O administrador recebe na hora, junto com a tela em que você
      está e os dados do navegador — você não precisa explicar nada disso.
    </p>
    <div class="campo"><label>Tipo</label>
      <select id="fb-tipo">
        <option value="ERRO">Erro — alguma coisa não funcionou</option>
        <option value="SUGESTAO">Sugestão — poderia ser melhor assim</option>
        <option value="DUVIDA">Dúvida — não sei como fazer</option>
      </select></div>
    <div class="campo"><label>O que aconteceu</label>
      <textarea id="fb-texto" rows="4"
        placeholder="Ex.: cliquei em Enviar entrega e apareceu uma mensagem vermelha escrita 'r is not defined'"></textarea></div>`, `
    <button class="botao secundario" onclick="fecharJanela()">Cancelar</button>
    <button class="botao" onclick="enviarFeedback()">Enviar</button>`);
}

function enviarFeedback() {
  agir('enviarFeedback', {
    tipo: val('fb-tipo'),
    texto: val('fb-texto'),
    tela: paginaAtual,
    navegador: navigator.userAgent
  }, 'Recebi. Obrigado por avisar.');
}

function classeStatus(s) {
  if (s === 'Aprovada') return 'aprovada';
  if (s === 'Aguard. valid.') return 'aguardando';
  if (s === 'Atrasada') return 'atrasada';
  if (s === 'Reprovada') return 'reprovada';
  if (s === 'Cancelada') return 'cancelada';
  // Plano de acao: a acao nao passa por validacao, entao ela conclui.
  if (s === 'Concluída' || s === 'Concluida') return 'concluido';
  return 'pendente';
}
const etiqueta = (s) => `<span class="etiqueta ${classeStatus(s)}">${esc(s)}</span>`;
