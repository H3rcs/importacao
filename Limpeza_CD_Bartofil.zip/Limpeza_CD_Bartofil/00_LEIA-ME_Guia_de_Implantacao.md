# Programa de Padronização da Limpeza — CD Bartofil Feira de Santana

Pacote completo para estruturar o setor de limpeza nos três turnos: procedimento, escala, checklists, treinamento, auditoria e planilha de gestão.

**Turnos adotados:** A = 06h00–15h00 · B = 15h00–00h00 · C = 00h00–06h00
**Documento mestre:** POP-LIM-001, revisão 00

---

## O que tem no pacote

| Arquivo | O que é | Para quem |
|---|---|---|
| `01_Proposta_Gerencia_Limpeza.pptx` | Apresentação de 14 slides com diagnóstico, proposta, cronograma e as 4 decisões que dependem do gerente | Reunião com a gerência |
| `02_POP_Limpeza_CD_Bartofil.docx` | Procedimento completo, 21 páginas: responsabilidades, postos, escala, zonas, matriz de frequência, passo a passo por posto, produtos, EPI, segurança, resíduos, verificação, auditoria e indicadores | Documento oficial do setor |
| `03_Checklists_e_Formularios.docx` (+ PDF) | 15 formulários prontos para imprimir | Parede e prancheta dos setores |
| `04_Planilha_Gestao_Limpeza.xlsx` | Planilha do supervisor pronta para subir no Drive e converter em Google Sheets | Supervisor |
| `05_AppsScript_Planilha_Supervisor.gs` | Script que monta a mesma planilha direto no Google Sheets, com menu próprio, validações e painel | Supervisor (versão completa) |
| `06_Treinamento_Colaboradores.pptx` | Treinamento padrão de 20 slides, linguagem direta, para aplicar nos 3 turnos | Colaboradores |

Os PDFs do POP e dos checklists são só para impressão — os arquivos editáveis são o `.docx` e o `.xlsx`.

---

## Passo a passo da implantação

### 1. Suba os documentos para o Google (10 minutos)

1. Abra o Google Drive e crie a pasta **Limpeza CD Feira de Santana**.
2. Arraste `02_POP_Limpeza_CD_Bartofil.docx` para dentro dela.
3. Clique com o botão direito no arquivo → **Abrir com** → **Documentos Google**. Ele vira um Google Docs mantendo toda a formatação.
4. Faça o mesmo com `03_Checklists_e_Formularios.docx`.

### 2. Monte a planilha do supervisor (escolha um dos dois caminhos)

**Caminho A — rápido (2 minutos):**

1. Arraste `04_Planilha_Gestao_Limpeza.xlsx` para a pasta do Drive.
2. Botão direito → **Abrir com** → **Planilhas Google**.
3. Apague as linhas 4 de exemplo das abas CHECKLIST, VERIFICACAO, AUDITORIA_INFRA e PLANO_ACAO.

**Caminho B — completo, com menu e automações (5 minutos):**

1. Abra `sheets.new` para criar uma planilha em branco.
2. Menu **Extensões** → **Apps Script**.
3. Apague o conteúdo do `Código.gs` e cole todo o conteúdo de `05_AppsScript_Planilha_Supervisor.gs`.
4. Salve e execute a função **criarEstrutura**. Autorize quando o Google pedir.
5. Volte para a planilha e recarregue a página (F5). O menu **Gestão da Limpeza** aparece ao lado de Ajuda.

O caminho B entrega tudo do A mais: geração automática dos lançamentos do dia, filtro de plano de ação em aberto e envio do resumo mensal por e-mail.

### 3. Preencha o que só você tem (é o único trabalho de campo)

Na aba **PARAMETROS** da planilha e na tabela do item 8 do POP:

- as ruas reais de cada zona (Z1 a Z10);
- a metragem aproximada de cada zona;
- o nome de cada colaborador do setor e o turno dele;
- a diluição de cada produto, copiada do rótulo (tabela do item 11 do POP).

Faça isso caminhando pelo CD com o líder de cada área. É uma volta só.

### 4. Imprima e afixe os checklists

| Formulário | Onde fica | Quantidade |
|---|---|---|
| CHK-LIM-A — Varrição de ruas | Prancheta do posto | 1 por turno/dia |
| CHK-LIM-B — Lavagem e piso | Prancheta do posto | 1 por turno/dia |
| CHK-LIM-C1 — Sanitários (execução) | Prancheta do posto | 1 por ambiente/dia |
| CHK-LIM-C2 — Controle de limpeza | **Afixado na porta de cada sanitário** | 1 por mês |
| CHK-LIM-D — Áreas nobres | Quadro do ADM | 1 por turno/dia |
| CHK-LIM-E — Áreas externas | Guarita P1 | 1 por turno/dia |
| CHK-LIM-F — Resíduos e reciclagem | Baia de recicláveis | 1 por turno/dia |
| CHK-LIM-G — Turno C / apoio noturno | Quadro do setor | 1 por noite |
| CHK-LIM-H — Passagem de turno | Quadro do setor | 1 por troca |
| CHK-LIM-I — Verificação do supervisor | Pasta do supervisor | 1 por turno |
| CHK-LIM-J — Auditoria de infraestrutura | Pasta do supervisor | 1 por mês |
| CHK-LIM-K — Plano de ação 5W2H | Pasta do supervisor | conforme demanda |
| CHK-LIM-L / M / M1 — Presença, avaliação e gabarito | Pasta do supervisor | no treinamento |

Sugestão: plastifique o CHK-LIM-C2 (folha de porta do sanitário) e imprima os demais em bloco mensal.

### 5. Aplique o treinamento

- 2 horas por turno, no próprio horário do turno, na mesma semana.
- Use `06_Treinamento_Colaboradores.pptx`. As anotações do apresentador trazem orientações ao instrutor.
- Ao final: aplique a avaliação **CHK-LIM-M**, corrija na hora pelo gabarito **CHK-LIM-M1** e recolha a lista de presença **CHK-LIM-L**.
- Nota mínima 70%. Abaixo disso, reorientação e reavaliação em até 7 dias.

### 6. Rode e meça

- **Todo turno:** o supervisor faz a ronda de verificação e recolhe os checklists.
- **Toda semana:** revisão do plano de ação, controle de insumos e montagem da escala seguinte.
- **Todo mês:** auditoria de infraestrutura e apresentação dos indicadores à gerência.

**Metas:** IAL ≥ 95% · NQL ≥ 90 pontos · Auditoria ≥ 90% · Plano de ação fechado em até 15 dias.

---

## Estrutura proposta do setor

**Turnos A e B — 6 postos cada:**

1. Varrição de ruas (varredora no A, manual no B)
2. Piso (lavadora automática no A, dois baldes no B)
3. Sanitários operacionais — principal, central, miudeza e mezanino
4. Áreas nobres — refeitório, descanso, hotel, gerência, RH, ADM, feminino
5. Áreas externas — vestiário central masculino, P1, P2, apoio dos caminhoneiros
6. Resíduos e reciclagem

**Turno C — 1 posto:** apoio noturno, com rotina fechada em 7 blocos e limpeza pesada por rodízio semanal de zonas.

**Zonas:** Z1 armazenagem · Z2 separação e miudeza · Z3 expedição e docas · Z4 recebimento · Z5 central de cargas · Z6 mezanino · Z7 sanitários e vestiários · Z8 áreas nobres · Z9 áreas externas · Z10 resíduos.

---

## Auditoria de infraestrutura — o que ela cobre

Iluminação · pintura e demarcação de piso · sistema de câmeras (CFTV) · sinalização de segurança · hidrossanitário · combate a incêndio e rotas de fuga · cobertura, piso e estrutura · vivência e ventilação · controle de pragas.

Cada item recebe C, NC ou NA. Toda NC vira linha no plano de ação, com responsável, prazo por criticidade (Alta: imediato · Média: 7 dias · Baixa: 30 dias) e número do chamado de manutenção. Só encerra com evidência.

---

## Ajustes que talvez você queira fazer

- **Cores da marca:** o pacote usa azul, verde e amarelo, sem vermelho na identidade. Se a empresa tiver os códigos exatos, troque as constantes `AZUL`, `VERDE` e `AMAR` no topo do arquivo `.gs`.
- **Nomes dos ambientes:** ajuste no POP e nos checklists os nomes exatos usados no dia a dia do CD.
- **Janelas de horário:** as janelas do item 7 do POP são um padrão de partida; ajuste conforme os picos reais de separação e expedição.
- **Rodízio de limpeza pesada:** defina qual zona entra em cada semana do mês e registre na planilha.

---

## Referências normativas usadas

NR-6 (EPI) · NR-24 (condições sanitárias e de conforto) · NR-26 (sinalização de segurança) · NR-11 e NR-12 (movimentação de cargas e máquinas) · NR-35 (trabalho em altura, para limpeza acima de 2 m) · Lei 12.305/2010 (Política Nacional de Resíduos Sólidos).
