/**
 * ============================================================================
 *  BARTOFIL — CD FEIRA DE SANTANA
 *  PLANILHA DE GESTÃO DA LIMPEZA E CONSERVAÇÃO  —  POP-LIM-001
 * ============================================================================
 *
 *  COMO INSTALAR (5 passos)
 *  1. Crie uma planilha nova no Google Sheets (sheets.new).
 *  2. Menu Extensões > Apps Script.
 *  3. Apague o conteúdo do arquivo Código.gs e cole TODO este arquivo.
 *  4. Salve (disquete) e execute a função  criarEstrutura  uma única vez.
 *     Autorize quando o Google pedir.
 *  5. Volte para a planilha e recarregue a página (F5).
 *     O menu "Gestão da Limpeza" aparece ao lado de Ajuda.
 *
 *  USO DIÁRIO DO SUPERVISOR
 *  - Gestão da Limpeza > Gerar lançamentos do dia   (cria as linhas previstas)
 *  - Lançar os checklists recolhidos na aba CHECKLIST
 *  - Lançar a ronda do turno na aba VERIFICACAO
 *  - Gestão da Limpeza > Atualizar painel
 *
 * ============================================================================
 */

// ---------------------------------------------------------------- IDENTIDADE
var AZUL   = '#0B4EA2';   // azul Bartofil
var AZULE  = '#083A7A';
var VERDE  = '#2AA84A';   // verde da marca
var AMAREL = '#F2C300';   // amarelo da marca
var CINZA  = '#EEF2F7';
var BRANCO = '#FFFFFF';
var TEXTO  = '#1F2937';

// Ajuste aqui se a empresa informar os códigos exatos da marca.

var ABAS = ['PAINEL','CHECKLIST','VERIFICACAO','AUDITORIA_INFRA','PLANO_ACAO',
            'ESCALA','OCORRENCIAS','INSUMOS','PARAMETROS','INICIO'];

// ============================================================================
//  MENU
// ============================================================================
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Gestão da Limpeza')
    .addItem('Gerar lançamentos do dia', 'gerarLancamentosDoDia')
    .addItem('Atualizar painel', 'atualizarPainel')
    .addSeparator()
    .addItem('Abrir plano de ação em aberto', 'filtrarPlanoAberto')
    .addItem('Resumo do mês por e-mail', 'enviarResumoMensal')
    .addSeparator()
    .addItem('Reconstruir estrutura (cuidado)', 'criarEstrutura')
    .addToUi();
}

// ============================================================================
//  ESTRUTURA
// ============================================================================
function criarEstrutura() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ss.rename('Gestão da Limpeza — CD Bartofil Feira de Santana');
  ss.setSpreadsheetLocale('pt_BR');
  ss.setSpreadsheetTimeZone('America/Bahia');

  criarParametros(ss);
  criarChecklist(ss);
  criarVerificacao(ss);
  criarAuditoria(ss);
  criarPlanoAcao(ss);
  criarEscala(ss);
  criarOcorrencias(ss);
  criarInsumos(ss);
  criarInicio(ss);
  criarPainel(ss);

  // remove a aba padrão vazia, se existir
  var p = ss.getSheetByName('Página1') || ss.getSheetByName('Sheet1');
  if (p) ss.deleteSheet(p);

  // ordena as abas
  for (var i = 0; i < ABAS.length; i++) {
    var sh = ss.getSheetByName(ABAS[i]);
    if (sh) { ss.setActiveSheet(sh); ss.moveActiveSheet(i + 1); }
  }
  ss.setActiveSheet(ss.getSheetByName('INICIO'));
  SpreadsheetApp.getUi().alert('Estrutura criada. Recarregue a página (F5) para o menu aparecer.');
}

function novaAba(ss, nome) {
  var sh = ss.getSheetByName(nome);
  if (sh) ss.deleteSheet(sh);
  sh = ss.insertSheet(nome);
  // garante espaço suficiente para as validações e fórmulas aplicadas em bloco
  if (sh.getMaxRows() < 2100) sh.insertRowsAfter(sh.getMaxRows(), 2100 - sh.getMaxRows());
  if (sh.getMaxColumns() < 40) sh.insertColumnsAfter(sh.getMaxColumns(), 40 - sh.getMaxColumns());
  return sh;
}

function cabecalho(sh, titulo, subtitulo, colunas) {
  var n = colunas.length;
  sh.getRange(1, 1, 1, n).merge()
    .setValue(titulo).setBackground(AZUL).setFontColor(BRANCO)
    .setFontSize(13).setFontWeight('bold').setVerticalAlignment('middle');
  sh.setRowHeight(1, 34);
  sh.getRange(2, 1, 1, n).merge()
    .setValue(subtitulo).setBackground(AZULE).setFontColor('#CFE0F5')
    .setFontSize(9).setVerticalAlignment('middle');
  sh.setRowHeight(2, 20);
  sh.getRange(3, 1, 1, n).setValues([colunas])
    .setBackground(CINZA).setFontColor(TEXTO).setFontWeight('bold')
    .setFontSize(9).setWrap(true).setVerticalAlignment('middle')
    .setBorder(true, true, true, true, true, true, '#B9C4D2', SpreadsheetApp.BorderStyle.SOLID);
  sh.setRowHeight(3, 34);
  sh.setFrozenRows(3);
  sh.getRange(4, 1, sh.getMaxRows() - 3, n).setFontSize(10).setVerticalAlignment('middle');
}

function larguras(sh, arr) { for (var i = 0; i < arr.length; i++) sh.setColumnWidth(i + 1, arr[i]); }

function validacao(sh, col, linhaIni, lista) {
  var regra = SpreadsheetApp.newDataValidation().requireValueInList(lista, true)
              .setAllowInvalid(false).build();
  sh.getRange(linhaIni, col, 2000, 1).setDataValidation(regra);
}

function validacaoIntervalo(sh, col, linhaIni, intervalo) {
  var regra = SpreadsheetApp.newDataValidation().requireValueInRange(intervalo, true)
              .setAllowInvalid(true).build();
  sh.getRange(linhaIni, col, 2000, 1).setDataValidation(regra);
}

function zebra(sh, nCols) {
  var r = sh.getRange(4, 1, sh.getMaxRows() - 3, nCols);
  var regra = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied('=AND(MOD(ROW(),2)=1,$A4<>"")')
    .setBackground(CINZA).setRanges([r]).build();
  var regras = sh.getConditionalFormatRules(); regras.push(regra);
  sh.setConditionalFormatRules(regras);
}

function regraCor(sh, intervalo, formula, cor, corFonte) {
  var regra = SpreadsheetApp.newConditionalFormatRule()
    .whenFormulaSatisfied(formula).setBackground(cor)
    .setFontColor(corFonte || TEXTO).setRanges([intervalo]).build();
  var regras = sh.getConditionalFormatRules(); regras.push(regra);
  sh.setConditionalFormatRules(regras);
}

// ============================================================================
//  ABA PARAMETROS
// ============================================================================
function criarParametros(ss) {
  var sh = novaAba(ss, 'PARAMETROS');
  cabecalho(sh, 'PARÂMETROS E CADASTROS',
    'Base de todas as listas da planilha. Preencher antes de começar a usar.',
    ['TURNO','HORÁRIO','POSTO','DENOMINAÇÃO DO POSTO','TURNO DO POSTO','ZONA','DESCRIÇÃO DA ZONA','ÁREA (m²)','COLABORADOR','FUNÇÃO/POSTO','TURNO DO COLABORADOR','STATUS','CRITICIDADE','TIPO DE OCORRÊNCIA','INSUMO','UNIDADE']);
  larguras(sh, [70,110,70,220,100,70,240,80,190,110,120,110,100,150,180,80]);

  var turnos = [['A','06h00 - 15h00'],['B','15h00 - 00h00'],['C','00h00 - 06h00']];
  sh.getRange(4, 1, 3, 2).setValues(turnos);

  var postos = [
    ['A1','Varrição mecanizada','A'],['A2','Lavagem mecanizada de piso','A'],
    ['A3','Sanitários operacionais','A'],['A4','Áreas nobres','A'],
    ['A5','Áreas externas','A'],['A6','Resíduos e reciclagem','A'],
    ['B1','Varrição manual de ruas','B'],['B2','Piso — mopping úmido','B'],
    ['B3','Sanitários operacionais','B'],['B4','Áreas nobres','B'],
    ['B5','Áreas externas','B'],['B6','Resíduos e reciclagem','B'],
    ['C1','Apoio noturno','C']];
  sh.getRange(4, 3, postos.length, 3).setValues(postos);

  var zonas = [
    ['Z1','Armazenagem — porta-paletes',''],['Z2','Separação / picking e miudeza',''],
    ['Z3','Expedição e docas',''],['Z4','Recebimento',''],
    ['Z5','Central de cargas',''],['Z6','Mezanino',''],
    ['Z7','Sanitários e vestiários',''],['Z8','Áreas nobres e administrativo',''],
    ['Z9','Áreas externas e apoio',''],['Z10','Resíduos e recicláveis','']];
  sh.getRange(4, 6, zonas.length, 3).setValues(zonas);

  sh.getRange(4, 9, 1, 3).setValues([['(preencher com o efetivo do setor)','','']]).setFontColor('#8A97A8');

  sh.getRange(4, 12, 5, 1).setValues([['Aberto'],['Em andamento'],['Concluído'],['Atrasado'],['Cancelado']]);
  sh.getRange(4, 13, 3, 1).setValues([['Alta'],['Média'],['Baixa']]);
  sh.getRange(4, 14, 7, 1).setValues([['Derramamento'],['Vazamento'],['Falta de insumo'],['Avaria de máquina'],['Resíduo fora do padrão'],['Condição insegura'],['Outro']]);
  sh.getRange(4, 15, 10, 2).setValues([
    ['Papel higiênico','rolo'],['Papel toalha','pacote'],['Sabonete líquido','L'],
    ['Saco de lixo 100L','pacote'],['Saco de lixo 60L','pacote'],['Detergente neutro','L'],
    ['Desinfetante','L'],['Desincrustante','L'],['Pano multiuso','un'],['Luva nitrílica','par']]);

  sh.getRange(4, 1, sh.getMaxRows() - 3, 16)
    .setBorder(true, true, true, true, true, true, '#DCE3EB', SpreadsheetApp.BorderStyle.SOLID);
  sh.getRange(4, 8, 100, 1).setNumberFormat('#,##0');
  return sh;
}

// ============================================================================
//  ABA CHECKLIST  (Nível 1 — autoverificação lançada pelo supervisor)
// ============================================================================
function criarChecklist(ss) {
  var sh = novaAba(ss, 'CHECKLIST');
  cabecalho(sh, 'LANÇAMENTO DOS CHECKLISTS DE POSTO (N1)',
    'Uma linha por posto/turno/dia. As folhas de papel recolhidas nos setores são lançadas aqui no mesmo dia.',
    ['DATA','TURNO','POSTO','COLABORADOR','ZONA','ITENS PREVISTOS','ITENS CONFORMES','% CONFORMIDADE','FOLHA ENTREGUE','ASSINADA','HORA DE ENTREGA','OBSERVAÇÃO / NC','LANÇADO POR']);
  larguras(sh, [90,60,70,190,70,110,110,110,110,90,110,320,140]);

  sh.getRange('A4:A2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('K4:K2000').setNumberFormat('hh:mm');
  sh.getRange('H4:H2000').setNumberFormat('0%');
  sh.getRange('H4:H2000').setFormula('=IF(N(F4)=0,"",G4/F4)');

  var ss2 = SpreadsheetApp.getActiveSpreadsheet();
  var par = ss2.getSheetByName('PARAMETROS');
  validacao(sh, 2, 4, ['A','B','C']);
  validacaoIntervalo(sh, 3, 4, par.getRange('C4:C20'));
  validacaoIntervalo(sh, 4, 4, par.getRange('I4:I200'));
  validacaoIntervalo(sh, 5, 4, par.getRange('F4:F20'));
  validacao(sh, 9, 4, ['Sim','Não']);
  validacao(sh, 10, 4, ['Sim','Não']);

  zebra(sh, 13);
  regraCor(sh, sh.getRange('H4:H2000'), '=AND($F4<>"",$H4>=0.95)', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('H4:H2000'), '=AND($F4<>"",$H4<0.95,$H4>=0.85)', '#FFF4CC', '#7A5B00');
  regraCor(sh, sh.getRange('H4:H2000'), '=AND($F4<>"",$H4<0.85)', '#FBE0E0', '#9B1C1C');
  regraCor(sh, sh.getRange('I4:J2000'), '=I4="Não"', '#FBE0E0', '#9B1C1C');
  return sh;
}

// ============================================================================
//  ABA VERIFICACAO (Nível 2 — ronda do supervisor)
// ============================================================================
function criarVerificacao(ss) {
  var sh = novaAba(ss, 'VERIFICACAO');
  cabecalho(sh, 'RONDA DE VERIFICAÇÃO DO SUPERVISOR (N2)',
    'Mínimo de uma ronda por turno, com pelo menos 3 zonas e sempre um sanitário. NQL = conformes / avaliados.',
    ['DATA','TURNO','HORA','ZONA','ITENS AVALIADOS','ITENS CONFORMES','NQL (0-100)','NÃO CONFORMIDADE ENCONTRADA','AÇÃO IMEDIATA','CRITICIDADE','PRAZO','STATUS','SUPERVISOR']);
  larguras(sh, [90,60,70,70,120,130,100,320,260,100,90,110,150]);

  sh.getRange('A4:A2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('C4:C2000').setNumberFormat('hh:mm');
  sh.getRange('K4:K2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('G4:G2000').setNumberFormat('0.0');
  sh.getRange('G4:G2000').setFormula('=IF(N(E4)=0,"",ROUND(F4/E4*100,1))');

  var par = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('PARAMETROS');
  validacao(sh, 2, 4, ['A','B','C']);
  validacaoIntervalo(sh, 4, 4, par.getRange('F4:F20'));
  validacao(sh, 10, 4, ['Alta','Média','Baixa']);
  validacao(sh, 12, 4, ['Aberto','Em andamento','Concluído','Atrasado','Cancelado']);

  zebra(sh, 13);
  regraCor(sh, sh.getRange('G4:G2000'), '=AND($E4<>"",$G4>=90)', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('G4:G2000'), '=AND($E4<>"",$G4<90,$G4>=80)', '#FFF4CC', '#7A5B00');
  regraCor(sh, sh.getRange('G4:G2000'), '=AND($E4<>"",$G4<80)', '#FBE0E0', '#9B1C1C');
  regraCor(sh, sh.getRange('L4:L2000'), '=$L4="Concluído"', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('L4:L2000'), '=$L4="Atrasado"', '#FBE0E0', '#9B1C1C');
  return sh;
}

// ============================================================================
//  ABA AUDITORIA_INFRA (Nível 3)
// ============================================================================
function criarAuditoria(ss) {
  var sh = novaAba(ss, 'AUDITORIA_INFRA');
  cabecalho(sh, 'AUDITORIA MENSAL DE INFRAESTRUTURA E CONSERVAÇÃO (N3)',
    'Iluminação, pintura e demarcação, CFTV, sinalização, hidrossanitário, incêndio, estrutura, vivência e pragas.',
    ['MÊS DE REFERÊNCIA','DATA DA AUDITORIA','BLOCO','ITEM VERIFICADO','SITUAÇÃO','LOCAL / DESCRIÇÃO','CRITICIDADE','AÇÃO NECESSÁRIA','RESPONSÁVEL','PRAZO','Nº DO CHAMADO','STATUS','EVIDÊNCIA / LINK']);
  larguras(sh, [120,120,150,300,90,280,100,260,140,90,110,110,200]);

  sh.getRange('A4:B2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('J4:J2000').setNumberFormat('dd/mm/yyyy');

  validacao(sh, 3, 4, ['1. Iluminação','2. Pintura e demarcação','3. Sistema de câmeras (CFTV)',
    '4. Sinalização','5. Hidrossanitário','6. Combate a incêndio','7. Cobertura, piso e estrutura',
    '8. Vivência e ventilação','9. Controle de pragas']);
  validacao(sh, 5, 4, ['C','NC','NA']);
  validacao(sh, 7, 4, ['Alta','Média','Baixa']);
  validacao(sh, 12, 4, ['Aberto','Em andamento','Concluído','Atrasado','Cancelado']);

  zebra(sh, 13);
  regraCor(sh, sh.getRange('E4:E2000'), '=$E4="C"', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('E4:E2000'), '=$E4="NC"', '#FBE0E0', '#9B1C1C');
  regraCor(sh, sh.getRange('G4:G2000'), '=$G4="Alta"', '#FBE0E0', '#9B1C1C');
  regraCor(sh, sh.getRange('J4:J2000'), '=AND($J4<>"",$J4<TODAY(),$L4<>"Concluído")', '#FBE0E0', '#9B1C1C');
  return sh;
}

// ============================================================================
//  ABA PLANO_ACAO (5W2H)
// ============================================================================
function criarPlanoAcao(ss) {
  var sh = novaAba(ss, 'PLANO_ACAO');
  cabecalho(sh, 'PLANO DE AÇÃO 5W2H',
    'Toda não conformidade da verificação ou da auditoria vira uma linha aqui. Só encerra com evidência.',
    ['ID','ORIGEM','ABERTURA','O QUE (não conformidade)','POR QUE','ONDE (zona/local)','QUEM','QUANDO (prazo)','COMO','QUANTO (R$)','CRITICIDADE','STATUS','CONCLUSÃO','DIAS EM ABERTO','EVIDÊNCIA']);
  larguras(sh, [60,140,100,300,220,150,140,110,260,90,100,110,110,110,180]);

  sh.getRange('C4:C2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('H4:H2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('M4:M2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('J4:J2000').setNumberFormat('R$ #,##0.00');
  sh.getRange('A4:A2000').setFormula('=IF($D4="","",TEXT(ROW()-3,"000"))');
  sh.getRange('N4:N2000').setFormula('=IF($C4="","",IF($M4<>"",$M4-$C4,TODAY()-$C4))');

  validacao(sh, 2, 4, ['Verificação N2','Auditoria N3','Ocorrência','Reclamação','Melhoria']);
  validacao(sh, 11, 4, ['Alta','Média','Baixa']);
  validacao(sh, 12, 4, ['Aberto','Em andamento','Concluído','Atrasado','Cancelado']);

  zebra(sh, 15);
  regraCor(sh, sh.getRange('L4:L2000'), '=$L4="Concluído"', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('L4:L2000'), '=OR($L4="Atrasado",AND($H4<>"",$H4<TODAY(),$L4<>"Concluído"))', '#FBE0E0', '#9B1C1C');
  regraCor(sh, sh.getRange('N4:N2000'), '=AND($N4<>"",$N4>15,$L4<>"Concluído")', '#FFF4CC', '#7A5B00');
  return sh;
}

// ============================================================================
//  ABA ESCALA
// ============================================================================
function criarEscala(ss) {
  var sh = novaAba(ss, 'ESCALA');
  var cols = ['COLABORADOR','TURNO','POSTO FIXO'];
  for (var d = 1; d <= 31; d++) cols.push(String(d));
  cols.push('FOLGAS','OBSERVAÇÃO');
  cabecalho(sh, 'ESCALA MENSAL DO SETOR DE LIMPEZA',
    'Preencha o posto de cada dia (A1, B3, C1...) ou F para folga, FE para férias e AT para atestado. Nenhum posto pode ficar descoberto.',
    cols);
  larguras(sh, [200, 60, 90]);
  for (var i = 4; i <= 34; i++) sh.setColumnWidth(i, 32);
  sh.setColumnWidth(35, 70); sh.setColumnWidth(36, 240);

  sh.getRange(2, 1).setValue('MÊS DE REFERÊNCIA: preencher na célula A2 do PAINEL  •  F = folga | FE = férias | AT = atestado | T = treinamento');
  sh.getRange(4, 35, 200, 1).setFormula('=IF($A4="","",COUNTIF($D4:$AH4,"F"))');
  sh.getRange(4, 1, sh.getMaxRows() - 3, 36)
    .setBorder(true, true, true, true, true, true, '#DCE3EB', SpreadsheetApp.BorderStyle.SOLID);
  sh.getRange(4, 4, 200, 31).setHorizontalAlignment('center').setFontSize(9);

  var faixa = sh.getRange(4, 4, 200, 31);
  regraCor(sh, faixa, '=D4="F"', '#E4E8EE', '#5B6B7F');
  regraCor(sh, faixa, '=D4="FE"', '#FFF4CC', '#7A5B00');
  regraCor(sh, faixa, '=D4="AT"', '#FBE0E0', '#9B1C1C');
  regraCor(sh, faixa, '=AND(D4<>"",LEFT(D4,1)="A")', '#DDEBFA', '#0B4EA2');
  regraCor(sh, faixa, '=AND(D4<>"",LEFT(D4,1)="B")', '#DCF3E3', '#12633A');
  regraCor(sh, faixa, '=AND(D4<>"",LEFT(D4,1)="C")', '#EFE3FA', '#5B21B6');
  return sh;
}

// ============================================================================
//  ABA OCORRENCIAS
// ============================================================================
function criarOcorrencias(ss) {
  var sh = novaAba(ss, 'OCORRENCIAS');
  cabecalho(sh, 'OCORRÊNCIAS DO SETOR',
    'Derramamentos, vazamentos, avarias, falta de insumo e condições inseguras — registrar no momento em que acontecem.',
    ['DATA','HORA','TURNO','TIPO','LOCAL','DESCRIÇÃO','AÇÃO TOMADA','COMUNICADO A','GEROU PLANO DE AÇÃO?','STATUS','REGISTRADO POR']);
  larguras(sh, [90,70,60,160,180,320,300,160,150,110,150]);
  sh.getRange('A4:A2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('B4:B2000').setNumberFormat('hh:mm');
  validacao(sh, 3, 4, ['A','B','C']);
  validacao(sh, 4, 4, ['Derramamento','Vazamento','Falta de insumo','Avaria de máquina','Resíduo fora do padrão','Condição insegura','Outro']);
  validacao(sh, 9, 4, ['Sim','Não']);
  validacao(sh, 10, 4, ['Aberto','Em andamento','Concluído']);
  zebra(sh, 11);
  return sh;
}

// ============================================================================
//  ABA INSUMOS
// ============================================================================
function criarInsumos(ss) {
  var sh = novaAba(ss, 'INSUMOS');
  cabecalho(sh, 'CONTROLE DE INSUMOS E EPI',
    'Entradas e saídas do depósito de material de limpeza. O saldo é calculado automaticamente por item.',
    ['DATA','MOVIMENTO','INSUMO','UNIDADE','QUANTIDADE','ZONA/ÁREA DESTINO','RETIRADO POR','CUSTO UNITÁRIO','CUSTO TOTAL','SALDO DO ITEM','OBSERVAÇÃO']);
  larguras(sh, [90,110,200,80,110,180,180,120,120,120,260]);
  sh.getRange('A4:A2000').setNumberFormat('dd/mm/yyyy');
  sh.getRange('H4:I2000').setNumberFormat('R$ #,##0.00');
  sh.getRange('I4:I2000').setFormula('=IF(N(E4)=0,"",E4*H4)');
  sh.getRange('J4:J2000').setFormula('=IF($C4="","",SUMIFS($E$4:$E4,$C$4:$C4,$C4,$B$4:$B4,"Entrada")-SUMIFS($E$4:$E4,$C$4:$C4,$C4,$B$4:$B4,"Saída"))');
  validacao(sh, 2, 4, ['Entrada','Saída']);
  var par = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('PARAMETROS');
  validacaoIntervalo(sh, 3, 4, par.getRange('O4:O100'));
  zebra(sh, 11);
  regraCor(sh, sh.getRange('J4:J2000'), '=AND($J4<>"",$J4<=0)', '#FBE0E0', '#9B1C1C');
  return sh;
}

// ============================================================================
//  ABA INICIO
// ============================================================================
function criarInicio(ss) {
  var sh = novaAba(ss, 'INICIO');
  sh.setHiddenGridlines(true);
  larguras(sh, [40, 320, 640, 40]);
  sh.getRange('B2:C2').merge().setValue('BARTOFIL — CD FEIRA DE SANTANA')
    .setFontSize(11).setFontColor('#5B6B7F').setFontWeight('bold');
  sh.getRange('B3:C3').merge().setValue('GESTÃO DA LIMPEZA E CONSERVAÇÃO')
    .setFontSize(22).setFontColor(AZUL).setFontWeight('bold');
  sh.getRange('B4:C4').merge().setValue('Ferramenta de trabalho do Supervisor de Limpeza — anexo N do POP-LIM-001')
    .setFontSize(11).setFontColor('#5B6B7F');
  sh.setRowHeight(3, 34);

  var linhas = [
    ['ROTINA DIÁRIA', ''],
    ['1. Início do turno', 'Menu Gestão da Limpeza > Gerar lançamentos do dia. A planilha cria as linhas previstas de cada posto na aba CHECKLIST.'],
    ['2. Durante o turno', 'Faça a ronda de verificação e registre na aba VERIFICACAO. Toda NC recebe ação imediata, criticidade e prazo.'],
    ['3. Fim do turno', 'Recolha as folhas dos setores e complete a aba CHECKLIST: itens previstos, itens conformes, folha entregue e assinada.'],
    ['4. Ocorrências', 'Derramamento, vazamento, avaria ou falta de insumo vão para a aba OCORRENCIAS no momento em que acontecem.'],
    ['', ''],
    ['ROTINA SEMANAL', ''],
    ['Plano de ação', 'Reveja a aba PLANO_ACAO: o que venceu, o que está em atraso e o que pode ser encerrado com evidência.'],
    ['Insumos', 'Lance entradas e saídas na aba INSUMOS e confira os saldos negativos destacados.'],
    ['Escala', 'Confira a aba ESCALA da semana seguinte: nenhum posto pode ficar descoberto.'],
    ['', ''],
    ['ROTINA MENSAL', ''],
    ['Auditoria', 'Execute a auditoria de infraestrutura com o formulário CHK-LIM-J e lance tudo na aba AUDITORIA_INFRA.'],
    ['Painel', 'Menu Gestão da Limpeza > Atualizar painel e apresente os indicadores à Gerência.'],
    ['Arquivo', 'Arquive as folhas físicas do mês. Guarda mínima: 12 meses.'],
    ['', ''],
    ['METAS DO SETOR', ''],
    ['IAL — aderência ao checklist', 'Meta: 95% ou mais das folhas previstas entregues completas e assinadas.'],
    ['NQL — nota de qualidade', 'Meta: 90 pontos ou mais na média das rondas de verificação.'],
    ['Auditoria de infraestrutura', 'Meta: 90% ou mais de itens conformes.'],
    ['Plano de ação', 'Meta: fechamento médio em até 15 dias e nenhuma NC reincidente pela 3ª vez.']
  ];
  sh.getRange(6, 2, linhas.length, 2).setValues(linhas).setVerticalAlignment('middle').setWrap(true);
  for (var i = 0; i < linhas.length; i++) {
    var r = 6 + i;
    if (linhas[i][1] === '' && linhas[i][0] !== '') {
      sh.getRange(r, 2, 1, 2).setBackground(AZUL).setFontColor(BRANCO).setFontWeight('bold').setFontSize(11);
      sh.setRowHeight(r, 26);
    } else if (linhas[i][0] !== '') {
      sh.getRange(r, 2).setFontWeight('bold').setFontColor(TEXTO);
      sh.getRange(r, 2, 1, 2).setBorder(null, null, true, null, null, null, '#DCE3EB', SpreadsheetApp.BorderStyle.SOLID);
      sh.setRowHeight(r, 34);
    }
  }
  return sh;
}

// ============================================================================
//  ABA PAINEL
// ============================================================================
function criarPainel(ss) {
  var sh = novaAba(ss, 'PAINEL');
  sh.setHiddenGridlines(true);
  larguras(sh, [30,190,150,150,150,150,150,190,30]);

  sh.getRange('B2:H2').merge().setValue('PAINEL DE INDICADORES — LIMPEZA E CONSERVAÇÃO')
    .setBackground(AZUL).setFontColor(BRANCO).setFontSize(15).setFontWeight('bold')
    .setVerticalAlignment('middle').setHorizontalAlignment('center');
  sh.setRowHeight(2, 42);

  sh.getRange('B4').setValue('MÊS DE REFERÊNCIA:').setFontWeight('bold');
  sh.getRange('C4').setValue(new Date()).setNumberFormat('mmmm "de" yyyy')
    .setBackground('#FFF9E0').setFontWeight('bold').setHorizontalAlignment('center')
    .setBorder(true, true, true, true, false, false, AMAREL, SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
  sh.getRange('D4').setValue('← digite qualquer data do mês que quer analisar')
    .setFontColor('#8A97A8').setFontSize(9);

  var INI = '">="&EOMONTH($C$4,-1)+1';
  var FIM = '"<="&EOMONTH($C$4,0)';

  var cards = [
    [6, 2, 'IAL — ADERÊNCIA AO CHECKLIST',
      '=IFERROR(TEXT(COUNTIFS(CHECKLIST!$A:$A,' + INI + ',CHECKLIST!$A:$A,' + FIM + ',CHECKLIST!$I:$I,"Sim",CHECKLIST!$J:$J,"Sim")/COUNTIFS(CHECKLIST!$A:$A,' + INI + ',CHECKLIST!$A:$A,' + FIM + '),"0.0%"),"—")',
      'Meta: 95%'],
    [6, 4, 'NQL — NOTA DE QUALIDADE',
      '=IFERROR(TEXT(AVERAGEIFS(VERIFICACAO!$G:$G,VERIFICACAO!$A:$A,' + INI + ',VERIFICACAO!$A:$A,' + FIM + '),"0.0"),"—")',
      'Meta: 90 pontos'],
    [6, 6, 'AUDITORIA DE INFRAESTRUTURA',
      '=IFERROR(TEXT(COUNTIFS(AUDITORIA_INFRA!$A:$A,' + INI + ',AUDITORIA_INFRA!$A:$A,' + FIM + ',AUDITORIA_INFRA!$E:$E,"C")/(COUNTIFS(AUDITORIA_INFRA!$A:$A,' + INI + ',AUDITORIA_INFRA!$A:$A,' + FIM + ',AUDITORIA_INFRA!$E:$E,"C")+COUNTIFS(AUDITORIA_INFRA!$A:$A,' + INI + ',AUDITORIA_INFRA!$A:$A,' + FIM + ',AUDITORIA_INFRA!$E:$E,"NC")),"0.0%"),"—")',
      'Meta: 90%'],
    [10, 2, 'NC EM ABERTO NO PLANO DE AÇÃO',
      '=COUNTIFS(PLANO_ACAO!$D:$D,"<>",PLANO_ACAO!$L:$L,"<>Concluído",PLANO_ACAO!$L:$L,"<>Cancelado")',
      'Acompanhar a tendência'],
    [10, 4, 'NC EM ATRASO',
      '=SUMPRODUCT((PLANO_ACAO!$H$4:$H$500<>"")*(PLANO_ACAO!$H$4:$H$500<TODAY())*(PLANO_ACAO!$L$4:$L$500<>"Concluído")*(PLANO_ACAO!$L$4:$L$500<>"Cancelado"))',
      'Meta: zero'],
    [10, 6, 'PRAZO MÉDIO DE FECHAMENTO',
      '=IFERROR(TEXT(AVERAGEIFS(PLANO_ACAO!$N:$N,PLANO_ACAO!$L:$L,"Concluído"),"0")&" dias","—")',
      'Meta: até 15 dias']
  ];

  cards.forEach(function (c) {
    var r = c[0], col = c[1];
    sh.getRange(r, col, 3, 2).setBackground('#F7FAFD')
      .setBorder(true, true, true, true, false, false, '#C8D6E5', SpreadsheetApp.BorderStyle.SOLID);
    sh.getRange(r, col, 1, 2).merge().setValue(c[2])
      .setFontSize(9).setFontWeight('bold').setFontColor('#5B6B7F')
      .setHorizontalAlignment('center').setVerticalAlignment('middle');
    sh.getRange(r + 1, col, 1, 2).merge().setFormula(c[3])
      .setFontSize(26).setFontWeight('bold').setFontColor(AZUL)
      .setHorizontalAlignment('center').setVerticalAlignment('middle');
    sh.getRange(r + 2, col, 1, 2).merge().setValue(c[4])
      .setFontSize(9).setFontColor('#8A97A8').setHorizontalAlignment('center');
    sh.setRowHeight(r, 28); sh.setRowHeight(r + 1, 52); sh.setRowHeight(r + 2, 22);
  });

  // ---------------- NQL POR ZONA ----------------
  sh.getRange('B14:H14').merge().setValue('NOTA DE QUALIDADE POR ZONA — MÊS DE REFERÊNCIA')
    .setBackground(AZULE).setFontColor(BRANCO).setFontWeight('bold').setFontSize(11)
    .setVerticalAlignment('middle');
  sh.setRowHeight(14, 28);
  sh.getRange('B15:G15').setValues([['ZONA','DESCRIÇÃO','RONDAS','NQL MÉDIO','NC ABERTAS','STATUS']])
    .setBackground(CINZA).setFontWeight('bold').setFontSize(9);
  for (var i = 0; i < 10; i++) {
    var r = 16 + i;
    sh.getRange(r, 2).setFormula('=IFERROR(PARAMETROS!F' + (4 + i) + ',"")');
    sh.getRange(r, 3).setFormula('=IFERROR(PARAMETROS!G' + (4 + i) + ',"")');
    sh.getRange(r, 4).setFormula('=IF($B' + r + '="","",COUNTIFS(VERIFICACAO!$D:$D,$B' + r + ',VERIFICACAO!$A:$A,' + INI + ',VERIFICACAO!$A:$A,' + FIM + '))');
    sh.getRange(r, 5).setFormula('=IF(N($D' + r + ')=0,"—",IFERROR(ROUND(AVERAGEIFS(VERIFICACAO!$G:$G,VERIFICACAO!$D:$D,$B' + r + ',VERIFICACAO!$A:$A,' + INI + ',VERIFICACAO!$A:$A,' + FIM + '),1),"—"))');
    sh.getRange(r, 6).setFormula('=IF($B' + r + '="","",COUNTIFS(PLANO_ACAO!$F:$F,$B' + r + ',PLANO_ACAO!$L:$L,"<>Concluído",PLANO_ACAO!$L:$L,"<>Cancelado"))');
    sh.getRange(r, 7).setFormula('=IF(OR($E' + r + '="—",$B' + r + '=""),"—",IF($E' + r + '>=90,"DENTRO DA META",IF($E' + r + '>=80,"ATENÇÃO","CRÍTICO")))');
  }
  sh.getRange('B16:G25').setBorder(true, true, true, true, true, true, '#DCE3EB', SpreadsheetApp.BorderStyle.SOLID);
  sh.getRange('D16:G25').setHorizontalAlignment('center');
  regraCor(sh, sh.getRange('G16:G25'), '=$G16="DENTRO DA META"', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('G16:G25'), '=$G16="ATENÇÃO"', '#FFF4CC', '#7A5B00');
  regraCor(sh, sh.getRange('G16:G25'), '=$G16="CRÍTICO"', '#FBE0E0', '#9B1C1C');

  // ---------------- DESEMPENHO POR TURNO ----------------
  sh.getRange('B27:H27').merge().setValue('DESEMPENHO POR TURNO')
    .setBackground(AZULE).setFontColor(BRANCO).setFontWeight('bold').setFontSize(11).setVerticalAlignment('middle');
  sh.setRowHeight(27, 28);
  sh.getRange('B28:G28').setValues([['TURNO','HORÁRIO','FOLHAS PREVISTAS','FOLHAS COMPLETAS','IAL','NQL MÉDIO']])
    .setBackground(CINZA).setFontWeight('bold').setFontSize(9);
  var turnos = ['A','B','C'], hor = ['06h00 - 15h00','15h00 - 00h00','00h00 - 06h00'];
  for (var t = 0; t < 3; t++) {
    var rt = 29 + t;
    sh.getRange(rt, 2).setValue(turnos[t]);
    sh.getRange(rt, 3).setValue(hor[t]);
    sh.getRange(rt, 4).setFormula('=COUNTIFS(CHECKLIST!$B:$B,$B' + rt + ',CHECKLIST!$A:$A,' + INI + ',CHECKLIST!$A:$A,' + FIM + ')');
    sh.getRange(rt, 5).setFormula('=COUNTIFS(CHECKLIST!$B:$B,$B' + rt + ',CHECKLIST!$A:$A,' + INI + ',CHECKLIST!$A:$A,' + FIM + ',CHECKLIST!$I:$I,"Sim",CHECKLIST!$J:$J,"Sim")');
    sh.getRange(rt, 6).setFormula('=IFERROR($E' + rt + '/$D' + rt + ',"—")').setNumberFormat('0.0%');
    sh.getRange(rt, 7).setFormula('=IFERROR(ROUND(AVERAGEIFS(VERIFICACAO!$G:$G,VERIFICACAO!$B:$B,$B' + rt + ',VERIFICACAO!$A:$A,' + INI + ',VERIFICACAO!$A:$A,' + FIM + '),1),"—")');
  }
  sh.getRange('B29:G31').setBorder(true, true, true, true, true, true, '#DCE3EB', SpreadsheetApp.BorderStyle.SOLID);
  sh.getRange('D29:G31').setHorizontalAlignment('center');
  regraCor(sh, sh.getRange('F29:F31'), '=AND(ISNUMBER($F29),$F29>=0.95)', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('F29:F31'), '=AND(ISNUMBER($F29),$F29<0.95)', '#FFF4CC', '#7A5B00');

  // ---------------- AUDITORIA POR BLOCO ----------------
  sh.getRange('B33:H33').merge().setValue('AUDITORIA DE INFRAESTRUTURA — CONFORMIDADE POR BLOCO')
    .setBackground(AZULE).setFontColor(BRANCO).setFontWeight('bold').setFontSize(11).setVerticalAlignment('middle');
  sh.setRowHeight(33, 28);
  sh.getRange('B34:F34').setValues([['BLOCO','ITENS C','ITENS NC','% CONFORME','NC ALTA EM ABERTO']])
    .setBackground(CINZA).setFontWeight('bold').setFontSize(9);
  var blocos = ['1. Iluminação','2. Pintura e demarcação','3. Sistema de câmeras (CFTV)','4. Sinalização',
                '5. Hidrossanitário','6. Combate a incêndio','7. Cobertura, piso e estrutura',
                '8. Vivência e ventilação','9. Controle de pragas'];
  for (var b = 0; b < blocos.length; b++) {
    var rb = 35 + b;
    sh.getRange(rb, 2).setValue(blocos[b]);
    sh.getRange(rb, 3).setFormula('=COUNTIFS(AUDITORIA_INFRA!$C:$C,$B' + rb + ',AUDITORIA_INFRA!$E:$E,"C",AUDITORIA_INFRA!$A:$A,' + INI + ',AUDITORIA_INFRA!$A:$A,' + FIM + ')');
    sh.getRange(rb, 4).setFormula('=COUNTIFS(AUDITORIA_INFRA!$C:$C,$B' + rb + ',AUDITORIA_INFRA!$E:$E,"NC",AUDITORIA_INFRA!$A:$A,' + INI + ',AUDITORIA_INFRA!$A:$A,' + FIM + ')');
    sh.getRange(rb, 5).setFormula('=IFERROR($C' + rb + '/($C' + rb + '+$D' + rb + '),"—")').setNumberFormat('0%');
    sh.getRange(rb, 6).setFormula('=COUNTIFS(AUDITORIA_INFRA!$C:$C,$B' + rb + ',AUDITORIA_INFRA!$G:$G,"Alta",AUDITORIA_INFRA!$L:$L,"<>Concluído")');
  }
  sh.getRange('B35:F43').setBorder(true, true, true, true, true, true, '#DCE3EB', SpreadsheetApp.BorderStyle.SOLID);
  sh.getRange('C35:F43').setHorizontalAlignment('center');
  regraCor(sh, sh.getRange('E35:E43'), '=AND(ISNUMBER($E35),$E35>=0.9)', '#DCF3E3', '#12633A');
  regraCor(sh, sh.getRange('E35:E43'), '=AND(ISNUMBER($E35),$E35<0.9)', '#FBE0E0', '#9B1C1C');
  regraCor(sh, sh.getRange('F35:F43'), '=$F35>0', '#FBE0E0', '#9B1C1C');

  sh.getRange('B45').setValue('Atualizado em:').setFontColor('#8A97A8').setFontSize(9);
  sh.getRange('C45').setFormula('=TEXT(NOW(),"dd/mm/yyyy hh:mm")').setFontColor('#8A97A8').setFontSize(9);
  return sh;
}

// ============================================================================
//  AÇÕES DO MENU
// ============================================================================
function gerarLancamentosDoDia() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var ui = SpreadsheetApp.getUi();
  var resp = ui.prompt('Gerar lançamentos', 'Data (dd/mm/aaaa). Deixe em branco para hoje:', ui.ButtonSet.OK_CANCEL);
  if (resp.getSelectedButton() !== ui.Button.OK) return;

  var txt = resp.getResponseText().trim();
  var data = new Date();
  if (txt) {
    var pp = txt.split('/');
    if (pp.length !== 3) { ui.alert('Data inválida. Use dd/mm/aaaa.'); return; }
    data = new Date(Number(pp[2]), Number(pp[1]) - 1, Number(pp[0]));
  }
  data.setHours(0, 0, 0, 0);

  var par = ss.getSheetByName('PARAMETROS');
  var postos = par.getRange('C4:E30').getValues().filter(function (r) { return r[0] !== ''; });
  var chk = ss.getSheetByName('CHECKLIST');

  // evita duplicar o mesmo dia
  var existentes = chk.getRange('A4:C' + Math.max(4, chk.getLastRow())).getValues();
  var jaTem = {};
  existentes.forEach(function (r) {
    if (r[0] instanceof Date) jaTem[Utilities.formatDate(r[0], 'America/Bahia', 'ddMMyyyy') + '|' + r[2]] = true;
  });

  var novas = [];
  postos.forEach(function (pst) {
    var chave = Utilities.formatDate(data, 'America/Bahia', 'ddMMyyyy') + '|' + pst[0];
    if (jaTem[chave]) return;
    novas.push([data, pst[2], pst[0], '', '', '', '', '', '', '', '', '', Session.getActiveUser().getEmail()]);
  });

  if (!novas.length) { ui.alert('Os lançamentos desse dia já existem.'); return; }
  var linha = Math.max(4, chk.getLastRow() + 1);
  chk.getRange(linha, 1, novas.length, 13).setValues(novas);
  chk.getRange(linha, 1, novas.length, 1).setNumberFormat('dd/mm/yyyy');
  chk.getRange(linha, 8, novas.length, 1).setFormula('=IF(N(F' + linha + ')=0,"",G' + linha + '/F' + linha + ')');
  ss.setActiveSheet(chk);
  ui.alert(novas.length + ' lançamentos criados para ' + Utilities.formatDate(data, 'America/Bahia', 'dd/MM/yyyy') + '.');
}

function atualizarPainel() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  SpreadsheetApp.flush();
  ss.setActiveSheet(ss.getSheetByName('PAINEL'));
  SpreadsheetApp.getActive().toast('Painel atualizado.', 'Gestão da Limpeza', 4);
}

function filtrarPlanoAberto() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('PLANO_ACAO');
  ss.setActiveSheet(sh);
  var f = sh.getFilter(); if (f) f.remove();
  var ult = Math.max(4, sh.getLastRow());
  sh.getRange(3, 1, ult - 2, 15).createFilter()
    .setColumnFilterCriteria(12, SpreadsheetApp.newFilterCriteria()
      .setHiddenValues(['Concluído', 'Cancelado']).build());
  SpreadsheetApp.getActive().toast('Filtrado: apenas o que está em aberto.', 'Plano de ação', 4);
}

function enviarResumoMensal() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var ui = SpreadsheetApp.getUi();
  var p = ss.getSheetByName('PAINEL');
  var resp = ui.prompt('Resumo mensal', 'E-mail do destinatário:', ui.ButtonSet.OK_CANCEL);
  if (resp.getSelectedButton() !== ui.Button.OK) return;
  var email = resp.getResponseText().trim();
  if (!email) { ui.alert('Informe um e-mail.'); return; }

  var mes = Utilities.formatDate(new Date(p.getRange('C4').getValue()), 'America/Bahia', 'MM/yyyy');
  var corpo =
    '<div style="font-family:Arial,sans-serif;color:#1F2937">' +
    '<h2 style="color:#0B4EA2;margin:0 0 4px">Limpeza e Conservação — CD Feira de Santana</h2>' +
    '<p style="margin:0 0 16px;color:#5B6B7F">Resumo de ' + mes + '</p>' +
    '<table cellpadding="8" cellspacing="0" style="border-collapse:collapse;font-size:14px">' +
    linhaEmail('IAL — aderência ao checklist', p.getRange('B7').getDisplayValue(), 'Meta 95%') +
    linhaEmail('NQL — nota de qualidade', p.getRange('D7').getDisplayValue(), 'Meta 90 pontos') +
    linhaEmail('Auditoria de infraestrutura', p.getRange('F7').getDisplayValue(), 'Meta 90%') +
    linhaEmail('NC em aberto', p.getRange('B11').getDisplayValue(), '') +
    linhaEmail('NC em atraso', p.getRange('D11').getDisplayValue(), 'Meta zero') +
    linhaEmail('Prazo médio de fechamento', p.getRange('F11').getDisplayValue(), 'Meta 15 dias') +
    '</table>' +
    '<p style="margin-top:18px"><a href="' + ss.getUrl() + '" style="color:#0B4EA2">Abrir a planilha completa</a></p>' +
    '</div>';
  MailApp.sendEmail({ to: email, subject: 'Limpeza CD — resumo de ' + mes, htmlBody: corpo });
  ui.alert('Resumo enviado para ' + email + '.');
}

function linhaEmail(rotulo, valor, meta) {
  return '<tr>' +
    '<td style="border-bottom:1px solid #E5E9F0">' + rotulo + '</td>' +
    '<td style="border-bottom:1px solid #E5E9F0;font-weight:bold;color:#0B4EA2;font-size:18px">' + valor + '</td>' +
    '<td style="border-bottom:1px solid #E5E9F0;color:#8A97A8">' + meta + '</td></tr>';
}
