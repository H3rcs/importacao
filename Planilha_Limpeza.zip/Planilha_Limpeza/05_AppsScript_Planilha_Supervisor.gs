/**
 * ============================================================================
 *  BARTOFIL — CD FEIRA DE SANTANA
 *  GESTÃO DA LIMPEZA E CONSERVAÇÃO  —  anexo N do POP-LIM-001
 * ----------------------------------------------------------------------------
 *  Esta planilha é um RESUMO, não uma cópia dos formulários.
 *  Só entra aqui: o que saiu NÃO CONFORME, o que virou ação, o que precisa
 *  ficar registrado e o custo/rendimento dos produtos.
 * ----------------------------------------------------------------------------
 *  COMO INSTALAR
 *  1. Abra sheets.new para criar uma planilha em branco.
 *  2. Menu Extensões > Apps Script.
 *  3. Apague o conteúdo de Código.gs e cole TODO este arquivo.
 *  4. Salve e execute a função  criarEstrutura  uma vez. Autorize quando pedir.
 *  5. Volte para a planilha e recarregue a página (F5).
 *     O menu "Gestão da Limpeza" aparece ao lado de Ajuda.
 * ============================================================================
 */

// ---------------------------------------------------------------- IDENTIDADE
var AZUL='#0B4EA2', AZULE='#063668', AZULC='#DDEBFA';
var VERDE='#2AA84A', VERDEC='#DCF3E3';
var AMAR='#F2C300', AMARC='#FFF6D6';
var BOM='#1E8E3E', ATEN='#B26B00', CRIT='#C0392B';
var BOMC='#E3F5E8', ATENC='#FDF0DA', CRITC='#FAE3E1';
var TXT='#1F2937', SEC='#6B7A8F', MUT='#9AA7B8';
var BRANCO='#FFFFFF', LINHA='#E6ECF3', PAPEL='#F7F9FC';
var FONTE='Arial';

var NL = 400;        // linhas úteis das abas de lançamento
var PROD_NL = 40;    // linhas da aba PRODUTOS
var REN_NL = 200;    // linhas da aba RENDIMENTO

var ZONAS = [
  ['Z1','Armazenagem — porta-paletes'],['Z2','Separação, picking e miudeza'],
  ['Z3','Expedição e docas'],['Z4','Recebimento'],['Z5','Central de cargas'],
  ['Z6','Mezanino'],['Z7','Sanitários e vestiários'],['Z8','Áreas nobres e administrativo'],
  ['Z9','Áreas externas e apoio'],['Z10','Resíduos e recicláveis']];
var ORIGENS = ['Checklist de posto','Ronda do supervisor','Auditoria mensal','Ocorrência do turno','Reclamação'];
var FORMS = ['CHK-LIM-A','CHK-LIM-B','CHK-LIM-C1','CHK-LIM-C2','CHK-LIM-D','CHK-LIM-E',
             'CHK-LIM-F','CHK-LIM-G','CHK-LIM-H','CHK-LIM-I','CHK-LIM-J'];
var CRITS = ['Alta','Média','Baixa'];
var STATUS = ['Aberta','Em andamento','Concluída','Cancelada'];
var TIPOS = ['Derramamento','Vazamento','Avaria de máquina','Falta de insumo','Condição insegura',
             'Quase-acidente','Visita / auditoria externa','Treinamento aplicado','Mudança de layout',
             'Elogio / reclamação','Outro'];
var RESPS = ['Supervisor de Limpeza','Manutenção Predial','SESMT','Gerência de Logística','Compras','Equipe do turno'];
var NC = "'NÃO CONFORMIDADES'";
var RT = "'RESUMO TURNOS'";

// ============================================================================
//  MENU
// ============================================================================
function onOpen() {
  SpreadsheetApp.getUi().createMenu('Gestão da Limpeza')
    .addItem('Abrir o painel', 'irPainel')
    .addSeparator()
    .addItem('Nova não conformidade', 'novaNC')
    .addItem('Novo registro do setor', 'novoRegistro')
    .addItem('Fechar o turno (resumo)', 'novoResumoTurno')
    .addItem('Abri uma embalagem nova', 'novaEmbalagem')
    .addSeparator()
    .addItem('Ver só o que está em aberto', 'filtrarAberto')
    .addItem('Limpar filtros', 'limparFiltros')
    .addItem('Resumo do mês por e-mail', 'enviarResumo')
    .addSeparator()
    .addItem('Apagar as linhas de exemplo', 'apagarExemplos')
    .addItem('Reconstruir estrutura (apaga tudo)', 'criarEstrutura')
    .addToUi();
}

// ============================================================================
//  CONSTRUÇÃO
// ============================================================================
function criarEstrutura() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ss.rename('Gestão da Limpeza — CD Bartofil Feira de Santana');
  ss.setSpreadsheetLocale('pt_BR');
  ss.setSpreadsheetTimeZone('America/Bahia');

  abaCadastros(ss);
  abaNC(ss);
  abaRegistros(ss);
  abaResumoTurnos(ss);
  abaProdutos(ss);
  abaRendimento(ss);
  abaCompras(ss);
  abaCalc(ss);
  abaPainel(ss);
  abaInicio(ss);

  var p = ss.getSheetByName('Página1') || ss.getSheetByName('Sheet1');
  if (p) ss.deleteSheet(p);

  var ordem = ['INÍCIO','PAINEL','NÃO CONFORMIDADES','REGISTROS','RESUMO TURNOS',
               'PRODUTOS','RENDIMENTO','COMPRAS','CADASTROS','CALC'];
  for (var i = 0; i < ordem.length; i++) {
    var sh = ss.getSheetByName(ordem[i]);
    if (sh) { ss.setActiveSheet(sh); ss.moveActiveSheet(i + 1); }
  }
  ss.getSheetByName('CALC').hideSheet();
  ss.setActiveSheet(ss.getSheetByName('INÍCIO'));
  SpreadsheetApp.getUi().alert('Pronto. Recarregue a página (F5) para o menu aparecer.');
}

function nova(ss, nome, linhas, colunas) {
  var sh = ss.getSheetByName(nome);
  if (sh) ss.deleteSheet(sh);
  sh = ss.insertSheet(nome);
  if (sh.getMaxRows() < linhas) sh.insertRowsAfter(sh.getMaxRows(), linhas - sh.getMaxRows());
  if (sh.getMaxRows() > linhas) sh.deleteRows(linhas + 1, sh.getMaxRows() - linhas);
  if (sh.getMaxColumns() < colunas) sh.insertColumnsAfter(sh.getMaxColumns(), colunas - sh.getMaxColumns());
  if (sh.getMaxColumns() > colunas) sh.deleteColumns(colunas + 1, sh.getMaxColumns() - colunas);
  sh.setHiddenGridlines(true);
  return sh;
}

function cabecalho(sh, titulo, sub, cols, larg, ultima) {
  var n = cols.length;
  sh.getRange(1, 1, 1, n).merge().setValue(titulo)
    .setBackground(AZUL).setFontColor(BRANCO).setFontFamily(FONTE)
    .setFontSize(13).setFontWeight('bold').setVerticalAlignment('middle');
  sh.setRowHeight(1, 34);
  sh.getRange(2, 1, 1, n).merge().setValue(sub)
    .setBackground(AZULE).setFontColor('#BBD3F0').setFontFamily(FONTE)
    .setFontSize(9).setVerticalAlignment('middle');
  sh.setRowHeight(2, 22);
  sh.getRange(3, 1, 1, n).setValues([cols])
    .setBackground(PAPEL).setFontColor(AZUL).setFontWeight('bold').setFontFamily(FONTE)
    .setFontSize(9).setWrap(true).setVerticalAlignment('middle').setHorizontalAlignment('center')
    .setBorder(null, null, true, null, null, null, AZUL, SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
  sh.setRowHeight(3, 36);
  sh.setFrozenRows(3);
  for (var i = 0; i < larg.length; i++) sh.setColumnWidth(i + 1, larg[i]);
  sh.getRange(4, 1, ultima - 3, n)
    .setFontFamily(FONTE).setFontSize(10).setFontColor(TXT).setVerticalAlignment('middle')
    .setBorder(true, true, true, true, true, true, LINHA, SpreadsheetApp.BorderStyle.SOLID);
  regra(sh, sh.getRange(4, 1, ultima - 3, n), '=AND(MOD(ROW(),2)=0,$A4<>"")', PAPEL, null);
}

function lista(sh, col, linhaIni, ultima, valores) {
  var r = SpreadsheetApp.newDataValidation().requireValueInList(valores, true)
          .setAllowInvalid(false).build();
  sh.getRange(linhaIni, col, ultima - linhaIni + 1, 1).setDataValidation(r);
}
function listaRange(sh, col, linhaIni, ultima, intervalo) {
  var r = SpreadsheetApp.newDataValidation().requireValueInRange(intervalo, true)
          .setAllowInvalid(true).build();
  sh.getRange(linhaIni, col, ultima - linhaIni + 1, 1).setDataValidation(r);
}
function regra(sh, intervalo, formula, fundo, cor, negrito) {
  var b = SpreadsheetApp.newConditionalFormatRule().whenFormulaSatisfied(formula)
          .setBackground(fundo).setRanges([intervalo]);
  if (cor) b = b.setFontColor(cor);
  if (negrito) b = b.setBold(true);
  var regras = sh.getConditionalFormatRules(); regras.push(b.build());
  sh.setConditionalFormatRules(regras);
}
function exemplo(sh, linha, n) {
  sh.getRange(linha, 1, 1, n).setFontColor('#7B8AA0').setFontStyle('italic');
}

// ============================================================================
//  CADASTROS
// ============================================================================
function abaCadastros(ss) {
  var sh = nova(ss, 'CADASTROS', 60, 12);
  cabecalho(sh, 'CADASTROS',
    'Listas usadas pelos menus suspensos das outras abas. Ajuste aqui e o resto acompanha.',
    ['ZONA','DESCRIÇÃO DA ZONA (preencher com as ruas reais)','ÁREA m²','TURNO','HORÁRIO',
     'ORIGEM DA NC','FORMULÁRIO','CRITICIDADE','STATUS','TIPO DE REGISTRO','RESPONSÁVEL','COLABORADOR'],
    [70,330,70,60,110,170,110,100,110,190,160,180], 60);
  sh.getRange(4, 1, ZONAS.length, 2).setValues(ZONAS);
  sh.getRange(4, 4, 3, 2).setValues([['A','06h00 - 15h00'],['B','15h00 - 00h00'],['C','00h00 - 06h00']]);
  col(sh, 6, ORIGENS); col(sh, 7, FORMS); col(sh, 8, CRITS);
  col(sh, 9, STATUS); col(sh, 10, TIPOS); col(sh, 11, RESPS);
  sh.getRange(4, 12).setValue('(preencher com o efetivo do setor)')
    .setFontColor(MUT).setFontStyle('italic');
}
function col(sh, c, arr) {
  var v = arr.map(function (x) { return [x]; });
  sh.getRange(4, c, v.length, 1).setValues(v);
}

// ============================================================================
//  NÃO CONFORMIDADES
// ============================================================================
function abaNC(ss) {
  var sh = nova(ss, 'NÃO CONFORMIDADES', NL, 18);
  cabecalho(sh, 'NÃO CONFORMIDADES E AÇÕES',
    'O coração da planilha. Só entra aqui o que saiu NÃO CONFORME nos formulários — não copie o checklist inteiro.',
    ['ID','DATA','TURNO','ORIGEM','FORM.','ZONA','LOCAL EXATO','O QUE FOI ENCONTRADO','CRIT.',
     'AÇÃO DEFINIDA','RESPONSÁVEL','PRAZO','STATUS','FECHAMENTO','DIAS EM ABERTO','REINCID.',
     'EVIDÊNCIA / Nº CHAMADO','ordem'],
    [45,85,55,150,80,55,170,300,60,280,150,85,105,90,80,70,160,50], NL);

  sh.getRange('A4:A' + NL).setFormula('=IF($H4="","",TEXT(ROW()-3,"000"))');
  sh.getRange('O4:O' + NL).setFormula(
    '=IF($B4="","",IF($N4<>"",$N4-$B4,IF(OR($M4="Concluída",$M4="Cancelada"),"",TODAY()-$B4)))');
  sh.getRange('P4:P' + NL).setFormula(
    '=IF($H4="","",COUNTIFS($G$4:$G$' + NL + ',$G4,$H$4:$H$' + NL + ',$H4))');
  sh.getRange('R4:R' + NL).setFormula(
    '=IF(OR($M4="Concluída",$M4="Cancelada",$L4="",$H4=""),"",' +
    'COUNTIFS($L$4:$L$' + NL + ',"<"&$L4,$M$4:$M$' + NL + ',"<>Concluída",$M$4:$M$' + NL + ',"<>Cancelada",$H$4:$H$' + NL + ',"<>")' +
    '+COUNTIFS($L$4:$L4,$L4,$M$4:$M4,"<>Concluída",$M$4:$M4,"<>Cancelada",$H$4:$H4,"<>"))');
  sh.hideColumns(18);

  sh.getRange('B4:B' + NL).setNumberFormat('dd/mm/yyyy');
  sh.getRange('L4:L' + NL).setNumberFormat('dd/mm/yyyy');
  sh.getRange('N4:N' + NL).setNumberFormat('dd/mm/yyyy');
  [1,3,5,6,9,12,13,15,16].forEach(function (c) {
    sh.getRange(4, c, NL - 3, 1).setHorizontalAlignment('center');
  });
  sh.getRange(4, 8, NL - 3, 1).setWrap(true);
  sh.getRange(4, 10, NL - 3, 1).setWrap(true);

  lista(sh, 3, 4, NL, ['A','B','C']);
  lista(sh, 4, 4, NL, ORIGENS);
  lista(sh, 5, 4, NL, FORMS);
  listaRange(sh, 6, 4, NL, ss.getSheetByName('CADASTROS').getRange('A4:A13'));
  lista(sh, 9, 4, NL, CRITS);
  lista(sh, 11, 4, NL, RESPS);
  lista(sh, 13, 4, NL, STATUS);

  regra(sh, sh.getRange(4, 9, NL - 3, 1), '=$I4="Alta"', CRITC, CRIT, true);
  regra(sh, sh.getRange(4, 9, NL - 3, 1), '=$I4="Média"', ATENC, ATEN, true);
  regra(sh, sh.getRange(4, 9, NL - 3, 1), '=$I4="Baixa"', BOMC, BOM, true);
  regra(sh, sh.getRange(4, 13, NL - 3, 1), '=$M4="Concluída"', BOMC, BOM, true);
  regra(sh, sh.getRange(4, 13, NL - 3, 1), '=$M4="Em andamento"', AZULC, AZUL, true);
  regra(sh, sh.getRange(4, 12, NL - 3, 2),
        '=AND($L4<>"",$L4<TODAY(),$M4<>"Concluída",$M4<>"Cancelada")', CRITC, CRIT, true);
  regra(sh, sh.getRange(4, 16, NL - 3, 1), '=$P4>=3', CRITC, CRIT, true);
  regra(sh, sh.getRange(4, 15, NL - 3, 1), '=AND(ISNUMBER($O4),$O4>15)', ATENC, ATEN, false);

  // exemplos — só nas colunas de digitação (B..N e Q), para não apagar as fórmulas de O, P e R
  sh.getRange(4, 2, 4, 13).setValues([
    [new Date(2026,8,10),'A','Ronda do supervisor','CHK-LIM-I','Z7','Banheiro da central',
     'Ralo com acúmulo e odor forte','Média','Desobstruir, desinfetar e incluir o ralo no checklist diário',
     'Supervisor de Limpeza',new Date(2026,8,12),'Concluída',new Date(2026,8,11)],
    [new Date(2026,8,8),'A','Ocorrência do turno','CHK-LIM-H','Z3','Doca 3',
     'Vazamento de óleo hidráulico de empilhadeira, cerca de 2 m²','Alta',
     'Abrir chamado da empilhadeira 04 e repor o kit de contenção da doca','Manutenção Predial',
     new Date(2026,8,12),'Em andamento',''],
    [new Date(2026,8,5),'B','Auditoria mensal','CHK-LIM-J','Z1','Rua 12',
     'Três luminárias apagadas sobre o corredor de picking','Média','Trocar reatores e lâmpadas',
     'Manutenção Predial',new Date(2026,8,15),'Aberta',''],
    [new Date(2026,8,2),'C','Checklist de posto','CHK-LIM-G','Z7','Vestiário central masculino',
     'Dispenser de papel toalha quebrado','Baixa','Substituir o dispenser','Compras',
     new Date(2026,8,8),'Aberta','']]);
  sh.getRange(4, 17, 4, 1).setValues([['Foto no Drive'],['CH-0151'],['CH-0142'],['']]);
  for (var i = 4; i <= 7; i++) exemplo(sh, i, 17);
}

// ============================================================================
//  REGISTROS
// ============================================================================
function abaRegistros(ss) {
  var sh = nova(ss, 'REGISTROS', NL, 11);
  cabecalho(sh, 'REGISTROS IMPORTANTES DO SETOR',
    'O que aconteceu e precisa ficar guardado: derramamento, avaria, visita, treinamento, quase-acidente, elogio.',
    ['DATA','HORA','TURNO','TIPO','LOCAL','O QUE ACONTECEU','O QUE FOI FEITO','COMUNICADO A',
     'GEROU NC?','ID DA NC','REGISTRADO POR'],
    [85,60,55,180,160,330,320,160,90,70,160], NL);
  sh.getRange('A4:A' + NL).setNumberFormat('dd/mm/yyyy');
  sh.getRange('B4:B' + NL).setNumberFormat('hh:mm');
  [1,2,3,9,10].forEach(function (c) { sh.getRange(4, c, NL - 3, 1).setHorizontalAlignment('center'); });
  sh.getRange(4, 6, NL - 3, 2).setWrap(true);
  lista(sh, 3, 4, NL, ['A','B','C']);
  lista(sh, 4, 4, NL, TIPOS);
  lista(sh, 9, 4, NL, ['Sim','Não']);
  regra(sh, sh.getRange(4, 4, NL - 3, 1),
        '=OR($D4="Quase-acidente",$D4="Condição insegura")', CRITC, CRIT, true);
  regra(sh, sh.getRange(4, 4, NL - 3, 1), '=$D4="Elogio / reclamação"', AZULC, AZUL, false);
  sh.getRange(4, 1, 1, 11).setValues([[new Date(2026,8,8),'14:10','A','Derramamento','Doca 3',
    'Vazamento de óleo hidráulico de empilhadeira, cerca de 2 m²',
    'Área isolada, contida com serragem e lavada com desengraxante','Líder da expedição','Sim','002','Supervisor']]);
  exemplo(sh, 4, 11);
}

// ============================================================================
//  RESUMO DOS TURNOS
// ============================================================================
function abaResumoTurnos(ss) {
  var sh = nova(ss, 'RESUMO TURNOS', NL, 9);
  cabecalho(sh, 'RESUMO DIÁRIO DOS TURNOS',
    'Uma linha por dia e turno. Do maço de folhas recolhidas, só o resumo: quantas voltaram, a nota da ronda e o destaque.',
    ['DATA','TURNO','FOLHAS PREVISTAS','FOLHAS ENTREGUES','% ENTREGA','NOTA DA RONDA (0-100)',
     'NC ABERTAS NO TURNO','DESTAQUE / PENDÊNCIA DO TURNO','SUPERVISOR'],
    [90,60,110,120,90,120,110,420,160], NL);
  sh.getRange('E4:E' + NL).setFormula('=IF(N($C4)=0,"",$D4/$C4)').setNumberFormat('0%');
  sh.getRange('G4:G' + NL).setFormula(
    '=IF($A4="","",COUNTIFS(' + NC + '!$B:$B,$A4,' + NC + '!$C:$C,$B4))');
  sh.getRange('A4:A' + NL).setNumberFormat('dd/mm/yyyy');
  for (var c = 1; c <= 7; c++) sh.getRange(4, c, NL - 3, 1).setHorizontalAlignment('center');
  sh.getRange(4, 8, NL - 3, 1).setWrap(true);
  lista(sh, 2, 4, NL, ['A','B','C']);
  var e = sh.getRange(4, 5, NL - 3, 1), f = sh.getRange(4, 6, NL - 3, 1);
  regra(sh, e, '=AND(ISNUMBER($E4),$E4>=0.95)', BOMC, BOM, true);
  regra(sh, e, '=AND(ISNUMBER($E4),$E4<0.95,$E4>=0.85)', ATENC, ATEN, true);
  regra(sh, e, '=AND(ISNUMBER($E4),$E4<0.85)', CRITC, CRIT, true);
  regra(sh, f, '=AND(ISNUMBER($F4),$F4>=90)', BOMC, BOM, true);
  regra(sh, f, '=AND(ISNUMBER($F4),$F4<90,$F4>=80)', ATENC, ATEN, true);
  regra(sh, f, '=AND(ISNUMBER($F4),$F4<80)', CRITC, CRIT, true);
  regra(sh, sh.getRange(4, 7, NL - 3, 1), '=$G4>0', ATENC, ATEN, false);
  sh.getRange(4, 1, 1, 4).setValues([[new Date(2026,8,10),'A',6,6]]);
  sh.getRange(4, 6).setValue(92);
  sh.getRange(4, 8, 1, 2).setValues([['Rua 12 bloqueada por recebimento — varrição reprogramada para o turno B','Supervisor']]);
  exemplo(sh, 4, 9);
}

// ============================================================================
//  PRODUTOS
// ============================================================================
function abaProdutos(ss) {
  var sh = nova(ss, 'PRODUTOS', PROD_NL + 6, 15);
  cabecalho(sh, 'PRODUTOS — CUSTO, CONCENTRAÇÃO E RENDIMENTO',
    'Preencha só as colunas de fundo azul claro. O resto é calculado: quanto rende a embalagem, quanto custa cada aplicação e quantos dias deve durar.',
    ['PRODUTO','TIPO','EMBALAGEM (ml)','PREÇO DA EMBALAGEM (R$)','DILUIÇÃO (ml por litro de solução)',
     'SOLUÇÃO POR APLICAÇÃO (L)','ml POR APLICAÇÃO','APLICAÇÕES POR EMBALAGEM','CUSTO POR APLICAÇÃO',
     'CUSTO POR LITRO DE SOLUÇÃO','APLICAÇÕES POR DIA (estimativa)','DURAÇÃO PREVISTA (dias)',
     'CUSTO POR DIA','CUSTO MENSAL PREVISTO (30 dias)','ONDE É USADO'],
    [210,100,95,110,115,110,95,110,100,110,115,100,95,115,250], PROD_NL);

  sh.getRange(4, 1, 7, 15).setValues([
    ['Detergente neutro','Concentrado',5000,42.90,20,8,'','','','',6,'','','','Piso em geral, bancadas e superfícies laváveis'],
    ['Desinfetante quaternário','Concentrado',5000,68.00,25,8,'','','','',9,'','','','Sanitários, vestiários e lixeiras'],
    ['Desincrustante ácido','Concentrado',1000,24.50,50,2,'','','','',3,'','','','Incrustação em louças e mictórios'],
    ['Desengraxante alcalino','Concentrado',5000,79.00,40,10,'','','','',2,'','','','Docas, área de manutenção e manchas de óleo'],
    ['Limpa-vidros','Pronto uso',500,9.80,'',0.05,'','','','',4,'','','','Vidros, espelhos e divisórias'],
    ['Álcool 70%','Pronto uso',1000,12.40,'',0.08,'','','','',6,'','','','Maçanetas, telefones e pontos de contato'],
    ['Água sanitária','Concentrado',5000,18.90,25,8,'','','','',2,'','','','Onde autorizado pelo SESMT']]);

  sh.getRange('G4:G' + PROD_NL).setFormula('=IF($A4="","",IF($B4="Pronto uso",$F4*1000,$E4*$F4))').setNumberFormat('#,##0.0');
  sh.getRange('H4:H' + PROD_NL).setFormula('=IFERROR($C4/$G4,"")').setNumberFormat('#,##0');
  sh.getRange('I4:I' + PROD_NL).setFormula('=IFERROR($D4/$H4,"")').setNumberFormat('R$ #,##0.00');
  sh.getRange('J4:J' + PROD_NL).setFormula('=IF($A4="","",IFERROR(IF($B4="Pronto uso",$D4/$C4*1000,($D4/$C4)*$E4),""))').setNumberFormat('R$ #,##0.00');
  sh.getRange('L4:L' + PROD_NL).setFormula('=IFERROR($H4/$K4,"")').setNumberFormat('#,##0.0');
  sh.getRange('M4:M' + PROD_NL).setFormula('=IFERROR($I4*$K4,"")').setNumberFormat('R$ #,##0.00');
  sh.getRange('N4:N' + PROD_NL).setFormula('=IFERROR($M4*30,"")').setNumberFormat('R$ #,##0.00');
  sh.getRange('C4:C' + PROD_NL).setNumberFormat('#,##0');
  sh.getRange('D4:D' + PROD_NL).setNumberFormat('R$ #,##0.00');
  sh.getRange(4, 2, PROD_NL - 3, 13).setHorizontalAlignment('center');
  [1,2,3,4,5,6,11].forEach(function (c) { sh.getRange(4, c, PROD_NL - 3, 1).setBackground('#EFF6FF'); });
  [7,8,9,10,12,13,14].forEach(function (c) {
    sh.getRange(4, c, PROD_NL - 3, 1).setFontColor(AZUL).setFontWeight('bold');
  });
  lista(sh, 2, 4, PROD_NL, ['Concentrado','Pronto uso']);

  sh.getRange(PROD_NL + 2, 1, 3, 1).setValues([
    ['Fundo azul claro = você preenche. Texto em azul = calculado, não digite nada.'],
    ['Exemplo: 5.000 ml de desinfetante, 25 ml por litro, 8 L por balde = 200 ml por aplicação → 25 aplicações por embalagem.'],
    ['Os preços e diluições acima são ilustrativos — troque pelos valores da nota fiscal e do rótulo.']])
    .setFontColor(SEC).setFontStyle('italic').setFontSize(9);
}

// ============================================================================
//  RENDIMENTO
// ============================================================================
function abaRendimento(ss) {
  var sh = nova(ss, 'RENDIMENTO', REN_NL, 15);
  cabecalho(sh, 'RENDIMENTO REAL DAS EMBALAGENS',
    'Uma linha por embalagem aberta. Responde: até quando ela deveria render, até quando rendeu de verdade e por quê.',
    ['Nº','PRODUTO','DATA DA COMPRA','NF / PEDIDO','PREÇO PAGO (R$)','DATA DE ABERTURA',
     'DURAÇÃO PREVISTA (dias)','DEVE RENDER ATÉ','DATA REAL DE TÉRMINO','DIAS QUE RENDEU',
     'DESVIO (dias)','RENDIMENTO','SITUAÇÃO','CAUSA PROVÁVEL / OBSERVAÇÃO','ordem'],
    [45,200,95,100,95,95,105,105,105,90,90,85,220,320,50], REN_NL);

  sh.getRange('A4:A' + REN_NL).setFormula('=IF($B4="","",TEXT(ROW()-3,"000"))');
  sh.getRange('G4:G' + REN_NL).setFormula(
    '=IFERROR(INDEX(PRODUTOS!$L$4:$L$' + PROD_NL + ',MATCH($B4,PRODUTOS!$A$4:$A$' + PROD_NL + ',0)),"")').setNumberFormat('#,##0.0');
  sh.getRange('H4:H' + REN_NL).setFormula('=IF(OR($F4="",N($G4)=0),"",$F4+ROUND($G4,0))').setNumberFormat('dd/mm/yyyy');
  sh.getRange('J4:J' + REN_NL).setFormula('=IF(OR($F4="",$I4=""),"",$I4-$F4)').setNumberFormat('#,##0');
  sh.getRange('K4:K' + REN_NL).setFormula('=IF(OR($J4="",N($G4)=0),"",$J4-$G4)').setNumberFormat('#,##0.0');
  sh.getRange('L4:L' + REN_NL).setFormula('=IFERROR($J4/$G4,"")').setNumberFormat('0%');
  sh.getRange('M4:M' + REN_NL).setFormula(
    '=IF($B4="","",IF($I4="",IF(AND($H4<>"",TODAY()>$H4),"Passou do prazo — ainda em uso","Em uso"),' +
    'IF($L4>=1.1,"Rendeu mais que o previsto",IF($L4>=0.9,"Dentro do previsto",' +
    'IF($L4>=0.75,"Rendeu abaixo","Muito abaixo — verificar diluição")))))');
  sh.getRange('O4:O' + REN_NL).setFormula(
    '=IF(OR($B4="",$I4<>"",$H4=""),"",COUNTIFS($H$4:$H$' + REN_NL + ',"<"&$H4,$I$4:$I$' + REN_NL + ',"",$B$4:$B$' + REN_NL + ',"<>")' +
    '+COUNTIFS($H$4:$H4,$H4,$I$4:$I4,"",$B$4:$B4,"<>"))');
  sh.hideColumns(15);

  sh.getRange('C4:C' + REN_NL).setNumberFormat('dd/mm/yyyy');
  sh.getRange('F4:F' + REN_NL).setNumberFormat('dd/mm/yyyy');
  sh.getRange('I4:I' + REN_NL).setNumberFormat('dd/mm/yyyy');
  sh.getRange('E4:E' + REN_NL).setNumberFormat('R$ #,##0.00');
  [1,3,4,5,6,7,8,9,10,11,12].forEach(function (c) {
    sh.getRange(4, c, REN_NL - 3, 1).setHorizontalAlignment('center');
  });
  [7,8,10,11,12,13].forEach(function (c) { sh.getRange(4, c, REN_NL - 3, 1).setFontColor(AZUL); });
  sh.getRange(4, 12, REN_NL - 3, 2).setFontWeight('bold');
  listaRange(sh, 2, 4, REN_NL, ss.getSheetByName('PRODUTOS').getRange('A4:A' + PROD_NL));

  var m = sh.getRange(4, 13, REN_NL - 3, 1);
  regra(sh, m, '=$M4="Dentro do previsto"', BOMC, BOM, true);
  regra(sh, m, '=$M4="Rendeu mais que o previsto"', BOMC, BOM, true);
  regra(sh, m, '=$M4="Rendeu abaixo"', ATENC, ATEN, true);
  regra(sh, m, '=$M4="Muito abaixo — verificar diluição"', CRITC, CRIT, true);
  regra(sh, m, '=$M4="Passou do prazo — ainda em uso"', AZULC, AZUL, true);
  var l = sh.getRange(4, 12, REN_NL - 3, 1);
  regra(sh, l, '=AND(ISNUMBER($L4),$L4<0.9)', CRITC, CRIT, true);
  regra(sh, l, '=AND(ISNUMBER($L4),$L4>=0.9)', BOMC, BOM, true);

  sh.getRange(4, 2, 3, 5).setValues([
    ['Desinfetante quaternário', new Date(2026,7,20), 'NF 10421', 68.00, new Date(2026,7,22)],
    ['Detergente neutro',        new Date(2026,8,2),  'NF 10520', 42.90, new Date(2026,8,3)],
    ['Desengraxante alcalino',   new Date(2026,8,5),  'NF 10533', 79.00, new Date(2026,8,6)]]);
  sh.getRange(4, 9).setValue(new Date(2026,7,24));
  sh.getRange(4, 14).setValue('Diluição feita no olho no turno B — reforçado no treinamento');
  for (var i = 4; i <= 6; i++) exemplo(sh, i, 14);
}

// ============================================================================
//  COMPRAS
// ============================================================================
function abaCompras(ss) {
  var sh = nova(ss, 'COMPRAS', NL, 8);
  cabecalho(sh, 'COMPRAS DE PRODUTOS E INSUMOS',
    'Toda entrada de material. É daqui que sai o custo do mês no painel.',
    ['DATA','PRODUTO / INSUMO','QUANTIDADE (embalagens)','PREÇO UNITÁRIO','TOTAL','FORNECEDOR','NF / PEDIDO','OBSERVAÇÃO'],
    [90,250,120,105,105,190,105,300], NL);
  sh.getRange('E4:E' + NL).setFormula('=IF(N($C4)=0,"",$C4*$D4)').setNumberFormat('R$ #,##0.00');
  sh.getRange('D4:D' + NL).setNumberFormat('R$ #,##0.00');
  sh.getRange('A4:A' + NL).setNumberFormat('dd/mm/yyyy');
  [1,3,4,5].forEach(function (c) { sh.getRange(4, c, NL - 3, 1).setHorizontalAlignment('center'); });
  sh.getRange(4, 1, 4, 4).setValues([
    [new Date(2026,7,20),'Desinfetante quaternário',4,68.00],
    [new Date(2026,8,2), 'Detergente neutro',6,42.90],
    [new Date(2026,8,5), 'Desengraxante alcalino',2,79.00],
    [new Date(2026,8,5), 'Papel toalha (pacote)',30,7.40]]);
  sh.getRange(4, 6, 4, 3).setValues([
    ['Fornecedor A','NF 10421','Reposição mensal'],
    ['Fornecedor A','NF 10520','Reposição mensal'],
    ['Fornecedor B','NF 10533','Docas e área de manutenção'],
    ['Fornecedor B','NF 10533','Sanitários e vestiários']]);
  for (var i = 4; i <= 7; i++) exemplo(sh, i, 8);
}

// ============================================================================
//  CALC — apoio dos gráficos
// ============================================================================
function abaCalc(ss) {
  var sh = nova(ss, 'CALC', 20, 12);
  sh.getRange('A1:L1').setValues([['Zona','NC abertas','','Criticidade','NC abertas','','Produto',
    'Custo mensal previsto','','Produto','Dias previstos','Dias que rendeu']])
    .setFontWeight('bold').setFontColor(AZUL).setFontFamily(FONTE);
  for (var i = 0; i < 10; i++) {
    var r = 2 + i;
    sh.getRange(r, 1).setFormula('=CADASTROS!A' + (4 + i) + '&" — "&CADASTROS!B' + (4 + i));
    sh.getRange(r, 2).setFormula('=COUNTIFS(' + NC + '!$F$4:$F$' + NL + ',CADASTROS!A' + (4 + i) +
      ',' + NC + '!$M$4:$M$' + NL + ',"<>Concluída",' + NC + '!$M$4:$M$' + NL + ',"<>Cancelada",' +
      NC + '!$H$4:$H$' + NL + ',"<>")');
  }
  for (var j = 0; j < 3; j++) {
    var rr = 2 + j;
    sh.getRange(rr, 4).setValue(CRITS[j]);
    sh.getRange(rr, 5).setFormula('=COUNTIFS(' + NC + '!$I$4:$I$' + NL + ',D' + rr +
      ',' + NC + '!$M$4:$M$' + NL + ',"<>Concluída",' + NC + '!$M$4:$M$' + NL + ',"<>Cancelada")');
  }
  for (var k = 0; k < 8; k++) {
    var r3 = 2 + k, pr = 4 + k;
    sh.getRange(r3, 7).setFormula('=IF(PRODUTOS!A' + pr + '="","",PRODUTOS!A' + pr + ')');
    sh.getRange(r3, 8).setFormula('=IFERROR(PRODUTOS!N' + pr + ',0)');
    sh.getRange(r3, 10).setFormula('=IF(PRODUTOS!A' + pr + '="","",PRODUTOS!A' + pr + ')');
    sh.getRange(r3, 11).setFormula('=IFERROR(ROUND(AVERAGEIFS(RENDIMENTO!$G$4:$G$' + REN_NL +
      ',RENDIMENTO!$B$4:$B$' + REN_NL + ',$J' + r3 + ',RENDIMENTO!$J$4:$J$' + REN_NL + ',"<>"),1),0)');
    sh.getRange(r3, 12).setFormula('=IFERROR(ROUND(AVERAGEIFS(RENDIMENTO!$J$4:$J$' + REN_NL +
      ',RENDIMENTO!$B$4:$B$' + REN_NL + ',$J' + r3 + '),1),0)');
  }
  sh.getRange('A14').setValue('Aba de apoio dos gráficos do painel. Não digite nada aqui.')
    .setFontColor(MUT).setFontStyle('italic').setFontSize(9);
}

// ============================================================================
//  PAINEL
// ============================================================================
function abaPainel(ss) {
  var sh = nova(ss, 'PAINEL', 70, 14);
  var larg = [24,110,80,70,180,130,130,130,130,95,150,110,120,24];
  for (var i = 0; i < larg.length; i++) sh.setColumnWidth(i + 1, larg[i]);

  sh.getRange('B2:M2').merge().setValue('PAINEL DA LIMPEZA E CONSERVAÇÃO — CD FEIRA DE SANTANA')
    .setBackground(AZUL).setFontColor(BRANCO).setFontFamily(FONTE).setFontSize(15)
    .setFontWeight('bold').setHorizontalAlignment('center').setVerticalAlignment('middle');
  sh.setRowHeight(2, 40);

  sh.getRange('B4:C4').merge().setValue('MÊS DE REFERÊNCIA')
    .setFontWeight('bold').setFontFamily(FONTE).setFontSize(10).setVerticalAlignment('middle');
  sh.getRange('D4:E4').merge().setValue(new Date())
    .setNumberFormat('mm/yyyy').setBackground(AMARC).setFontWeight('bold').setFontSize(12)
    .setFontFamily(FONTE).setHorizontalAlignment('center')
    .setBorder(true, true, true, true, false, false, AMAR, SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
  sh.getRange('G4').setValue('digite qualquer data do mês que quer analisar')
    .setFontColor(MUT).setFontStyle('italic').setFontSize(9);

  var INI = '">="&EOMONTH($D$4,-1)+1', FIM = '"<="&EOMONTH($D$4,0)';
  var cards = [
    [2, 'NC EM ABERTO',
     '=COUNTIFS(' + NC + '!$H$4:$H$' + NL + ',"<>",' + NC + '!$M$4:$M$' + NL + ',"<>Concluída",' + NC + '!$M$4:$M$' + NL + ',"<>Cancelada")',
     'acompanhar a tendência', '0', AZUL],
    [4, 'NC ATRASADAS',
     '=SUMPRODUCT((' + NC + '!$H$4:$H$' + NL + '<>"")*(' + NC + '!$L$4:$L$' + NL + '<>"")*(' + NC + '!$L$4:$L$' + NL + '<TODAY())*(' +
     NC + '!$M$4:$M$' + NL + '<>"Concluída")*(' + NC + '!$M$4:$M$' + NL + '<>"Cancelada"))',
     'meta: zero', '0', CRIT],
    [6, 'NC DE CRITICIDADE ALTA',
     '=COUNTIFS(' + NC + '!$I$4:$I$' + NL + ',"Alta",' + NC + '!$M$4:$M$' + NL + ',"<>Concluída",' + NC + '!$M$4:$M$' + NL + ',"<>Cancelada")',
     'correção imediata', '0', CRIT],
    [8, 'ENTREGA DAS FOLHAS',
     '=IFERROR(SUMIFS(' + RT + '!$D$4:$D$' + NL + ',' + RT + '!$A$4:$A$' + NL + ',' + INI + ',' + RT + '!$A$4:$A$' + NL + ',' + FIM + ')' +
     '/SUMIFS(' + RT + '!$C$4:$C$' + NL + ',' + RT + '!$A$4:$A$' + NL + ',' + INI + ',' + RT + '!$A$4:$A$' + NL + ',' + FIM + '),"—")',
     'meta: 95%', '0%', AZUL],
    [10, 'NOTA MÉDIA DA RONDA',
     '=IFERROR(AVERAGEIFS(' + RT + '!$F$4:$F$' + NL + ',' + RT + '!$A$4:$A$' + NL + ',' + INI + ',' + RT + '!$A$4:$A$' + NL + ',' + FIM + '),"—")',
     'meta: 90 pontos', '0.0', AZUL],
    [12, 'COMPRAS DO MÊS',
     '=SUMIFS(COMPRAS!$E$4:$E$' + NL + ',COMPRAS!$A$4:$A$' + NL + ',' + INI + ',COMPRAS!$A$4:$A$' + NL + ',' + FIM + ')',
     'produtos e insumos', 'R$ #,##0', AZUL]
  ];
  cards.forEach(function (c) {
    var col = c[0];
    sh.getRange(6, col, 3, 2).setBackground(PAPEL)
      .setBorder(true, true, true, true, false, false, LINHA, SpreadsheetApp.BorderStyle.SOLID);
    sh.getRange(6, col, 1, 2).merge().setValue(c[1]).setFontFamily(FONTE)
      .setFontSize(9).setFontWeight('bold').setFontColor(SEC)
      .setHorizontalAlignment('center').setVerticalAlignment('middle');
    sh.getRange(7, col, 1, 2).merge().setFormula(c[2]).setNumberFormat(c[4])
      .setFontFamily(FONTE).setFontSize(24).setFontWeight('bold').setFontColor(c[5])
      .setHorizontalAlignment('center').setVerticalAlignment('middle');
    sh.getRange(8, col, 1, 2).merge().setValue(c[3]).setFontFamily(FONTE)
      .setFontSize(9).setFontColor(MUT).setHorizontalAlignment('center').setVerticalAlignment('middle');
  });
  sh.setRowHeight(6, 24); sh.setRowHeight(7, 46); sh.setRowHeight(8, 20);

  secao(sh, 10, 'NÃO CONFORMIDADES — ONDE ESTÃO E QUÃO GRAVES');
  secao(sh, 29, 'AS 8 AÇÕES QUE VENCEM PRIMEIRO');
  secao(sh, 40, 'CUSTO E RENDIMENTO DOS PRODUTOS');
  secao(sh, 59, 'PRODUTOS ABERTOS — QUANDO DEVEM ACABAR');

  // tabela de ações
  var spans = [[2,2,'PRAZO','L'],[3,3,'CRIT.','I'],[4,4,'ZONA','F'],[5,5,'LOCAL','G'],
               [6,8,'O QUE FOI ENCONTRADO','H'],[9,10,'AÇÃO DEFINIDA','J'],
               [11,11,'RESPONSÁVEL','K'],[12,13,'STATUS','M']];
  cabecTabela(sh, 30, spans);
  for (var i = 0; i < 8; i++) {
    var r = 31 + i, k = i + 1;
    spans.forEach(function (sp) {
      if (sp[1] > sp[0]) sh.getRange(r, sp[0], 1, sp[1] - sp[0] + 1).merge();
      sh.getRange(r, sp[0]).setFormula('=IFERROR(INDEX(' + NC + '!$' + sp[3] + '$4:$' + sp[3] + '$' + NL +
        ',MATCH(' + k + ',' + NC + '!$R$4:$R$' + NL + ',0)),"")')
        .setFontFamily(FONTE).setFontSize(9.5).setWrap(sp[0] === 6 || sp[0] === 9)
        .setHorizontalAlignment((sp[0] === 2 || sp[0] === 3 || sp[0] === 4 || sp[0] === 12) ? 'center' : 'left')
        .setVerticalAlignment('middle');
      sh.getRange(r, sp[0], 1, sp[1] - sp[0] + 1)
        .setBorder(true, true, true, true, false, false, LINHA, SpreadsheetApp.BorderStyle.SOLID);
    });
    sh.getRange(r, 2).setNumberFormat('dd/mm/yyyy');
    sh.setRowHeight(r, 34);
  }
  regra(sh, sh.getRange('C31:C38'), '=$C31="Alta"', CRITC, CRIT, true);
  regra(sh, sh.getRange('C31:C38'), '=$C31="Média"', ATENC, ATEN, true);
  regra(sh, sh.getRange('C31:C38'), '=$C31="Baixa"', BOMC, BOM, true);
  regra(sh, sh.getRange('B31:B38'), '=AND(ISNUMBER($B31),$B31<TODAY())', CRITC, CRIT, true);

  // tabela de produtos abertos
  var sp2 = [[2,4,'PRODUTO','B'],[5,5,'DEVE RENDER ATÉ','H'],[6,7,'DIAS RESTANTES',''],[8,13,'SITUAÇÃO','M']];
  cabecTabela(sh, 60, sp2);
  for (var j = 0; j < 6; j++) {
    var r2 = 61 + j, k2 = j + 1;
    sp2.forEach(function (sp) {
      if (sp[1] > sp[0]) sh.getRange(r2, sp[0], 1, sp[1] - sp[0] + 1).merge();
      var f = (sp[0] === 6)
        ? '=IF($E' + r2 + '="","",$E' + r2 + '-TODAY())'
        : '=IFERROR(INDEX(RENDIMENTO!$' + sp[3] + '$4:$' + sp[3] + '$' + REN_NL +
          ',MATCH(' + k2 + ',RENDIMENTO!$O$4:$O$' + REN_NL + ',0)),"")';
      sh.getRange(r2, sp[0]).setFormula(f).setFontFamily(FONTE).setFontSize(9.5)
        .setHorizontalAlignment(sp[0] === 2 ? 'left' : 'center').setVerticalAlignment('middle');
      sh.getRange(r2, sp[0], 1, sp[1] - sp[0] + 1)
        .setBorder(true, true, true, true, false, false, LINHA, SpreadsheetApp.BorderStyle.SOLID);
    });
    sh.getRange(r2, 5).setNumberFormat('dd/mm/yyyy');
    sh.getRange(r2, 6).setNumberFormat('#,##0');
    sh.setRowHeight(r2, 26);
  }
  regra(sh, sh.getRange('F61:G66'), '=AND(ISNUMBER($F61),$F61<=3)', CRITC, CRIT, true);
  regra(sh, sh.getRange('F61:G66'), '=AND(ISNUMBER($F61),$F61>3,$F61<=7)', ATENC, ATEN, true);
  regra(sh, sh.getRange('F61:G66'), '=AND(ISNUMBER($F61),$F61>7)', BOMC, BOM, true);

  sh.getRange('B68').setValue('Todos os números deste painel vêm das abas NÃO CONFORMIDADES, REGISTROS, RESUMO TURNOS, PRODUTOS, RENDIMENTO e COMPRAS. Não digite nada aqui além do mês de referência.')
    .setFontColor(SEC).setFontStyle('italic').setFontSize(9);

  graficos(ss, sh);
}

function secao(sh, row, titulo) {
  sh.getRange(row, 2, 1, 12).merge().setValue(titulo)
    .setBackground(AZULE).setFontColor(BRANCO).setFontFamily(FONTE)
    .setFontSize(11).setFontWeight('bold').setVerticalAlignment('middle');
  sh.setRowHeight(row, 28);
}
function cabecTabela(sh, row, spans) {
  spans.forEach(function (sp) {
    if (sp[1] > sp[0]) sh.getRange(row, sp[0], 1, sp[1] - sp[0] + 1).merge();
    sh.getRange(row, sp[0]).setValue(sp[2]);
    sh.getRange(row, sp[0], 1, sp[1] - sp[0] + 1).setBackground(PAPEL)
      .setFontColor(AZUL).setFontWeight('bold').setFontFamily(FONTE).setFontSize(9)
      .setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(true)
      .setBorder(null, null, true, null, null, null, AZUL, SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
  });
  sh.setRowHeight(row, 28);
}

function graficos(ss, sh) {
  var calc = ss.getSheetByName('CALC');
  sh.getCharts().forEach(function (c) { sh.removeChart(c); });

  var g1 = sh.newChart().asBarChart()
    .addRange(calc.getRange('A1:B11'))
    .setNumHeaders(1)
    .setOption('title', 'NC em aberto por zona')
    .setOption('titleTextStyle', { fontName: FONTE, fontSize: 13, bold: true, color: TXT })
    .setOption('colors', [AZUL])
    .setOption('legend', { position: 'none' })
    .setOption('hAxis', { textStyle: { fontName: FONTE, fontSize: 10 }, gridlines: { count: 0 } })
    .setOption('vAxis', { textStyle: { fontName: FONTE, fontSize: 10 } })
    .setOption('backgroundColor', BRANCO)
    .setOption('width', 560).setOption('height', 300)
    .setPosition(12, 2, 0, 0).build();
  sh.insertChart(g1);

  var g2 = sh.newChart().asColumnChart()
    .addRange(calc.getRange('D1:E4'))
    .setNumHeaders(1)
    .setOption('title', 'NC em aberto por criticidade')
    .setOption('titleTextStyle', { fontName: FONTE, fontSize: 13, bold: true, color: TXT })
    .setOption('colors', [AZUL])
    .setOption('series', { 0: { color: AZUL } })
    .setOption('legend', { position: 'none' })
    .setOption('hAxis', { textStyle: { fontName: FONTE, fontSize: 10 } })
    .setOption('vAxis', { textStyle: { fontName: FONTE, fontSize: 10 }, format: '0' })
    .setOption('backgroundColor', BRANCO)
    .setOption('width', 560).setOption('height', 300)
    .setPosition(12, 8, 0, 0).build();
  sh.insertChart(g2);

  var g3 = sh.newChart().asBarChart()
    .addRange(calc.getRange('G1:H9'))
    .setNumHeaders(1)
    .setOption('title', 'Custo mensal previsto por produto (R$)')
    .setOption('titleTextStyle', { fontName: FONTE, fontSize: 13, bold: true, color: TXT })
    .setOption('colors', [AZUL])
    .setOption('legend', { position: 'none' })
    .setOption('hAxis', { textStyle: { fontName: FONTE, fontSize: 10 } })
    .setOption('vAxis', { textStyle: { fontName: FONTE, fontSize: 10 } })
    .setOption('backgroundColor', BRANCO)
    .setOption('width', 560).setOption('height', 300)
    .setPosition(42, 2, 0, 0).build();
  sh.insertChart(g3);

  var g4 = sh.newChart().asColumnChart()
    .addRange(calc.getRange('J1:L9'))
    .setNumHeaders(1)
    .setOption('title', 'Dias que a embalagem deveria render x rendeu')
    .setOption('titleTextStyle', { fontName: FONTE, fontSize: 13, bold: true, color: TXT })
    .setOption('colors', [AZUL, VERDE])
    .setOption('legend', { position: 'bottom', textStyle: { fontName: FONTE, fontSize: 10 } })
    .setOption('hAxis', { textStyle: { fontName: FONTE, fontSize: 9 } })
    .setOption('vAxis', { textStyle: { fontName: FONTE, fontSize: 10 }, format: '0' })
    .setOption('backgroundColor', BRANCO)
    .setOption('width', 560).setOption('height', 300)
    .setPosition(42, 8, 0, 0).build();
  sh.insertChart(g4);
}

// ============================================================================
//  INÍCIO
// ============================================================================
function abaInicio(ss) {
  var sh = nova(ss, 'INÍCIO', 40, 4);
  sh.setColumnWidth(1, 24); sh.setColumnWidth(2, 260); sh.setColumnWidth(3, 700); sh.setColumnWidth(4, 24);
  sh.getRange('B2:C2').merge().setValue('GESTÃO DA LIMPEZA E CONSERVAÇÃO')
    .setBackground(AZUL).setFontColor(BRANCO).setFontFamily(FONTE).setFontSize(16)
    .setFontWeight('bold').setVerticalAlignment('middle');
  sh.setRowHeight(2, 38);
  sh.getRange('B3:C3').merge()
    .setValue('CD Bartofil Feira de Santana  •  anexo N do POP-LIM-001  •  esta planilha é um RESUMO, não uma cópia dos formulários')
    .setBackground(AZULE).setFontColor('#BBD3F0').setFontFamily(FONTE).setFontSize(9.5)
    .setVerticalAlignment('middle');
  sh.setRowHeight(3, 22);

  var linhas = [
    ['A REGRA DE OURO DESTA PLANILHA',''],
    ['O que NÃO entra aqui','Item conforme. Se o checklist do setor voltou todo certo, nada precisa ser digitado além do resumo do turno.'],
    ['O que entra aqui','Só o que saiu NÃO CONFORME, o que virou ação, o que precisa ficar registrado e o custo dos produtos.'],
    ['Por quê','O papel já é o registro detalhado. A planilha existe para responder: o que está pendente, o que é grave, quem resolve e quanto custa.'],
    ['',''],
    ['AS ABAS, NA ORDEM DE USO',''],
    ['PAINEL','Resumo de tudo. Só ajuste o mês de referência na célula D4 — o resto é calculado.'],
    ['NÃO CONFORMIDADES','Uma linha por item não conforme, com ação, responsável, prazo e status. A coluna REINCID. avisa quando o mesmo problema volta.'],
    ['REGISTROS','Derramamento, avaria, quase-acidente, visita, treinamento, elogio. O que aconteceu e precisa ficar guardado.'],
    ['RESUMO TURNOS','Uma linha por dia e turno: quantas folhas voltaram, a nota da ronda e o destaque. Leva 1 minuto por turno.'],
    ['PRODUTOS','Cadastro com o cálculo de rendimento: quanto rende a embalagem, quanto custa cada aplicação e quantos dias deve durar.'],
    ['RENDIMENTO','Uma linha por embalagem aberta: deve render até tal dia, rendeu até tal dia, e a causa quando rende menos.'],
    ['COMPRAS','Toda entrada de material. É daqui que sai o custo do mês.'],
    ['CADASTROS','As listas dos menus suspensos. Ajuste as zonas com as ruas reais do CD antes de começar.'],
    ['',''],
    ['COMO O CUSTO DO PRODUTO É CALCULADO',''],
    ['Você informa','Embalagem em ml, preço pago, diluição do rótulo (ml por litro de solução), litros de solução por aplicação e aplicações por dia.'],
    ['A planilha calcula','ml por aplicação, aplicações por embalagem, custo por aplicação, custo por litro de solução, duração prevista, custo por dia e custo mensal.'],
    ['Exemplo','5.000 ml de desinfetante, 25 ml por litro, 8 L por balde = 200 ml por aplicação → 25 aplicações por embalagem. A 9 aplicações por dia, dura 2,8 dias.'],
    ['O que isso revela','Se a embalagem acaba muito antes do previsto, alguém está usando acima da dose. A aba RENDIMENTO mostra isso em número, não em suposição.'],
    ['',''],
    ['ROTINA',''],
    ['Todo turno','Menu Gestão da Limpeza > Fechar o turno. E abra uma NC para cada item não conforme das folhas.'],
    ['Toda semana','Abra o PAINEL, olhe as 8 ações que vencem primeiro e cobre os responsáveis.'],
    ['Todo mês','Lance a auditoria de infraestrutura como NC, feche o mês em COMPRAS e apresente o PAINEL à gerência.'],
    ['Quando abrir uma embalagem','Menu Gestão da Limpeza > Abri uma embalagem nova. Quando ela acabar, preencha a data real de término.'],
    ['',''],
    ['ANTES DE COMEÇAR PARA VALER',''],
    ['Apague os exemplos','Menu Gestão da Limpeza > Apagar as linhas de exemplo.']
  ];
  sh.getRange(5, 2, linhas.length, 2).setValues(linhas)
    .setFontFamily(FONTE).setVerticalAlignment('middle').setWrap(true);
  for (var i = 0; i < linhas.length; i++) {
    var r = 5 + i;
    if (linhas[i][1] === '' && linhas[i][0] !== '') {
      sh.getRange(r, 2, 1, 2).setBackground(AZULC).setFontColor(AZUL).setFontWeight('bold').setFontSize(10.5);
      sh.setRowHeight(r, 26);
    } else if (linhas[i][0] !== '') {
      sh.getRange(r, 2).setFontWeight('bold').setFontColor(TXT);
      sh.getRange(r, 2, 1, 2).setFontSize(10)
        .setBorder(null, null, true, null, null, null, LINHA, SpreadsheetApp.BorderStyle.SOLID);
      sh.setRowHeight(r, 32);
    }
  }
}

// ============================================================================
//  AÇÕES DO MENU
// ============================================================================
function irPainel() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ss.setActiveSheet(ss.getSheetByName('PAINEL'));
  SpreadsheetApp.flush();
  ss.toast('Painel atualizado.', 'Gestão da Limpeza', 4);
}
function primeiraLivre(sh, col) {
  var v = sh.getRange(4, col, sh.getMaxRows() - 3, 1).getValues();
  for (var i = 0; i < v.length; i++) if (v[i][0] === '' || v[i][0] === null) return 4 + i;
  return sh.getMaxRows();
}
function irPara(nome, colChave, colFoco) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(nome);
  ss.setActiveSheet(sh);
  var r = primeiraLivre(sh, colChave);
  sh.getRange(r, colFoco).setValue(new Date()).setNumberFormat('dd/mm/yyyy');
  sh.setActiveRange(sh.getRange(r, colFoco + 1));
  ss.toast('Linha ' + r + ' pronta. A data de hoje já foi preenchida.', nome, 5);
}
function novaNC()          { irPara('NÃO CONFORMIDADES', 8, 2); }
function novoRegistro()    { irPara('REGISTROS', 6, 1); }
function novoResumoTurno() { irPara('RESUMO TURNOS', 1, 1); }
function novaEmbalagem() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('RENDIMENTO');
  ss.setActiveSheet(sh);
  var r = primeiraLivre(sh, 2);
  sh.getRange(r, 6).setValue(new Date()).setNumberFormat('dd/mm/yyyy');
  sh.setActiveRange(sh.getRange(r, 2));
  ss.toast('Linha ' + r + ': escolha o produto. A data de abertura já é hoje.', 'RENDIMENTO', 5);
}
function filtrarAberto() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('NÃO CONFORMIDADES');
  ss.setActiveSheet(sh);
  var f = sh.getFilter(); if (f) f.remove();
  sh.getRange(3, 1, NL - 2, 17).createFilter()
    .setColumnFilterCriteria(13, SpreadsheetApp.newFilterCriteria()
      .setHiddenValues(['Concluída', 'Cancelada']).build());
  ss.toast('Mostrando apenas o que está em aberto.', 'Não conformidades', 4);
}
function limparFiltros() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ['NÃO CONFORMIDADES','REGISTROS','RESUMO TURNOS','RENDIMENTO','COMPRAS'].forEach(function (n) {
    var sh = ss.getSheetByName(n); if (!sh) return;
    var f = sh.getFilter(); if (f) f.remove();
  });
  ss.toast('Filtros removidos.', 'Gestão da Limpeza', 4);
}
function apagarExemplos() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var ui = SpreadsheetApp.getUi();
  var resp = ui.alert('Apagar exemplos',
    'Isso apaga as linhas de exemplo de NÃO CONFORMIDADES, REGISTROS, RESUMO TURNOS, RENDIMENTO e COMPRAS. Os produtos cadastrados ficam. Continuar?',
    ui.ButtonSet.YES_NO);
  if (resp !== ui.Button.YES) return;
  limpar(ss, 'NÃO CONFORMIDADES', 4, 7, [2,3,4,5,6,7,8,9,10,11,12,13,14,17]);
  limpar(ss, 'REGISTROS', 4, 4, [1,2,3,4,5,6,7,8,9,10,11]);
  limpar(ss, 'RESUMO TURNOS', 4, 4, [1,2,3,4,6,8,9]);
  limpar(ss, 'RENDIMENTO', 4, 6, [2,3,4,5,6,9,14]);
  limpar(ss, 'COMPRAS', 4, 7, [1,2,3,4,6,7,8]);
  ss.toast('Exemplos apagados. A planilha está pronta para uso real.', 'Gestão da Limpeza', 6);
}
function limpar(ss, nome, de, ate, colunas) {
  var sh = ss.getSheetByName(nome); if (!sh) return;
  colunas.forEach(function (c) { sh.getRange(de, c, ate - de + 1, 1).clearContent(); });
  sh.getRange(de, 1, ate - de + 1, sh.getMaxColumns())
    .setFontColor(TXT).setFontStyle('normal');
}
function enviarResumo() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var ui = SpreadsheetApp.getUi();
  var p = ss.getSheetByName('PAINEL');
  var r = ui.prompt('Resumo do mês', 'E-mail do destinatário:', ui.ButtonSet.OK_CANCEL);
  if (r.getSelectedButton() !== ui.Button.OK) return;
  var email = r.getResponseText().trim();
  if (!email) { ui.alert('Informe um e-mail.'); return; }
  var mes = p.getRange('D4').getDisplayValue();
  var html = '<div style="font-family:Arial,sans-serif;color:#1F2937">' +
    '<h2 style="color:#0B4EA2;margin:0 0 4px">Limpeza e Conservação — CD Feira de Santana</h2>' +
    '<p style="margin:0 0 16px;color:#6B7A8F">Resumo de ' + mes + '</p>' +
    '<table cellpadding="8" cellspacing="0" style="border-collapse:collapse;font-size:14px">' +
    linhaEmail('NC em aberto', p.getRange('B7').getDisplayValue(), '') +
    linhaEmail('NC atrasadas', p.getRange('D7').getDisplayValue(), 'meta: zero') +
    linhaEmail('NC de criticidade alta', p.getRange('F7').getDisplayValue(), 'correção imediata') +
    linhaEmail('Entrega das folhas', p.getRange('H7').getDisplayValue(), 'meta: 95%') +
    linhaEmail('Nota média da ronda', p.getRange('J7').getDisplayValue(), 'meta: 90 pontos') +
    linhaEmail('Compras do mês', p.getRange('L7').getDisplayValue(), '') +
    '</table>' +
    '<p style="margin-top:18px"><a href="' + ss.getUrl() + '" style="color:#0B4EA2">Abrir a planilha completa</a></p></div>';
  MailApp.sendEmail({ to: email, subject: 'Limpeza CD — resumo de ' + mes, htmlBody: html });
  ui.alert('Resumo enviado para ' + email + '.');
}
function linhaEmail(rotulo, valor, meta) {
  return '<tr><td style="border-bottom:1px solid #E6ECF3">' + rotulo + '</td>' +
    '<td style="border-bottom:1px solid #E6ECF3;font-weight:bold;color:#0B4EA2;font-size:18px">' + valor + '</td>' +
    '<td style="border-bottom:1px solid #E6ECF3;color:#9AA7B8">' + meta + '</td></tr>';
}
