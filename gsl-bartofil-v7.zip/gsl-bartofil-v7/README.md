# GSL Bartofil — v7

CD Feira de Santana · Turnos A / B / C

O projeto passa a ter **duas planilhas**, com papéis separados.

| | **GSL — Calendário (v5)** | **GSL-DADOS (v7)** |
|---|---|---|
| Para quê | Atividades, prazos, entregas, reunião de sexta | Base de dados do BI |
| Estrutura | permanece exatamente como está | nova, gerada por script |
| Quem abre | coordenadores e gerente | administrador, gerente e RH |
| Alimentada por | coordenadores, como hoje | ETL das 3 planilhas da empresa |
| Consumida por | quem trabalha no CD | Looker Studio |

```
Planilha do RH ┐
Planilha erros ├─► GSL-DADOS (restrita) ─┬─► Looker Studio · gerência
Planilha metas ┘   de-para + FATOS       └─► (opcional) totais no calendário
```

## O que há no pacote

| Caminho | O que é |
|---|---|
| `GSL-DADOS-v7.xlsx` | A planilha restrita — subir no Drive e salvar como Planilhas Google |
| `build/gerar_gsl_dados.py` | Gerador da planilha — fonte da verdade da estrutura |
| `apps-script/dados/src/*.gs` | O ETL: leitura, tradução, fatos e publicação |
| `apps-script/gsl/src/Code.gs` | O script do calendário, **inalterado** (v6) |
| `apps-script/gsl/src/CorrigirPlacar.gs` | Correção do placar da aba SCORE — rodar uma vez |
| `docs/ARQUITETURA-DADOS.md` | O porquê de cada decisão |
| `docs/RUNBOOK.md` | Como instalar, operar e consertar |

## As três garantias do desenho

1. **Nenhum dado individual chega aos coordenadores.** A publicação é empurrada
   pelo script com a conta do administrador; o calendário não conhece o ID da
   base restrita e não tem `IMPORTRANGE` para ela.
2. **Mudança de layout na origem não corrompe número.** As colunas são achadas
   pelo nome do cabeçalho; coluna obrigatória ausente aborta aquela fonte e
   avisa por e-mail, sem gravar nada pela metade.
3. **Nada é adivinhado.** Nome parecido vira sugestão na fila de pendências,
   nunca um lançamento automático.

## Correção do placar (aba SCORE do calendário)

O score contava como "programada" toda atividade da aba do mês, inclusive as
ainda **pendentes**. Resultado: aprovação `0 ÷ N`, pontualidade e absenteísmo
cheios, e todo mês de todo turno fechando em **60,0** — inclusive meses que nem
começaram. Empatados, os três ganhavam 🥇 e o líder era sempre "Turno A", por ser
o primeiro `IF` da fórmula.

`CorrigirPlacar.gs` passa a medir só o que **já venceu** (Aprovada + Entregue +
Atrasada + Reprovada). Verificado com dados simulados:

| Situação | Score |
|---|---|
| Entregou e foi aprovado, sem faltas | 100 🥇 |
| Aprovado, mas 6 faltas (meta 12) | 85 🥈 |
| Reprovado | 60 🥉 |
| Mês que ainda não venceu nada | em branco |

Empate agora aparece como "Empate técnico", e no início do mês o painel mostra o
último mês fechado, dizendo qual é.

## Instalação

Passo a passo em `docs/RUNBOOK.md`.

## Estado

| Fase | Situação |
|---|---|
| F1 · GSL-DADOS + de-para | pronto |
| F2 · ETL do RH | pronto — falta o de-para real e a validação de 30 dias |
| F3 · erros e metas | pronto — mesma pendência |
| F4 · publicação no calendário | pronto, aguardando decisão (seção 6 da arquitetura) |
| F5 · Looker Studio | a fazer |
| F6 · servidor Bartofil | a fazer |

Paleta oficial Bartofil: azul `#111785` · verde `#01973A` · amarelo `#FFEE03`.
